from __future__ import annotations

import hashlib
import tempfile
from pathlib import Path

from noeron.cognition.models import NativeProposition, NativeThought, NativeThoughtKind, NativeUtterance
from noeron.english_egress import ENGLISH_EGRESS_VERSION, realize_native_thought
from noeron.inference import infer, parse_surface_logic_detailed
from noeron.language_dialogue import (
    CONVERSATION_VERSION,
    DIALOGUE_VERSION,
    PRODUCTIVE_ENGLISH_VERSION,
    SPEECH_ACT_AFFORDANCES,
    analyze_dialogue_structure,
    lemma,
)
from noeron.llm import MockLanguageEngine
from noeron.memory import LocalEventStore
from noeron.models import CognitiveEvent, EventKind
from noeron.orchestrator import Noeron

ROOT = Path(__file__).resolve().parents[1]
checks: list[tuple[str, bool]] = []


def check(name: str, ok: object) -> None:
    value = bool(ok)
    checks.append((name, value))
    print(f"{len(checks):03d}. {'PASS' if value else 'FAIL'}: {name}")


def owner_event(text: str, **metadata: object) -> CognitiveEvent:
    m = {"owner_authenticated": True, "owner_device_id": "authority-audit-device"}
    m.update(metadata)
    return CognitiveEvent(kind=EventKind.USER_MESSAGE, source="authenticated-owner", content=text, trusted=True, metadata=m)


# Static authority surfaces -------------------------------------------------
dialogue_src = (ROOT / "src/noeron/language_dialogue.py").read_text(encoding="utf-8")
egress_src = (ROOT / "src/noeron/english_egress.py").read_text(encoding="utf-8")
orch_src = (ROOT / "src/noeron/orchestrator.py").read_text(encoding="utf-8")
api_src = (ROOT / "src/noeron/api.py").read_text(encoding="utf-8")
models_src = (ROOT / "src/noeron/cognition/models.py").read_text(encoding="utf-8")
composition_src = (ROOT / "src/noeron/language_composition.py").read_text(encoding="utf-8")
engineering_src = (ROOT / "src/noeron/engineering.py").read_text(encoding="utf-8")

check("dialogue substrate has no LLM import", "noeron.llm" not in dialogue_src and "openai" not in dialogue_src.lower())
check("dialogue substrate has no network client", all(x not in dialogue_src for x in ("requests", "httpx", "urllib", "socket")))
check("dialogue substrate has no shell execution", "subprocess" not in dialogue_src and "os.system" not in dialogue_src)
check("English egress has no LLM import", "noeron.llm" not in egress_src and "openai" not in egress_src.lower())
check("English egress has no network client", all(x not in egress_src for x in ("requests", "httpx", "urllib", "socket")))
check("English egress has no shell execution", "subprocess" not in egress_src and "os.system" not in egress_src)
check("productive conversation mechanism version explicit", CONVERSATION_VERSION == "0.8.2-stage8B-native-conversation-v1")
check("dialogue mechanism version explicit", DIALOGUE_VERSION == "0.8.2-stage8B-dialogue-v1")
check("productive English mechanism version explicit", PRODUCTIVE_ENGLISH_VERSION == "0.8.2-stage8B-productive-english-v1")
check("English egress mechanism version explicit", ENGLISH_EGRESS_VERSION == "0.8.2-stage8B-english-egress-v1")
check("v0.8.1 composition mechanism preserved", "0.8.1-stage8B-composition-v1" in composition_src)
check("Stage8A engineering mechanism preserved", "0.8.0-stage8A-engineering-source-perception-v1" in engineering_src)
check("Stage8A source write authority remains false", "write_authority" in engineering_src and "False" in engineering_src)
check("Stage8A deployment authority remains false", "deployment_authority" in engineering_src and "False" in engineering_src)

# Productive structural ingress --------------------------------------------
probe = analyze_dialogue_structure(
    "If Mira may not place the book beside the lamp, then Omar might ask why it moved because the shelf changed."
)
check("dialogue structural semantic truth authority false", probe["semantic_truth_authority"] is False)
check("dialogue answer authority false", probe["answer_authority"] is False)
check("dialogue cognitive-memory authority false", probe["cognitive_memory_authority"] is False)
check("dialogue relationship authority false", probe["relationship_authority"] is False)
check("dialogue Terra authority false", probe["terra_authority"] is False)
check("dialogue source-write authority false", probe["source_write_authority"] is False)
check("dialogue deployment authority false", probe["deployment_authority"] is False)
check("dialogue initiative authority false", probe["initiative_authority"] is False)
check("speech-act affordances have zero selection authority", probe["speech_act_selection_authority"] is False)
check("all required speech-act affordances exposed", set(SPEECH_ACT_AFFORDANCES) == {"assert","answer","ask","clarify","correct","contrast","explain","hypothesize","acknowledge","defer","refuse","remain-silent"})
check("transparent morphology handles present agreement", lemma("contains") == "contain" and lemma("supports") == "support")
check("why question recognized productively", analyze_dialogue_structure("Why did Mira leave?")["question_families"] == ["why-question"])
check("how question recognized productively", analyze_dialogue_structure("How did Mira leave?")["question_families"] == ["how-question"])
check("when question recognized productively", analyze_dialogue_structure("When did Mira leave?")["question_families"] == ["when-question"])
check("where question recognized productively", analyze_dialogue_structure("Where did Mira leave from?")["question_families"] == ["where-question"])
check("who question recognized productively", analyze_dialogue_structure("Who moved the book?")["question_families"] == ["who-question"])
check("which question recognized productively", analyze_dialogue_structure("Which book moved?")["question_families"] == ["which-question"])
check("what question recognized productively", analyze_dialogue_structure("What moved?")["question_families"] == ["what-question"])
check("yes-no question recognized productively", analyze_dialogue_structure("Does Mira contain copper?")["question_families"] == ["yes-no-question"])
check("passive event candidates preserve candidate-only authority", all(x["authority"] == "candidate-only" for x in analyze_dialogue_structure("The book was placed by Mira.")["event_candidates"]))
check("event roles include agent/patient for passive candidate", any(x.get("roles",{}).get("agent") == "mira" and x.get("roles",{}).get("patient") == "book" for x in analyze_dialogue_structure("The book was placed by Mira.")["event_candidates"]))
check("structural ambiguity remains represented", bool(analyze_dialogue_structure("Mira saw the scholar with the telescope.")["ambiguities"]))
check("unknown vocabulary is represented as lexical gap", any(x["surface"] == "quorvex" for x in analyze_dialogue_structure("The quorvex supports the lamp.", lexicon={"lamp": object(), "supports": object()})["lexical_gaps"]))
check("deixis represented without semantic authority", any(x["surface"] == "this" for x in analyze_dialogue_structure("This changed now.")["deixis_candidates"]))
check("anaphora without sufficient antecedent remains unresolved", any(x["status"].startswith("unresolved") for x in analyze_dialogue_structure("It moved.")["reference_candidates"]))

# Proof-grounded question interface ----------------------------------------
props, q, _ = parse_surface_logic_detailed("Mira placed the book. Who placed the book?")
check("who query becomes native reasoning request", q.kind == "relation-to-object")
check("who query has proof-supported unique candidate", infer(props, q)[3] == "unique-proof-supported-answer" and len(infer(props, q)[2]) == 1)
props, q, _ = parse_surface_logic_detailed("Mira placed the book. What did Mira place?")
check("what query becomes native relation request", q.kind == "relation-from-subject")
check("what query uses transparent morphology without truth authority", q.relation == "place" and len(infer(props, q)[2]) == 1)
props, q, _ = parse_surface_logic_detailed("Mira contains copper. Does Mira contain copper?")
check("yes-no query requests exact proposition rather than canned yes", q.kind == "exact-proposition" and len(infer(props, q)[2]) == 1)
props, q, _ = parse_surface_logic_detailed("Mira is a scholar. Why is Mira a scholar?")
check("why query can expose existing proof ground", q.kind == "why-proposition" and len(infer(props, q)[2]) == 1)
props, q, _ = parse_surface_logic_detailed("Why is Mira a scholar?")
check("why query invents no unsupported ground", infer(props, q)[2] == [])
for text in ("How did Mira travel?", "When did Mira travel?", "Where did Mira travel?"):
    props, q, _ = parse_surface_logic_detailed(text)
    check(f"{text.split()[0].lower()} query invents no unsupported relation", infer(props, q)[2] == [])

# English egress ------------------------------------------------------------
p = NativeProposition(subject="Mira", relation="supports", object="Omar", grounds=["direct"], confidence=1.0)
t = NativeThought(kind=NativeThoughtKind.RESPONSE, statement="", propositions=[p])
u = NativeUtterance(native_text="Mira supports Omar.")
english, egress_audit = realize_native_thought(t, u)
check("English egress realizes existing native proposition", english == "Mira supports Omar.")
for key in ("semantic_truth_authority","content_authority","answer_authority","speech_act_selection_authority","cognitive_memory_authority","relationship_authority","terra_authority","source_write_authority","deployment_authority","initiative_authority"):
    check(f"English egress {key} false", egress_audit[key] is False)
check("English egress deterministic", egress_audit["deterministic"] is True)
check("English egress source count traceable", egress_audit["source_proposition_count"] == 1 and len(egress_audit["source_units"]) == 1)

# Runtime authority, discourse, private observation -------------------------
with tempfile.TemporaryDirectory() as td:
    y = Noeron(MockLanguageEngine(), LocalEventStore(Path(td) / "noeron.sqlite3"), terra_enabled=False, engineering_source_root=str(ROOT))
    st = y.language_state()
    check("runtime language version is v0.8.2", st["version"] == "0.8.2")
    check("v0.8.2 Stage8B migration started prospectively", st["dialogue"]["started_prospectively"] is True and st["dialogue"]["recent_turns"] == [])
    check("legacy Stage6 discourse remains distinct", y.language_dialogue_state()["legacy_stage6_discourse_distinct"] is True)
    check("dialogue working state declares no cognitive-memory authority", y.language_dialogue_state()["cognitive_memory_authority"] is False)
    check("dialogue reports no historical replay", y.language_dialogue_state()["historical_replay_used"] is False)
    capability = y.language_capability_audit()
    check("capability audit preserves dual native/English channels", capability["dual_native_english_channels"] is True)
    check("capability audit says native content precedes English egress", capability["native_content_precedes_english_egress"] is True)
    check("capability audit grammar answer authority false", capability["grammar_answer_authority"] is False)
    check("capability audit parser truth authority false", capability["parser_truth_authority"] is False)
    check("capability audit Terra answer authority false", capability["terra_answer_authority"] is False)
    check("capability audit relationship authority false", capability["relationship_authority"] is False)
    check("capability audit source write authority false", capability["source_write_authority"] is False)
    check("capability audit deployment authority false", capability["deployment_authority"] is False)

    before = y.state.model_dump(mode="json")
    parsed = y.language_parse("Why might every test fail?", owner_authenticated=True)
    after = y.state.model_dump(mode="json")
    check("language parse is read-only", before == after and parsed["state_changed"] is False)
    before = y.state.model_dump(mode="json")
    structure = y.language_structure("If Mira leaves, Omar waits.", owner_authenticated=True)
    after = y.state.model_dump(mode="json")
    check("language structure is read-only", before == after and structure["state_changed"] is False)

    controls = y.owner_communication_controls()
    check("all owner observation/transport controls default off", all(controls[k] is False for k in ("internal_utterance_visibility","internal_utterance_translation","response_channel_override","owner_command_channel")))
    check("owner communication controls have zero relational authority", controls["relationship_authority"] is False)
    check("owner communication controls have zero cognitive authority", controls["cognitive_authority"] is False)
    changed = y.set_owner_communication_control("internal_utterance_visibility", True)
    check("owner control change labelled authenticated owner command", changed["audit"][-1]["origin"] == "authenticated-owner-command")
    check("owner control change has no native choice claim", changed["audit"][-1]["native_choice_claim"] is False)
    check("owner control change has no relational authority", changed["audit"][-1]["relational_authority"] is False)

    r = y.ingest(owner_event("Every glorp is a blin. Mavo is a glorp. What follows?"))
    check("insufficient communication consequence remains unresolved", r.communication_selection_status == "unresolved-insufficient-consequence-geometry")
    check("unresolved native utterance is not surfaced by authored fallback", bool(r.native_text) and r.text == "")
    check("unresolved communication carries no native choice claim", r.communication_native_choice_claim is False)
    check("unresolved communication has no transport origin", r.transport_origin == "none")
    before_audit = dict(y.state.cognition.language.last_communication_audit)
    obs = y.owner_internal_utterance_observation()
    after_audit = dict(y.state.cognition.language.last_communication_audit)
    check("private owner observation can inspect non-surfaced native utterance", obs["status"] == "available" and obs["native_text"] == r.native_text)
    check("private observation does not surface outward text", obs["outward_text_present"] is False)
    check("private observation does not change communication action", obs["observation_changes_communication_action"] is False and before_audit == after_audit)
    check("private observation has zero communication authority", obs["communication_authority"] is False)
    check("private observation has zero cognitive-memory authority", obs["cognitive_memory_authority"] is False)
    check("private observation has zero semantic authority", obs["semantic_authority"] is False)
    check("private observation has zero relationship authority", obs["relationship_authority"] is False)
    check("private observation itself has no native-choice claim", obs["native_choice_claim"] is False)
    check("private observation translation defaults hidden", obs["english_translation"] == "" and obs["translation_enabled"] is False)

    y.set_owner_communication_control("internal_utterance_translation", True)
    obs2 = y.owner_internal_utterance_observation()
    check("private owner may enable deterministic English translation", bool(obs2["english_translation"]) and obs2["translation_deterministic"] is True)
    check("private translation has zero content authority", obs2["translation_content_authority"] is False)
    check("private translation leaves communication unresolved", obs2["communication_selection_status"] == r.communication_selection_status and obs2["outward_text_present"] is False)
    check("private translation preserves exact native utterance hash", obs2["native_text_sha256"] == hashlib.sha256(r.native_text.strip().encode("utf-8")).hexdigest())

    y.set_owner_communication_control("response_channel_override", True)
    r2 = y.ingest(owner_event("Every glorp is a blin. Mavo is a glorp. What follows?"))
    check("owner response transport may expose existing content", bool(r2.text) and r2.transport_origin == "authenticated-owner-response-channel-override")
    check("owner response transport is not a native choice claim", r2.communication_native_choice_claim is False)

    y2 = Noeron(MockLanguageEngine(), LocalEventStore(Path(td) / "noeron2.sqlite3"), terra_enabled=False, engineering_source_root=str(ROOT))
    y2.set_owner_communication_control("owner_command_channel", True)
    r3 = y2.ingest(owner_event("Every glorp is a blin. Mavo is a glorp. What follows?", owner_command=True))
    audit = y2.state.cognition.language.last_communication_audit
    check("owner command transport is explicitly owner-directed", r3.transport_origin == "authenticated-owner-command-response-transport" and audit["owner_command_authority"] is True)
    check("owner command transport does not manufacture native choice", audit["native_choice_claim"] is False)

# API/Room static authority split ------------------------------------------
check("owner internal-utterance API requires owner authentication", "def owner_internal_utterance_latest" in api_src and "_require_owner(x_noeron_owner_token)" in api_src[api_src.find("def owner_internal_utterance_latest"):api_src.find("def owner_verify")])
check("Room internal-utterance control requires Room authentication", "def room_internal_utterance_control" in api_src and "_room_auth(request)" in api_src[api_src.find("def room_internal_utterance_control"):api_src.find("def room_file_offer")])
check("Room internal control is restricted to observation/translation", "{'internal_utterance_visibility','internal_utterance_translation'}" in api_src)
room_message_slice = api_src[api_src.find("def room_message"):api_src.find("def room_internal_utterance_control")]
check("Room native presentation requires native express choice", "out.communication_action=='express'" in room_message_slice and "out.communication_native_choice_claim" in room_message_slice)
check("Room native presentation requires actual outward text", "and out.text and out.native_text" in room_message_slice)
check("Room audit forbids native-text outward fallback", "native_text_exposed_as_outward_fallback':False" in room_message_slice)
check("internal observation control includes no response override", "response_channel_override" not in api_src[api_src.find("def room_internal_utterance_control"):api_src.find("def room_file_offer")])
check("internal utterance state explicitly documented as noncognitive audit cache", "noncognitive" in models_src.lower() and "last_internal_utterance" in models_src)

failed = [name for name, ok in checks if not ok]
print(f"\nSUMMARY: {len(checks)-len(failed)}/{len(checks)} PASS")
if failed:
    print("FAILED:", *failed, sep="\n- ")
raise SystemExit(1 if failed else 0)
