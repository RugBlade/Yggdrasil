from pathlib import Path
import ast,json,tomllib

ROOT=Path(__file__).resolve().parents[1]
checks=[]
def add(name,ok):
    checks.append((name,bool(ok)));print(('PASS' if ok else 'FAIL'),name)

project=tomllib.loads((ROOT/'pyproject.toml').read_text())['project']
api=(ROOT/'src/noeron/api.py').read_text();room=(ROOT/'src/noeron/room.py').read_text();models=(ROOT/'src/noeron/room_models.py').read_text();init=(ROOT/'src/noeron/__init__.py').read_text()
add('outer release 0.7.6.1',project['version']=='0.7.6.1' and "__version__ = '0.7.6.1'" in init)
add('websockets exact live-proven pin','websockets==17.0.1' in project['dependencies'])
add('python floor compatible with websockets 17',project['requires-python']=='>=3.11')
add('uvicorn dependency preserved',any(x.startswith('uvicorn>=') for x in project['dependencies']))
manifest=json.loads((ROOT/'vendor/python/INTEGRITY.json').read_text())
wheel=ROOT/'vendor/python'/manifest['live_server_wheel']
import hashlib
add('vendored live-server websocket wheel present',wheel.is_file())
add('vendored websocket wheel hash exact',wheel.is_file() and hashlib.sha256(wheel.read_bytes()).hexdigest()=='f47b0815af3948ec6a440b3afa02f05b18cc0939549e91b5c677b5d9c2c8472a')
add('vendored websocket transport has zero authority','zero cognitive, relational' in manifest.get('runtime_authority',''))
add('room patch version explicit',"version: str = '0.7.6.1'" in models)
add('room schema remains v0.7.6',"schema_version: str = '0.7.6'" in models)
add('cognition core not relabelled',"'kernel_version':'0.7.5.1'" in api)
add('math interface not relabelled',"'math_interface':'0.7.3.4-causal'" in api)
add('publication candidate root private substrate','publication-candidates' in room and '0o700' in room)
add('candidate symlink fail closed','stat.S_ISLNK' in room)
add('candidate O_NOFOLLOW read','_read_publication_candidate_bytes' in room and 'O_NOFOLLOW' in room)
add('candidate hash verified before deliberation','Room publication candidate bytes changed before deliberation' in room)
add('separate file publication decision state','last_file_publication_decision' in models and 'last_file_publication_decision=rec' in room)
add('native publication guard preserved',"decision.native_choice_claim and decision.decision_layer=='native-deliberative'" in room)
add('publish action required',"decision.selected_action==expected_action" in room)
add('hold/tie does not publish',"if rec.native_choice_claim and rec.selected_action=='publish'" in room)
add('owner force publication explicitly false',"'owner_force_publication':False" in api and "'owner_force_publication': False" in room)
add('no owner force publish route','/publication/force' not in api and '/publish-now' not in api)
add('publication list endpoint',"@app.get('/room/publication/candidates')" in api)
add('publication deliberate endpoint',"@app.post('/room/publication/candidates/{candidate_id}/deliberate')" in api)
add('publication endpoints authenticate',api[api.index('def room_publication_candidates'):api.index("@app.post('/room/camera')")].count('_room_auth(request)')>=2)
add('browser file control','id="fileInput"' in api and 'id="fileOffer"' in api)
add('browser camera control','id="cameraCapture"' in api and 'getUserMedia({video:true,audio:false})' in api)
add('browser mic control','id="micStart"' in api and 'id="micStop"' in api and 'getUserMedia({audio:true,video:false})' in api)
add('browser microphone produces WAV',"type:'audio/wav'" in api and 'encodeWav' in api)
add('file arrival no-force text explicit','arrival did not force attention' in api)
add('file consider remains explicit separate action','Present attention affordance' in api and "'/room/files/'+a0.id+'/consider'" in api)
add('publication UI says opportunity','Present publish/hold opportunity' in api)
add('local Three.js route preserved',"import('/room/vendor/three-r185/build/three.module.js')" in api)
add('no renderer CDN','cdn.jsdelivr.net' not in api and 'unpkg.com' not in api)
add('websocket connected state visible','Room socket connected / owner-only Ed25519 session' in api)
# route delta
tr=ast.parse(api);routes=[]
for node in ast.walk(tr):
    if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
        for dec in node.decorator_list:
            if isinstance(dec,ast.Call) and isinstance(dec.func,ast.Attribute) and dec.func.attr in {'get','post','put','patch','delete'} and dec.args and isinstance(dec.args[0],ast.Constant):routes.append((dec.func.attr.upper(),str(dec.args[0].value)))
cert={tuple(x) for x in json.loads((ROOT/'scripts/v0751_certified_api_routes.json').read_text())};new=set(routes)-cert
add('93 unique HTTP routes',len(routes)==len(set(routes))==93)
add('19 post-v0751 routes',len(new)==19)
add('all new routes Room-scoped',all(path.startswith('/room') for _,path in new))
failed=[n for n,ok in checks if not ok]
print(f'\nsummary: {len(checks)-len(failed)}/{len(checks)} PASS')
raise SystemExit(1 if failed else 0)
