from __future__ import annotations

from pathlib import Path
import tomllib

ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'src'/'noeron'
api=(SRC/'api.py').read_text()
config=(SRC/'config.py').read_text()
orch=(SRC/'orchestrator.py').read_text()
math_models=(SRC/'math'/'models.py').read_text()
project=tomllib.loads((ROOT/'pyproject.toml').read_text())
init=(SRC/'__init__.py').read_text()
checks=[]

def check(name,condition,detail=''):
    checks.append((name,bool(condition),detail))

check('project-version-v0761',project['project']['version']=='0.7.6.1')
check('package-version-v0761',"__version__ = '0.7.6.1'" in init)
check('api-imports-single-outer-version','from noeron import __version__ as OUTER_RUNTIME_VERSION' in api)
check('fastapi-uses-outer-version','version=OUTER_RUNTIME_VERSION' in api.replace(' ',''))
check('outer-runtime-surfaces-use-release-constant',api.count("'runtime_version':OUTER_RUNTIME_VERSION")>=6)
check('cognition-core-remains-v0751',"'runtime_version':'0.7.5.1'" in orch)
check('graph-kernel-remains-v0751',"'kernel_version':'0.7.5.1'" in api)
check('math-interface-remains-v0734',"interface_version: str = '0.7.3.4'" in math_models)
check('cookie-secure-default-false','room_cookie_secure: bool = False' in config)
check('cookie-secure-env-explicit','NOERON_ROOM_COOKIE_SECURE' in config)
check('cookie-secure-only-used-by-cookie','secure=settings.room_cookie_secure' in api)
check('cookie-remains-http-only','httponly=True' in api)
check('cookie-remains-samesite-strict',"samesite='strict'" in api)
check('cookie-remains-room-scoped',"path='/room'" in api)
for rel in ('README.md','RELEASE_COMMIT.txt','BUILD_PROVENANCE.txt','LOCAL_CERTIFICATION.txt'):
    text=(ROOT/rel).read_text()
    check(f'{rel}-v0761-stage7-release-truth','v0.7.6.1' in text and ('Stage 7' in text or 'Stage-7' in text))
    check(f'{rel}-not-live-certified-truth','NOT live-certified' in text or 'NOT LIVE-CERTIFIED' in text or 'Stage-7 live certification: PENDING' in text)
    check(f'{rel}-no-stale-stage6-pending-claim','Stage 6 live certification: PENDING' not in text and 'does not by itself authorize Stage 6/8 completion' not in text)

for rel in ('.env.example','deploy/noeron.env.example'):
    text=(ROOT/rel).read_text()
    check(f'{rel}-stage7-release-context','Noeron v0.7.6.1' in text and 'not live-certified' in text)
    check(f'{rel}-legacy-bootstrap-disabled-example','NOERON_OWNER_LEGACY_TOKEN_ENABLED=false' in text)
    check(f'{rel}-cookie-setting-documented','NOERON_ROOM_COOKIE_SECURE=false' in text and 'loopback/SSH tunnel' in text)
    check(f'{rel}-local-observational-adapters-documented','NOERON_ROOM_NATIVE_DECODER_EXECUTABLE=' in text and 'NOERON_ROOM_ASR_EXECUTABLE=' in text)

failed=[x for x in checks if not x[1]]
for i,(name,ok,detail) in enumerate(checks,1):
    print(f'{i:02d}. {"PASS" if ok else "FAIL"}: {name}' + (f' — {detail}' if detail else ''))
print(f'SUMMARY: {len(checks)-len(failed)}/{len(checks)} checks passed')
if failed: raise SystemExit(1)
