from __future__ import annotations

import ast
import tomllib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
checks = []


def check(name, ok):
    checks.append((name, bool(ok)))
    print(f"{'PASS' if ok else 'FAIL'} {name}")


project = tomllib.loads((ROOT/"pyproject.toml").read_text(encoding="utf-8"))["project"]
init = (ROOT/"src/noeron/__init__.py").read_text(encoding="utf-8")
api = (ROOT/"src/noeron/api.py").read_text(encoding="utf-8")
orch = (ROOT/"src/noeron/orchestrator.py").read_text(encoding="utf-8")
models = (ROOT/"src/noeron/math/models.py").read_text(encoding="utf-8")
room_models = (ROOT/"src/noeron/room_models.py").read_text(encoding="utf-8")
eng = (ROOT/"src/noeron/engineering.py").read_text(encoding="utf-8")
composition = (ROOT/"src/noeron/language_composition.py").read_text(encoding="utf-8")

check("outer project version v0.8.1", project["version"] == "0.8.1")
check("outer package version v0.8.1", "__version__ = '0.8.1'" in init)
check("API imports one outer release constant", "from noeron import __version__ as OUTER_RUNTIME_VERSION" in api)
check("FastAPI outer version uses release constant", "version=OUTER_RUNTIME_VERSION" in api.replace(" ",""))
check("outer runtime surfaces use release constant", "'runtime_version':OUTER_RUNTIME_VERSION" in api.replace(" ",""))
check("cognition core remains v0.7.5.1", "'runtime_version':'0.7.5.1'" in orch)
check("math interface remains v0.7.3.4", "interface_version: str = '0.7.3.4'" in models)
check("Room subsystem remains v0.7.6.1", "version: str = '0.7.6.1'" in room_models)
check("Room schema remains v0.7.6", "schema_version: str = '0.7.6'" in room_models)
check("Room mechanism remains completion patch", "mechanism_version: str = '0.7.6.1-room-completion-patch'" in room_models)
check("Stage8A engineering mechanism preserved", "0.8.0-stage8A-engineering-source-perception-v1" in eng)
check("Stage8A source sensor remains read only", '"read_only": True' in eng and '"write_authority": False' in eng and '"deployment_authority": False' in eng)
check("Stage8B language mechanism explicit", "0.8.1-stage8B-native-language-v1" in composition)
check("Stage8B composition mechanism explicit", "0.8.1-stage8B-composition-v1" in composition)
check("Stage8B composition semantic authority false", '"semantic_authority": False' in composition)
check("Stage8B composition answer authority false", '"answer_selection_authority": False' in composition)
check("Stage8B composition Terra authority false", '"terra_authority": False' in composition)
check("Stage8B migration is prospective", "no historical replay" in orch.lower())

# AST route inventory: Stage 8B intentionally adds no HTTP route.
tree = ast.parse(api)
routes = []
for node in ast.walk(tree):
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
        for dec in node.decorator_list:
            if isinstance(dec, ast.Call) and isinstance(dec.func, ast.Attribute):
                if isinstance(dec.func.value, ast.Name) and dec.func.value.id == "app" and dec.func.attr.lower() in {"get","post","put","delete","patch","options","head"}:
                    if dec.args and isinstance(dec.args[0], ast.Constant) and isinstance(dec.args[0].value, str):
                        routes.append((dec.func.attr.upper(), dec.args[0].value, node.name))
check("Stage8B HTTP route count remains 98", len(routes) == 98)
check("Stage8B HTTP route definitions unique", len({(m,p) for m,p,_ in routes}) == 98)
engineering_routes = {(m,p) for m,p,_ in routes if p.startswith("/engineering/")}
check("exact five Stage8A engineering routes preserved", engineering_routes == {
    ("GET","/engineering/status"),
    ("GET","/engineering/source/index"),
    ("GET","/engineering/source/file"),
    ("GET","/engineering/source/symbol"),
    ("POST","/engineering/source/observe"),
})

for rel in ("README.md","RELEASE_COMMIT.txt","BUILD_PROVENANCE.txt","LOCAL_CERTIFICATION.txt"):
    text = (ROOT/rel).read_text(encoding="utf-8")
    check(f"{rel} identifies v0.8.1 Stage8B", "v0.8.1" in text and ("Stage 8B" in text or "Stage-8B" in text))
    check(f"{rel} records Stage8A live-certified", ("Stage 8A" in text or "Stage-8A" in text) and ("live-certified" in text.lower() or "LIVE-CERTIFIED" in text))
    check(f"{rel} preserves roadmap 7/8", "7/8" in text)
    check(f"{rel} does not claim Stage8 final certified", (
        "Stage-8 final certification: PENDING" in text
        or "Stage 8 as a whole is still in progress" in text
        or "does not certify Stage 8/8" in text
        or "does NOT by itself certify Stage 8/8" in text
    ))

for rel in (".env.example","deploy/noeron.env.example"):
    text = (ROOT/rel).read_text(encoding="utf-8")
    check(f"{rel} current candidate truth", "Noeron v0.8.1" in text and "Stage 8B" in text and "Stage 8A live-certified" in text)
    check(f"{rel} engineering source root documented", "NOERON_ENGINEERING_SOURCE_ROOT=" in text)
    check(f"{rel} engineering byte bound documented", "NOERON_ENGINEERING_MAX_SOURCE_BYTES=300000" in text)
    check(f"{rel} legacy owner bootstrap fail closed", "NOERON_OWNER_LEGACY_TOKEN_ENABLED=false" in text)
    check(f"{rel} Room remains tunnel/private transport documented", "loopback/SSH tunnel" in text)

failed = [name for name, ok in checks if not ok]
print(f"\nSUMMARY: {len(checks)-len(failed)}/{len(checks)} PASS")
if failed:
    print("FAILED:", *failed, sep="\n- ")
raise SystemExit(1 if failed else 0)
