from __future__ import annotations

import ast
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
room=(ROOT/'src/noeron/room.py').read_text()
api=(ROOT/'src/noeron/api.py').read_text()
models=(ROOT/'src/noeron/room_models.py').read_text()
speech=(ROOT/'src/noeron/speech.py').read_text()
decoder=(ROOT/'src/noeron/native_decoder.py').read_text() if (ROOT/'src/noeron/native_decoder.py').exists() else ''
config=(ROOT/'src/noeron/config.py').read_text()

checks=[]
def add(name, ok): checks.append((name,bool(ok)))

# Architecture / no authored identity defaults
add('room state prospective no embodiment default', "embodiment_configuration: RendererConfiguration | None = None" in models)
add('room state prospective no environment default', "environment_configuration: RendererConfiguration | None = None" in models)
add('renderer schema has no gender field', 'gender:' not in models)
add('renderer schema has no body_family field', 'body_family:' not in models)
add('voice schema has no speaker field', 'speaker:' not in models)
add('voice schema has no accent field', 'accent:' not in models)
add('voice profile continuous coordinates', all(x in models for x in ['base_frequency','overtone_ratio','modulation','articulation','pulse_shape','tempo']))
add('exact ties remain unresolved', "selection_status='unresolved-exact-tie'" in room)
add('native choice requires unique minimum', "native_choice_claim=True" in room and 'minimum_candidates=mins' in room)
add('current configuration remains candidate', 'out.append(current.model_copy(deep=True))' in room)
add('retain does not false morph', 'genuine retain decision; no false morph/adoption event' in room)
add('adoption provenance noncognitive', "'cognitive_authority':False" in room)
add('room journal noncognitive', 'cognitive_authority=False' in room)
add('decoder cognitive authority false', 'decoder_cognitive_authority=False' in room)
add('decoder realization authority false', 'decoder_realization_authority=False' in room)
add('native text not outward fallback', 'native_text_exposed_as_fallback' in api and "'native_text_exposed':False" in api)

# Private file substrate
add('payload bound configured', 'room_max_payload_bytes' in config and 'NOERON_ROOM_MAX_PAYLOAD_BYTES' in config)
add('payload lower bound', '1_048_576' in config)
add('payload upper bound', '1_073_741_824' in config)
add('path separators rejected', "'/' in name" in room and "'\\\\' in name" in room)
add('nul filename rejected', "'\\x00' in name" in room)
add('exclusive create', 'os.O_EXCL' in room)
add('nofollow supported', 'O_NOFOLLOW' in room)
add('private fsync', 'os.fsync' in room)
add('private file mode 0600', '0o600' in room)
add('private root mode 0700', '0o700' in room)
add('artifact root containment', 'resolved.relative_to(root)' in room)
add('artifact symlink rejected', 'Room artifact symlink is forbidden' in room)
add('artifact regular-file check', 'stat.S_ISREG' in room)
add('artifact size verified', 'persisted provenance' in room and 'st.st_size' in room)
add('artifact sha256 verified', 'Room artifact SHA-256 does not match persisted provenance' in room)
add('file publication domain/action strict', "expected_domain: str = 'file-publication'" in room and "expected_action: str = 'publish'" in room)
add('native voice domain/action strict', "expected_domain='native-voice',expected_action='voice'" in room)

# Transport/browser/private subprocess substrate
add('http room loopback guard', '_room_transport_guard(request)' in api)
add('websocket loopback guard', '_room_ws_transport_allowed(ws)' in api)
add('websocket same-origin guard', 'origin not in allowed' in api)
add('websocket revalidates session', 'owner_auth.verify_detail(token)' in api and 'await asyncio.sleep(0.75)' in api)
add('room requires ed25519 session', "d.get('method')!='ed25519-device-session'" in api)
add('legacy Room bootstrap rejected', 'legacy bootstrap is not accepted' in api)
add('CSP default deny', "default-src 'none'" in api and "object-src 'none'" in api and "base-uri 'none'" in api)
add('local speech subprocess shell false/no urls', 'shell=False' in speech and 'subprocess.run' in speech and 'http://' not in speech and 'https://' not in speech)

assert len(checks)==41,len(checks)
failed=[]
for i,(name,ok) in enumerate(checks,1):
    print(f'{i:02d} {"PASS" if ok else "FAIL"} {name}')
    if not ok: failed.append(name)
print('THREEJS=SEPARATE-AUDIT (see audit_v076_stage7_three_renderer.py; not part of 41 non-Three checks)')
print(f'SUMMARY: {len(checks)-len(failed)}/{len(checks)} non-Three checks passed')
sys.exit(1 if failed else 0)
