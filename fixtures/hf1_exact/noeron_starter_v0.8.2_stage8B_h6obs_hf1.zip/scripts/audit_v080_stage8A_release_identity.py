from __future__ import annotations

import tomllib
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
checks=[]
def check(name,ok):
    checks.append((name,bool(ok))); print(('PASS' if ok else 'FAIL'),name)

project=tomllib.loads((ROOT/'pyproject.toml').read_text())['project']
init=(ROOT/'src/noeron/__init__.py').read_text()
api=(ROOT/'src/noeron/api.py').read_text()
orch=(ROOT/'src/noeron/orchestrator.py').read_text()
models=(ROOT/'src/noeron/math/models.py').read_text()
room_models=(ROOT/'src/noeron/room_models.py').read_text()
eng=(ROOT/'src/noeron/engineering.py').read_text()

check('outer project version v0.8.0',project['version']=='0.8.0')
check('outer package version v0.8.0',"__version__ = '0.8.0'" in init)
check('API imports one outer release constant','from noeron import __version__ as OUTER_RUNTIME_VERSION' in api)
check('FastAPI outer version uses release constant','version=OUTER_RUNTIME_VERSION' in api.replace(' ',''))
check('outer runtime surfaces use release constant',"'runtime_version':OUTER_RUNTIME_VERSION" in api.replace(' ',''))
check('cognition core remains v0.7.5.1',"'runtime_version':'0.7.5.1'" in orch)
check('math interface remains v0.7.3.4',"interface_version: str = '0.7.3.4'" in models)
check('Room subsystem version remains v0.7.6.1',"version: str = '0.7.6.1'" in room_models)
check('Room schema remains v0.7.6',"schema_version: str = '0.7.6'" in room_models)
check('Room mechanism remains completion patch',"mechanism_version: str = '0.7.6.1-room-completion-patch'" in room_models)
check('Stage8A engineering mechanism explicit','0.8.0-stage8A-engineering-source-perception-v1' in eng)
check('Stage8A source sensor remains read only','"read_only": True' in eng and '"write_authority": False' in eng and '"deployment_authority": False' in eng)

for rel in ('README.md','RELEASE_COMMIT.txt','BUILD_PROVENANCE.txt','LOCAL_CERTIFICATION.txt'):
    text=(ROOT/rel).read_text()
    check(f'{rel} identifies v0.8.0 Stage8A','v0.8.0' in text and ('Stage 8A' in text or 'Stage-8A' in text))
    check(f'{rel} preserves roadmap 7/8','7/8' in text)
    check(f'{rel} does not claim Stage8 final certified','Stage 8/8: **PENDING**' in text or 'Stage-8 final certification: PENDING' in text or 'does NOT by itself certify Stage 8/8' in text or 'Stage 8 does not provide' in text or 'Stage 8A does not provide' in text)

for rel in ('.env.example','deploy/noeron.env.example'):
    text=(ROOT/rel).read_text()
    check(f'{rel} current release truth','Noeron v0.8.0' in text and 'Stage 8A' in text and 'Stage 7 live-certified' in text)
    check(f'{rel} engineering source root documented','NOERON_ENGINEERING_SOURCE_ROOT=' in text)
    check(f'{rel} engineering byte bound documented','NOERON_ENGINEERING_MAX_SOURCE_BYTES=300000' in text)
    check(f'{rel} legacy owner bootstrap fail closed','NOERON_OWNER_LEGACY_TOKEN_ENABLED=false' in text)
    check(f'{rel} Room remains tunnel/private transport documented','loopback/SSH tunnel' in text)

failed=[n for n,ok in checks if not ok]
print(f'\nSUMMARY: {len(checks)-len(failed)}/{len(checks)} PASS')
if failed:
    print('FAILED:',*failed,sep='\n- ')
raise SystemExit(1 if failed else 0)
