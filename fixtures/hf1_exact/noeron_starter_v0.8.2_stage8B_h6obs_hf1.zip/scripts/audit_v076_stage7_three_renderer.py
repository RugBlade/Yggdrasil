from __future__ import annotations

import ast
from pathlib import Path
import sys

from noeron import renderer

ROOT=Path(__file__).resolve().parents[1]
api=(ROOT/'src/noeron/api.py').read_text()
room_models=(ROOT/'src/noeron/room_models.py').read_text()
checks=[]
def add(name,ok):checks.append((name,bool(ok)))

try:
    manifest=renderer.verify_vendor_material(); material_ok=True
except Exception:
    manifest={}; material_ok=False

add('exact r185 vendor material verifies',material_ok)
add('three package version exact',manifest.get('package')=='three' and manifest.get('version')=='0.185.1')
add('three tag exact',manifest.get('upstream_tag')=='r185')
add('three license MIT',manifest.get('license')=='MIT')
add('runtime public network dependency false',manifest.get('runtime_public_network_dependency') is False)
add('browser asset allowlist exact',renderer.THREE_BROWSER_ASSETS==frozenset({'build/three.module.js','build/three.core.js'}))
add('module blob exact',renderer.THREE_REQUIRED['build/three.module.js']['git_blob_sha1']=='ad13abf7d128bee607a7672646ca543327e258d3')
add('core blob exact',renderer.THREE_REQUIRED['build/three.core.js']['git_blob_sha1']=='0bb9262cd029f411933d077fd44197a51ec5e8e9')
add('license blob exact',renderer.THREE_REQUIRED['LICENSE']['git_blob_sha1']=='8ada2a5f982916b0ba4b7a0aa7de347587e745d7')
add('room imports three locally',"await import('/room/vendor/three-r185/build/three.module.js')" in api)
add('authenticated room-scoped asset route',"@app.get('/room/vendor/three-r185/{asset_path:path}')" in api and 'def room_three_r185_asset' in api and '_room_auth(request)' in api)
add('same-origin script allowed under default deny',"default-src 'none'" in api and "script-src 'self' 'unsafe-inline'" in api)
add('webgl renderer used','new THREE.WebGLRenderer' in api)
add('generic BufferGeometry used','new THREE.BufferGeometry' in api and 'new THREE.Points(' in api)
renderer_slice=api[api.index('function neutralCoordinates'):api.index('async function post')]
add('no 2d renderer fallback',"getContext('2d')" not in renderer_slice and 'getContext("2d")' not in renderer_slice)
add('no named morphology geometry family',all(x not in api for x in ['THREE.SphereGeometry','THREE.BoxGeometry','THREE.CapsuleGeometry','THREE.ConeGeometry','THREE.CylinderGeometry','GLTFLoader']))
add('zero or absent embodiment creates no object','if(!THREE||!config||config.visible===false)return null' in api)
add('renderer explicitly presentation-only','presentation_substrate_only:true' in api and 'morphology_template_authority' in (ROOT/'src/noeron/renderer.py').read_text())
add('renderer availability has zero native choice authority','embodiment_choice_authority": False' in (ROOT/'src/noeron/renderer.py').read_text() and 'environment_choice_authority": False' in (ROOT/'src/noeron/renderer.py').read_text())
add('no hidden gender/body family schema default','gender:' not in room_models and 'body_family:' not in room_models)

assert len(checks)==20,len(checks)
failed=[]
for i,(name,ok) in enumerate(checks,1):
    print(f'{i:02d} {"PASS" if ok else "FAIL"} {name}')
    if not ok:failed.append(name)
print(f'SUMMARY: {len(checks)-len(failed)}/{len(checks)} Three.js renderer checks passed')
sys.exit(1 if failed else 0)
