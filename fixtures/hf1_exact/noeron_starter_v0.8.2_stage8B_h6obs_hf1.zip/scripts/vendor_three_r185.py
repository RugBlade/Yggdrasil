#!/usr/bin/env python3
"""Fail-closed offline vendoring for the Stage-7 Three.js r185 substrate.

This tool NEVER downloads anything.  It accepts either an already-local npm
three@0.185.1 tarball or an already-local r185 source/package directory.  It
installs only when the supplied bytes match the exact upstream Git blob
identities pinned below.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
import re
from pathlib import Path
import shutil
import stat
import tarfile
import tempfile
from typing import Mapping

PACKAGE_NAME = "three"
PACKAGE_VERSION = "0.185.1"
UPSTREAM_TAG = "r185"
LICENSE_ID = "MIT"
NPM_SRI = "sha512-5aojFCXKwnjBRZvUnt3WFfEcvUJgkN5LlijRFN95hMy8WVkG4I0QNcJE+OuWvuJ0bOdStrbfXn0pkd6/QyiAlg=="
REQUIRED_FILES: Mapping[str, str] = {
    "build/three.module.js": "ad13abf7d128bee607a7672646ca543327e258d3",
    "build/three.core.js": "0bb9262cd029f411933d077fd44197a51ec5e8e9",
    "LICENSE": "8ada2a5f982916b0ba4b7a0aa7de347587e745d7",
}
DEFAULT_DESTINATION = Path("src/noeron/static/vendor/three-r185")
MAX_TARBALL_BYTES = 64 * 1024 * 1024
MAX_MEMBER_BYTES = 16 * 1024 * 1024


class VerificationError(RuntimeError):
    """Raised when supplied Three.js material is not the exact pinned release."""


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def git_blob_sha1(data: bytes) -> str:
    header = f"blob {len(data)}\0".encode("ascii")
    return hashlib.sha1(header + data).hexdigest()


def verify_npm_sri(tarball: Path) -> None:
    size = tarball.stat().st_size
    if size <= 0 or size > MAX_TARBALL_BYTES:
        raise VerificationError(f"tarball size outside allowed bounds: {size}")
    algorithm, encoded = NPM_SRI.split("-", 1)
    if algorithm != "sha512":
        raise VerificationError("internal SRI pin is not sha512")
    actual = base64.b64encode(hashlib.sha512(tarball.read_bytes()).digest()).decode("ascii")
    if actual != encoded:
        raise VerificationError("npm tarball SRI mismatch")


def _safe_tar_member(member: tarfile.TarInfo) -> bool:
    p = Path(member.name)
    return (
        member.isfile()
        and not p.is_absolute()
        and ".." not in p.parts
        and member.size >= 0
        and member.size <= MAX_MEMBER_BYTES
    )


def _read_tgz_files(tarball: Path) -> tuple[dict[str, bytes], dict[str, object]]:
    verify_npm_sri(tarball)
    wanted = {f"package/{name}": name for name in REQUIRED_FILES}
    wanted["package/package.json"] = "package.json"
    found: dict[str, bytes] = {}
    with tarfile.open(tarball, mode="r:gz") as tf:
        for member in tf.getmembers():
            if member.name not in wanted:
                continue
            if not _safe_tar_member(member):
                raise VerificationError(f"unsafe required tar member: {member.name}")
            fh = tf.extractfile(member)
            if fh is None:
                raise VerificationError(f"cannot read required tar member: {member.name}")
            found[wanted[member.name]] = fh.read()
    expected = set(REQUIRED_FILES) | {"package.json"}
    if set(found) != expected:
        missing = sorted(expected - set(found))
        raise VerificationError(f"npm tarball missing required files: {missing}")
    try:
        package = json.loads(found.pop("package.json").decode("utf-8"))
    except Exception as exc:
        raise VerificationError("invalid package.json in npm tarball") from exc
    return found, package


def _find_source_root(source: Path) -> Path:
    source = source.resolve(strict=True)
    if (source / "package.json").is_file() and (source / "build").is_dir():
        return source
    if (source / "package" / "package.json").is_file() and (source / "package" / "build").is_dir():
        return source / "package"
    raise VerificationError("source directory is not a Three.js package/source root")


def _read_source_files(source: Path) -> tuple[dict[str, bytes], dict[str, object]]:
    root = _find_source_root(source)
    try:
        package = json.loads((root / "package.json").read_text(encoding="utf-8"))
    except Exception as exc:
        raise VerificationError("invalid package.json in source directory") from exc
    files: dict[str, bytes] = {}
    for rel in REQUIRED_FILES:
        path = root / rel
        if not path.is_file() or path.is_symlink():
            raise VerificationError(f"missing or unsafe source file: {rel}")
        st = path.stat()
        if not stat.S_ISREG(st.st_mode) or st.st_size > MAX_MEMBER_BYTES:
            raise VerificationError(f"invalid source file: {rel}")
        files[rel] = path.read_bytes()
    return files, package


def _verify_package_identity(package: Mapping[str, object]) -> None:
    if package.get("name") != PACKAGE_NAME:
        raise VerificationError(f"package name mismatch: {package.get('name')!r}")
    if package.get("version") != PACKAGE_VERSION:
        raise VerificationError(f"package version mismatch: {package.get('version')!r}")


def _module_specifiers(text: str) -> list[str]:
    """Return literal JS module specifiers without treating comments/docs as dependencies."""
    patterns = (
        r"\bfrom\s*['\"]([^'\"]+)['\"]",
        r"\bimport\s*['\"]([^'\"]+)['\"]",
        r"\bimport\s*\(\s*['\"]([^'\"]+)['\"]\s*\)",
    )
    out: list[str] = []
    for pattern in patterns:
        out.extend(re.findall(pattern, text))
    return out


def _verify_module_linkage(module_bytes: bytes) -> None:
    try:
        text = module_bytes.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise VerificationError("three.module.js is not UTF-8") from exc
    specifiers = _module_specifiers(text)
    if "./three.core.js" not in specifiers:
        raise VerificationError("three.module.js does not import local ./three.core.js")
    external = sorted({s for s in specifiers if not s.startswith(("./", "../"))})
    if external:
        raise VerificationError(f"three.module.js contains non-local module dependencies: {external}")


def _verify_license(files: Mapping[str, bytes]) -> None:
    try:
        license_text = files["LICENSE"].decode("utf-8")
        module_head = files["build/three.module.js"][:512].decode("utf-8", errors="strict")
        core_head = files["build/three.core.js"][:512].decode("utf-8", errors="strict")
    except Exception as exc:
        raise VerificationError("license/header material is not valid UTF-8") from exc
    if "The MIT License" not in license_text or "Permission is hereby granted" not in license_text:
        raise VerificationError("LICENSE is not the expected MIT license text")
    for name, head in (("three.module.js", module_head), ("three.core.js", core_head)):
        if "SPDX-License-Identifier: MIT" not in head:
            raise VerificationError(f"{name} lacks MIT SPDX header")


def verify_payload(files: Mapping[str, bytes], package: Mapping[str, object]) -> dict[str, dict[str, object]]:
    _verify_package_identity(package)
    if set(files) != set(REQUIRED_FILES):
        raise VerificationError("verified payload file set is not exact")
    _verify_module_linkage(files["build/three.module.js"])
    _verify_license(files)
    manifest_files: dict[str, dict[str, object]] = {}
    for rel, expected_blob in REQUIRED_FILES.items():
        data = files[rel]
        actual_blob = git_blob_sha1(data)
        if actual_blob != expected_blob:
            raise VerificationError(
                f"Git blob mismatch for {rel}: expected {expected_blob}, got {actual_blob}"
            )
        manifest_files[rel] = {
            "size": len(data),
            "sha256": sha256_hex(data),
            "upstream_git_blob_sha1": actual_blob,
        }
    return manifest_files


def _write_private_file(path: Path, data: bytes) -> None:
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
    try:
        with os.fdopen(fd, "wb", closefd=True) as fh:
            fh.write(data)
            fh.flush()
            os.fsync(fh.fileno())
    except Exception:
        try:
            path.unlink(missing_ok=True)
        finally:
            raise


def atomic_install(
    files: Mapping[str, bytes],
    manifest_files: Mapping[str, Mapping[str, object]],
    destination: Path,
    *,
    source_mode: str,
) -> Path:
    destination = destination.resolve()
    parent = destination.parent
    parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        raise VerificationError(f"destination already exists: {destination}")
    temp = Path(tempfile.mkdtemp(prefix=f".{destination.name}.tmp-", dir=parent))
    try:
        (temp / "build").mkdir(mode=0o755)
        for rel in REQUIRED_FILES:
            target = temp / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            _write_private_file(target, files[rel])
        integrity = {
            "package": PACKAGE_NAME,
            "version": PACKAGE_VERSION,
            "upstream_tag": UPSTREAM_TAG,
            "license": LICENSE_ID,
            "npm_sri": NPM_SRI,
            "source_mode": source_mode,
            "runtime_public_network_dependency": False,
            "files": dict(manifest_files),
        }
        _write_private_file(
            temp / "INTEGRITY.json",
            (json.dumps(integrity, indent=2, sort_keys=True) + "\n").encode("utf-8"),
        )
        os.replace(temp, destination)
        return destination
    except Exception:
        shutil.rmtree(temp, ignore_errors=True)
        raise


def vendor(*, source_dir: Path | None, npm_tgz: Path | None, destination: Path) -> Path:
    if (source_dir is None) == (npm_tgz is None):
        raise VerificationError("provide exactly one of --source-dir or --npm-tgz")
    if npm_tgz is not None:
        files, package = _read_tgz_files(npm_tgz.resolve(strict=True))
        source_mode = "npm-tgz-exact-sri"
    else:
        assert source_dir is not None
        files, package = _read_source_files(source_dir)
        source_mode = "local-source-directory"
    manifest_files = verify_payload(files, package)
    return atomic_install(files, manifest_files, destination, source_mode=source_mode)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--source-dir", type=Path)
    group.add_argument("--npm-tgz", type=Path)
    parser.add_argument("--destination", type=Path, default=DEFAULT_DESTINATION)
    args = parser.parse_args()
    try:
        installed = vendor(
            source_dir=args.source_dir,
            npm_tgz=args.npm_tgz,
            destination=args.destination,
        )
    except (VerificationError, OSError, tarfile.TarError) as exc:
        print(f"THREE_R185_VENDOR=FAIL_CLOSED: {exc}")
        return 2
    print(f"THREE_R185_VENDOR=PASS: {installed}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
