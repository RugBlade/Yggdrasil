from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from noeron.llm import MockLanguageEngine
from noeron.memory import LocalEventStore
from noeron.orchestrator import Noeron


def _memory_rows(store: LocalEventStore) -> dict[str, dict]:
    return {str(m.id): m.model_dump(mode='json') for m in store.all_knot_memories()}


def _digest(value) -> str:
    raw = json.dumps(value, sort_keys=True, separators=(',', ':'), default=str).encode()
    return hashlib.sha256(raw).hexdigest()


def _checkpoint(store: LocalEventStore, n: Noeron | None = None) -> dict:
    state = n.state if n is not None else store.latest_state()
    if state is None:
        raise RuntimeError('database has no persisted Noeron state')
    rows = _memory_rows(store)
    active = [str(m.id) for m in store.cognitive_memories()]
    math_payload = state.math_kernel.model_dump(mode='json')
    # Historical runtime/interface labels are metadata, not mathematical state.
    # The trusted v0.7.4 live checkpoint can legitimately carry an older bridge
    # label after ordinary kernel evolution.  First-boot preservation therefore
    # compares every math field except these two labels; immediate restarts still
    # compare the full math-kernel digest exactly.
    math_causal_payload = json.loads(json.dumps(math_payload))
    math_causal_payload.pop('interface_version', None)
    if isinstance(math_causal_payload.get('egr'), dict):
        math_causal_payload['egr'].pop('bridge_name', None)
    return {
        'turn': int(state.conversational_turn),
        'memory_rows_sha256': _digest(rows),
        'all_knot_memory_count': len(rows),
        'active_cognitive_ids': active,
        'active_cognitive_count': len(active),
        'archived_or_noncognitive_count': int(store.archived_cognitive_memory_count()),
        'core_knot_sha256': _digest(state.math_kernel.dkt.core_knot.model_dump(mode='json')),
        'core_invariant_signature': state.math_kernel.dkt.invariant_signature,
        'core_sobolev_norm_sq': float(state.math_kernel.dkt.sobolev_norm_sq),
        'math_kernel_sha256': _digest(math_payload),
        'math_kernel_causal_sha256': _digest(math_causal_payload),
        'language_state_sha256': _digest(state.cognition.language.model_dump(mode='json')),
        'memory_retention_state_sha256': _digest(state.cognition.memory_retention.model_dump(mode='json')),
        'owner_relation_state_sha256': _digest(state.cognition.owner_relation.model_dump(mode='json')),
        'realization_state_sha256': _digest(state.cognition.realization_development.model_dump(mode='json')),
        'initiative_state_sha256': _digest(state.cognition.initiative_development.model_dump(mode='json')),
        'defense_state_sha256': _digest(state.cognition.defense.model_dump(mode='json')),
        'cognition_version': state.cognition.version,
        'v061_geometry_migration_complete': bool(state.cognition.v061_geometry_migration_complete),
    }


def audit_copy(db_path: Path) -> dict:
    if not db_path.is_file():
        raise FileNotFoundError(db_path)
    store = LocalEventStore(db_path)
    before = _checkpoint(store)
    if not before['v061_geometry_migration_complete']:
        raise RuntimeError('refusing preservation audit: supplied database is not a completed post-v0.6.1 state')
    first_n = Noeron(MockLanguageEngine(), store)
    first = _checkpoint(store, first_n)
    second_n = Noeron(MockLanguageEngine(), store)
    second = _checkpoint(store, second_n)

    invariant_keys = [
        'turn', 'memory_rows_sha256', 'all_knot_memory_count', 'active_cognitive_ids',
        'active_cognitive_count', 'archived_or_noncognitive_count', 'core_knot_sha256',
        'core_invariant_signature', 'core_sobolev_norm_sq',
    ]
    # First boot is allowed to perform the prospective Stage-6 language/hotfix
    # metadata migration, but it must preserve every Stage-5 cognitive subsystem
    # that the hotfix does not own.  Language state is intentionally excluded here
    # because v0.7.5 prospectively extends that subsystem.
    first_boot_changes = {k: [before[k], first[k]] for k in invariant_keys if before[k] != first[k]}
    first_boot_stable_subsystem_keys = [
        'math_kernel_causal_sha256','memory_retention_state_sha256','owner_relation_state_sha256',
        'realization_state_sha256','initiative_state_sha256','defense_state_sha256',
    ]
    first_boot_subsystem_changes = {
        k: [before[k], first[k]] for k in first_boot_stable_subsystem_keys if before[k] != first[k]
    }
    restart_invariant_keys = invariant_keys + [
        'math_kernel_sha256','language_state_sha256','memory_retention_state_sha256',
        'owner_relation_state_sha256','realization_state_sha256','initiative_state_sha256','defense_state_sha256',
    ]
    second_restart_changes = {k: [first[k], second[k]] for k in restart_invariant_keys if first[k] != second[k]}
    ok = (
        not first_boot_changes
        and not first_boot_subsystem_changes
        and not second_restart_changes
        and first['cognition_version'] == '0.7.5.1'
        and second['cognition_version'] == '0.7.5.1'
    )
    return {
        'status': 'PASS' if ok else 'FAIL',
        'database': str(db_path),
        'before': before,
        'after_first_hotfix_boot': first,
        'after_second_hotfix_restart': second,
        'first_boot_invariant_changes': first_boot_changes,
        'first_boot_subsystem_changes': first_boot_subsystem_changes,
        'second_restart_invariant_changes': second_restart_changes,
        'note': 'This utility mutates the supplied DB by booting it twice. Use only a disposable copy of the trusted checkpoint, never the sole backup.',
    }


def main() -> int:
    ap = argparse.ArgumentParser(description='Audit v0.7.5.1 restart preservation on a disposable database copy.')
    ap.add_argument('--db-copy', required=True, type=Path)
    ap.add_argument('--json-out', type=Path)
    args = ap.parse_args()
    result = audit_copy(args.db_copy)
    text = json.dumps(result, indent=2, sort_keys=True)
    print(text)
    if args.json_out:
        args.json_out.write_text(text + '\n')
    return 0 if result['status'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
