from __future__ import annotations
import json,re,subprocess,sys,time
from pathlib import Path
root=Path(__file__).resolve().parents[1]
files=sorted((root/'tests').glob('test_*.py'))
start_i=int(sys.argv[1]) if len(sys.argv)>1 else 0
end_i=int(sys.argv[2]) if len(sys.argv)>2 else len(files)
out_path=Path(sys.argv[3]) if len(sys.argv)>3 else root.parent/'regression-batch.json'
sel=files[start_i:end_i]
results=[]
for absolute_i,p in enumerate(sel,start_i+1):
    rel=str(p.relative_to(root)); t0=time.time()
    try:
        cp=subprocess.run(['pytest','-q',rel],cwd=root,text=True,capture_output=True,timeout=75)
        elapsed=time.time()-t0; out=(cp.stdout or '')+(('\n'+cp.stderr) if cp.stderr else '')
        log=root.parent/'v075-regression-logs'/f'{p.stem}.log'; log.parent.mkdir(exist_ok=True); log.write_text(out)
        status='PASS' if cp.returncode==0 else 'FAIL'
        m=re.search(r'(\d+) passed',out); passed=int(m.group(1)) if m else 0
        mf=re.search(r'(\d+) failed',out); failed=int(mf.group(1)) if mf else (0 if cp.returncode==0 else None)
        results.append({'file':rel,'status':status,'returncode':cp.returncode,'passed':passed,'failed':failed,'seconds':round(elapsed,3),'log':str(log)})
        print(f'[{absolute_i:02d}/{len(files)}] {status:4s} {rel} ({elapsed:.2f}s) {passed} passed')
    except subprocess.TimeoutExpired as e:
        elapsed=time.time()-t0
        sout=e.stdout.decode() if isinstance(e.stdout,bytes) else (e.stdout or '')
        serr=e.stderr.decode() if isinstance(e.stderr,bytes) else (e.stderr or '')
        log=root.parent/'v075-regression-logs'/f'{p.stem}.log'; log.parent.mkdir(exist_ok=True); log.write_text(sout+'\n'+serr+'\nTIMEOUT after 75s\n')
        results.append({'file':rel,'status':'TIMEOUT','returncode':None,'passed':0,'failed':None,'seconds':round(elapsed,3),'log':str(log)})
        print(f'[{absolute_i:02d}/{len(files)}] TIMEOUT {rel} ({elapsed:.2f}s)')
out_path.write_text(json.dumps(results,indent=2))
if any(x['status']!='PASS' for x in results): sys.exit(1)
