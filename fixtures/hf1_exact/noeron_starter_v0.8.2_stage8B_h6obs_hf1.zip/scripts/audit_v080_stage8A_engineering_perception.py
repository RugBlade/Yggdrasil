from __future__ import annotations

import ast
import json
import re
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
ENG=ROOT/'src/noeron/engineering.py'
API=ROOT/'src/noeron/api.py'
ORCH=ROOT/'src/noeron/orchestrator.py'
IRG=ROOT/'src/noeron/math/irg.py'
CFG=ROOT/'src/noeron/config.py'
TEST=ROOT/'tests/test_v080_stage8_engineering_perception.py'

checks=[]
def check(name, condition, detail=''):
    ok=bool(condition); checks.append((name,ok,detail)); print(('PASS' if ok else 'FAIL'),name,('- '+detail if detail else ''))
    return ok

eng=ENG.read_text(encoding='utf-8')
api=API.read_text(encoding='utf-8')
orch=ORCH.read_text(encoding='utf-8')
irg=IRG.read_text(encoding='utf-8')
cfg=CFG.read_text(encoding='utf-8')
test=TEST.read_text(encoding='utf-8')

check('engineering module exists', ENG.is_file())
check('engineering source root defaults disabled', 'engineering_source_root: str = ""' in cfg)
check('engineering source root must be absolute', 'NOERON_ENGINEERING_SOURCE_ROOT must be an absolute path' in cfg)
check('source observation byte bound configured', 'engineering_max_source_bytes' in cfg and '2000000' in cfg)
check('explicit read-only status', '"read_only": True' in eng)
check('explicit zero write authority', '"write_authority": False' in eng)
check('explicit zero deployment authority', '"deployment_authority": False' in eng)
check('source allowlist excludes data', '"data"' in eng and '"data"' not in re.search(r'_ALLOWED_TOP_LEVEL\s*=\s*\{(.*?)\n\}',eng,re.S).group(1))
check('source allowlist excludes vendor', '"vendor"' in eng and '"vendor"' not in re.search(r'_ALLOWED_TOP_LEVEL\s*=\s*\{(.*?)\n\}',eng,re.S).group(1))
check('path escape guarded by resolved relative_to root', 'candidate.relative_to(root)' in eng)
check('index symlinks blocked', '.is_symlink()' in eng and 'resolved.relative_to(root)' in eng)
check('exact SHA256 source provenance', 'sha256' in eng and 'hashlib.sha256' in eng)
check('Python AST parser present', 'ast.parse' in eng and 'ast.NodeVisitor' in eng)
check('call facts present', '"relation": "calls"' in eng)
check('route facts present', '"relation": "exposes-route"' in eng)
check('no hidden LLM import in source sensor', not re.search(r'^\s*(from|import)\s+.*(?:llm|openai)',eng,re.M))
check('no subprocess execution in source sensor', 'subprocess' not in eng)
eng_tree=ast.parse(eng)
mutation_calls=[]
for node in ast.walk(eng_tree):
    if not isinstance(node,ast.Call) or not isinstance(node.func,ast.Attribute):
        continue
    attr=node.func.attr
    if attr in {'write_text','write_bytes','unlink','rename','chmod','mkdir','rmdir','touch','symlink_to','hardlink_to'}:
        mutation_calls.append(attr)
    elif attr=='replace':
        # str.replace is used only to normalize path separators; flag Path-like
        # receiver names instead of treating every string replacement as mutation.
        recv=node.func.value
        if isinstance(recv,ast.Name) and recv.id in {'p','candidate','resolved','root'}:
            mutation_calls.append('replace')
    elif attr=='open':
        modes=[]
        if node.args and isinstance(node.args[0],ast.Constant) and isinstance(node.args[0].value,str):
            modes.append(node.args[0].value)
        for kw in node.keywords:
            if kw.arg=='mode' and isinstance(kw.value,ast.Constant) and isinstance(kw.value.value,str):
                modes.append(kw.value.value)
        if any(any(flag in mode for flag in ('w','a','x','+')) for mode in modes):
            mutation_calls.append('open-write')
check('no filesystem mutation primitives in source sensor', not mutation_calls, json.dumps(mutation_calls))

route_expected={
 ('GET','/engineering/status'),
 ('GET','/engineering/source/index'),
 ('GET','/engineering/source/file'),
 ('GET','/engineering/source/symbol'),
 ('POST','/engineering/source/observe'),
}
tree=ast.parse(api)
routes=[]
for node in ast.walk(tree):
    if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
        for dec in node.decorator_list:
            if isinstance(dec,ast.Call) and isinstance(dec.func,ast.Attribute) and dec.args and isinstance(dec.args[0],ast.Constant):
                method=dec.func.attr.upper(); path=dec.args[0].value
                if method in {'GET','POST','PUT','PATCH','DELETE'} and isinstance(path,str) and path.startswith('/engineering'):
                    routes.append((method,path,node.name,ast.get_source_segment(api,node) or ''))
engineering_route_set={(m,p) for m,p,_,_ in routes}
check('exactly five engineering HTTP routes', engineering_route_set==route_expected and len(routes)==5, json.dumps([(m,p,n) for m,p,n,_ in routes]))
check('all engineering routes owner-gated', all('_require_owner(' in src for _,_,_,src in routes))

# Stage-7 compatibility is checked as a preserved subset plus the exact new 8A delta,
# rather than requiring the historical v0.7.6.1 route count to remain frozen forever.
all_routes=[]
for node in ast.walk(tree):
    if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
        for dec in node.decorator_list:
            if isinstance(dec,ast.Call) and isinstance(dec.func,ast.Attribute) and dec.args and isinstance(dec.args[0],ast.Constant):
                method=dec.func.attr.upper(); path=dec.args[0].value
                if method in {'GET','POST','PUT','PATCH','DELETE'} and isinstance(path,str):
                    all_routes.append((method,path))
certified={tuple(x) for x in json.loads((ROOT/'scripts/v0751_certified_api_routes.json').read_text())}
current=set(all_routes); delta=current-certified
room_delta={(m,p) for m,p in delta if p.startswith('/room')}
check('v0.7.5.1 certified 74-route surface preserved', len(certified)==74 and certified.issubset(current))
check('Stage-8A HTTP surface is exactly 98 unique routes', len(all_routes)==len(current)==98)
check('post-v0.7.5.1 delta is exactly 19 Room plus 5 engineering routes', len(delta)==24 and len(room_delta)==19 and engineering_route_set==route_expected)
check('no unexpected non-Room/non-engineering routes added', delta==room_delta|engineering_route_set)
check('engineering observe is authenticated owner-directed', "authenticated owner authority is required for engineering source observation" in orch)
check('engineering observation not native upgrade choice', "'native_upgrade_choice_claim':False" in orch)
check('engineering observation zero write/deployment authority', "'write_authority':False" in orch and "'deployment_authority':False" in orch)
check('engineering observation reports no LLM use', "'llm_used':False" in orch)
check('objective engineering facts enter IRG', "engineering_facts=event.metadata.get('engineering_facts'" in irg)
check('IRG engineering facts carry no-write/deploy modifiers', "'no-write-authority','no-deployment-authority'" in irg)
check('pending provenance test exists', 'provenance-pending-cognitive' in test and 'consolidated is False' in test)
check('unauthenticated observation rejection test exists', 'test_engineering_observation_requires_authenticated_owner' in test)
check('symlink escape regression test exists', 'test_source_index_does_not_follow_symlinks_outside_source_root' in test)

failed=[name for name,ok,_ in checks if not ok]
print(f'\nRESULT {len(checks)-len(failed)}/{len(checks)} PASS')
if failed:
    print('FAILED:',*failed,sep='\n- ')
    raise SystemExit(1)
