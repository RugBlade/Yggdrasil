from __future__ import annotations

import ast
import hashlib
import json
import re
import tomllib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
checks: list[tuple[str, bool]] = []


def check(name: str, ok: object) -> None:
    value = bool(ok)
    checks.append((name, value))
    print(f"{len(checks):03d}. {'PASS' if value else 'FAIL'}: {name}")


def sha(rel: str) -> str:
    return hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()

project = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))["project"]
init = (ROOT / "src/noeron/__init__.py").read_text(encoding="utf-8")
api = (ROOT / "src/noeron/api.py").read_text(encoding="utf-8")
orch = (ROOT / "src/noeron/orchestrator.py").read_text(encoding="utf-8")
models = (ROOT / "src/noeron/math/models.py").read_text(encoding="utf-8")
room_models = (ROOT / "src/noeron/room_models.py").read_text(encoding="utf-8")
eng = (ROOT / "src/noeron/engineering.py").read_text(encoding="utf-8")
composition = (ROOT / "src/noeron/language_composition.py").read_text(encoding="utf-8")
dialogue = (ROOT / "src/noeron/language_dialogue.py").read_text(encoding="utf-8")
egress = (ROOT / "src/noeron/english_egress.py").read_text(encoding="utf-8")
cognitive_models = (ROOT / "src/noeron/cognition/models.py").read_text(encoding="utf-8")

# Runtime/version boundaries ------------------------------------------------
check("outer project version v0.8.2", project["version"] == "0.8.2")
check("outer package version v0.8.2", "__version__ = '0.8.2'" in init)
check("API imports one outer release constant", "from noeron import __version__ as OUTER_RUNTIME_VERSION" in api)
check("FastAPI outer version uses release constant", "version=OUTER_RUNTIME_VERSION" in api.replace(" ", ""))
check("outer runtime surfaces use release constant", "'runtime_version':OUTER_RUNTIME_VERSION" in api.replace(" ", ""))
check("cognition core remains v0.7.5.1", "'runtime_version':'0.7.5.1'" in orch)
check("math interface remains v0.7.3.4", "interface_version: str = '0.7.3.4'" in models)
check("Room subsystem remains v0.7.6.1", "version: str = '0.7.6.1'" in room_models)
check("Room schema remains v0.7.6", "schema_version: str = '0.7.6'" in room_models)
check("Room mechanism remains completion patch", "mechanism_version: str = '0.7.6.1-room-completion-patch'" in room_models)
check("Stage8A engineering mechanism preserved", "0.8.0-stage8A-engineering-source-perception-v1" in eng)
check("Stage8A source sensor remains read only", '"read_only": True' in eng and '"write_authority": False' in eng and '"deployment_authority": False' in eng)
check("preserved Stage8B composition mechanism explicit", "0.8.1-stage8B-composition-v1" in composition)
check("revised Stage8B conversation mechanism explicit", "0.8.2-stage8B-native-conversation-v1" in dialogue)
check("revised Stage8B dialogue mechanism explicit", "0.8.2-stage8B-dialogue-v1" in dialogue)
check("revised Stage8B productive English mechanism explicit", "0.8.2-stage8B-productive-english-v1" in dialogue)
check("revised Stage8B English egress explicit", "0.8.2-stage8B-english-egress-v1" in egress)
migration_start = orch.find("def _migrate_v082_stage8b_conversation")
if migration_start < 0:
    migration_start = orch.find("Prospective v0.8.1 -> v0.8.2")
migration_end = orch.find("def _owner_referent", migration_start)
migration_slice = orch[migration_start:migration_end] if migration_start >= 0 and migration_end > migration_start else ""
check("v0.8.2 migration is explicitly prospective", "prospective" in migration_slice.lower())
check("v0.8.2 migration forbids historical replay", "no historical" in migration_slice.lower())

# Historical audit preservation --------------------------------------------
frozen = {
    "scripts/audit_v081_stage8B_language.py": "fd44555aadd9cfd2df6741c73b418e310a629bdaa2be21c41f1862e6b172b054",
    "scripts/audit_v081_stage8B_release_identity.py": "afc912941d7dd38ea07004c0338ab64c7a8784a110f8fa2a6f754ba73c2998b5",
}
for rel, expected in frozen.items():
    check(f"frozen historical audit byte-preserved: {rel}", sha(rel) == expected)

# Route inventory -----------------------------------------------------------
tree = ast.parse(api)
routes: list[tuple[str, str, str]] = []
websockets: list[tuple[str, str]] = []
for node in ast.walk(tree):
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
        for dec in node.decorator_list:
            if not (isinstance(dec, ast.Call) and isinstance(dec.func, ast.Attribute) and isinstance(dec.func.value, ast.Name) and dec.func.value.id == "app"):
                continue
            if dec.args and isinstance(dec.args[0], ast.Constant) and isinstance(dec.args[0].value, str):
                path = dec.args[0].value
                attr = dec.func.attr.lower()
                if attr in {"get","post","put","delete","patch","options","head"}:
                    routes.append((attr.upper(), path, node.name))
                elif attr == "websocket":
                    websockets.append((path, node.name))
check("current v0.8.2 HTTP route count is reproduced as 104", len(routes) == 104)
check("all v0.8.2 HTTP method/path definitions unique", len({(m, p) for m, p, _ in routes}) == len(routes))
check("one Room WebSocket route preserved", websockets == [("/room/ws", "room_ws")])
engineering_routes = {(m, p) for m, p, _ in routes if p.startswith("/engineering/")}
check("exact five Stage8A engineering routes preserved", engineering_routes == {
    ("GET", "/engineering/status"),
    ("GET", "/engineering/source/index"),
    ("GET", "/engineering/source/file"),
    ("GET", "/engineering/source/symbol"),
    ("POST", "/engineering/source/observe"),
})
required_v082_routes = {
    ("GET", "/language/dialogue/state"),
    ("GET", "/language/capability/audit"),
    ("POST", "/language/structure"),
    ("POST", "/owner/communication/control"),
    ("GET", "/owner/internal-utterance/latest"),
    ("POST", "/room/internal-utterance/control"),
}
check("all revised Stage8B HTTP surfaces present", required_v082_routes.issubset({(m, p) for m, p, _ in routes}))

# Auth/private observation static boundary ----------------------------------
owner_obs = api[api.find("def owner_internal_utterance_latest"):api.find("def owner_verify")]
check("owner internal utterance endpoint fail-closed behind owner auth", "_require_owner(x_noeron_owner_token)" in owner_obs)
room_control = api[api.find("def room_internal_utterance_control"):api.find("def room_file_offer")]
check("Room observation control fail-closed behind Room auth", "_room_auth(request)" in room_control)
check("Room observation control cannot enable response transport", "response_channel_override" not in room_control and "owner_command_channel" not in room_control)
check("Room message does not expose native text as outward fallback", "native_text_exposed_as_outward_fallback':False" in api)
check("native presentation requires express plus native choice plus outward text", "out.communication_action=='express' and out.communication_native_choice_claim and out.text and out.native_text" in api)
check("owner communication controls persist zero relational authority", "relationship_authority: bool = False" in cognitive_models)
check("owner communication controls persist zero cognitive authority", "cognitive_authority: bool = False" in cognitive_models)
check("internal utterance visibility defaults false", "internal_utterance_visibility: bool = False" in cognitive_models)
check("internal utterance translation defaults false", "internal_utterance_translation: bool = False" in cognitive_models)

# Documentation/candidate truth --------------------------------------------
for rel in ("README.md", "RELEASE_COMMIT.txt", "BUILD_PROVENANCE.txt", "LOCAL_CERTIFICATION.txt"):
    text = (ROOT / rel).read_text(encoding="utf-8")
    check(f"{rel} identifies v0.8.2 revised Stage8B", "v0.8.2" in text and ("Stage 8B" in text or "Stage-8B" in text))
    check(f"{rel} records Stage8A live-certified", ("Stage 8A" in text or "Stage-8A" in text) and "live" in text.lower() and "certif" in text.lower())
    check(f"{rel} records v0.8.1 Stage8B certified ancestor", "v0.8.1" in text and "certif" in text.lower())
    check(f"{rel} records official roadmap 7/8", "7/8" in text)
    check(f"{rel} does not self-certify current v0.8.2", any(marker in text.lower() for marker in ("candidate", "pending", "not itself certification evidence", "detached certification")))

check("BUILD_PROVENANCE records exact certified ancestor TAR hash", "21e5d4a6883ce687cfe04e75c10b76a3d642d15567900f567c366399d36a5338" in (ROOT / "BUILD_PROVENANCE.txt").read_text())
check("BUILD_PROVENANCE records frozen v0.8.1 commit", "a69b37876302605e71d96145a555a977e0b219bd" in (ROOT / "BUILD_PROVENANCE.txt").read_text())
check("BUILD_PROVENANCE records frozen v0.8.1 tree", "a1e4436c34edd87fe5592294de21382297d17ad3" in (ROOT / "BUILD_PROVENANCE.txt").read_text())
check("BUILD_PROVENANCE records frozen v0.8.1 tag", "v0.8.1-stage8B-local-certified" in (ROOT / "BUILD_PROVENANCE.txt").read_text())
check("LOCAL_CERTIFICATION explicitly forbids resuming old H5", "H5 was NEVER" in (ROOT / "LOCAL_CERTIFICATION.txt").read_text() and "must not be resumed" in (ROOT / "LOCAL_CERTIFICATION.txt").read_text())

for rel in (".env.example", "deploy/noeron.env.example"):
    text = (ROOT / rel).read_text(encoding="utf-8")
    check(f"{rel} identifies v0.8.2 candidate truth", "Noeron v0.8.2" in text and "candidate" in text.lower())
    check(f"{rel} Stage8A engineering source root documented", "NOERON_ENGINEERING_SOURCE_ROOT=" in text)
    check(f"{rel} engineering byte bound documented", "NOERON_ENGINEERING_MAX_SOURCE_BYTES=300000" in text)
    check(f"{rel} legacy owner bootstrap fail closed", "NOERON_OWNER_LEGACY_TOKEN_ENABLED=false" in text)
    check(f"{rel} Room private transport documented", "loopback/SSH tunnel" in text)

# Source/package hygiene ----------------------------------------------------
forbidden_suffixes = {".sqlite3", ".db", ".pem", ".key", ".p12", ".pfx"}
forbidden_names = {".env", "id_ed25519", "id_rsa"}
files = [p for p in ROOT.rglob("*") if p.is_file() and "__pycache__" not in p.parts and ".pytest_cache" not in p.parts]
check("source tree contains no canonical DB/private-key file types", not any(p.suffix.lower() in forbidden_suffixes or p.name in forbidden_names for p in files))
check("source tree contains no embedded git repository", not (ROOT / ".git").exists())
check("candidate recovery manifest exists", (ROOT / "RECOVERY_CHANGED_FILES.json").is_file())
manifest = json.loads((ROOT / "RECOVERY_CHANGED_FILES.json").read_text(encoding="utf-8"))
check("candidate recovery manifest names exact ancestor hash", manifest["ancestor_sha256"] == "21e5d4a6883ce687cfe04e75c10b76a3d642d15567900f567c366399d36a5338")
check("candidate recovery manifest remains explicitly non-certified", manifest["status"] == "development-candidate-not-certified")
check("candidate recovery manifest explicitly self-excludes its own hash", manifest.get("self_excluded_path") == "RECOVERY_CHANGED_FILES.json" and manifest.get("self_hash_reason") == "self-referential-hash-not-embedded")
check("candidate recovery manifest has 21 externally hashable changed paths", len(manifest["changed_files"]) == 21)
for row in manifest["changed_files"]:
    path = ROOT / row["path"]
    check(f"candidate manifest current hash matches {row['path']}", path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest() == row["candidate_sha256"])

failed = [name for name, ok in checks if not ok]
print(f"\nSUMMARY: {len(checks)-len(failed)}/{len(checks)} PASS")
if failed:
    print("FAILED:", *failed, sep="\n- ")
raise SystemExit(1 if failed else 0)
