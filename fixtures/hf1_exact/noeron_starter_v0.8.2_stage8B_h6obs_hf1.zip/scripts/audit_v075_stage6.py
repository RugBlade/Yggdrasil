from __future__ import annotations

import ast
import inspect
from pathlib import Path

from noeron.orchestrator import Noeron
from noeron.realization import RealizationPolicy
from noeron.cognition.models import LanguageFacultyState

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'src' / 'noeron'

checks: list[tuple[str, bool, str]] = []
def check(name: str, condition: bool, detail: str = '') -> None:
    checks.append((name, bool(condition), detail))

native_files = [
    SRC / 'inference.py', SRC / 'development.py', SRC / 'reasoning.py',
    SRC / 'cognition' / 'kernel.py', SRC / 'math' / 'irg.py',
]
combined = '\n'.join(p.read_text() for p in native_files)
orch = (SRC / 'orchestrator.py').read_text()
api = (SRC / 'api.py').read_text()
web = (SRC / 'perception.py').read_text()
models = (SRC / 'cognition' / 'models.py').read_text()

check('native-language-path-no-noeron-llm-import', 'from noeron.llm import' not in combined and 'import noeron.llm' not in combined)
check('no-renderer-needed-auto-dispatch', 'if utterance.renderer_needed' not in orch and 'not thought.native_utterance.renderer_needed' not in orch)
check('lexical-coverage-not-realization-authority', 'lexical_coverage' not in inspect.getsource(Noeron._realize_output))
realize_src = inspect.getsource(Noeron._realize_output)
check('terra-disabled-no-native-fallback', "if not self.terra_enabled" in realize_src and "return '',False,selection" in realize_src and "effective='native-direct'" not in realize_src)
check('missing-realization-action-executes-none', "if action is None:" in realize_src and "return '',False,selection" in realize_src)
check('operator-override-labelled-calibration', 'operator-directed-calibration-not-native-choice' in realize_src)
choose_src = inspect.getsource(RealizationPolicy.choose)
check('realization-needs-both-affordance-models', 'unresolved-insufficient-realization-consequence-geometry' in choose_src)
check('realization-ties-unresolved', 'unresolved-exact-realization-consequence-tie' in choose_src)
check('stage6-migration-no-history-replay', 'recent_events' not in inspect.getsource(Noeron._migrate_v075_stage6) and 'append_event' not in inspect.getsource(Noeron._migrate_v075_stage6))
check('stage6-migration-no-memory-promotion', 'consolidated=True' not in inspect.getsource(Noeron._migrate_v075_stage6) and 'upsert_knot_memory' not in inspect.getsource(Noeron._migrate_v075_stage6))
check('plural-provenance-schema-present', 'source_memory_ids' in models)
check('per-source-language-confidence-schema-present', 'source_confidences' in models)
reasoning = (SRC / 'reasoning.py').read_text()
check('persistent-premises-intersect-dkt-provenance', 'ids.intersection(retrieved_ids)' in reasoning)
check('persistent-premise-confidence-is-dkt-source-scoped', 'by_source' in reasoning and 'authorized=[float(by_source[mid]) for mid in matched if mid in by_source]' in reasoning)
development = (SRC / 'development.py').read_text()
check('language-propositions-no-fixed-recency-prune', 'propositions[-1024:]' not in development and 'propositions[-512:]' not in development)
check('read-only-language-parse-no-stored-answer-authority', 'this read-only language probe has no DKT retrieval authority' in development)
check('read-only-identity-parse-no-proof-bypass', 'this read-only probe does not bypass the IRG/DKT native proof path' in development and "frame='speaker-identity-question'" in development)
check('unresolved-pronoun-never-literalized', '_resolved_or_literal' in (SRC / 'inference.py').read_text() and 'invented truth' in (SRC / 'inference.py').read_text())
check('discourse-state-no-affection-familiarity-fields', all(x not in LanguageFacultyState.model_fields for x in ('familiarity','affection','closeness','trust')))
check('identity-substrate-separate-from-text-parser', 'authenticated-owner-identity-substrate' not in (SRC / 'inference.py').read_text())
check('owner-name-not-hardcoded-in-native-language-math-path', 'abdelaziz' not in combined.lower())
check('document-observation-links-exact-pending-memory', "source=f'owner-document:{ident.canonical_source_id}',source_memory_id=mem.id" in orch.replace('\n',''))
check('web-language-marked-untrusted', "source=f'public-web-untrusted:{row[\"url\"]}'" in orch.replace('\n',''))
check('web-language-links-exact-pending-memory', 'source_memory_id=mem.id' in orch[orch.find('def web_study'):])
check('web-read-is-get-only-policy', 'GET-only' in web or 'GET only' in web)
check('external-defense-retaliation-disabled', "'external_retaliation_enabled':False" in (SRC / 'security.py').read_text().replace(' ',''))
check('hardcoding-audit-retains-lexical-zero-authority', 'lexical coverage has zero invocation authority' in orch)
check('terra-env-switch-explicit', 'NOERON_TERRA_ENABLED' in (SRC / 'config.py').read_text())
check('language-parse-declared-read-only', "'state_changed':False" in orch.replace(' ',''))
check('math-interface-not-relabelled-stage6', "interface_version: str = '0.7.3.4'" in (SRC / 'math' / 'models.py').read_text())
check('stage6-outer-runtime-version-present', "from noeron import __version__ as OUTER_RUNTIME_VERSION" in api and "version=OUTER_RUNTIME_VERSION" in api.replace(' ','') and "'runtime_version':OUTER_RUNTIME_VERSION" in api.replace(' ',''))
check('stage6-language-grounding-audit-version-coherent', "return {'version':'0.7.5','schema_version':'0.7.5','mechanism_version':'0.7.5'" in orch)
check('document-discourse-source-local', 'study_context:dict[str,str]={}' in orch and "source=f'owner-document:{ident.canonical_source_id}',source_memory_id=mem.id" in orch.replace('\n','') and 'discourse_context=segment_context,advance_discourse=False' in orch)
check('web-discourse-source-local', 'web_context:dict[str,str]={}' in orch and "source=f'public-web-untrusted:{row[\"url\"]}',source_memory_id=mem.id" in orch.replace('\n','') and orch.count('discourse_context=segment_context,advance_discourse=False') >= 2)
check('owner-curriculum-does-not-overwrite-conversation-discourse', 'discourse_context={},advance_discourse=False' in orch)


v061_src = inspect.getsource(Noeron._migrate_v061_geometry)
check('v061-complete-flag-authoritative', 'if self.state.cognition.v061_geometry_migration_complete:' in v061_src and 'compatible_prefixes' not in v061_src)
check('v061-only-exact-legacy-geometry-candidate', "str(m.geometry_version or '')=='legacy-v0.6'" in v061_src)
check('v061-modern-memory-never-upserted-by-prefix-heuristic', "legacy=[m for m in allm if str(m.geometry_version or '')=='legacy-v0.6']" in v061_src and 'compatible_prefixes' not in v061_src)
check('v061-egr-conversion-requires-concrete-legacy-row', "if legacy and not self.state.math_kernel.egr.bridge_name.startswith('chi-log1p-causal-v0.6.')" in v061_src)
v0751_src = inspect.getsource(Noeron._migrate_v0751_restart_preservation)
check('v0751-hotfix-does-not-rewrite-memory-rows', 'upsert_knot_memory' not in v0751_src and 'append_knot_memory' not in v0751_src and 'append_event' not in v0751_src)
restart_audit=(ROOT/'scripts'/'audit_v0751_restart_preservation.py').read_text()
check('v0751-restart-audit-requires-explicit-db-copy', "--db-copy" in restart_audit and "Use only a disposable copy" in restart_audit)
check('v0751-restart-audit-compares-memory-identity-and-core', all(x in restart_audit for x in ('memory_rows_sha256','active_cognitive_ids','core_knot_sha256','second_restart_invariant_changes')))
check('v0751-first-boot-preserves-stage5-subsystem-digests', all(x in restart_audit for x in ('first_boot_subsystem_changes','math_kernel_causal_sha256','memory_retention_state_sha256','owner_relation_state_sha256','realization_state_sha256','initiative_state_sha256','defense_state_sha256')))

# Forward-compatible Stage-7 API audit: preserve the entire certified v0.7.5.1
# HTTP surface as a required subset while separately requiring uniqueness of the
# current API. New Stage-7 routes therefore cannot make a certified Stage-6 route
# disappear, nor can duplicate method/path pairs hide behind a larger route count.
import json
certified_routes={tuple(x) for x in json.loads((ROOT/'scripts'/'v0751_certified_api_routes.json').read_text())}
tree = ast.parse(api)
routes = []
for node in ast.walk(tree):
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
        for dec in node.decorator_list:
            if isinstance(dec, ast.Call) and isinstance(dec.func, ast.Attribute) and dec.func.attr in {'get','post','put','patch','delete'}:
                if dec.args and isinstance(dec.args[0], ast.Constant):
                    routes.append((dec.func.attr.upper(), str(dec.args[0].value)))
current_routes=set(routes)
check('certified-v0751-route-manifest-count-remains-74', len(certified_routes)==74, f'certified={len(certified_routes)}')
check('certified-v0751-api-routes-preserved-as-subset', certified_routes.issubset(current_routes), f'certified={len(certified_routes)}, current={len(routes)}, missing={sorted(certified_routes-current_routes)}')
check('api-routes-unique', len(routes) == len(current_routes), f'unique={len(current_routes)}')

failed = [(n,d) for n,ok,d in checks if not ok]
for i,(name,ok,detail) in enumerate(checks,1):
    suffix = f' — {detail}' if detail else ''
    print(f'{i:02d}. {"PASS" if ok else "FAIL"}: {name}{suffix}')
print(f'SUMMARY: {len(checks)-len(failed)}/{len(checks)} checks passed')
if failed:
    raise SystemExit(1)
