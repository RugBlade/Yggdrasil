from __future__ import annotations

import tempfile
from pathlib import Path

from noeron.language_composition import analyze_surface_composition, COMPOSITION_VERSION, LANGUAGE_MECHANISM_VERSION
from noeron.llm import MockLanguageEngine
from noeron.memory import LocalEventStore
from noeron.orchestrator import Noeron

ROOT = Path(__file__).resolve().parents[1]
checks = []


def check(name, ok):
    checks.append((name, bool(ok)))
    print(f"{len(checks):02d}. {'PASS' if ok else 'FAIL'}: {name}")


src = (ROOT / "src/noeron/language_composition.py").read_text(encoding="utf-8")
dev = (ROOT / "src/noeron/development.py").read_text(encoding="utf-8")
irg = (ROOT / "src/noeron/math/irg.py").read_text(encoding="utf-8")
orch = (ROOT / "src/noeron/orchestrator.py").read_text(encoding="utf-8")
eng = (ROOT / "src/noeron/engineering.py").read_text(encoding="utf-8")

check("composition module has no LLM import", "noeron.llm" not in src and "openai" not in src.lower())
check("composition module has no network import", all(x not in src for x in ("requests", "urllib", "httpx", "socket")))
check("composition module has no subprocess/shell execution", "subprocess" not in src and "os.system" not in src)
probe = analyze_surface_composition("If every test may not pass, then perhaps another test should run because evidence changed.")
check("surface composition declares semantic authority false", probe["semantic_authority"] is False)
check("surface composition declares cognitive-memory authority false", probe["cognitive_memory_authority"] is False)
check("surface composition declares answer-selection authority false", probe["answer_selection_authority"] is False)
check("surface composition declares Terra authority false", probe["terra_authority"] is False)
check("surface composition declares relationship authority false", probe["relationship_authority"] is False)
check("conditional composition present", probe["frame_counts"].get("conditional") == 1)
check("surface causal composition present", probe["frame_counts"].get("causal-because") == 1)
check("temporal composition present", analyze_surface_composition("A happens before B.")["frame_counts"].get("temporal-before") == 1)
check("contrast composition present", analyze_surface_composition("A holds but B differs.")["frame_counts"].get("contrast",0) >= 1)
check("analogy composition present", analyze_surface_composition("A is similar to B.")["frame_counts"].get("analogy") == 1)
check("correction composition present", analyze_surface_composition("Actually A replaces B.")["frame_counts"].get("correction") == 1)
check("uncertainty markers are grammatical diagnostics", analyze_surface_composition("Perhaps A holds.")["frame_counts"].get("uncertainty-marker") == 1)
question_families = [
    analyze_surface_composition(f"{w.capitalize()} is this?")["sentences"][0]["question_family"]
    for w in ("why","how","when","where","who","which","what")
]
check("question frame family present", question_families == [f"{w}-question" for w in ("why","how","when","where","who","which","what")])
quant = analyze_surface_composition("Every A may differ from some B.")
check("quantifier family present", quant["frame_counts"].get("quantifier:universal") == 1 and quant["frame_counts"].get("quantifier:existential") == 1)
check("composition audit integrated into IRG parser", "stage8b_composition" in irg and "analyze_surface_composition" in irg)
check("language interpretation carries composition audit", "composition_audit=composition" in dev)
check("compact persistent frame counts present", "composition_frame_counts" in (ROOT/"src/noeron/cognition/models.py").read_text())
check("last composition audit present", "last_composition_audit" in (ROOT/"src/noeron/cognition/models.py").read_text())
check("Stage8B migration flag present", "v081_stage8b_language_migration_complete" in orch)
check("Stage8B migration is explicitly prospective", "no historical replay" in orch.lower())
check("Stage8B migration does not call all_events", "all_events(" not in orch[orch.find("def _migrate_v081_stage8b_language"):orch.find("def _owner_referent")])
check("Stage8B migration does not call teach/observe_admitted_text", all(x not in orch[orch.find("def _migrate_v081_stage8b_language"):orch.find("def _owner_referent")] for x in (".teach(", "observe_admitted_text(")))
check("Stage8B language mechanism version explicit", LANGUAGE_MECHANISM_VERSION in src)
check("Stage8B composition mechanism version explicit", COMPOSITION_VERSION in src)
check("Stage8A engineering mechanism identity preserved", "0.8.0-stage8A-engineering-source-perception-v1" in eng)
check("Stage8A source write authority remains false", '"write_authority": False' in eng or "'write_authority': False" in eng)
check("Stage8A deployment authority remains false", '"deployment_authority": False' in eng or "'deployment_authority': False" in eng)

with tempfile.TemporaryDirectory() as td:
    td = Path(td)
    y = Noeron(MockLanguageEngine(), LocalEventStore(td/"noeron.sqlite3"), terra_enabled=False, engineering_source_root=str(ROOT))
    st = y.language_state()
    check("runtime language version 0.8.1", st["version"] == "0.8.1")
    check("runtime Stage8B started", st["stage8b_started"] is True)
    check("memory retention mechanism not relabelled", y.state.cognition.memory_retention.mechanism_version == "0.7.4")
    check("initiative mechanism not relabelled", y.state.cognition.initiative_development.mechanism_version == "0.7.4")
    before = y.state.model_dump(mode="json")
    parsed = y.language_parse("Why might every test fail?")
    after = y.state.model_dump(mode="json")
    check("read-only language parse does not change state", before == after)
    check("read-only rich parse has no answer authority", parsed["answer_supported"] is False and parsed["stage8b_composition_audit"]["answer_selection_authority"] is False)
    check("Terra disabled does not remove native composition", y.terra_enabled is False and parsed["stage8b_composition_audit"]["version"] == COMPOSITION_VERSION)

cond = analyze_surface_composition("If A changes, then B changes.")
roles = {x.get("role") for x in cond["sentences"][0]["clauses"]}
check("conditional decomposes into two surface clauses", {"antecedent","consequent"}.issubset(roles))
check("conditional link has surface-only authority", any(x.get("relation")=="conditional" and x.get("authority")=="surface-composition-only" for x in cond["sentences"][0]["links"]))

passed = sum(ok for _, ok in checks)
print(f"SUMMARY: {passed}/{len(checks)} PASS")
raise SystemExit(0 if passed == len(checks) else 1)
