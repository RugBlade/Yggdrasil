from __future__ import annotations

from typing import Protocol

import httpx


class LanguageEngine(Protocol):
    def generate(self, messages: list[dict[str, str]]) -> str: ...


class MockLanguageEngine:
    def generate(self, messages: list[dict[str, str]]) -> str:
        last = messages[-1]["content"]
        return f"Yggdrasil received: {last}"


class LocalOpenAICompatibleEngine:
    """Calls a llama.cpp/vLLM-style OpenAI-compatible Chat Completions endpoint."""

    def __init__(self, base_url: str, model: str, api_key: str) -> None:
        self._base_url = base_url.rstrip("/")
        self._model = model
        self._api_key = api_key

    def generate(self, messages: list[dict[str, str]]) -> str:
        response = httpx.post(
            f"{self._base_url}/chat/completions",
            headers={"Authorization": f"Bearer {self._api_key}"},
            json={
                "model": self._model,
                "messages": messages,
                "temperature": 0.4,
                "max_tokens": 800,
            },
            timeout=180.0,
        )
        response.raise_for_status()
        payload = response.json()
        return payload["choices"][0]["message"]["content"]


class OpenAIResponsesEngine:
    """Calls OpenAI's Responses API while keeping the provider behind LanguageEngine."""

    def __init__(
        self,
        base_url: str,
        model: str,
        api_key: str,
        reasoning_effort: str = "medium",
        max_output_tokens: int = 1200,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._model = model
        self._api_key = api_key
        self._reasoning_effort = reasoning_effort
        self._max_output_tokens = max_output_tokens

    def generate(self, messages: list[dict[str, str]]) -> str:
        system_parts = [m["content"] for m in messages if m.get("role") == "system"]
        user_parts = [m["content"] for m in messages if m.get("role") != "system"]
        body: dict[str, object] = {
            "model": self._model,
            "instructions": "\n\n".join(system_parts),
            "input": "\n\n".join(user_parts),
            "max_output_tokens": self._max_output_tokens,
        }
        if self._reasoning_effort != "none":
            body["reasoning"] = {"effort": self._reasoning_effort}

        response = httpx.post(
            f"{self._base_url}/responses",
            headers={
                "Authorization": f"Bearer {self._api_key}",
                "Content-Type": "application/json",
            },
            json=body,
            timeout=240.0,
        )
        response.raise_for_status()
        payload = response.json()
        text = self._extract_output_text(payload)
        if not text:
            raise ValueError("Responses API returned no output_text content.")
        return text

    @staticmethod
    def _extract_output_text(payload: dict[str, object]) -> str:
        parts: list[str] = []
        for item in payload.get("output", []) or []:
            if not isinstance(item, dict):
                continue
            for content in item.get("content", []) or []:
                if not isinstance(content, dict):
                    continue
                if content.get("type") == "output_text" and isinstance(content.get("text"), str):
                    parts.append(content["text"])
        return "\n".join(parts).strip()
