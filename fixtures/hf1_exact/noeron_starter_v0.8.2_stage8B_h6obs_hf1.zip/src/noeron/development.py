from __future__ import annotations

"""v0.7.5 Stage-6 perspective language grounding and compositional cognition.

This module is deterministic and non-LLM.  DKT semantic prototypes remain the
semantic authority.  The language layer binds observed English surface forms to
those prototypes, stores transparent proposition structure learned from owner-
authorized lessons, parses a small set of inspectable query frames, and can form
native propositions from grounded language memory before Terra is called.

The grammar, proposition parser, reference binding and query composer are
NOERON_EXTENSION computational scaffolds, not claims that natural-language
understanding has been solved.
"""

import re
from copy import deepcopy
from typing import Mapping, Sequence
from uuid import UUID

from noeron.cognition.models import (
    LanguageFacultyState, LanguageInterpretation, LanguageProposition,
    NativeLexeme, NativeProposition, NativeThought, NativeUtterance,
)
from noeron.learning_models import SemanticKnotPrototype
from noeron.math.irg import lexical_root
from noeron.inference import parse_surface_logic_detailed
from noeron.language_composition import (
    COMPOSITION_VERSION, LANGUAGE_MECHANISM_VERSION,
    analyze_surface_composition, merge_frame_counts,
)
from noeron.language_dialogue import (
    CONVERSATION_VERSION, DIALOGUE_VERSION, PRODUCTIVE_ENGLISH_VERSION,
    analyze_dialogue_structure, referent_mentions,
)
from noeron.english_egress import ENGLISH_EGRESS_VERSION

_WORD_RE=re.compile(r"[A-Za-z]+(?:[-'][A-Za-z]+)*")
_SENTENCE_RE=re.compile(r"(?<=[.!?])\s+|\n+")
_FUNCTION_WORDS={
    'a','an','the','i','you','he','she','it','we','they','this','that','these','those',
    'am','is','are','was','were','be','been','being','do','does','did','have','has','had',
    'and','or','but','if','then','because','since','therefore','so','not','no','yes','of',
    'to','from','in','on','at','by','with','for','as','about','into','through','before',
    'after','what','why','how','when','where','which','who','can','could','may','might',
    'will','would','should','must','my','your','his','her','our','their','its'
}


def _words(text:str)->list[str]:
    return [x.lower() for x in _WORD_RE.findall(text)]


def _frame(sentence:str)->str:
    low=sentence.lower().strip()
    if not low:return 'empty'
    if sentence.rstrip().endswith('?'):return 'question'
    if any(x in low for x in (' because ',' since ',' therefore ',' hence ',' thus ')):return 'causal'
    if re.search(r"\b(not|never|no)\b",low):return 'negation'
    if re.search(r"\b(is|are|was|were|be|am)\b",low):return 'copular-declarative'
    return 'declarative'


def _roles(word:str)->list[str]:
    if word in {'a','an','the'}:return ['determiner']
    if word in {'and','or','but'}:return ['conjunction']
    if word in {'because','since','therefore','so'}:return ['discourse-relation']
    if word in {'not','no','never'}:return ['negation']
    if word in {'i','you','he','she','it','we','they','this','that','these','those'}:return ['reference']
    if word in {'is','are','was','were','am','be','been','being'}:return ['copula']
    if word in {'what','why','how','when','where','which','who'}:return ['interrogative']
    if word in {'can','could','may','might','will','would','should','must'}:return ['modality']
    if word.endswith('ing') or word.endswith('ed'):return ['predicate-candidate']
    return ['content-word']


def _find_proto(word:str,prototypes:Mapping[str,SemanticKnotPrototype]):
    low=word.lower().strip()
    root=lexical_root(low)
    return prototypes.get(low) or prototypes.get(root)


def _concept_for_surface(surface:str,state:LanguageFacultyState,prototypes:Mapping[str,SemanticKnotPrototype])->str:
    low=surface.lower().strip()
    lx=state.lexicon.get(low)
    if lx and lx.concept_term and not lx.concept_term.startswith('grammar:'):
        return lx.concept_term
    p=_find_proto(low,prototypes)
    if p is not None:return p.term
    return lexical_root(low)


def _strip_det(text:str)->str:
    return re.sub(r'^(?:a|an|the)\s+','',text.strip(),flags=re.I).strip()


class NativeLanguageFaculty:
    """Deterministic developmental English faculty with DKT grounding."""

    def seed_from_semantics(self,state:LanguageFacultyState,prototypes:Mapping[str,SemanticKnotPrototype])->LanguageFacultyState:
        out=deepcopy(state)
        # Any non-retired observed DKT prototype can ground a surface form.  There
        # is no authored maturity threshold at which a word suddenly gains meaning.
        active={k:p for k,p in prototypes.items() if not p.status.startswith('perception-retired')}
        for key,lx in list(out.lexicon.items()):
            p=_find_proto(key,active)
            if p is not None and lx.status not in {'functional-scaffold','reference-grounded'}:
                lx.concept_term=p.term; lx.status='concept-grounded'
                lx.confidence=float(p.context_coherence or 0.0)
                lx.source=lx.source or 'DKT semantic prototype'; out.lexicon[key]=lx
        for term,p in active.items():
            surface=term.replace('-',' '); key=surface.lower()
            if key not in out.lexicon:
                out.lexicon[key]=NativeLexeme(surface=surface,concept_term=term,observations=max(1,p.observations),
                    confidence=float(p.context_coherence or 0.0),status='concept-grounded',grammatical_roles=['content-word'],source='DKT semantic prototype')
        for w in sorted(_FUNCTION_WORDS):
            if w not in out.lexicon:
                out.lexicon[w]=NativeLexeme(surface=w,concept_term=f'grammar:{w}',observations=1,confidence=0.55,
                    status='functional-scaffold',grammatical_roles=_roles(w),source='v0.6.9 bootstrap grammar scaffold')
        # Preserve the explicit developmental references learned in lesson 001.
        if out.referents.get('i'):
            out.lexicon['i']=NativeLexeme(surface='i',concept_term=out.referents['i'],observations=max(1,out.lexicon.get('i',NativeLexeme(surface='i')).observations),confidence=0.92,status='reference-grounded',grammatical_roles=['reference'],source='learned reference binding')
        if out.referents.get('you'):
            out.lexicon['you']=NativeLexeme(surface='you',concept_term=out.referents['you'],observations=max(1,out.lexicon.get('you',NativeLexeme(surface='you')).observations),confidence=0.90,status='reference-grounded',grammatical_roles=['reference'],source='learned reference binding')
        for prop in out.propositions:
            if prop.source_memory_id is not None and prop.source_memory_id not in prop.source_memory_ids:
                prop.source_memory_ids.append(prop.source_memory_id)
            # Legacy rows did not retain parser support per provenance source. Seed
            # their known source IDs with the historical row confidence without
            # changing memory activation or replaying any event.
            if not prop.source_confidences:
                for mid in prop.source_memory_ids:
                    prop.source_confidences[str(mid)]=float(prop.confidence)
        if out.v082_stage8b_started:
            out.version='0.8.2'; out.schema_version='0.8.2'; out.mechanism_version=CONVERSATION_VERSION
            out.composition_version=COMPOSITION_VERSION
            out.conversation_version=CONVERSATION_VERSION
            out.dialogue_version=DIALOGUE_VERSION
            out.productive_english_version=PRODUCTIVE_ENGLISH_VERSION
            out.english_egress_version=ENGLISH_EGRESS_VERSION
            out.dialogue.version='0.8.2'; out.dialogue.mechanism_version=DIALOGUE_VERSION
            out.note='Revised Stage-8B productive conversation substrate with DKT-gated proposition authority; parser/dialogue/English egress have zero truth/answer/memory/relationship/Terra authority.'
        elif out.v081_stage8b_started:
            out.version='0.8.1'; out.schema_version='0.8.1'; out.mechanism_version=LANGUAGE_MECHANISM_VERSION
            out.composition_version=COMPOSITION_VERSION
            out.note='Stage-8B rich transparent compositional native-language substrate with DKT-gated proposition authority; grammar has zero truth/answer/memory/Terra authority.'
        else:
            out.version='0.7.5'; out.schema_version='0.7.5'; out.mechanism_version='0.7.5'
        out.native_expression_enabled=True
        return out

    @staticmethod
    def discourse_context(state:LanguageFacultyState)->dict[str,str]:
        """Return grammatical working context only; no proposition truth is stored here."""
        return {
            'last_subject':state.discourse_last_subject,
            'last_direct_object':state.discourse_last_direct_object,
            'last_oblique_object':state.discourse_last_oblique_object,
        }

    @staticmethod
    def _apply_discourse_audit(state:LanguageFacultyState,audit:dict)->None:
        state.discourse_last_subject=str(audit.get('last_subject') or '')
        state.discourse_last_direct_object=str(audit.get('last_direct_object') or '')
        state.discourse_last_oblique_object=str(audit.get('last_oblique_object') or '')
        mentions=[str(x.get('entity') or '') for x in (audit.get('mentions') or []) if isinstance(x,dict) and x.get('entity')]
        if mentions:
            state.discourse_recent_mentions=(state.discourse_recent_mentions+mentions)[-24:]
        state.discourse_last_resolution_status=str(audit.get('resolution_status') or 'no-reference-resolution-needed')
        state.discourse_turn+=1

    @staticmethod
    def _prop_key(prop:LanguageProposition)->tuple:
        return (prop.subject_concept,prop.relation,prop.object_concept,bool(prop.polarity),bool(prop.universal),prop.modality)

    def _merge_prop(self,state:LanguageFacultyState,prop:LanguageProposition)->None:
        if prop.source_memory_id is not None and prop.source_memory_id not in prop.source_memory_ids:
            prop.source_memory_ids.append(prop.source_memory_id)
        if prop.source_memory_id is not None:
            prop.source_confidences.setdefault(str(prop.source_memory_id),float(prop.confidence))
        existing=next((x for x in state.propositions if self._prop_key(x)==self._prop_key(prop)),None)
        if existing is None:
            state.propositions.append(prop)
            return
        existing.observations+=1
        existing.confidence=min(0.98,0.70*existing.confidence+0.30*prop.confidence)
        existing.source=prop.source or existing.source
        if prop.source_memory_id is not None:
            existing.source_memory_id=prop.source_memory_id  # compatibility/current pointer only
        for mid in prop.source_memory_ids:
            if mid not in existing.source_memory_ids: existing.source_memory_ids.append(mid)
        for mid,value in prop.source_confidences.items():
            existing.source_confidences.setdefault(str(mid),float(value))
        existing.modifiers=list(dict.fromkeys(existing.modifiers+prop.modifiers))

    def _logic_language_props(self,text:str,state:LanguageFacultyState,prototypes:Mapping[str,SemanticKnotPrototype],source:str,source_memory_id:UUID|None,*,discourse_context:Mapping[str,object]|None=None):
        # A caller may supply a source-local grammatical context (document/web/lesson).
        # This prevents unrelated channels from borrowing conversational pronoun focus.
        context=self.discourse_context(state) if discourse_context is None else discourse_context
        logical,_query,audit=parse_surface_logic_detailed(text,context)
        rows=[]
        for lp in logical:
            # Runtime identity substrate is injected later by IRG and never enters this
            # text-only parser, so persisted discourse propositions remain tied to the
            # admitted linguistic event rather than infrastructure identity facts.
            subj=lp.subject;obj=lp.object
            sp=_find_proto(subj,prototypes);op=_find_proto(obj,prototypes)
            rows.append(LanguageProposition(
                subject_surface=subj,subject_concept=_concept_for_surface(subj,state,prototypes),
                relation=lp.relation,object_surface=obj,object_concept=_concept_for_surface(obj,state,prototypes),
                polarity=lp.polarity,universal=lp.universal,modality=lp.modality,modifiers=list(lp.modifiers),
                confidence=lp.confidence,source=source,source_memory_id=source_memory_id,
                source_memory_ids=([source_memory_id] if source_memory_id is not None else []),
                source_confidences=({str(source_memory_id):float(lp.confidence)} if source_memory_id is not None else {}),
                subject_knot_signature=(sp.knot.invariant_signature if sp else ''),
                object_knot_signature=(op.knot.invariant_signature if op else ''),
            ))
        return rows,audit

    def observe_admitted_text(self,text:str,state:LanguageFacultyState,prototypes:Mapping[str,SemanticKnotPrototype],*,source:str,source_memory_id:UUID,discourse_context:Mapping[str,object]|None=None,advance_discourse:bool=True)->LanguageFacultyState:
        """Observe admitted language as provenance-linked structure, never as memory authority.

        The caller supplies the exact event/study/web provenance memory ID.  The
        resulting proposition rows remain non-cognitive until that source is active
        in DKT retrieval.  Discourse state records only grammatical referent focus.
        """
        out=self.seed_from_semantics(state,prototypes)
        for w in _words(text):
            proto=_find_proto(w,prototypes); old=out.lexicon.get(w)
            if old is None:
                if proto is not None:
                    old=NativeLexeme(surface=w,concept_term=proto.term,observations=0,confidence=float(proto.context_coherence or 0.0),status='concept-grounded',grammatical_roles=_roles(w),source=source)
                elif w in _FUNCTION_WORDS:
                    old=NativeLexeme(surface=w,concept_term=f'grammar:{w}',observations=0,confidence=0.45,status='functional-scaffold',grammatical_roles=_roles(w),source=source)
                else:
                    old=NativeLexeme(surface=w,concept_term='',observations=0,confidence=0.18,status='surface-ungrounded',grammatical_roles=_roles(w),source=source)
            old.observations+=1
            if proto is not None:
                old.concept_term=proto.term;old.status='concept-grounded';old.confidence=float(proto.context_coherence or old.confidence)
            old.source=source;out.lexicon[w]=old
        rows,audit=self._logic_language_props(text,out,prototypes,source,source_memory_id,discourse_context=discourse_context)
        for row in rows:self._merge_prop(out,row)
        if advance_discourse:self._apply_discourse_audit(out,audit)
        composition=analyze_surface_composition(text)
        if out.v081_stage8b_started:
            out.composition_version=COMPOSITION_VERSION
            out.composition_frame_counts=merge_frame_counts(out.composition_frame_counts,composition)
            out.last_composition_audit=composition
        out.sentences_observed+=len([x for x in _SENTENCE_RE.split(text.strip()) if x.strip()])
        if out.v082_stage8b_started:
            out.version='0.8.2';out.schema_version='0.8.2';out.mechanism_version=CONVERSATION_VERSION
        elif out.v081_stage8b_started:
            out.version='0.8.1';out.schema_version='0.8.1';out.mechanism_version=LANGUAGE_MECHANISM_VERSION
        else:
            out.version='0.7.5';out.schema_version='0.7.5';out.mechanism_version='0.7.5'
        return out

    def dialogue_structure(self,text:str,state:LanguageFacultyState,*,speaker:str='external:unknown',addressee:str='interlocutor:self')->dict:
        """Read-only Stage-8B conversation analysis; does not advance working state."""
        return analyze_dialogue_structure(
            text,lexicon=state.lexicon,
            recent_referents=[x.model_dump(mode='python') for x in state.dialogue.recent_referents],
            legacy_context={**self.discourse_context(state),'speaker':speaker,'addressee':addressee},
            speaker=speaker,addressee=addressee,
        )

    def advance_dialogue(self,text:str,state:LanguageFacultyState,*,speaker:str='external:unknown',addressee:str='interlocutor:self')->LanguageFacultyState:
        """Advance bounded noncognitive dialogue context for one admitted live turn."""
        from noeron.cognition.models import DialogueReferent, DialogueTurnRecord
        out=self.seed_from_semantics(state,{}) if not state.v082_stage8b_started else deepcopy(state)
        analysis=self.dialogue_structure(text,out,speaker=speaker,addressee=addressee)
        d=out.dialogue; d.started_prospectively=True; d.turn+=1
        qfamilies=list(analysis.get('question_families') or [])
        d.question_under_discussion=(qfamilies[-1] if qfamilies else '')
        content=[x for x in _words(text) if x not in _FUNCTION_WORDS]
        if content:d.current_topic=content[0]
        for row in referent_mentions(analysis):
            d.recent_referents.append(DialogueReferent(surface=str(row.get('surface') or ''),role=str(row.get('role') or ''),kind=str(row.get('kind') or 'unknown'),turn=d.turn))
        d.recent_referents=d.recent_referents[-max(1,d.max_referents):]
        d.last_structure=analysis
        d.last_ambiguities=list(analysis.get('ambiguities') or [])[-24:]
        d.last_lexical_gaps=list(analysis.get('lexical_gaps') or [])[-48:]
        refs=list(analysis.get('reference_candidates') or [])
        if any(str(x.get('status') or '').startswith('ambiguous') for x in refs):d.last_reference_status='ambiguous-alternatives-preserved'
        elif any(str(x.get('status') or '').startswith('unresolved') for x in refs):d.last_reference_status='unresolved-reference'
        elif refs:d.last_reference_status='resolved-reference-candidates'
        else:d.last_reference_status='no-reference-needed'
        d.recent_turns.append(DialogueTurnRecord(
            turn=d.turn,speaker=speaker,text_sha256=str(analysis.get('text_sha256') or ''),surface_excerpt=text[:300],
            question_families=qfamilies,topic_candidate=d.current_topic,
            ambiguity_count=len(d.last_ambiguities),lexical_gap_count=len(d.last_lexical_gaps),
        ))
        d.recent_turns=d.recent_turns[-max(1,d.max_turns):]
        out.v082_stage8b_started=True
        out.version='0.8.2';out.schema_version='0.8.2';out.mechanism_version=CONVERSATION_VERSION
        out.conversation_version=CONVERSATION_VERSION;out.dialogue_version=DIALOGUE_VERSION
        out.productive_english_version=PRODUCTIVE_ENGLISH_VERSION;out.english_egress_version=ENGLISH_EGRESS_VERSION
        return out

    def preview_teaching(self,text:str,state:LanguageFacultyState,prototypes:Mapping[str,SemanticKnotPrototype])->dict:
        sentences=[s.strip() for s in _SENTENCE_RE.split(text.strip()) if s.strip()]
        known=set(state.lexicon); grounded=[]; new=[]; frames={}
        for s in sentences:
            fr=_frame(s); frames[fr]=frames.get(fr,0)+1
            for w in _words(s):
                if w in known or _find_proto(w,prototypes) is not None: grounded.append(w)
                else:new.append(w)
        composition=analyze_surface_composition(text)
        return {'status':'read-only-preview','language':'English','sentences':len(sentences),'grammar_frames':frames,
            'known_or_groundable_words':sorted(set(grounded)),'new_surface_words':sorted(set(new)),
            'proposition_candidates':[x.model_dump(mode='json') for x in self._extract_propositions(sentences,state,prototypes,'preview',None)],
            'stage8b_composition_audit':composition,
            'note':'Preview only. DKT prototypes are semantic authority; Stage-8B composition is transparent grammatical substrate with zero answer authority.'}

    def _extract_propositions(self,sentences:list[str],state:LanguageFacultyState,prototypes:Mapping[str,SemanticKnotPrototype],source:str,source_memory_id:UUID|None)->list[LanguageProposition]:
        out=[]
        for raw in sentences:
            s=raw.strip().rstrip('.!?').strip(); low=s.lower()
            # Developmental reference grounding from the supplied lesson; no owner name is built into the grammar.
            m=re.match(r'^(i|you)\s+(?:am|are)\s+([A-Za-z][A-Za-z-]*)$',low,re.I)
            if m:
                subj=m.group(1).lower(); obj=m.group(2).lower()
                out.append(LanguageProposition(subject_surface=subj,subject_concept=f'reference:{subj}',relation='is',object_surface=obj,
                    object_concept=f'identity:{obj}',confidence=0.96,source=source,source_memory_id=source_memory_id))
                continue
            # A question asks for information.
            m=re.match(r'^(?:a|an|the)\s+([A-Za-z-]+)\s+([A-Za-z-]+)\s+for\s+(?:(?:a|an|the)\s+)?([A-Za-z-]+)$',low,re.I)
            if m:
                subj,verb,obj=m.groups(); sc=_concept_for_surface(subj,state,prototypes); oc=_concept_for_surface(obj,state,prototypes)
                sp=_find_proto(subj,prototypes); op=_find_proto(obj,prototypes)
                out.append(LanguageProposition(subject_surface=subj,subject_concept=sc,relation=f'{verb.lower()}-for',object_surface=obj,object_concept=oc,
                    confidence=0.88,source=source,source_memory_id=source_memory_id,
                    subject_knot_signature=(sp.knot.invariant_signature if sp else ''),object_knot_signature=(op.knot.invariant_signature if op else '')))
                continue
            # A word can name a concept. / A sentence can express a thought.
            m=re.match(r'^(?:a|an|the)\s+([A-Za-z-]+)\s+can\s+([A-Za-z-]+)\s+(?:(?:a|an|the)\s+)?([A-Za-z-]+)$',low,re.I)
            if m:
                subj,verb,obj=m.groups(); sp=_find_proto(subj,prototypes); op=_find_proto(obj,prototypes)
                out.append(LanguageProposition(subject_surface=subj,subject_concept=_concept_for_surface(subj,state,prototypes),relation=f'can-{lexical_root(verb)}',
                    object_surface=obj,object_concept=_concept_for_surface(obj,state,prototypes),confidence=0.86,source=source,source_memory_id=source_memory_id,
                    subject_knot_signature=(sp.knot.invariant_signature if sp else ''),object_knot_signature=(op.knot.invariant_signature if op else '')))
                continue
            # This is a statement.
            m=re.match(r'^(this)\s+is\s+(?:(?:a|an|the)\s+)?([A-Za-z-]+)$',low,re.I)
            if m:
                obj=m.group(2); op=_find_proto(obj,prototypes)
                out.append(LanguageProposition(subject_surface='this',subject_concept='reference:this',relation='is',object_surface=obj,
                    object_concept=_concept_for_surface(obj,state,prototypes),confidence=0.72,source=source,source_memory_id=source_memory_id,
                    object_knot_signature=(op.knot.invariant_signature if op else '')))
        return out

    def teach(self,text:str,state:LanguageFacultyState,prototypes:Mapping[str,SemanticKnotPrototype],source:str='owner-language-curriculum',source_memory_id:UUID|None=None,*,discourse_context:Mapping[str,object]|None=None,advance_discourse:bool=True)->LanguageFacultyState:
        out=self.seed_from_semantics(state,prototypes)
        sentences=[s.strip() for s in _SENTENCE_RE.split(text.strip()) if s.strip()]
        # First observe surface forms and bind any available DKT concept even when it is still emerging.
        for s in sentences:
            fr=_frame(s); out.grammar_frames[fr]=out.grammar_frames.get(fr,0)+1
            for w in _words(s):
                p=_find_proto(w,prototypes); old=out.lexicon.get(w)
                if old is None:
                    if p is not None:
                        status='concept-grounded'
                        old=NativeLexeme(surface=w,concept_term=p.term,observations=0,confidence=float(p.context_coherence or 0.0),status=status,grammatical_roles=_roles(w),source=source)
                    elif w in _FUNCTION_WORDS:
                        old=NativeLexeme(surface=w,concept_term=f'grammar:{w}',observations=0,confidence=0.45,status='functional-scaffold',grammatical_roles=_roles(w),source=source)
                    else:
                        old=NativeLexeme(surface=w,concept_term='',observations=0,confidence=0.18,status='surface-ungrounded',grammatical_roles=_roles(w),source=source)
                old.observations+=1; old.confidence=min(0.98,old.confidence+0.08*(1.0-old.confidence))
                if p is not None:
                    old.concept_term=p.term; old.status='concept-grounded'; old.confidence=float(p.context_coherence or old.confidence)
                old.source=source; out.lexicon[w]=old
        # Learn explicit self/owner references from the lesson rather than hard-coding a name pair.
        for s in sentences:
            low=s.lower().strip().rstrip('.!?')
            m=re.match(r'^i\s+am\s+([A-Za-z][A-Za-z-]*)$',low)
            if m: out.referents['i']=f'identity:{m.group(1)}'; out.referents[m.group(1)]=f'identity:{m.group(1)}'
            m=re.match(r'^you\s+are\s+([A-Za-z][A-Za-z-]*)$',low)
            if m: out.referents['you']=f'owner:{m.group(1)}'; out.referents[m.group(1)]=f'owner:{m.group(1)}'
        out=self.seed_from_semantics(out,prototypes)
        # Store transparent compositional propositions, merging repeated observations.
        learned=self._extract_propositions(sentences,out,prototypes,source,source_memory_id)
        for prop in learned:self._merge_prop(out,prop)
        generic,audit=self._logic_language_props(text,out,prototypes,source,source_memory_id,discourse_context=discourse_context)
        for prop in generic:self._merge_prop(out,prop)
        if advance_discourse:self._apply_discourse_audit(out,audit)
        composition=analyze_surface_composition(text)
        if out.v081_stage8b_started:
            out.composition_version=COMPOSITION_VERSION
            out.composition_frame_counts=merge_frame_counts(out.composition_frame_counts,composition)
            out.last_composition_audit=composition
        out.lessons_observed+=1; out.sentences_observed+=len(sentences)
        if out.v082_stage8b_started:
            out.version='0.8.2'; out.schema_version='0.8.2'; out.mechanism_version=CONVERSATION_VERSION
        elif out.v081_stage8b_started:
            out.version='0.8.1'; out.schema_version='0.8.1'; out.mechanism_version=LANGUAGE_MECHANISM_VERSION
        else:
            out.version='0.7.5'; out.schema_version='0.7.5'; out.mechanism_version='0.7.5'
        return out

    def migrate_existing_lesson(self,text:str,state:LanguageFacultyState,prototypes:Mapping[str,SemanticKnotPrototype],source:str,source_memory_id:UUID|None)->LanguageFacultyState:
        """Re-ground a pre-v0.6.8 lesson without counting it as a new experience."""
        out=self.seed_from_semantics(state,prototypes)
        sentences=[s.strip() for s in _SENTENCE_RE.split(text.strip()) if s.strip()]
        for w in _words(text):
            p=_find_proto(w,prototypes); old=out.lexicon.get(w)
            if old is not None and p is not None and old.status!='functional-scaffold':
                old.concept_term=p.term
                old.status='concept-grounded'
                old.confidence=float(p.context_coherence or old.confidence); out.lexicon[w]=old
        for sentence in sentences:
            low=sentence.lower().strip().rstrip('.!?')
            m=re.match(r'^i\s+am\s+([A-Za-z][A-Za-z-]*)$',low)
            if m: out.referents['i']=f'identity:{m.group(1)}'; out.referents[m.group(1)]=f'identity:{m.group(1)}'
            m=re.match(r'^you\s+are\s+([A-Za-z][A-Za-z-]*)$',low)
            if m: out.referents['you']=f'owner:{m.group(1)}'; out.referents[m.group(1)]=f'owner:{m.group(1)}'
        learned=self._extract_propositions(sentences,out,prototypes,source,source_memory_id)
        for prop in learned:
            if not any((x.subject_concept,x.relation,x.object_concept)==(prop.subject_concept,prop.relation,prop.object_concept) for x in out.propositions):
                out.propositions.append(prop)
        return self.seed_from_semantics(out,prototypes)

    def interpret(self,text:str,state:LanguageFacultyState,prototypes:Mapping[str,SemanticKnotPrototype],*,speaker_referent:str='',addressee_referent:str='',authorized_propositions:Sequence[LanguageProposition]|None=None)->LanguageInterpretation:
        """Interpret an incoming utterance with explicit conversational perspective.

        ``speaker_referent`` and ``addressee_referent`` are supplied by the authenticated
        interaction boundary.  Therefore English ``I``/``you`` are not globally bound
        constants; they resolve according to who is speaking.
        """
        composition=analyze_surface_composition(text)
        words=_words(text); low=' '.join(words)
        grounded={}
        for w in words:
            if w in {'i','me','my'} and speaker_referent:
                grounded[w]=speaker_referent; continue
            if w in {'you','your'} and addressee_referent:
                grounded[w]=addressee_referent; continue
            lx=state.lexicon.get(w); p=_find_proto(w,prototypes)
            if lx and lx.concept_term:grounded[w]=lx.concept_term
            elif p is not None:grounded[w]=p.term

        # "What is a question?" -> definition-query(target=question).
        m=re.match(r'^what\s+is\s+(?:a\s+|an\s+|the\s+)?([a-z-]+)$',low)
        if m:
            surface=m.group(1); concept=_concept_for_surface(surface,state,prototypes)
            stored=[p for p in state.propositions if p.subject_concept==concept or lexical_root(p.subject_surface)==lexical_root(surface)]
            allowed=list(authorized_propositions or [])
            candidates=[p for p in allowed if p.subject_concept==concept or lexical_root(p.subject_surface)==lexical_root(surface)]
            candidates=sorted(candidates,key=lambda p:(-p.confidence,-p.observations))
            if candidates:
                p=candidates[0]; rel=p.relation.replace('-',' ')
                subj=('A '+p.subject_surface) if p.subject_surface.lower() not in {'i','you','this'} else p.subject_surface.capitalize()
                native=NativeProposition(subject=subj,relation=rel,object=p.object_surface,
                    grounds=[f'grounded target={concept}',f'DKT-authorized language proposition={p.id}',f'source memory={p.source_memory_id or "none"}',
                        f'subject DKT prototype={p.subject_knot_signature or "unavailable"}',f'object DKT prototype={p.object_knot_signature or "unavailable"}'],
                    epistemic_status='dkt-authorized-language-proposition',confidence=p.confidence)
                return LanguageInterpretation(input_text=text,composition_audit=composition,frame='definition-question',target_surface=surface,target_concept=concept,
                    grounded_terms=grounded,matched_proposition_ids=[p.id],source_memory_ids=([p.source_memory_id] if p.source_memory_id else []),confidence=p.confidence,
                    answer_supported=True,native_proposition=native,note='Answer support is restricted to propositions explicitly supplied by DKT-authorized retrieval.')
            return LanguageInterpretation(input_text=text,composition_audit=composition,frame='definition-question',target_surface=surface,target_concept=concept,grounded_terms=grounded,
                matched_proposition_ids=[p.id for p in stored],confidence=0.25,answer_supported=False,
                note=('Stored proposition candidates exist, but this read-only language probe has no DKT retrieval authority and therefore cannot claim an answer.' if stored else 'No DKT-authorized language proposition supports this definition query.'))

        # Modal object query: "What can a sentence express?" interrogates the object
        # slot of a learned proposition sentence --can-express--> thought.
        m=re.match(r'^what\s+can\s+(?:a\s+|an\s+|the\s+)?([a-z-]+)\s+([a-z-]+)$',low)
        if m:
            subject_surface,verb=m.groups(); subject_concept=_concept_for_surface(subject_surface,state,prototypes); relation=f'can-{lexical_root(verb)}'
            stored=[p for p in state.propositions if (p.subject_concept==subject_concept or lexical_root(p.subject_surface)==lexical_root(subject_surface)) and p.relation==relation]
            allowed=list(authorized_propositions or [])
            candidates=[p for p in allowed if (p.subject_concept==subject_concept or lexical_root(p.subject_surface)==lexical_root(subject_surface)) and p.relation==relation]
            candidates=sorted(candidates,key=lambda p:(-p.confidence,-p.observations))
            if candidates:
                p=candidates[0]; native=NativeProposition(subject='A '+p.subject_surface,relation=p.relation.replace('-',' '),object=p.object_surface,
                    grounds=[f'grounded subject={subject_concept}',f'queried relation={relation}',f'DKT-authorized language proposition={p.id}',f'source memory={p.source_memory_id or "none"}'],
                    epistemic_status='dkt-authorized-language-proposition',confidence=p.confidence)
                return LanguageInterpretation(input_text=text,composition_audit=composition,frame='modal-object-question',target_surface=subject_surface,target_concept=subject_concept,
                    grounded_terms=grounded,matched_proposition_ids=[p.id],source_memory_ids=([p.source_memory_id] if p.source_memory_id else []),confidence=p.confidence,answer_supported=True,native_proposition=native,note='Answer support is restricted to propositions explicitly supplied by DKT-authorized retrieval.')
            return LanguageInterpretation(input_text=text,composition_audit=composition,frame='modal-object-question',target_surface=subject_surface,target_concept=subject_concept,grounded_terms=grounded,
                matched_proposition_ids=[p.id for p in stored],confidence=0.25,answer_supported=False,
                note=('Stored proposition candidates exist, but this read-only language probe has no DKT retrieval authority and therefore cannot claim an answer.' if stored else 'No DKT-authorized language proposition supports this modal query.'))

        # Perspective-sensitive identity questions.  Incoming "I" denotes the speaker,
        # incoming "you" denotes the addressee.
        if low in {'who are you','who is yggdrasil'} and addressee_referent:
            return LanguageInterpretation(input_text=text,composition_audit=composition,frame='identity-question',target_surface='you',target_concept=addressee_referent,grounded_terms=grounded,confidence=0.96,answer_supported=False,native_proposition=None,note='Perspective-sensitive factual referent binding is available as substrate, but this read-only probe does not bypass the IRG/DKT native proof path to claim an identity answer.')
        if low=='who am i' and speaker_referent:
            return LanguageInterpretation(input_text=text,composition_audit=composition,frame='speaker-identity-question',target_surface='i',target_concept=speaker_referent,grounded_terms=grounded,confidence=0.96,answer_supported=False,native_proposition=None,note='Authenticated speaker identity is factual substrate, but this read-only probe does not bypass the IRG/DKT native proof path to claim an identity answer.')
        return LanguageInterpretation(input_text=text,composition_audit=composition,frame='unparsed',grounded_terms=grounded,confidence=0.0,answer_supported=False)

    def realize(self,thought:NativeThought,state:LanguageFacultyState)->NativeUtterance:
        clauses=[]; frames=[]
        for p in thought.propositions:
            clauses.append(f'{p.subject.strip()} {p.relation.strip()} {p.object.strip()}.'); frames.append('subject-relation-object')
        for q in thought.question_candidates:
            text=q.strip()
            if text:
                clauses.append(text if text.endswith('?') else text+'?'); frames.append('native-open-question')
        native=' '.join(c for c in clauses if c.strip()).strip() or thought.statement.strip()
        words=_words(native); known=0; concepts=[]
        for w in words:
            lx=state.lexicon.get(w)
            if lx is not None and lx.status!='surface-ungrounded':
                known+=1
                if lx.concept_term and not lx.concept_term.startswith('grammar:') and lx.concept_term not in concepts:concepts.append(lx.concept_term)
        coverage=(known/len(words)) if words else 1.0
        # Renderer invocation is transport/surface infrastructure, never a cognitive
        # preference.  Native content is already fixed; Terra is needed only when
        # the native lexicon does not cover every emitted surface token.
        fluency=coverage
        return NativeUtterance(native_text=native,utterance_plan=clauses,grammar_frames=frames,concept_terms=concepts,lexical_coverage=coverage,
            fluency_score=fluency,renderer_needed=False,lexical_coverage_complete=(not words or known==len(words)),renderer_role='Terra availability is infrastructure only; lexical coverage has zero invocation authority; tool use is selected separately by learned consequence geometry and missing/unavailable execution never falls back to native-direct')
