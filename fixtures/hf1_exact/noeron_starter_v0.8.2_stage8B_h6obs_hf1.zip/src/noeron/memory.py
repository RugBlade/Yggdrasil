from __future__ import annotations

import json, sqlite3
from pathlib import Path
from threading import RLock
from noeron.cognition.models import KnotMemory, NativeThought
from noeron.models import CognitiveEvent, InitiativeMessage, NoeronState
from noeron.room_models import RoomJournalEntry, RoomArtifactRecord, NativePresentationRecord
from noeron.learning_models import (
    SemanticKnotPrototype, LearningSourceRecord, NoeronSemanticStratumRecord,
    IsotopyComponentRecord, StratifiedLearningMemory, ReasoningConceptRecord,
)
from noeron.learning import decode_sparse_deformation


class LocalEventStore:
    """Persistence only. Cognitive retrieval is DKT H^s geometry, never SQL text search."""
    def __init__(self,path:Path):
        self.path=path
        path.parent.mkdir(parents=True,exist_ok=True); self._lock=RLock(); self._connection=sqlite3.connect(path,check_same_thread=False)
        with self._lock:
            for sql in [
                'CREATE TABLE IF NOT EXISTS events (id TEXT PRIMARY KEY, created_at TEXT NOT NULL, payload TEXT NOT NULL)',
                'CREATE TABLE IF NOT EXISTS states (sequence INTEGER PRIMARY KEY AUTOINCREMENT, payload TEXT NOT NULL)',
                'CREATE TABLE IF NOT EXISTS initiative_outbox (id TEXT PRIMARY KEY, created_at TEXT NOT NULL, payload TEXT NOT NULL, delivered INTEGER NOT NULL DEFAULT 0)',
                'CREATE TABLE IF NOT EXISTS native_thoughts (id TEXT PRIMARY KEY, created_at TEXT NOT NULL, payload TEXT NOT NULL)',
                'CREATE TABLE IF NOT EXISTS knot_memories (id TEXT PRIMARY KEY, created_at TEXT NOT NULL, source_event_id TEXT NOT NULL UNIQUE, payload TEXT NOT NULL)',
                'CREATE TABLE IF NOT EXISTS semantic_prototypes (term TEXT PRIMARY KEY, updated_at TEXT NOT NULL, payload TEXT NOT NULL)',
                'CREATE TABLE IF NOT EXISTS learning_sources (id TEXT PRIMARY KEY, created_at TEXT NOT NULL, payload TEXT NOT NULL)',
                'CREATE TABLE IF NOT EXISTS semantic_strata (id TEXT PRIMARY KEY, updated_at TEXT NOT NULL, payload TEXT NOT NULL)',
                'CREATE TABLE IF NOT EXISTS isotopy_components (id TEXT PRIMARY KEY, updated_at TEXT NOT NULL, payload TEXT NOT NULL)',
                'CREATE TABLE IF NOT EXISTS stratified_learning_memories (id TEXT PRIMARY KEY, created_at TEXT NOT NULL, source_event_id TEXT NOT NULL UNIQUE, payload TEXT NOT NULL)',
                'CREATE TABLE IF NOT EXISTS reasoning_concepts (id TEXT PRIMARY KEY, updated_at TEXT NOT NULL, payload TEXT NOT NULL)',
                'CREATE TABLE IF NOT EXISTS owner_devices (device_id TEXT PRIMARY KEY, updated_at TEXT NOT NULL, payload TEXT NOT NULL)',
                'CREATE TABLE IF NOT EXISTS owner_challenges (challenge_id TEXT PRIMARY KEY, expires_at TEXT NOT NULL, payload TEXT NOT NULL)',
                'CREATE TABLE IF NOT EXISTS owner_sessions (session_hash TEXT PRIMARY KEY, expires_at TEXT NOT NULL, payload TEXT NOT NULL)',
                'CREATE TABLE IF NOT EXISTS room_journal (id TEXT PRIMARY KEY, created_at TEXT NOT NULL, payload TEXT NOT NULL)',
                'CREATE TABLE IF NOT EXISTS room_artifacts (id TEXT PRIMARY KEY, created_at TEXT NOT NULL, payload TEXT NOT NULL)',
                'CREATE TABLE IF NOT EXISTS native_presentations (id TEXT PRIMARY KEY, created_at TEXT NOT NULL, payload TEXT NOT NULL)',
            ]:
                self._connection.execute(sql)
            self._connection.commit()

    def append_event(self,e:CognitiveEvent):
        with self._lock: self._connection.execute('INSERT OR IGNORE INTO events VALUES (?,?,?)',(str(e.id),e.created_at.isoformat(),e.model_dump_json())); self._connection.commit()
    def append_state(self,s:NoeronState):
        with self._lock: self._connection.execute('INSERT INTO states(payload) VALUES (?)',(s.model_dump_json(),)); self._connection.commit()
    def latest_state(self):
        with self._lock: row=self._connection.execute('SELECT payload FROM states ORDER BY sequence DESC LIMIT 1').fetchone()
        if not row:return None
        try:return NoeronState.model_validate(json.loads(row[0]))
        except Exception:return None

    def all_events(self):
        with self._lock: rows=self._connection.execute('SELECT payload FROM events ORDER BY created_at ASC').fetchall()
        out=[]
        for r in rows:
            try: out.append(CognitiveEvent.model_validate_json(r[0]))
            except Exception: pass
        return out
    def all_external_events(self): return [e for e in self.all_events() if e.kind != e.kind.INTERNAL_REFLECTION and not e.source.startswith('noeron')]
    def latest_external_event(self):
        xs=self.all_external_events(); return xs[-1] if xs else None
    def event_by_id(self,event_id:str):
        with self._lock: row=self._connection.execute('SELECT payload FROM events WHERE id=?',(event_id,)).fetchone()
        return CognitiveEvent.model_validate_json(row[0]) if row else None

    # ------------------------------------------------------------------
    # Full DKT memories (episodic/source roots/legacy)
    # ------------------------------------------------------------------
    def append_knot_memory(self,m:KnotMemory):
        with self._lock: self._connection.execute('INSERT OR IGNORE INTO knot_memories VALUES (?,?,?,?)',(str(m.id),m.created_at.isoformat(),str(m.source_event_id),m.model_dump_json())); self._connection.commit()
    def upsert_knot_memory(self,m:KnotMemory):
        with self._lock:
            self._connection.execute('INSERT INTO knot_memories(id,created_at,source_event_id,payload) VALUES (?,?,?,?) ON CONFLICT(source_event_id) DO UPDATE SET id=excluded.id,created_at=excluded.created_at,payload=excluded.payload',(str(m.id),m.created_at.isoformat(),str(m.source_event_id),m.model_dump_json())); self._connection.commit()
    def all_knot_memories(self):
        with self._lock: rows=self._connection.execute('SELECT payload FROM knot_memories ORDER BY created_at ASC').fetchall()
        out=[]
        for r in rows:
            try: out.append(KnotMemory.model_validate_json(r[0]))
            except Exception: pass
        return out
    def knot_memories(self,limit:int|None=None):
        xs=[m for m in self.all_knot_memories() if m.consolidated]
        return xs if limit is None else xs[-limit:]
    def archived_knot_memories(self): return [m for m in self.all_knot_memories() if not m.consolidated]
    def pending_cognitive_provenance_memories(self):
        return [m for m in self.all_knot_memories() if (not m.consolidated and m.memory_class.endswith('provenance-pending-cognitive'))]
    def knot_memory_for_event(self,event_id:str,include_archived:bool=True):
        with self._lock: row=self._connection.execute('SELECT payload FROM knot_memories WHERE source_event_id=?',(event_id,)).fetchone()
        if not row:return None
        m=KnotMemory.model_validate_json(row[0]); return m if include_archived or m.consolidated else None
    def knot_memory_by_id(self,memory_id:str,include_archived:bool=True):
        with self._lock: row=self._connection.execute('SELECT payload FROM knot_memories WHERE id=?',(memory_id,)).fetchone()
        if not row:return None
        m=KnotMemory.model_validate_json(row[0]); return m if include_archived or m.consolidated else None

    # ------------------------------------------------------------------
    # Learned semantic prototypes
    # ------------------------------------------------------------------
    def semantic_prototypes(self):
        with self._lock: rows=self._connection.execute('SELECT payload FROM semantic_prototypes ORDER BY term ASC').fetchall()
        out=[]
        for r in rows:
            try: out.append(SemanticKnotPrototype.model_validate_json(r[0]))
            except Exception: pass
        return out
    def semantic_prototype_map(self): return {p.term:p for p in self.semantic_prototypes()}
    def upsert_semantic_prototype(self,p:SemanticKnotPrototype):
        with self._lock:
            self._connection.execute('INSERT INTO semantic_prototypes(term,updated_at,payload) VALUES (?,?,?) ON CONFLICT(term) DO UPDATE SET updated_at=excluded.updated_at,payload=excluded.payload',(p.term,p.last_seen_at.isoformat(),p.model_dump_json())); self._connection.commit()

    # ------------------------------------------------------------------
    # Learning sources
    # ------------------------------------------------------------------
    def append_learning_source(self,src:LearningSourceRecord):
        with self._lock:
            self._connection.execute('INSERT INTO learning_sources(id,created_at,payload) VALUES (?,?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload',(str(src.id),src.created_at.isoformat(),src.model_dump_json())); self._connection.commit()
    def learning_sources(self):
        with self._lock: rows=self._connection.execute('SELECT payload FROM learning_sources ORDER BY created_at ASC').fetchall()
        out=[]
        for r in rows:
            try: out.append(LearningSourceRecord.model_validate_json(r[0]))
            except Exception: pass
        return out
    def learning_source_by_id(self,source_id:str):
        with self._lock: row=self._connection.execute('SELECT payload FROM learning_sources WHERE id=?',(source_id,)).fetchone()
        return LearningSourceRecord.model_validate_json(row[0]) if row else None

    # ------------------------------------------------------------------
    # v0.6.3 learned semantic strata / local isotopy components
    # ------------------------------------------------------------------
    def all_semantic_strata(self):
        with self._lock: rows=self._connection.execute('SELECT payload FROM semantic_strata ORDER BY updated_at ASC').fetchall()
        out=[]
        for r in rows:
            try: out.append(NoeronSemanticStratumRecord.model_validate_json(r[0]))
            except Exception: pass
        return out
    def semantic_strata(self,include_retired:bool=False):
        xs=self.all_semantic_strata()
        return xs if include_retired else [s for s in xs if getattr(s,'status','active')=='active']
    def semantic_stratum_by_id(self,stratum_id:str):
        with self._lock: row=self._connection.execute('SELECT payload FROM semantic_strata WHERE id=?',(stratum_id,)).fetchone()
        return NoeronSemanticStratumRecord.model_validate_json(row[0]) if row else None
    def upsert_semantic_stratum(self,s:NoeronSemanticStratumRecord):
        with self._lock:
            self._connection.execute('INSERT INTO semantic_strata(id,updated_at,payload) VALUES (?,?,?) ON CONFLICT(id) DO UPDATE SET updated_at=excluded.updated_at,payload=excluded.payload',(str(s.id),s.updated_at.isoformat(),s.model_dump_json())); self._connection.commit()

    def all_isotopy_components(self):
        with self._lock: rows=self._connection.execute('SELECT payload FROM isotopy_components ORDER BY updated_at ASC').fetchall()
        out=[]
        for r in rows:
            try: out.append(IsotopyComponentRecord.model_validate_json(r[0]))
            except Exception: pass
        return out
    def isotopy_components(self,include_retired:bool=False):
        xs=self.all_isotopy_components()
        return xs if include_retired else [c for c in xs if getattr(c,'status','active')=='active']
    def isotopy_component_by_id(self,component_id:str):
        with self._lock: row=self._connection.execute('SELECT payload FROM isotopy_components WHERE id=?',(component_id,)).fetchone()
        return IsotopyComponentRecord.model_validate_json(row[0]) if row else None
    def upsert_isotopy_component(self,c:IsotopyComponentRecord):
        with self._lock:
            self._connection.execute('INSERT INTO isotopy_components(id,updated_at,payload) VALUES (?,?,?) ON CONFLICT(id) DO UPDATE SET updated_at=excluded.updated_at,payload=excluded.payload',(str(c.id),c.updated_at.isoformat(),c.model_dump_json())); self._connection.commit()

    def append_stratified_learning_memory(self,m:StratifiedLearningMemory):
        with self._lock:
            self._connection.execute('INSERT OR IGNORE INTO stratified_learning_memories VALUES (?,?,?,?)',(str(m.id),m.created_at.isoformat(),str(m.source_event_id),m.model_dump_json())); self._connection.commit()
    def upsert_stratified_learning_memory(self,m:StratifiedLearningMemory):
        with self._lock:
            self._connection.execute('INSERT INTO stratified_learning_memories(id,created_at,source_event_id,payload) VALUES (?,?,?,?) ON CONFLICT(source_event_id) DO UPDATE SET id=excluded.id,created_at=excluded.created_at,payload=excluded.payload',(str(m.id),m.created_at.isoformat(),str(m.source_event_id),m.model_dump_json())); self._connection.commit()
    def all_stratified_learning_memories(self):
        with self._lock: rows=self._connection.execute('SELECT payload FROM stratified_learning_memories ORDER BY created_at ASC').fetchall()
        out=[]
        for r in rows:
            try: out.append(StratifiedLearningMemory.model_validate_json(r[0]))
            except Exception: pass
        return out
    def stratified_learning_memories(self): return [m for m in self.all_stratified_learning_memories() if m.consolidated]
    def archived_stratified_learning_memories(self): return [m for m in self.all_stratified_learning_memories() if not m.consolidated]
    def stratified_learning_memory_by_id(self,memory_id:str,include_archived:bool=True):
        with self._lock: row=self._connection.execute('SELECT payload FROM stratified_learning_memories WHERE id=?',(memory_id,)).fetchone()
        if not row:return None
        m=StratifiedLearningMemory.model_validate_json(row[0]); return m if include_archived or m.consolidated else None

    def _decode_stratified(self,m:StratifiedLearningMemory) -> KnotMemory | None:
        c=self.isotopy_component_by_id(str(m.isotopy_component_id))
        if c is None:return None
        knot=decode_sparse_deformation(c.anchor_knot,m.deformation)
        return KnotMemory(
            id=m.id,created_at=m.created_at,source_event_id=m.source_event_id,knot=knot,
            logical_coordinates=m.logical_coordinates,logical_entropy=m.logical_entropy,egr_entropy_current=m.egr_entropy_current,
            parent_memory_id=m.parent_memory_id,branch_depth=m.branch_depth,provenance_excerpt=m.provenance_excerpt,
            geometry_version=m.geometry_version,consolidated=m.consolidated,memory_class=m.memory_class,
            consolidation_score=m.consolidation_score,consolidation_reasons=m.consolidation_reasons,
            learning_source_id=m.learning_source_id,source_title=m.source_title,canonical_source_id=m.canonical_source_id,source_segment_index=m.source_segment_index,
            revision_of_memory_id=m.revision_of_memory_id,superseded_by_memory_id=m.superseded_by_memory_id,
            semantic_stratum_id=m.semantic_stratum_id,isotopy_component_id=m.isotopy_component_id,
            semantic_frontier_neighbor_ids=(self.semantic_stratum_by_id(str(m.semantic_stratum_id)).frontier_neighbors if self.semantic_stratum_by_id(str(m.semantic_stratum_id)) else []),
        )

    def cognitive_memories(self,limit:int|None=None):
        """Authoritative retrieval population: full DKT knots + decoded compressed learned knots."""
        xs=list(self.knot_memories())
        for sm in self.stratified_learning_memories():
            km=self._decode_stratified(sm)
            if km is not None: xs.append(km)
        xs.sort(key=lambda m:m.created_at)
        return xs if limit is None else xs[-limit:]

    def archived_cognitive_memory_count(self):
        return len(self.archived_knot_memories())+len(self.archived_stratified_learning_memories())

    def cognitive_memory_by_id(self,memory_id:str,include_archived:bool=True):
        """Resolve the authoritative representation for a cognitive-memory ID.

        Stage 5 may keep a noncognitive full provenance row and an active compressed
        stratified cognitive row under the same stable ID.  Prefer whichever
        representation is actually consolidated/active; otherwise an archived full
        provenance row would shadow its active compressed cognitive counterpart.
        Archived rows remain available only when explicitly requested.
        """
        full=self.knot_memory_by_id(memory_id,include_archived=True)
        if full is not None and full.consolidated:return full
        sm=self.stratified_learning_memory_by_id(memory_id,include_archived=True)
        if sm is not None and sm.consolidated:return self._decode_stratified(sm)
        if not include_archived:return None
        if full is not None:return full
        return self._decode_stratified(sm) if sm is not None else None


    # ------------------------------------------------------------------
    # Stage-5 owner device authentication persistence
    # ------------------------------------------------------------------
    def upsert_owner_device(self, rec: dict):
        with self._lock:
            self._connection.execute(
                'INSERT INTO owner_devices(device_id,updated_at,payload) VALUES (?,?,?) ON CONFLICT(device_id) DO UPDATE SET updated_at=excluded.updated_at,payload=excluded.payload',
                (str(rec['device_id']),str(rec.get('updated_at') or rec.get('created_at') or ''),json.dumps(rec,separators=(',',':'))),
            ); self._connection.commit()

    def owner_device(self, device_id: str):
        with self._lock: row=self._connection.execute('SELECT payload FROM owner_devices WHERE device_id=?',(str(device_id),)).fetchone()
        return json.loads(row[0]) if row else None

    def owner_devices(self):
        with self._lock: rows=self._connection.execute('SELECT payload FROM owner_devices ORDER BY updated_at ASC').fetchall()
        return [json.loads(r[0]) for r in rows]

    def append_owner_challenge(self, rec: dict):
        with self._lock:
            self._connection.execute('INSERT INTO owner_challenges(challenge_id,expires_at,payload) VALUES (?,?,?)',(str(rec['challenge_id']),str(rec['expires_at']),json.dumps(rec,separators=(',',':')))); self._connection.commit()

    def owner_challenge(self, challenge_id: str):
        with self._lock: row=self._connection.execute('SELECT payload FROM owner_challenges WHERE challenge_id=?',(str(challenge_id),)).fetchone()
        return json.loads(row[0]) if row else None

    def consume_owner_challenge(self, challenge_id: str, consumed_at: str):
        rec=self.owner_challenge(challenge_id)
        if not rec:return False
        rec['consumed']=True;rec['consumed_at']=str(consumed_at)
        with self._lock:
            cur=self._connection.execute('UPDATE owner_challenges SET payload=? WHERE challenge_id=?',(json.dumps(rec,separators=(',',':')),str(challenge_id))); self._connection.commit(); return cur.rowcount>0

    def append_owner_session(self, rec: dict):
        with self._lock:
            self._connection.execute('INSERT INTO owner_sessions(session_hash,expires_at,payload) VALUES (?,?,?)',(str(rec['session_hash']),str(rec['expires_at']),json.dumps(rec,separators=(',',':')))); self._connection.commit()

    def owner_session_by_hash(self, session_hash: str):
        with self._lock: row=self._connection.execute('SELECT payload FROM owner_sessions WHERE session_hash=?',(str(session_hash),)).fetchone()
        return json.loads(row[0]) if row else None

    def revoke_owner_sessions(self, device_id: str):
        with self._lock:
            rows=self._connection.execute('SELECT session_hash,payload FROM owner_sessions').fetchall();count=0
            for sh,payload in rows:
                rec=json.loads(payload)
                if rec.get('device_id')!=str(device_id) or rec.get('revoked'):continue
                rec['revoked']=True
                self._connection.execute('UPDATE owner_sessions SET payload=? WHERE session_hash=?',(json.dumps(rec,separators=(',',':')),sh));count+=1
            self._connection.commit();return count


    # ------------------------------------------------------------------
    # Stage-7 private Room persistence — presentation/provenance only
    # ------------------------------------------------------------------
    def append_room_journal(self, entry: RoomJournalEntry):
        with self._lock:
            self._connection.execute('INSERT OR IGNORE INTO room_journal VALUES (?,?,?)',(str(entry.id),entry.created_at.isoformat(),entry.model_dump_json())); self._connection.commit()

    def room_journal(self, limit:int=200):
        with self._lock: rows=self._connection.execute('SELECT payload FROM room_journal ORDER BY created_at DESC LIMIT ?',(max(1,min(int(limit),1000)),)).fetchall()
        out=[]
        for r in reversed(rows):
            try: out.append(RoomJournalEntry.model_validate_json(r[0]))
            except Exception: pass
        return out

    def append_room_artifact(self, rec: RoomArtifactRecord):
        with self._lock:
            self._connection.execute('INSERT OR IGNORE INTO room_artifacts VALUES (?,?,?)',(str(rec.id),rec.created_at.isoformat(),rec.model_dump_json())); self._connection.commit()

    def room_artifacts(self, limit:int=200):
        with self._lock: rows=self._connection.execute('SELECT payload FROM room_artifacts ORDER BY created_at DESC LIMIT ?',(max(1,min(int(limit),1000)),)).fetchall()
        out=[]
        for r in reversed(rows):
            try: out.append(RoomArtifactRecord.model_validate_json(r[0]))
            except Exception: pass
        return out

    def room_artifact(self, artifact_id:str):
        with self._lock: row=self._connection.execute('SELECT payload FROM room_artifacts WHERE id=?',(str(artifact_id),)).fetchone()
        return RoomArtifactRecord.model_validate_json(row[0]) if row else None

    def append_native_presentation(self, rec: NativePresentationRecord):
        with self._lock:
            self._connection.execute('INSERT OR IGNORE INTO native_presentations VALUES (?,?,?)',(str(rec.id),rec.created_at.isoformat(),rec.model_dump_json())); self._connection.commit()

    def native_presentations(self, limit:int=100):
        with self._lock: rows=self._connection.execute('SELECT payload FROM native_presentations ORDER BY created_at DESC LIMIT ?',(max(1,min(int(limit),500)),)).fetchall()
        out=[]
        for r in reversed(rows):
            try: out.append(NativePresentationRecord.model_validate_json(r[0]))
            except Exception: pass
        return out

    # ------------------------------------------------------------------
    # v0.6.5 higher-order reasoning concepts
    # ------------------------------------------------------------------
    def reasoning_concepts(self, include_retired: bool = False):
        with self._lock:
            rows=self._connection.execute('SELECT payload FROM reasoning_concepts ORDER BY updated_at ASC').fetchall()
        out=[]
        for r in rows:
            try:
                c=ReasoningConceptRecord.model_validate_json(r[0])
                if include_retired or not c.status.startswith('retired-'):
                    out.append(c)
            except Exception:
                pass
        return out

    def reasoning_concept_by_id(self,concept_id:str):
        with self._lock: row=self._connection.execute('SELECT payload FROM reasoning_concepts WHERE id=?',(concept_id,)).fetchone()
        return ReasoningConceptRecord.model_validate_json(row[0]) if row else None

    def upsert_reasoning_concept(self,c:ReasoningConceptRecord):
        with self._lock:
            self._connection.execute('INSERT INTO reasoning_concepts(id,updated_at,payload) VALUES (?,?,?) ON CONFLICT(id) DO UPDATE SET updated_at=excluded.updated_at,payload=excluded.payload',(str(c.id),c.updated_at.isoformat(),c.model_dump_json())); self._connection.commit()

    # ------------------------------------------------------------------
    # Thought / initiative persistence
    # ------------------------------------------------------------------
    def append_thought(self,t:NativeThought):
        with self._lock: self._connection.execute('INSERT OR IGNORE INTO native_thoughts VALUES (?,?,?)',(str(t.id),t.created_at.isoformat(),t.model_dump_json())); self._connection.commit()
    def recent_thoughts(self,limit=20):
        with self._lock: rows=self._connection.execute('SELECT payload FROM native_thoughts ORDER BY created_at DESC LIMIT ?',(limit,)).fetchall()
        out=[]
        for r in rows:
            try: out.append(NativeThought.model_validate_json(r[0]))
            except Exception: pass
        return list(reversed(out))
    def append_initiative(self,m:InitiativeMessage):
        with self._lock: self._connection.execute('INSERT INTO initiative_outbox VALUES (?,?,?,?)',(str(m.id),m.created_at.isoformat(),m.model_dump_json(),int(m.delivered))); self._connection.commit()
    def pending_initiatives(self,limit=20):
        with self._lock: rows=self._connection.execute('SELECT payload FROM initiative_outbox WHERE delivered=0 ORDER BY created_at ASC LIMIT ?',(limit,)).fetchall()
        return [InitiativeMessage.model_validate_json(r[0]) for r in rows]
    def acknowledge_initiative(self,message_id:str):
        with self._lock:
            row=self._connection.execute('SELECT payload FROM initiative_outbox WHERE id=?',(message_id,)).fetchone()
            if not row:return False
            m=InitiativeMessage.model_validate_json(row[0]); m.delivered=True
            cur=self._connection.execute('UPDATE initiative_outbox SET delivered=1,payload=? WHERE id=?',(m.model_dump_json(),message_id)); self._connection.commit(); return cur.rowcount>0
    def acknowledge_all_initiatives(self):
        with self._lock:
            rows=self._connection.execute('SELECT id,payload FROM initiative_outbox WHERE delivered=0').fetchall(); count=0
            for mid,p in rows:
                m=InitiativeMessage.model_validate_json(p); m.delivered=True; self._connection.execute('UPDATE initiative_outbox SET delivered=1,payload=? WHERE id=?',(m.model_dump_json(),mid)); count+=1
            self._connection.commit(); return count
