from __future__ import annotations

"""Local, integrity-pinned Stage-7 renderer substrate.

This module has presentation authority only.  It does not select embodiment,
environment, morphology, material, colour, motion, voice, or attention.  It
serves the exact locally-vendored Three.js r185 build only after integrity
verification.
"""

from hashlib import sha1, sha256
import json
from pathlib import Path
import stat
from typing import Any


THREE_PACKAGE = "three"
THREE_VERSION = "0.185.1"
THREE_TAG = "r185"
THREE_LICENSE = "MIT"
THREE_VENDOR_ROOT = Path(__file__).resolve().parent / "static" / "vendor" / "three-r185"
THREE_REQUIRED: dict[str, dict[str, Any]] = {
    "build/three.module.js": {
        "size": 650153,
        "sha256": "bbf5ed13fe4373f5bd38b14ea8e62e9f157327da5638edc6d3863e08b167c9c7",
        "git_blob_sha1": "ad13abf7d128bee607a7672646ca543327e258d3",
    },
    "build/three.core.js": {
        "size": 1443056,
        "sha256": "3718df126d69c125362a03340913204470d8c50238605150e57f808840fb7759",
        "git_blob_sha1": "0bb9262cd029f411933d077fd44197a51ec5e8e9",
    },
    "LICENSE": {
        "size": 1081,
        "sha256": "8b378ebe60e2fe500158cb0ac71cb5e8b7d92953c2abcc63a0eb90499653b5bc",
        "git_blob_sha1": "8ada2a5f982916b0ba4b7a0aa7de347587e745d7",
    },
}
THREE_BROWSER_ASSETS = frozenset({"build/three.module.js", "build/three.core.js"})


class RendererIntegrityError(RuntimeError):
    pass


def _git_blob_sha1(data: bytes) -> str:
    return sha1(f"blob {len(data)}\0".encode("ascii") + data).hexdigest()


def _safe_required_path(rel: str) -> Path:
    if rel not in THREE_REQUIRED:
        raise RendererIntegrityError("renderer asset is not in the pinned allowlist")
    path = THREE_VENDOR_ROOT / rel
    try:
        lst = path.lstat()
    except FileNotFoundError as exc:
        raise RendererIntegrityError(f"missing renderer asset: {rel}") from exc
    if stat.S_ISLNK(lst.st_mode) or not stat.S_ISREG(lst.st_mode):
        raise RendererIntegrityError(f"renderer asset is not a regular non-symlink file: {rel}")
    resolved = path.resolve(strict=True)
    root = THREE_VENDOR_ROOT.resolve(strict=True)
    try:
        resolved.relative_to(root)
    except ValueError as exc:
        raise RendererIntegrityError(f"renderer asset escapes vendor root: {rel}") from exc
    return resolved


def _verified_bytes(rel: str) -> bytes:
    path = _safe_required_path(rel)
    data = path.read_bytes()
    expected = THREE_REQUIRED[rel]
    if len(data) != expected["size"]:
        raise RendererIntegrityError(f"renderer asset size mismatch: {rel}")
    if sha256(data).hexdigest() != expected["sha256"]:
        raise RendererIntegrityError(f"renderer asset SHA-256 mismatch: {rel}")
    if _git_blob_sha1(data) != expected["git_blob_sha1"]:
        raise RendererIntegrityError(f"renderer asset Git blob mismatch: {rel}")
    return data


def verify_vendor_material() -> dict[str, Any]:
    manifest_path = THREE_VENDOR_ROOT / "INTEGRITY.json"
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, ValueError, UnicodeDecodeError) as exc:
        raise RendererIntegrityError("renderer INTEGRITY.json is unavailable or invalid") from exc
    if manifest.get("package") != THREE_PACKAGE or manifest.get("version") != THREE_VERSION:
        raise RendererIntegrityError("renderer package identity mismatch")
    if manifest.get("upstream_tag") != THREE_TAG or manifest.get("license") != THREE_LICENSE:
        raise RendererIntegrityError("renderer tag/license identity mismatch")
    if manifest.get("runtime_public_network_dependency") is not False:
        raise RendererIntegrityError("renderer manifest does not assert local-only runtime material")
    if set(manifest.get("files", {})) != set(THREE_REQUIRED):
        raise RendererIntegrityError("renderer manifest file set mismatch")
    for rel, expected in THREE_REQUIRED.items():
        data = _verified_bytes(rel)
        row = manifest["files"].get(rel, {})
        if row.get("size") != expected["size"]:
            raise RendererIntegrityError(f"renderer manifest size mismatch: {rel}")
        if row.get("sha256") != expected["sha256"]:
            raise RendererIntegrityError(f"renderer manifest SHA-256 mismatch: {rel}")
        if row.get("upstream_git_blob_sha1") != expected["git_blob_sha1"]:
            raise RendererIntegrityError(f"renderer manifest Git blob mismatch: {rel}")
        if len(data) != row["size"]:
            raise RendererIntegrityError(f"renderer material length mismatch: {rel}")
    return manifest


def read_three_browser_asset(rel: str) -> bytes:
    if rel not in THREE_BROWSER_ASSETS:
        raise RendererIntegrityError("renderer browser asset is not allowed")
    # Verify the complete pinned material before any browser asset is served.
    verify_vendor_material()
    return _verified_bytes(rel)


def renderer_substrate_descriptor() -> dict[str, Any]:
    return {
        "backend": "three.js",
        "version": THREE_VERSION,
        "upstream_tag": THREE_TAG,
        "local_vendored": True,
        "runtime_public_network_dependency": False,
        "asset_integrity_enforced_on_read": True,
        "projection": "continuous native renderer coordinates -> neutral 3-D BufferGeometry points",
        "cognitive_authority": False,
        "embodiment_choice_authority": False,
        "environment_choice_authority": False,
        "morphology_template_authority": False,
    }
