from __future__ import annotations

import math
import re
from typing import Mapping

from noeron.math.linalg import norm
from noeron.inference import parse_surface_logic_detailed
from noeron.language_composition import analyze_surface_composition
from noeron.math.models import IRGMathState, SemanticAtom, LogicalQuery, LogicalProposition
from noeron.learning_models import SemanticKnotPrototype
from noeron.models import CognitiveEvent, EventKind

# This vocabulary is a sensor ontology, not memory.  Synonyms collapse to the same
# environment-state atom so semantic proximity is reflected in IRG/DKT geometry.
# Unknown terms are retained only as low-weight lexical residuals.
_STOP = {
    # Programmed grammatical / markup surface forms only.  These tokens are syntax
    # substrate, not judgments about what content is important enough to mean.
    'the','a','an','of','to','for','in','on','at','as','or','if','and','but','with','from','into','onto',
    'is','am','are','was','were','be','been','being','do','does','did','have','has','had',
    'this','that','these','those','it','its','i','me','my','we','us','our','you','your','he','she','they','them','their',
    'begin','end','itemize','enumerate','description','item','left','right','mathrm','mathbf','mathbb','mathcal',
    'textbf','textit','emph','label','ref','cite',
}


_CANON = {'dkt':'DKT','irg':'IRG','rl':'RL','egr':'EGR','frenet':'Frenet','noeron':'Noeron','yggdrasil':'Yggdrasil','terra':'Terra'}

# v0.6.6 discourse words are logical/inferential sensor roles, not learned concepts.




def _raw_terms(text: str) -> list[str]:
    return [t.lower().strip('_-') for t in re.findall(r"[A-Za-z][A-Za-z0-9_-]{1,}", text)]


def lexical_root(term: str) -> str:
    """Conservative deterministic lexical normalization.

    v0.6.4's generic ``-es`` stripping produced artifacts such as ``spher`` from
    ``spheres``.  v0.6.4 intentionally prefers under-stemming to inventing a
    malformed concept.  This is a text-sensor normalizer, not learned knowledge.
    """
    root=term.lower().strip('_-')
    if root.endswith('ies') and len(root)>5:
        root=root[:-3]+'y'
    elif root.endswith('ing') and len(root)>6:
        stem=root[:-3]
        # A small spelling repair for common e-dropping verbs; these are mostly
        # background terms and are filtered before concept learning.
        if stem in {'describ','defin','introduc','deriv'}:
            stem += 'e'
        root=stem
    elif root.endswith('ed') and len(root)>5:
        stem=root[:-2]
        if stem in {'describ','defin','introduc'}:
            stem += 'e'
        root=stem
    elif root.endswith('ly') and len(root)>5:
        root=root[:-2]
    elif root.endswith('s') and len(root)>4 and not root.endswith(('ss','us','is','ous','ics')):
        root=root[:-1]
    aliases={'mechanic':'mechanics','mathematic':'mathematics','physic':'physics'}
    return aliases.get(root,root)


def candidate_residual_terms(text: str, limit: int | None=12) -> list[str]:
    """Potential developmental vocabulary not already learned/canonical.

    v0.7.3.4 deliberately does *not* suppress terms merely because an engineer put
    them in the legacy sensor ontology.  Ordinary semantic vocabulary can therefore
    become experience-grounded DKT prototypes instead of remaining permanently
    dependent on a hand-authored lexical family.
    """
    terms=_raw_terms(text); out=[]
    for t in terms:
        if t in _STOP or len(t)<3:
            continue
        root=lexical_root(t)
        if root and root not in out:
            out.append(root)
        if limit is not None and len(out)>=limit:
            break
    return out


def semantic_tokens(text: str, limit: int = 32) -> list[str]:
    """Transient audit tokens only.  They are never stored as a cognitive graph."""
    out: list[str] = []
    for low in _raw_terms(text):
        if low in _STOP or len(low) < 2:
            continue
        value = _CANON.get(low, low)
        if value not in out:
            out.append(value)
        if len(out) >= limit:
            break
    return out


def _residual_atom(term: str, position: int) -> SemanticAtom:
    """Low-weight, nonsemantic fallback for vocabulary outside the current sensor ontology.

    Unlike v0.6 this does not hash the term.  Letter moments provide a stable lexical
    residual so exact/resembling unknown words can still perturb IRG without pretending
    that lexical form is semantic understanding.
    """
    letters=[ord(c)-96 for c in term if 'a' <= c <= 'z']
    if not letters:
        letters=[1]
    mean=sum(letters)/len(letters)
    spread=sum((x-mean)**2 for x in letters)/len(letters)
    mode=2+(int(mean) % 7)
    axis=int(spread) % 3
    phase=(sum((i+1)*x for i,x in enumerate(letters)) % 360) * math.pi/180.0
    return SemanticAtom(label=f'lexeme:{term}',role='lexical-residual',weight=0.14,polarity=1.0,mode=mode,axis=axis,phase=phase,source_terms=[term])


def semantic_measure(text: str, learned_semantics: Mapping[str,SemanticKnotPrototype]|None=None, limit_residuals: int | None = None) -> list[SemanticAtom]:
    """Finite text-channel environment measure without authored semantic priorities.

    Meaning-bearing learned terms are identified only by their persisted DKT
    prototype.  Unlearned content words enter as lexical-form sensor residuals.
    Every observed content root is retained; ``limit_residuals`` is compatibility
    only and is intentionally ignored so list position cannot become attention.

    Formal logical/query meaning is supplied separately by ``parse_surface_logic``.
    This function contains no hand-written ``memory/evaluation/explanation`` intent
    mapping and no confidence/recurrence weighting of semantic importance.
    """
    learned_semantics=learned_semantics or {}
    terms=_raw_terms(text)
    counts={}
    ordered=[]
    for t in terms:
        if t in _STOP or len(t)<2:
            continue
        root=lexical_root(t)
        if not root:
            continue
        if root not in counts:
            counts[root]=0; ordered.append(root)
        counts[root]+=1

    atoms=[]
    for pos,root in enumerate(ordered):
        proto=learned_semantics.get(root)
        if proto is not None and not proto.status.startswith('perception-retired'):
            # Weight is empirical occurrence mass only.  The full learned knot enters
            # the interaction field below; this audit atom does not define meaning.
            atoms.append(SemanticAtom(label=f'learned:{root}',role='learned-semantic-knot',weight=float(counts[root]),polarity=1.0,mode=1,axis=0,phase=0.0,source_terms=[root]))
        else:
            a=_residual_atom(root,pos)
            a.weight=float(counts[root])
            atoms.append(a)
    return atoms


def _prototype_deviation(proto: SemanticKnotPrototype, theta: float) -> list[float]:
    """Evaluate only the learned knot deformation away from the reference loop."""
    k=proto.knot; out=[0.0,0.0,0.0]
    if len(k.cosine)>1:
        out[2]+=k.cosine[1][2]*math.cos(theta)
    if len(k.sine)>1:
        out[2]+=k.sine[1][2]*math.sin(theta)
    for n in range(2,k.mode_radius+1):
        c=k.cosine[n] if n < len(k.cosine) else [0.0,0.0,0.0]
        ss=k.sine[n] if n < len(k.sine) else [0.0,0.0,0.0]
        for axis in range(3):
            out[axis]+=c[axis]*math.cos(n*theta)+ss[axis]*math.sin(n*theta)
    return out


def linguistic_observables(text: str) -> tuple[str,list[str],list[str],list[str]]:
    """Compatibility-only surface-form diagnostics with zero semantic routing role.

    Older releases used hand-written keyword classes such as ``memory_query`` and
    ``evaluation_query`` to choose what Yggdrasil should talk about.  v0.7.3.4
    retains only the syntactic fact that an utterance visibly contains a question
    mark.  Meaning-bearing structure comes from learned DKT semantics and the
    explicit proposition/query parser, not from this compatibility field.
    """
    act='surface-question' if '?' in text else 'surface-statement'
    return act,[act],[],[]


def _event_gain(event: CognitiveEvent) -> float:
    """Uniform admitted-event gain.

    Trust/authentication controls authority and sensor admission elsewhere; it does
    not make an admitted experience semantically more important.
    """
    return 1.0


def interaction_geometry(event: CognitiveEvent, samples: int = 24, semantic_prototypes: Mapping[str,SemanticKnotPrototype]|None=None) -> IRGMathState:
    """Finite direct realization of manuscript f -> I_f -> X_f -> O[f].

    Text is measured as a finite semantic environment measure.  The interaction
    kernel K(theta,e) acts on each semantic atom e, and the empirical integral over
    E gives I_f(theta).  No token hash, embedding vector, concept graph, or LLM is used.
    """
    tokens = semantic_tokens(event.content)
    primary,acts,dims,targets = linguistic_observables(event.content)
    if event.content:
        discourse=(event.metadata.get('discourse_context') if isinstance(event.metadata,dict) else None)
        logical_props, logical_query, language_parse_audit = parse_surface_logic_detailed(event.content,discourse_context=discourse)
        language_parse_audit=dict(language_parse_audit)
        language_parse_audit['stage8b_composition']=analyze_surface_composition(event.content)
    else:
        logical_props, logical_query, language_parse_audit = [], None, {}
    # Objective identity bindings are substrate facts supplied by authenticated/runtime
    # provenance. They enter the same IRG -> DKT -> EGR -> RL/Frenet -> DKT -> proof
    # path as other premises and carry no relationship/preference meaning.
    identity_facts=event.metadata.get('identity_facts',[]) if isinstance(event.metadata,dict) else []
    if isinstance(identity_facts,list):
        for row in identity_facts:
            if not isinstance(row,dict):continue
            subject=str(row.get('subject') or '').strip().lower();relation=str(row.get('relation') or '').strip().lower();obj=str(row.get('object') or '').strip().lower()
            if subject and relation and obj:
                logical_props.append(LogicalProposition(subject=subject,relation=relation,object=obj,source=str(row.get('source') or 'runtime-identity-substrate'),confidence=1.0))
    # Stage-8 engineering-source observations are objective parser/source facts.
    # They enter native IRG/DKT reasoning as factual premises, while explicitly
    # carrying zero write, deployment, preference, or upgrade-choice authority.
    engineering_facts=event.metadata.get('engineering_facts',[]) if isinstance(event.metadata,dict) else []
    if isinstance(engineering_facts,list):
        for row in engineering_facts:
            if not isinstance(row,dict):continue
            subject=str(row.get('subject') or '').strip();relation=str(row.get('relation') or '').strip();obj=str(row.get('object') or '').strip()
            if subject and relation and obj:
                logical_props.append(LogicalProposition(
                    subject=subject,relation=relation,object=obj,
                    source=str(row.get('source') or 'engineering-source-parser'),confidence=1.0,
                    modifiers=['objective-source-fact','no-write-authority','no-deployment-authority'],
                ))
    semantic_prototypes=semantic_prototypes or {}
    atoms = semantic_measure(event.content,semantic_prototypes) if event.content else []
    # Logical form is measured by IRG as structure, not as a prewritten answer.
    # Generic proposition/query atoms make proof structure causal in the same
    # environment -> IRG -> DKT path as the rest of the interaction.
    for i,p0 in enumerate(logical_props):
        atoms.append(SemanticAtom(label=f'logic:{p0.relation}',role='logical-relation',weight=1.0,polarity=(1.0 if p0.polarity else -1.0),mode=2+(i%7),axis=i%3,phase=(i+1)*math.pi/13.0,source_terms=[]))
    if logical_query is not None and logical_query.kind!='none':
        atoms.append(SemanticAtom(label=f'logic-query:{logical_query.kind}',role='logical-query',weight=1.0,polarity=1.0,mode=3,axis=2,phase=math.pi/5.0,source_terms=[]))
    gain = _event_gain(event)

    # Endogenous state enters IRG directly as geometric environment atoms.
    internal_drive = event.metadata.get('internal_drive', []) if isinstance(event.metadata, dict) else []
    sensory = event.metadata.get('sensory_observables', []) if isinstance(event.metadata, dict) else []
    if isinstance(sensory,list):
        for i,row in enumerate(sensory[:24]):
            if not isinstance(row,dict):continue
            try:value=max(0.0,min(1.0,float(row.get('value',0.0))))
            except (TypeError,ValueError):continue
            name=str(row.get('name','sensor')); role=str(row.get('role','sensory-observable'))

            if value>0.0:
                atoms.append(SemanticAtom(label=f'sensory:{name}',role=role,weight=value,polarity=1.0,mode=2+(i%7),axis=i%3,phase=(i+1)*math.pi/11.0,source_terms=[]))
    if isinstance(internal_drive,list) and internal_drive:
        names=('dkt-drift-rate','egr-sigma','egr-sigma-delta','rl-curvature','rl-curvature-contrast','frenet-curvature','irg-memory','irg-topology')
        for i,raw in enumerate(internal_drive[:8]):
            try: value=float(raw)
            except (TypeError,ValueError): continue

            magnitude=abs(value)/(1.0+abs(value))
            if magnitude>0.0:
                atoms.append(SemanticAtom(label=f'endogenous:{names[i]}',role='endogenous-state',weight=magnitude,polarity=1.0 if value>=0 else -1.0,mode=1+(i%8),axis=i%3,phase=(i+1)*math.pi/9.0,source_terms=[]))
    if not atoms:
        atoms=[SemanticAtom(label='quiet-state',role='endogenous-state',weight=1.0,mode=1,axis=0,phase=0.0)]

    learned_occurrences={}
    for t in _raw_terms(event.content):
        root=lexical_root(t); proto=semantic_prototypes.get(root)
        if proto is not None and not proto.status.startswith('perception-retired'):
            learned_occurrences[root]=(proto,learned_occurrences.get(root,(proto,0))[1]+1)
    learned_used=[row[0] for row in learned_occurrences.values()]

    total_mass=max(sum(a.weight for a in atoms),1e-9)
    density:list[float]=[]; field:list[list[float]]=[]
    for j in range(samples):
        th=2.0*math.pi*j/samples
        # f(theta) is the body/support density induced by the current environment measure.
        f=1.0+sum(0.10*a.weight*math.cos(a.mode*th+a.phase) for a in atoms)/math.sqrt(total_mass)
        f=max(0.08,f); density.append(f)
        vec=[0.0,0.0,0.0]
        # I_f(theta) = integral_E K(theta,e) f(theta) dmu(e), empirical finite form.
        for a in atoms:
            if a.role=='learned-semantic-knot':
                continue
            basis=math.cos(a.mode*th+a.phase); transverse=math.sin((a.mode+1)*th-a.phase)
            amp=gain*a.weight*a.polarity/total_mass
            vec[a.axis]+=amp*f*basis
            vec[(a.axis+1)%3]+=0.32*amp*f*transverse
        # Learned semantics acts through the learned DKT prototype itself, not a
        # dense embedding.  Its higher-mode deformation is injected into I_f.
        if learned_occurrences:
            learned_mass=float(sum(n for _proto,n in learned_occurrences.values()))
            for proto,nobs in learned_occurrences.values():
                pv=_prototype_deviation(proto,th)
                # Empirical lexical occurrence mass only; confidence/status does not
                # become a semantic importance coefficient.
                scale=gain*float(nobs)/learned_mass
                for axis in range(3): vec[axis]+=scale*pv[axis]
        field.append(vec)

    # Constitutive operator A is a finite direct scale in v0.6.1; it can be replaced
    # by a manuscript-derived constitutive law as IRG is developed further.
    deformation=[[0.42*x for x in v] for v in field]
    interaction_mag=sum(norm(v) for v in field)/samples
    curvature_terms=[]
    for j in range(samples):
        prev,cur,nxt=deformation[(j-1)%samples],deformation[j],deformation[(j+1)%samples]
        second=[nxt[k]-2.0*cur[k]+prev[k] for k in range(3)]
        curvature_terms.append(norm(second))
    curvature_response=sum(curvature_terms)/samples
    energy_density=sum(sum(x*x for x in v) for v in field)/samples
    entropy_source=max(0.0,energy_density)
    memory_response=sum(norm(v)*f for v,f in zip(field,density))/(samples*max(sum(density)/samples,1e-9))
    topology_response=sum(abs(curvature_terms[j]-curvature_terms[j-1]) for j in range(samples))/samples
    response_potential=interaction_mag+0.5*curvature_response+0.35*memory_response

    loc=event.metadata.get('location',[0.0,0.0,0.0]) if isinstance(event.metadata,dict) else [0.0,0.0,0.0]
    if not isinstance(loc,list) or len(loc)!=3: loc=[0.0,0.0,0.0]
    return IRGMathState(
        support_samples=samples,body_density=density,interaction_field=field,deformation_velocity=deformation,
        interaction_magnitude=interaction_mag,curvature_response=curvature_response,entropy_source=entropy_source,
        memory_response=memory_response,topology_response=topology_response,response_potential=response_potential,
        location=[float(x) for x in loc],semantic_tokens=tokens,semantic_atoms=atoms,dialogue_act=primary,
        dialogue_acts=acts,request_dimensions=dims,query_targets=targets,
        learned_semantic_terms=[p.term for p in learned_used],learned_semantic_prototype_count_used=len(learned_used),
        logical_propositions=logical_props,logical_query=(logical_query if logical_query is not None else LogicalQuery()),
        language_parse_audit=language_parse_audit,
        semantic_geometry_version='semantic-measure-kernel+learned-DKT-prototypes+native-proof-structure+compositional-discourse-v0.7.5',
    )
