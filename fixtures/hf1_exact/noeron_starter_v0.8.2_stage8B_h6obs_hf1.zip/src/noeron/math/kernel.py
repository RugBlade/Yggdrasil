from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping, Sequence

from noeron.math import dkt, egr, rl
from noeron.math.frenet import analyze_trajectory
from noeron.math.affect import project_regional_activation, proto_affective_state
from noeron.math.irg import interaction_geometry
from noeron.math.models import MathKernelState, KnotState
from noeron.cognition.models import KnotMemory
from noeron.models import CognitiveEvent
from noeron.learning_models import SemanticKnotPrototype
from noeron.reasoning import build_multi_memory_reasoning


@dataclass
class CausalMathResult:
    state: MathKernelState
    experience_knot: KnotState
    retrieved: list[tuple[float,KnotMemory]]
    consolidation: dkt.MemoryConsolidationDecision


class MathematicalCognitiveKernel:
    """v0.7.3.4 causal Noeron kernel.

    environment -> IRG semantic measure/kernel -> DKT memory geometry ->
    EGR entropy-current direction -> RL(+Frenet) -> DKT persistence.

    Terra is not imported here.  Every cognition-facing quantity is fixed before
    the renderer is reachable.
    """

    def update(self,event:CognitiveEvent,previous:MathKernelState,memories:list[KnotMemory],semantic_prototypes:Mapping[str,SemanticKnotPrototype]|None=None,language_propositions:Sequence[object]|None=None)->CausalMathResult:
        # 1) Environment -> IRG via an explicit measured environment and interaction kernel.
        irg_state=interaction_geometry(event,semantic_prototypes=semantic_prototypes)

        # 2) IRG -> DKT experience knot; memory recall is H^s geometry only.
        core=previous.dkt.core_knot
        if not core.cosine:
            core=dkt.reference_knot()
        experience=dkt.experience_knot(irg_state,s=core.sobolev_order,modes=core.mode_radius)
        retrieved=dkt.retrieve(experience,memories,limit=6)
        # Pre-EGR support is DKT geometry only. No proposition has been concluded yet.
        # This preserves the required Environment -> IRG -> DKT -> EGR -> RL/Frenet
        # -> DKT -> native cognition order.
        support=build_multi_memory_reasoning(experience,retrieved)
        dkt_displacement=dkt.sobolev_distance(core,experience)

        # 3) DKT/IRG -> EGR.  v0.6.1 keeps an unbounded entropy state; chi maps it
        # into RL without hard saturation.
        prev_egr_state=float(getattr(previous.egr,'entropy_state',0.0))
        if prev_egr_state<=0.0 and previous.egr.mapped_entropy>0.0:
            # compatibility for v0.6.0 persisted states, whose mapped coordinate was bounded
            # but whose value can be inverted through the new chart for continuity.
            import math
            prev_egr_state=math.expm1(max(0.0,float(previous.egr.mapped_entropy)))
        egr_state=egr.entropy_direction(prev_egr_state,previous.egr.entropy_current,irg_state.entropy_source,dkt_displacement)
        # Regional EGR projection allocates salience over retrieved DKT/semantic regions.
        egr_state=project_regional_activation(egr_state,irg_state,support,retrieved)

        # 4) EGR-oriented, DKT-memory-conditioned, IRG-forced RL motion.
        prev_rl=previous.rl; prev_traj=list(previous.trajectory); fr_prev=previous.frenet
        reasoning_target=(support.logical_target if support.active else None)
        nx,nv,force,accnorm=rl.geodesic_step(prev_rl,irg_state,egr_state,retrieved,fr_prev.tangent,fr_prev.metric_feedback_strength,memory_target_override=reasoning_target)
        target=(support.logical_target if support.active else rl.weighted_memory_target(retrieved))
        candidate_rl=rl.build_state(nx,nv,force,prev_traj,target,fr_prev.tangent,fr_prev.metric_feedback_strength,prev_rl.logical_time,accnorm)

        # The fourth distinguished coordinate is the EGR map chi(S_E).  It is a
        # causal coordinate, not the normalized RL curvature entropy.
        px=(prev_rl.coordinates+[0.0]*8)[:8]
        final_coords=list(candidate_rl.coordinates)
        final_coords[3]=max(px[3],egr_state.target_logical_entropy)
        trajectory=(prev_traj+[final_coords])[-24:]
        ds=sum((a-b)**2 for a,b in zip(final_coords,px))**0.5
        dS=max(0.0,final_coords[3]-px[3])
        logical_time=prev_rl.logical_time+dS*max(ds,1e-9)
        final_rl=rl.build_state(final_coords,nv,force,trajectory[:-1],target,fr_prev.tangent,fr_prev.metric_feedback_strength,logical_time,accnorm)
        egr_state=egr.close_bridge(egr_state,final_rl.egr_entropy_coordinate)

        # 5) Frenet invariants of the actual RL trajectory; feedback acts next step.
        fr=analyze_trajectory(trajectory,final_rl.metric)

        # Proto-affective state is an unnamed recurrent activation geometry, not an
        # emotion label or a claim of subjective feeling.
        affect=proto_affective_state(irg_state,egr_state,support,fr,dkt_displacement)

        # 6) RL/EGR/Frenet closes back into persistent DKT.  Regional EGR is already
        # causal through the RL/Frenet trajectory above.  The engineered proto-affect
        # diagnostic field has no independent hard-coded DKT coupling.
        core2=dkt.evolve_core(core,experience,final_coords,sigma=egr_state.entropy_production,frenet_curvature=fr.first_curvature)
        core2,dkt_guard=dkt.retract_to_admissible(core,core2)

        external=not bool(event.metadata.get('endogenous')) and not event.source.startswith('noeron-endogenous')
        consolidation=dkt.consolidation_decision(
            core,experience,retrieved,previous_frenet_curvature=fr_prev.first_curvature,
            current_frenet_curvature=fr.first_curvature,sigma=egr_state.entropy_production,
            irg_response=irg_state.response_potential,external_event=external,
        )
        dkt_state=dkt.state_from(core2,experience,retrieved,consolidation)
        dkt_state.security_admissible=dkt_guard['admissible']; dkt_state.security_retracted=dkt_guard['retracted']; dkt_state.security_reason=dkt_guard['reason']
        dkt_state.stratum_estimate=dkt.estimate_whitney_stratum(core2); dkt_state.stratum_transition_proposed=(core2.stratum_index!=core.stratum_index); dkt_state.stratum_transition_admissible=bool(dkt_guard.get('stratum_transition_admissible',False))

        # 7) Native proposition inference occurs only after the regional EGR ->
        # RL/Frenet -> DKT closure. Premises come from current IRG logical form plus
        # persistent propositions whose source memories were selected by DKT H^s
        # retrieval. The calculus constructs proof consequences; it does not select
        # from authored answer sentences.
        reasoning=build_multi_memory_reasoning(
            experience,retrieved,
            logical_propositions=irg_state.logical_propositions,
            logical_query=irg_state.logical_query,
            learned_language_propositions=language_propositions or [],
            post_closure_knot=core2,
            active_region_ids=egr_state.simultaneous_active_regions,
        )

        trace=[
            'IRG: environment measure + interaction kernel -> I_f -> geometric state X_f',
            'DKT: X_f -> Sobolev/Fourier experience knot; H^s geometry selected memory branches',
            'EGR: DKT deformation + IRG source -> div(J_tot)=Sigma>=0 -> simultaneous regional activation + piecewise stratified activation path -> chi(S_E)',
            'RL: EGR entropy coordinate + DKT memory geometry + IRG forcing -> Levi-Civita inference trajectory',
            'Frenet: frame/curvature measured on the RL trajectory and fed into the next RL metric',
            'Affect diagnostic: recurring unnamed multi-region activation geometry is derived from EGR/IRG/DKT/RL/Frenet; it has no independent causal DKT coupling or preference authority',
            'DKT: RL/EGR/Frenet result -> persistent knot deformation; external-event persistence is an explicit provenance substrate',
            'Native reasoning: current IRG logical form + DKT-gated persistent propositions -> generic proof closure -> auditable candidate propositions',
        ]
        state=MathKernelState(
            interface_version='0.7.3.4',dkt=dkt_state,irg=irg_state,rl=final_rl,egr=egr_state,frenet=fr,affect=affect,reasoning=reasoning,
            trajectory=trajectory,causal_trace=trace,
            metadata={
                'dkt_live_role':'authoritative knot memory + persistent/security wrapper around cognition',
                'irg_live_role':'causal environment measure/kernel -> geometric interaction state',
                'semantic_encoding':'experience-learned DKT semantic prototypes + formal logical/modality sensor primitives + unresolved lexical residuals integrated by IRG; legacy authored semantic sectors have zero causal role',
                'egr_live_role':'causal entropy-current arrow + simultaneous regional activation and finite stratified activation path; unbounded entropy state mapped into RL before inference',
                'rl_live_role':'causal Riemannian inference trajectory driven by DKT support geometry (including distributed exact ties); EGR entropy coordinate distinguished from RL curvature entropy',
                'multi_memory_reasoning':'pre-EGR DKT H^s support geometry drives regional activation/RL; only after RL/Frenet/DKT closure do current logical premises + DKT-gated persistent propositions enter generic proof inference',
                'frenet_live_role':'trajectory-dependent metric feedback',
                'proto_affect':'unnamed recurrent multi-region activation geometry; computational state only, no subjective-emotion claim',
                'dkt_strata':'finite sampled transverse-self-intersection estimator can propose geometry-backed Sigma_j transitions',
                'memory_consolidation':'continuous DKT evolution separated from durable DKT branch formation; v0.7.3.4 audits storage gating as programmed substrate rather than a Yggdrasil preference',
                'word_graph':'retired / zero causal authority','sqlite':'serialization/provenance only; never the retrieval metric','llm':'not reachable from mathematical kernel',
            },
        )
        return CausalMathResult(state=state,experience_knot=experience,retrieved=retrieved,consolidation=consolidation)

    @staticmethod
    def registry()->dict[str,object]:
        return {
            'interface_version':'0.7.3.4','runtime_mode':'causal-mathematical',
            'causal_order':['environment','IRG semantic measure/kernel','DKT H^s active-memory/topology support','regional EGR activation + entropy arrow','RL + Frenet trajectory','DKT closure','native proof proposition inference','native utterance composition','v0.7.4 consequence-selected realization affordance'],
            'memory':'active cognitive DKT Sobolev knots + learned semantic strata/local isotopy components + multi-memory reasoning workspace; v0.7.4 keeps programmed provenance persistence separate and activates pending provenance only through native consequence retention; dynamic Sigma_j estimation remains distinct from Noeron semantic strata',
            'semantic_ingress':'IRG environment atoms + learned DKT semantic prototypes + explicit interaction kernel; no token hashes, vector embeddings, or concept graph',
            'RL_coordinates':['x1','x2','x3','EGR entropy coordinate','deformation','curvature','memory','topology'],
            'RL_curvature_entropy':'rho=e^-R/Z and S_L=<R>+log Z kept distinct from the EGR-driven fourth coordinate; variance/contrast are auxiliary diagnostics',
            'entropy_equation':'div(J_tot)=Sigma>=0; entropy state advances, EGR activation is projected over retrieved DKT/semantic regions, and chi(S)=log(1+S) maps into RL before inference',
            'learning':'admitted source/language experience -> IRG -> DKT semantic/provenance geometry; owner curriculum and web admission cannot force active cognitive DKT retention; no LLM access',
            'reasoning':'DKT H^s support influences EGR/RL first; after DKT closure, current logical form + DKT-gated learned propositions undergo transparent finite proof closure; no LLM and no authored answer table',
            'dynamic_dkt_strata':'sampled nonlocal self-contact + tangent transversality estimator; geometry-backed transitions only',
            'regional_egr':'support-weighted simultaneous activation over semantic/episodic DKT regions plus a finite piecewise-smooth stratified activation path; compatibility is a computational proxy',
            'proto_affect':'derived diagnostic activation/uncertainty/novelty/tension/coherence/approach coordinates; no independent choice coupling and no subjective-emotion claim',
            'native_language':'native proposition -> deterministic English utterance plan; native-direct/Terra are downstream affordances and Terra receives only finalized native content if the v0.7.4 consequence selector actually selects it or the owner explicitly calibrates that path',
            'stage5_outer_selection':'native retention, autonomous communication and realization-tool choice are v0.7.4 consequence layers around this unchanged 0.7.3.4 math interface; missing/tied evidence stays unresolved','concept_graph':False,'llm_role':'available downstream Terra tool only after native utterance content exists; lexical coverage has zero invocation authority',
        }
