from __future__ import annotations

import math

from noeron.math.linalg import inverse, mat_vec, quad, sub, clamp
from noeron.math.models import FrenetMathState


def _metric_norm(v: list[float], g: list[list[float]]) -> float:
    return math.sqrt(max(0.0, quad(g,v)))


def _normalize(v: list[float], g: list[list[float]]) -> list[float]:
    n=_metric_norm(v,g)
    return [0.0 for _ in v] if n<1e-12 else [x/n for x in v]


def analyze_trajectory(points: list[list[float]], metric: list[list[float]]) -> FrenetMathState:
    if len(points)<2:
        return FrenetMathState(samples=len(points))
    v2=sub(points[-1],points[-2]); speed=_metric_norm(v2,metric)
    t2=_normalize(v2,metric)
    if len(points)<3 or speed<1e-12:
        return FrenetMathState(tangent=t2,speed=speed,samples=len(points))
    v1=sub(points[-2],points[-3]); t1=_normalize(v1,metric)
    dt=sub(t2,t1)
    ds=max(0.5*(_metric_norm(v1,metric)+speed),1e-12)
    curvature=_metric_norm(dt,metric)/ds
    feedback=clamp(0.12*curvature,0.0,0.65)
    return FrenetMathState(tangent=t2,speed=speed,first_curvature=curvature,samples=len(points),metric_feedback_strength=feedback)


def deform_metric(base: list[list[float]], tangent: list[float], strength: float) -> list[list[float]]:
    """Trajectory-dependent Frenet metric deformation g_F = g + eta T⊗T."""
    n=len(base)
    if len(tangent)!=n or strength<=0:
        return [row[:] for row in base]
    out=[row[:] for row in base]
    for i in range(n):
        for j in range(n):
            out[i][j]+=strength*tangent[i]*tangent[j]
    return out
