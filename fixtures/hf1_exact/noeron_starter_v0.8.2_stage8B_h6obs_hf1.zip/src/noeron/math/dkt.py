from __future__ import annotations

import hashlib
import math
import sys
from dataclasses import dataclass
from typing import Iterable, Protocol

from noeron.math.linalg import clamp, numerically_tied
from noeron.math.models import DKTMathState, DKTStratumEstimate, IRGMathState, KnotState


class MemoryLike(Protocol):
    id: object
    knot: KnotState
    logical_coordinates: list[float]
    branch_depth: int


@dataclass
class MemoryConsolidationDecision:
    consolidate: bool
    score: float
    threshold: float
    components: dict[str,float]
    reason: str
    decision_layer: str = 'programmed-persistence-substrate'
    selection_rule: str = 'external interaction provenance persists; endogenous ticks do not create episodic branches'


def reference_knot(s: float = 2.0, modes: int = 8) -> KnotState:
    cosine = [[0.0, 0.0, 0.0] for _ in range(modes + 1)]
    sine = [[0.0, 0.0, 0.0] for _ in range(modes + 1)]
    cosine[1] = [1.0, 0.0, 0.0]
    sine[1] = [0.0, 1.0, 0.0]
    k = KnotState(sobolev_order=s, mode_radius=modes, cosine=cosine, sine=sine, stratum_index=0)
    k.invariant_signature = invariant_signature(k)
    return k


def _pad(k: KnotState, modes: int) -> tuple[list[list[float]], list[list[float]]]:
    c = [list(v) for v in k.cosine]
    s = [list(v) for v in k.sine]
    while len(c) <= modes: c.append([0.0,0.0,0.0])
    while len(s) <= modes: s.append([0.0,0.0,0.0])
    return c, s


def sobolev_norm_sq(k: KnotState) -> float:
    total = sum(x*x for x in k.c0)
    for n in range(1, min(len(k.cosine), len(k.sine))):
        weight = (1.0 + n*n) ** k.sobolev_order
        total += weight * sum(x*x for x in k.cosine[n])
        total += weight * sum(x*x for x in k.sine[n])
    return total


def sobolev_distance(a: KnotState, b: KnotState) -> float:
    modes = max(a.mode_radius, b.mode_radius)
    ac, ass = _pad(a, modes); bc, bss = _pad(b, modes)
    s = max(a.sobolev_order, b.sobolev_order)
    total = sum((x-y)**2 for x,y in zip(a.c0,b.c0))
    for n in range(1, modes+1):
        w = (1.0+n*n) ** s
        total += w * sum((x-y)**2 for x,y in zip(ac[n],bc[n]))
        total += w * sum((x-y)**2 for x,y in zip(ass[n],bss[n]))
    # This is the finite Fourier-chart H^s distance only. Whitney/singularity
    # stratum labels are topological metadata handled separately by stratified
    # paths and admissibility checks; an authored stratum-index penalty would
    # distort the manuscript metric and therefore must not enter retrieval.
    return math.sqrt(max(0.0,total))


def invariant_signature(k: KnotState) -> str:
    # v0.6 protects the coarse DKT topological/regularity identity, not message content.
    payload = f"Sigma={k.stratum_index}|s={k.sobolev_order:.6f}|base={k.cosine[1] if len(k.cosine)>1 else []}|{k.sine[1] if len(k.sine)>1 else []}"
    return hashlib.sha256(payload.encode()).hexdigest()[:24]


def _fourier_field(irg: IRGMathState, modes: int) -> tuple[list[list[float]], list[list[float]]]:
    m = len(irg.deformation_velocity)
    cos = [[0.0,0.0,0.0] for _ in range(modes+1)]
    sin = [[0.0,0.0,0.0] for _ in range(modes+1)]
    if not m:
        return cos, sin
    for n in range(1,modes+1):
        for j,v in enumerate(irg.deformation_velocity):
            th = 2.0*math.pi*j/m
            for axis in range(3):
                cos[n][axis] += 2.0*v[axis]*math.cos(n*th)/m
                sin[n][axis] += 2.0*v[axis]*math.sin(n*th)/m
    return cos, sin


def _sample_tangents(k: KnotState, samples: int = 96) -> list[list[float]]:
    out=[]
    for j in range(samples):
        th=2.0*math.pi*j/samples; v=[0.0,0.0,0.0]
        for n in range(1,k.mode_radius+1):
            c=k.cosine[n] if n < len(k.cosine) else [0.0,0.0,0.0]
            ss=k.sine[n] if n < len(k.sine) else [0.0,0.0,0.0]
            for a in range(3):v[a]+=n*(-c[a]*math.sin(n*th)+ss[a]*math.cos(n*th))
        out.append(v)
    return out


def estimate_whitney_stratum(k: KnotState, *, samples: int = 96, contact_radius: float = 0.08, adjacency_exclusion: int = 4) -> DKTStratumEstimate:
    """Finite sampled proxy for transverse self-intersection Whitney strata.

    Nonlocal sample pairs closer than ``contact_radius`` are candidate contacts.
    A contact is counted as transverse when the tangent cross-product sine exceeds
    0.20.  Nearby duplicate sample pairs are clustered so one geometric crossing is
    not counted many times.  This is a computational truncation, not an exact theorem.
    """
    pts=sample_curve(k,samples); tans=_sample_tangents(k,samples)
    candidates=[]; min_d=float('inf'); min_sine=1.0
    for i in range(samples):
        for j in range(i+1,samples):
            cyc=min(j-i,samples-(j-i))
            if cyc<=adjacency_exclusion:continue
            d=math.sqrt(sum((pts[i][a]-pts[j][a])**2 for a in range(3))); min_d=min(min_d,d)
            if d>contact_radius:continue
            ti,tj=tans[i],tans[j]; ni=math.sqrt(sum(x*x for x in ti)); nj=math.sqrt(sum(x*x for x in tj))
            if ni<1e-9 or nj<1e-9:continue
            cross=[ti[1]*tj[2]-ti[2]*tj[1],ti[2]*tj[0]-ti[0]*tj[2],ti[0]*tj[1]-ti[1]*tj[0]]
            sine=math.sqrt(sum(x*x for x in cross))/(ni*nj); min_sine=min(min_sine,sine)
            candidates.append((i,j,d,sine))
    transverse=[x for x in candidates if x[3]>=0.20]
    clusters=[]
    for row in sorted(transverse,key=lambda x:x[2]):
        i,j,_,_=row
        if any(min(abs(i-a),samples-abs(i-a))<=2 and min(abs(j-b),samples-abs(j-b))<=2 for a,b,_,_ in clusters):
            continue
        if any(min(abs(i-b),samples-abs(i-b))<=2 and min(abs(j-a),samples-abs(j-a))<=2 for a,b,_,_ in clusters):
            continue
        clusters.append(row)
    index=min(8,len(clusters))
    conf=0.0
    if clusters:
        conf=min(0.99,0.55+0.30*sum(x[3] for x in clusters)/len(clusters)+0.14*min(1.0,len(clusters)/3.0))
    else:
        separation=(min_d/contact_radius) if math.isfinite(min_d) else 4.0
        conf=min(0.98,0.55+0.12*min(3.5,separation))
    return DKTStratumEstimate(estimated_index=index,transverse_self_intersections=len(clusters),near_self_contacts=len(candidates),
        min_nonlocal_distance=(0.0 if not math.isfinite(min_d) else min_d),min_transversality_sine=(0.0 if min_sine==1.0 and not candidates else min_sine),
        confidence=conf,samples=samples,contact_radius=contact_radius)


def experience_knot(irg: IRGMathState, *, s: float = 2.0, modes: int = 8) -> KnotState:
    """IRG geometric state -> DKT memory knot, using actual Fourier coefficients."""
    k = reference_knot(s=s, modes=modes)
    fc, fs = _fourier_field(irg, modes)
    raw = math.sqrt(sum(x*x for n in range(2,modes+1) for row in (fc[n],fs[n]) for x in row))
    amp = min(0.11, 0.055 + 0.025*irg.interaction_magnitude + 0.02*irg.memory_response)
    factor = amp / max(raw, 1e-12)
    for n in range(2,modes+1):
        k.cosine[n] = [factor*x for x in fc[n]]
        k.sine[n] = [factor*x for x in fs[n]]
    # Small mode-1 normal change makes interaction magnitude part of geometry while preserving the base loop.
    k.cosine[1][2] = clamp(0.015*irg.curvature_response, -0.03, 0.03)
    est=estimate_whitney_stratum(k); k.stratum_index=est.estimated_index
    k.invariant_signature = invariant_signature(k)
    return k



def chart_mean(knots: list[KnotState], weights: list[float] | None = None) -> KnotState | None:
    """Order-independent finite H^s coefficient-chart mean.

    This is a programmed geometric operator, not a choice rule.  All supplied knots
    participate simultaneously; there is no first-item winner or sequential
    interpolation/retraction order.  The result receives one stratum evaluation only
    after its coefficients have been averaged.
    """
    if not knots:
        return None
    modes=max(k.mode_radius for k in knots)
    order=max(k.sobolev_order for k in knots)
    if weights is None:
        ws=[1.0/len(knots)]*len(knots)
    else:
        if len(weights)!=len(knots):
            raise ValueError('weights length must equal knots length')
        vals=[max(0.0,float(w)) for w in weights]
        z=sum(vals)
        if z<=sys.float_info.min:
            ws=[1.0/len(knots)]*len(knots)
        else:
            ws=[w/z for w in vals]
    padded=[_pad(k,modes) for k in knots]
    c0=[sum(w*k.c0[a] for w,k in zip(ws,knots)) for a in range(3)]
    cosine=[[0.0,0.0,0.0] for _ in range(modes+1)]
    sine=[[0.0,0.0,0.0] for _ in range(modes+1)]
    for n in range(modes+1):
        for a in range(3):
            cosine[n][a]=sum(w*padded[i][0][n][a] for i,w in enumerate(ws))
            sine[n][a]=sum(w*padded[i][1][n][a] for i,w in enumerate(ws))
    out=KnotState(sobolev_order=order,mode_radius=modes,c0=c0,cosine=cosine,sine=sine,stratum_index=0)
    est=estimate_whitney_stratum(out); out.stratum_index=est.estimated_index
    out.invariant_signature=invariant_signature(out)
    return out

def interpolate(a: KnotState, b: KnotState, t: float) -> KnotState:
    t = clamp(t,0.0,1.0)
    modes=max(a.mode_radius,b.mode_radius)
    ac,ass=_pad(a,modes); bc,bss=_pad(b,modes)
    out=KnotState(sobolev_order=max(a.sobolev_order,b.sobolev_order),mode_radius=modes,
                  c0=[(1-t)*x+t*y for x,y in zip(a.c0,b.c0)],
                  cosine=[[(1-t)*x+t*y for x,y in zip(ac[n],bc[n])] for n in range(modes+1)],
                  sine=[[(1-t)*x+t*y for x,y in zip(ass[n],bss[n])] for n in range(modes+1)],
                  stratum_index=a.stratum_index)
    est=estimate_whitney_stratum(out); out.stratum_index=est.estimated_index
    out.invariant_signature=invariant_signature(out)
    return out


def evolve_core(core: KnotState, experience: KnotState, logical_coordinates: list[float], *, sigma: float, frenet_curvature: float) -> KnotState:
    """RL/EGR/Frenet feed back into the DKT wrapper, so the math is bidirectionally causal."""
    strength = clamp(0.035 + 0.05*abs(sigma) + 0.025*abs(frenet_curvature), 0.02, 0.22)
    out = interpolate(core, experience, strength)
    modes=out.mode_radius
    # RL state deforms higher knot modes directly. This is the explicit Noeron RL->DKT coupling.
    for i,x in enumerate(logical_coordinates):
        n=2+(i % max(1,modes-1)); axis=i%3
        out.cosine[n][axis] += 0.0025*math.tanh(x)
    est=estimate_whitney_stratum(out); out.stratum_index=est.estimated_index
    out.invariant_signature=invariant_signature(out)
    return out


def consolidation_decision(
    core_before: KnotState,
    experience: KnotState,
    retrieved: list[tuple[float, MemoryLike]],
    *,
    previous_frenet_curvature: float,
    current_frenet_curvature: float,
    sigma: float,
    irg_response: float,
    external_event: bool,
) -> MemoryConsolidationDecision:
    """Programmed persistence substrate, not a Yggdrasil preference.

    v0.7.3.4 removes the authored weighted importance score and retention threshold.
    External interactions are retained as provenance-bearing DKT event branches; an
    endogenous scheduler tick does not manufacture a new episodic memory branch.
    A coordinate-free RMS displacement diagnostic is kept for audit only and has no
    authority over the persistence decision.
    """
    nearest = retrieved[0][0] if retrieved else sobolev_distance(core_before,experience)
    novelty = nearest/(1.0+nearest)
    displacement = sobolev_distance(core_before,experience)
    displacement_n = displacement/(1.0+displacement)
    bend_delta = abs(float(current_frenet_curvature)-float(previous_frenet_curvature))
    bend_n = bend_delta/(1.0+bend_delta)
    entropy_n = max(0.0,float(sigma))/(1.0+max(0.0,float(sigma)))
    response_n = max(0.0,float(irg_response))/(1.0+max(0.0,float(irg_response)))
    components={
        'dkt_novelty':novelty,
        'dkt_displacement':displacement_n,
        'frenet_redirection':bend_n,
        'egr_entropy_production':entropy_n,
        'irg_response':response_n,
    }
    # Equal-coordinate RMS is an audit magnitude, not a hand-weighted importance utility.
    score=math.sqrt(sum(v*v for v in components.values())/len(components))
    # This diagnostic has zero cognitive retention authority in Stage 5.  The
    # orchestrator persists admitted experience knots as provenance, then a separate
    # native consequence selector may later activate them as cognitive memories.
    consolidate=False
    threshold=0.0
    reason='programmed provenance diagnostic only; cognitive retention authority belongs to native consequence selection'
    return MemoryConsolidationDecision(
        consolidate,score,threshold,components,reason,
        decision_layer='programmed-provenance-only-no-cognitive-authority',
        selection_rule='no cognitive retention decision in DKT diagnostic; provenance persistence is separate from native memory activation',
    )


def retrieve(query: KnotState, memories: Iterable[MemoryLike], limit: int = 4) -> list[tuple[float, MemoryLike]]:
    scored=[(sobolev_distance(query,m.knot),m) for m in memories]
    scored.sort(key=lambda x:x[0])
    if limit<=0 or not scored:
        return []
    if len(scored)<=limit:
        return scored
    cutoff=scored[limit-1][0]
    # Preserve the complete exact H^s tie class at the nominal cutoff so storage
    # order cannot become a hidden cognitive selection rule.
    return [row for row in scored if row[0] < cutoff or numerically_tied(row[0],cutoff)]


def state_from(core: KnotState, experience: KnotState, retrieved: list[tuple[float,MemoryLike]], consolidation: MemoryConsolidationDecision|None=None) -> DKTMathState:
    return DKTMathState(
        sobolev_order=core.sobolev_order,
        fourier_mode_radius=core.mode_radius,
        sobolev_norm_sq=sobolev_norm_sq(core),
        stratum_index=core.stratum_index,
        invariant_signature=core.invariant_signature,
        core_knot=core,
        experience_knot=experience,
        retrieved_memory_ids=[str(m.id) for _,m in retrieved],
        retrieval_distances=[d for d,_ in retrieved],
        geodesic_displacement=sobolev_distance(core,experience),
        memory_tree_depth=max((m.branch_depth for _,m in retrieved),default=0),
        consolidation_score=consolidation.score if consolidation else 0.0,
        consolidation_threshold=consolidation.threshold if consolidation else 0.0,
        consolidation_recommended=consolidation.consolidate if consolidation else False,
        consolidation_components=consolidation.components if consolidation else {},
        consolidation_decision_layer=consolidation.decision_layer if consolidation else 'programmed-persistence-substrate',
        consolidation_selection_rule=consolidation.selection_rule if consolidation else 'external interaction provenance persists; endogenous ticks do not create episodic branches',
        stratum_estimate=estimate_whitney_stratum(core),
        stratum_transition_proposed=(core.stratum_index != experience.stratum_index),
    )


def sample_curve(k: KnotState, samples: int = 96) -> list[list[float]]:
    """Sample the finite Fourier representative K(theta)."""
    out=[]
    for j in range(samples):
        th=2.0*math.pi*j/samples
        x=list(k.c0)
        for n in range(1,k.mode_radius+1):
            c=k.cosine[n] if n < len(k.cosine) else [0.0,0.0,0.0]
            s=k.sine[n] if n < len(k.sine) else [0.0,0.0,0.0]
            for a in range(3):
                x[a]+=c[a]*math.cos(n*th)+s[a]*math.sin(n*th)
        out.append(x)
    return out


def regularity_margin(k: KnotState, samples: int = 96) -> float:
    """Finite proxy for the immersion condition K'(theta) != 0."""
    margin=float('inf')
    for j in range(samples):
        th=2.0*math.pi*j/samples
        d=[0.0,0.0,0.0]
        for n in range(1,k.mode_radius+1):
            c=k.cosine[n] if n < len(k.cosine) else [0.0,0.0,0.0]
            s=k.sine[n] if n < len(k.sine) else [0.0,0.0,0.0]
            for a in range(3):
                d[a]+=n*(-c[a]*math.sin(n*th)+s[a]*math.cos(n*th))
        margin=min(margin,math.sqrt(sum(x*x for x in d)))
    return 0.0 if not math.isfinite(margin) else margin


def finite_hs_derivative_constant(k: KnotState) -> float:
    """Finite Fourier-chart constant for ``||δK'||∞ <= C ||δK||_{H^s}``.

    The constant follows directly from Cauchy--Schwarz in the truncated Fourier
    chart. It is a substrate bound, not a semantic/category-specific radius.
    """
    s=float(k.sobolev_order)
    return math.sqrt(sum(
        2.0*(n*n)/((1.0+n*n)**s)
        for n in range(1,max(0,int(k.mode_radius))+1)
    ))


def finite_hs_immersion_radius(k: KnotState, *, samples: int = 96) -> tuple[float,float,float]:
    """Return sampled tangent margin, derivative constant, and derived H^s radius.

    If ``m`` is the sampled minimum tangent norm and ``C`` the finite chart bound,
    perturbations with H^s norm strictly below ``m/C`` preserve sampled immersion.
    This is a finite computational sufficient bound, not a global isotopy theorem.
    """
    margin=regularity_margin(k,samples=samples)
    constant=finite_hs_derivative_constant(k)
    radius=(margin/constant) if constant>0.0 else float('inf')
    return float(margin),float(constant),float(radius)


def numerical_regularity_floor(k: KnotState) -> float:
    """Floating-point distinguishability floor, not an authored geometry threshold."""
    scale=max(1.0,math.sqrt(max(0.0,sobolev_norm_sq(k))))
    return max(sys.float_info.min,math.ulp(scale))


def interpolate_within_immersion_radius(anchor: KnotState, target: KnotState, *, samples: int = 96) -> KnotState:
    """Move toward ``target`` without exceeding the anchor's derived H^s radius."""
    distance=sobolev_distance(anchor,target)
    if distance<=0.0:
        return anchor.model_copy(deep=True)
    _margin,_constant,radius=finite_hs_immersion_radius(anchor,samples=samples)
    if not math.isfinite(radius) or distance < radius:
        return target.model_copy(deep=True)
    safe_radius=math.nextafter(max(0.0,radius),0.0)
    return interpolate(anchor,target,max(0.0,min(1.0,safe_radius/distance)))


def retract_to_admissible(previous: KnotState, candidate: KnotState) -> tuple[KnotState, dict[str,object]]:
    """Finite DKT security/retraction gate used on the actual persistent knot state.

    Normal cognition is allowed to move inside the current Whitney stratum.  An
    uncommanded stratum transition or loss of immersion regularity is treated as an
    inadmissible deformation and is retracted toward the last trusted knot.  This is
    the computational seed of the user's DKT security idea; it is not claimed as a
    theorem of the manuscript.
    """
    prev_est=estimate_whitney_stratum(previous); cand_est=estimate_whitney_stratum(candidate)
    claimed_index=int(candidate.stratum_index)
    if claimed_index != cand_est.estimated_index:
        return previous.model_copy(deep=True), {
            'admissible':False,'retracted':True,'stratum_transition_admissible':False,
            'reason':'unsupported Whitney-stratum label disagrees with sampled geometry; restored trusted DKT state',
        }
    candidate.stratum_index=cand_est.estimated_index; candidate.invariant_signature=invariant_signature(candidate)
    # A stratum transition has no authored confidence or index-jump gate.  The
    # finite estimator is numerical substrate: once the supplied label agrees
    # with the geometry detected from the candidate itself, admissibility is
    # decided by the common immersion condition below.  This avoids turning a
    # human-chosen confidence threshold into cognitive/security authority.
    margin=regularity_margin(candidate)
    floor=numerical_regularity_floor(candidate)
    if margin > floor:
        return candidate, {
            'admissible':True,'retracted':False,
            'reason':f'DKT geometry is admissible in detected stratum Sigma_{candidate.stratum_index} with sampled immersion margin {margin:.4f}',
            'stratum_transition_admissible':candidate.stratum_index!=previous.stratum_index,
        }
    # Find the maximal numerically distinguishable admissible point on the local
    # path by bisection. Iteration count follows float mantissa precision rather
    # than an authored geometric percentage/step grid.
    lo,hi=0.0,1.0
    best=previous.model_copy(deep=True)
    for _ in range(sys.float_info.mant_dig):
        t=(lo+hi)/2.0
        trial=interpolate(previous,candidate,t)
        if regularity_margin(trial)>numerical_regularity_floor(trial):
            best=trial;lo=t
        else:
            hi=t
    if lo>0.0:
        return best, {
            'admissible':True,'retracted':True,
            'reason':f'DKT deformation was retracted to the maximal sampled-immersion-admissible local-path point t={lo:.17g}',
        }
    return previous.model_copy(deep=True), {
        'admissible':False,'retracted':True,
        'reason':'candidate DKT deformation lost immersion regularity; restored trusted knot',
    }
