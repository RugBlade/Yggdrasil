from __future__ import annotations

import math
from noeron.math.linalg import clamp
from noeron.math.models import EGRMathState


def chi(entropy_state: float) -> float:
    """Explicit monotone Noeron EGR -> RL entropy chart.

    The manuscript supplies the entropy-current/production law, but not a canonical
    EGR->RL map.  v0.7.1 retains the declared Noeron extension
    chi(S)=log(1+S).  It is monotone and does not collapse all large entropies to 1.
    """
    return math.log1p(max(0.0,float(entropy_state)))


def entropy_direction(
    previous_entropy_state: float,
    previous_current: float,
    irg_entropy_source: float,
    dkt_deformation: float,
    *,
    dt: float = 1.0,
) -> EGRMathState:
    """Homogeneous finite reduction of div(J_tot)=Sigma>=0 upstream of RL.

    Sigma is sourced by the live IRG interaction and DKT deformation.  The second-law
    orientation advances an unbounded entropy state.  chi maps that state to the
    distinguished RL entropy coordinate before the RL geodesic step.
    """
    source=max(0.0,float(irg_entropy_source))
    deformation_source=max(0.0,0.035*float(dkt_deformation)**2)
    sigma=max(0.0,source+deformation_source)
    prevS=max(0.0,float(previous_entropy_state))
    S=prevS+sigma*dt
    current=max(0.0,float(previous_current))+sigma*dt
    previous_mapped=chi(prevS); target=chi(S)
    return EGRMathState(
        bridge_name='chi-log1p-causal-v0.7.1',previous_entropy_state=prevS,entropy_state=S,
        previous_mapped_entropy=previous_mapped,candidate_mapped_entropy=target,mapped_entropy=target,
        target_logical_entropy=target,entropy_current=current,entropy_production=sigma,raw_entropy_production=sigma,
        irg_entropy_source=source,dkt_deformation_source=deformation_source,allowed_step_scale=1.0,arrow_orientation=1,
        balance_residual=((current-max(0.0,float(previous_current)))/dt)-sigma,bridge_residual=0.0,
    )


def close_bridge(egr_state:EGRMathState, realized_entropy_coordinate:float)->EGRMathState:
    out=egr_state.model_copy(deep=True)
    out.bridge_residual=float(realized_entropy_coordinate)-out.target_logical_entropy
    return out


def orient_entropy(previous_entropy:float,candidate_entropy:float,previous_current:float,irg_entropy_source:float,dt:float=1.0)->EGRMathState:
    """Compatibility helper for older tests/tools; v0.6.1 cognition uses entropy_direction."""
    prev_state=max(0.0,math.expm1(max(0.0,float(previous_entropy))))
    base=entropy_direction(prev_state,previous_current,irg_entropy_source,0.0,dt=dt)
    delta=float(candidate_entropy)-float(previous_entropy)
    raw=delta/dt+max(0.0,float(irg_entropy_source))
    scale=1.0
    if raw<0.0 and delta<0.0:
        scale=clamp((max(0.0,float(irg_entropy_source))*dt)/(-delta+1e-15),0.0,1.0)
    mapped=float(previous_entropy)+scale*delta
    sigma=max(0.0,(mapped-float(previous_entropy))/dt+max(0.0,float(irg_entropy_source)))
    base.candidate_mapped_entropy=float(candidate_entropy); base.mapped_entropy=mapped; base.target_logical_entropy=mapped
    base.entropy_production=sigma; base.raw_entropy_production=raw; base.entropy_current=float(previous_current)+sigma*dt
    base.allowed_step_scale=scale; base.balance_residual=((base.entropy_current-float(previous_current))/dt)-sigma
    return base
