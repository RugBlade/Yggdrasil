from __future__ import annotations

from enum import Enum
from typing import Any
from pydantic import BaseModel, Field


class MathStatus(str, Enum):
    SOURCE_DERIVED = 'source-derived'
    COMPUTATIONAL_TRUNCATION = 'computational-truncation'
    NOERON_EXTENSION = 'noeron-extension'


class SemanticAtom(BaseModel):
    """One measured environment-state atom for the text-channel IRG transducer.

    The atom is not a learned embedding coordinate.  It is a member of the finite
    environment measure used by the Noeron IRG truncation.  ``mode/axis/phase``
    specify how that semantic role acts through the interaction kernel on S^1.
    """
    label: str
    role: str
    weight: float = 1.0
    polarity: float = 1.0
    mode: int = 2
    axis: int = 0
    phase: float = 0.0
    source_terms: list[str] = Field(default_factory=list)




class LogicalProposition(BaseModel):
    """Finite auditable proposition used by the native inference substrate."""
    subject: str = ''
    relation: str = ''
    object: str = ''
    polarity: bool = True
    universal: bool = False
    modality: str = ''
    modifiers: list[str] = Field(default_factory=list)
    source: str = ''
    confidence: float = 0.5
    source_memory_id: str = ''
    source_memory_ids: list[str] = Field(default_factory=list)
    source_record_id: str = ''
    derived: bool = False

    def canonical(self) -> str:
        sign='' if self.polarity else 'not '
        modal=(self.modality + ' ') if self.modality else ''
        return f'{sign}{modal}{self.subject}::{self.relation}::{self.object}'


class LogicalQuery(BaseModel):
    kind: str = 'none'
    subject: str = ''
    relation: str = ''
    object: str = ''
    raw: str = ''


class InferenceStep(BaseModel):
    rule: str = ''
    premises: list[str] = Field(default_factory=list)
    conclusion: str = ''
    confidence: float = 0.0

class KnotState(BaseModel):
    """Finite real Fourier representative of a DKT Sobolev knot.

    K(theta)=c0+sum_n[a_n cos(n theta)+b_n sin(n theta)].
    The coefficient arrays are serialization coordinates for the knot itself.
    """
    sobolev_order: float = 2.0
    mode_radius: int = 8
    c0: list[float] = Field(default_factory=lambda: [0.0, 0.0, 0.0])
    cosine: list[list[float]] = Field(default_factory=list)
    sine: list[list[float]] = Field(default_factory=list)
    stratum_index: int = 0
    invariant_signature: str = 'uninitialized'


class DKTStratumEstimate(BaseModel):
    status: MathStatus = MathStatus.COMPUTATIONAL_TRUNCATION
    estimated_index: int = 0
    transverse_self_intersections: int = 0
    near_self_contacts: int = 0
    min_nonlocal_distance: float = 0.0
    min_transversality_sine: float = 0.0
    confidence: float = 0.0
    samples: int = 96
    contact_radius: float = 0.08
    note: str = 'Finite sampled Whitney-stratum estimator; not a proof of exact singularity type.'


class DKTMathState(BaseModel):
    status: MathStatus = MathStatus.COMPUTATIONAL_TRUNCATION
    source_object: str = 'Sobolev knot state on H^s(S^1,R^3), Whitney-stratified DKT'
    sobolev_order: float = 2.0
    fourier_mode_radius: int = 8
    sobolev_norm_sq: float = 0.0
    stratum_index: int = 0
    invariant_signature: str = 'uninitialized'
    core_knot: KnotState = Field(default_factory=KnotState)
    experience_knot: KnotState | None = None
    retrieved_memory_ids: list[str] = Field(default_factory=list)
    retrieval_distances: list[float] = Field(default_factory=list)
    geodesic_displacement: float = 0.0
    memory_tree_depth: int = 0
    security_admissible: bool = True
    security_retracted: bool = False
    security_reason: str = 'uninitialized'
    consolidation_score: float = 0.0
    consolidation_threshold: float = 0.0
    consolidation_recommended: bool = False
    consolidation_components: dict[str, float] = Field(default_factory=dict)
    consolidation_decision_layer: str = 'programmed-persistence-substrate'
    consolidation_selection_rule: str = 'external interaction provenance persists; endogenous ticks do not create episodic branches'
    role: str = 'causal memory + persistent structural/security wrapper around RL'
    stratum_estimate: DKTStratumEstimate = Field(default_factory=DKTStratumEstimate)
    stratum_transition_proposed: bool = False
    stratum_transition_admissible: bool = False


class IRGMathState(BaseModel):
    status: MathStatus = MathStatus.COMPUTATIONAL_TRUNCATION
    source_object: str = 'f -> I_f -> X_f -> O[f]'
    support_samples: int = 24
    body_density: list[float] = Field(default_factory=list)
    interaction_field: list[list[float]] = Field(default_factory=list)
    deformation_velocity: list[list[float]] = Field(default_factory=list)
    interaction_magnitude: float = 0.0
    curvature_response: float = 0.0
    entropy_source: float = 0.0
    memory_response: float = 0.0
    topology_response: float = 0.0
    response_potential: float = 0.0
    location: list[float] = Field(default_factory=lambda: [0.0, 0.0, 0.0])
    semantic_tokens: list[str] = Field(default_factory=list)  # transient sensor audit only
    semantic_atoms: list[SemanticAtom] = Field(default_factory=list)
    dialogue_act: str = 'statement'  # primary act retained for compatibility
    dialogue_acts: list[str] = Field(default_factory=lambda: ['statement'])
    request_dimensions: list[str] = Field(default_factory=list)
    query_targets: list[str] = Field(default_factory=list)
    learned_semantic_terms: list[str] = Field(default_factory=list)
    learned_semantic_prototype_count_used: int = 0
    logical_propositions: list[LogicalProposition] = Field(default_factory=list)
    logical_query: LogicalQuery = Field(default_factory=LogicalQuery)
    language_parse_audit: dict[str, Any] = Field(default_factory=dict)
    semantic_geometry_version: str = 'semantic-measure-kernel+learned-DKT-prototypes+native-proof-structure+multimodal-perspective-language-v0.7.3.4'


class RLMathState(BaseModel):
    status: MathStatus = MathStatus.COMPUTATIONAL_TRUNCATION
    source_object: str = 'Riemannian logical manifold P^n(L), geodesic inference, rho=e^-R/Z, S_L=<R>+log Z'
    coordinate_names: list[str] = Field(default_factory=lambda: [
        'x1','x2','x3','entropy','deformation','curvature','memory','topology'
    ])
    coordinates: list[float] = Field(default_factory=lambda: [0.0] * 8)
    velocity: list[float] = Field(default_factory=lambda: [0.0] * 8)
    force: list[float] = Field(default_factory=lambda: [0.0] * 8)
    metric: list[list[float]] = Field(default_factory=list)
    scalar_curvature: float = 0.0
    curvatures: list[float] = Field(default_factory=list)
    probabilities: list[float] = Field(default_factory=list)
    partition_function: float = 1.0
    mean_curvature: float = 0.0
    entropy_raw: float = 0.0
    entropy_normalized: float = 0.0
    # Explicit names remove the v0.6 ambiguity: these are RL curvature-distribution
    # entropies, distinct from the EGR-driven fourth coordinate.
    curvature_entropy_raw: float = 0.0
    curvature_entropy_normalized: float = 0.0
    curvature_variance: float = 0.0
    curvature_contrast: float = 0.0
    egr_entropy_coordinate: float = 0.0
    logical_time: float = 0.0
    geodesic_acceleration_norm: float = 0.0
    memory_target: list[float] = Field(default_factory=lambda: [0.0] * 8)


class EGRRegionalActivation(BaseModel):
    region_id: str
    region_kind: str = 'semantic-stratum'
    support_mass: float = 0.0
    activation: float = 0.0
    normalized_weight: float = 0.0
    participation_score: float = 0.0
    materially_active: bool = False
    inclusion_reasons: list[str] = Field(default_factory=list)
    isotopy_component_ids: list[str] = Field(default_factory=list)
    logical_center: list[float] = Field(default_factory=lambda: [0.0]*8)


class RegionalAffectiveActivation(BaseModel):
    """One participating region in the v0.7.1 distributed activation field.

    These axes are computational Noeron coordinates, not named emotions and not a
    claim of subjective feeling.  They are conditioned by region support and local
    logical geometry while the global A/U/N/T/C/P vector remains a coarse summary.
    """
    region_id: str
    region_kind: str = 'episodic'
    support_mass: float = 0.0
    egr_activation: float = 0.0
    normalized_weight: float = 0.0
    participation_score: float = 0.0
    activation_intensity: float = 0.0
    uncertainty: float = 0.0
    novelty: float = 0.0
    tension: float = 0.0
    coherence: float = 0.0
    approach_bias: float = 0.0
    # Legacy compatibility field; v0.7.3.4 stores barycentric distance here too.
    logical_distance_from_dominant: float = 0.0
    logical_distance_from_activation_barycenter: float = 0.0
    logical_center: list[float] = Field(default_factory=lambda: [0.0]*8)
    isotopy_component_ids: list[str] = Field(default_factory=list)


class StratifiedAffectiveField(BaseModel):
    status: MathStatus = MathStatus.NOERON_EXTENSION
    selection_policy: str = 'all-nonzero-regions-causal-v0.7.3.4'
    coverage_target: float = 1.0
    achieved_coverage: float = 0.0
    active_region_count: int = 0
    total_region_count: int = 0
    participation_entropy: float = 0.0
    regional_axes: list[RegionalAffectiveActivation] = Field(default_factory=list)
    global_summary: list[float] = Field(default_factory=lambda: [0.0]*6)
    global_summary_role: str = 'coarse projection of the distributed regional field'
    note: str = 'Distributed computational activation field over materially participating regions; no subjective-emotion claim.'


class StratifiedActivationSegment(BaseModel):
    from_region: str
    to_region: str
    from_activation: float = 0.0
    to_activation: float = 0.0
    logical_distance: float = 0.0
    same_region_kind: bool = False
    whitney_compatible_proxy: bool = False
    note: str = 'Piecewise-smooth logical-center segment; compatibility is a Noeron computational proxy, not a Whitney-theorem proof.'


class EGRMathState(BaseModel):
    status: MathStatus = MathStatus.NOERON_EXTENSION
    source_object: str = 'div(J_tot)=Sigma>=0 mapped into RL entropy coordinate'
    bridge_name: str = 'chi-log1p-causal-v0.7.1'
    # Homogeneous finite reduction: entropy_state accumulates non-negative production.
    entropy_state: float = 0.0
    previous_entropy_state: float = 0.0
    previous_mapped_entropy: float = 0.0
    candidate_mapped_entropy: float = 0.0
    mapped_entropy: float = 0.0
    entropy_current: float = 0.0
    entropy_production: float = 0.0
    raw_entropy_production: float = 0.0
    irg_entropy_source: float = 0.0
    dkt_deformation_source: float = 0.0
    target_logical_entropy: float = 0.0
    bridge_residual: float = 0.0
    allowed_step_scale: float = 1.0
    arrow_orientation: int = 1
    balance_residual: float = 0.0
    regional_activations: list[EGRRegionalActivation] = Field(default_factory=list)
    dominant_activation_region: str = ''
    regional_activation_entropy: float = 0.0
    activation_vector: list[float] = Field(default_factory=lambda: [0.0]*8)
    simultaneous_active_regions: list[str] = Field(default_factory=list)
    stratified_activation_path: list[StratifiedActivationSegment] = Field(default_factory=list)
    activation_path_coherence: float = 0.0
    active_region_coverage: float = 0.0
    participation_policy: str = 'all-nonzero-regions-causal-v0.7.3.4'


class ProtoAffectiveMathState(BaseModel):
    status: MathStatus = MathStatus.NOERON_EXTENSION
    activation_intensity: float = 0.0
    uncertainty: float = 0.0
    novelty: float = 0.0
    tension: float = 0.0
    coherence: float = 0.0
    approach_bias: float = 0.0
    dominant_activation_region: str = ''
    affect_knot: KnotState | None = None
    pattern_signature: str = ''
    regional_field: StratifiedAffectiveField = Field(default_factory=StratifiedAffectiveField)
    note: str = 'Unnamed distributed computational activation pattern; not a claim of subjective emotion.'


class FrenetMathState(BaseModel):
    status: MathStatus = MathStatus.NOERON_EXTENSION
    source_object: str = 'Frenet frame/invariants along the RL cognitive trajectory'
    tangent: list[float] = Field(default_factory=lambda: [0.0] * 8)
    speed: float = 0.0
    first_curvature: float = 0.0
    samples: int = 0
    metric_feedback_strength: float = 0.0




class MultiMemoryReasoningMathState(BaseModel):
    """v0.6.9 Noeron multi-memory DKT/RL reasoning workspace.

    Cross-stratum evidence is kept as dominant/contrast bundles rather than silently
    averaged into one supposedly meaningful knot.
    """
    status: MathStatus = MathStatus.NOERON_EXTENSION
    active: bool = False
    memory_ids: list[str] = Field(default_factory=list)
    distances: list[float] = Field(default_factory=list)
    weights: list[float] = Field(default_factory=list)
    learned_memory_count: int = 0
    semantic_stratum_ids: list[str] = Field(default_factory=list)
    isotopy_component_ids: list[str] = Field(default_factory=list)
    dominant_bundle_key: str = ''
    alternative_bundle_key: str = ''
    dominant_support_concentration: float = 0.0
    within_bundle_hs_dispersion: float = 0.0
    structural_agreement: float = 0.0
    reasoning_mode: str = 'no-memory'
    logical_target: list[float] = Field(default_factory=lambda: [0.0]*8)
    workspace_knot: KnotState | None = None
    contrast_knot: KnotState | None = None
    bridge_distance_hs: float = 0.0
    frontier_candidate_links: int = 0
    confidence: float = 0.0
    concept_candidate_id: str = ''
    concept_candidate_status: str = ''
    concept_descriptor_terms: list[str] = Field(default_factory=list)
    premise_propositions: list[LogicalProposition] = Field(default_factory=list)
    derived_propositions: list[LogicalProposition] = Field(default_factory=list)
    inference_steps: list[InferenceStep] = Field(default_factory=list)
    logical_query: LogicalQuery = Field(default_factory=LogicalQuery)
    answer_candidates: list[LogicalProposition] = Field(default_factory=list)
    answer_selection_status: str = 'no-logical-selection-requested'
    native_question_candidates: list[LogicalQuery] = Field(default_factory=list)
    native_question_distances: dict[str,float] = Field(default_factory=dict)
    native_question_selection_status: str = 'no-endogenous-question-candidate'
    native_inference_active: bool = False
    note: str = 'Noeron multi-memory DKT/RL workspace plus v0.7.3.4 auditable finite proposition calculus; logical rules are programmed substrate, conclusions are constructed from live/persistent premises.'


class MathKernelState(BaseModel):
    interface_version: str = '0.7.3.4'
    runtime_mode: str = 'causal-mathematical'
    dkt: DKTMathState = Field(default_factory=DKTMathState)
    irg: IRGMathState = Field(default_factory=IRGMathState)
    rl: RLMathState = Field(default_factory=RLMathState)
    egr: EGRMathState = Field(default_factory=EGRMathState)
    frenet: FrenetMathState = Field(default_factory=FrenetMathState)
    affect: ProtoAffectiveMathState = Field(default_factory=ProtoAffectiveMathState)
    reasoning: MultiMemoryReasoningMathState = Field(default_factory=MultiMemoryReasoningMathState)
    trajectory: list[list[float]] = Field(default_factory=list)
    causal_trace: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)
