from __future__ import annotations

"""Distributed regional EGR activation and unnamed proto-affective field (v0.7.1).

NOERON_EXTENSION engineering coupling.  A single experience may recruit several
materially participating episodic/semantic regions at once.  Non-dominant regions
are not discarded merely because a stronger region exists.  The finite path between
logical centers is a Whitney/frontier compatibility *proxy*, not a theorem about the
manuscript DKT stratification.  The state is computational and does not claim
subjective feeling or hard-code human emotion labels.
"""

import math
from collections import defaultdict

from noeron.math import dkt
from noeron.math.linalg import clamp
from noeron.math.models import (
    EGRRegionalActivation, ProtoAffectiveMathState, StratifiedActivationSegment,
    RegionalAffectiveActivation, StratifiedAffectiveField,
)


def _dist(a,b):
    aa=(list(a)+[0.0]*8)[:8]; bb=(list(b)+[0.0]*8)[:8]
    return math.sqrt(sum((x-y)**2 for x,y in zip(aa,bb)))


def _all_nonzero_active_rows(rows:list[EGRRegionalActivation]):
    """Keep every region carrying non-zero EGR activation causally active.

    There is deliberately no authored salience floor, relative-to-dominant cutoff,
    or cumulative-coverage target.  Normalized activation mass is the participation
    measure itself.  Zero-mass regions are retained in audit rows but do not drive RL.
    """
    if not rows:
        return [],0.0
    z=sum(max(0.0,r.activation) for r in rows)
    if z<=0.0:
        for r in rows:
            r.normalized_weight=0.0;r.participation_score=0.0;r.materially_active=False
            r.inclusion_reasons=['zero-activation-no-causal-participation']
        return [],0.0
    active=[]
    for r in rows:
        r.normalized_weight=max(0.0,r.activation)/z
        r.participation_score=r.normalized_weight
        r.materially_active=bool(r.activation>0.0)
        r.inclusion_reasons=(['nonzero-egr-activation'] if r.materially_active else ['zero-activation-no-causal-participation'])
        if r.materially_active:
            active.append(r)
    # Sorting below is serialization only; no downstream winner is inferred from it.
    active.sort(key=lambda r:(-r.activation,r.region_id))
    return active,1.0


def _pairwise_stratified_relations(active:list[EGRRegionalActivation]):
    """Order-independent finite relations among every participating logical center.

    The legacy ``stratified_activation_path`` field is retained for schema
    compatibility, but v0.7.3.4 stores all unordered pairs rather than a greedy path
    rooted at a dominant region.  No Whitney compatibility theorem is inferred.
    ``activation_path_coherence`` is only the mean inverse metric separation and is
    not a choice/preference variable.
    """
    if len(active)<2:
        return [],1.0 if active else 0.0
    ordered=sorted(active,key=lambda r:r.region_id)
    relations=[]; proximity=[]
    for i,a in enumerate(ordered):
        for b in ordered[i+1:]:
            dist=_dist(a.logical_center,b.logical_center)
            relations.append(StratifiedActivationSegment(
                from_region=a.region_id,to_region=b.region_id,
                from_activation=a.activation,to_activation=b.activation,
                logical_distance=dist,same_region_kind=(a.region_kind==b.region_kind),
                whitney_compatible_proxy=False,
                note='v0.7.3.4 unordered finite logical-center relation; no Whitney compatibility theorem or semantic preference inferred.'
            ))
            proximity.append(1.0/(1.0+dist))
    return relations,(sum(proximity)/len(proximity) if proximity else 1.0)


def _unique_max_region(rows:list[EGRRegionalActivation])->str:
    positive=[r for r in rows if r.activation>0.0]
    if not positive:return ''
    top=max(r.activation for r in positive)
    tied=[r.region_id for r in positive if math.isclose(r.activation,top,rel_tol=0.0,abs_tol=math.ulp(max(1.0,abs(top))))]
    return tied[0] if len(tied)==1 else ''


def project_regional_activation(egr_state, irg_state, reasoning, retrieved):
    out=egr_state.model_copy(deep=True)
    if not retrieved:
        out.regional_activations=[];out.dominant_activation_region='';out.activation_vector=[0.0]*8
        out.regional_activation_entropy=0.0;out.simultaneous_active_regions=[];out.stratified_activation_path=[]
        out.activation_path_coherence=0.0;out.active_region_coverage=0.0
        out.participation_policy='all-nonzero-regions-causal-v0.7.3.4'
        return out
    weights=list(reasoning.weights) if reasoning.weights and len(reasoning.weights)==len(retrieved) else [1.0/len(retrieved)]*len(retrieved)
    grouped=defaultdict(lambda:{'mass':0.0,'coords':[0.0]*8,'components':set(),'kind':'episodic'})
    for w,(_dist0,m) in zip(weights,retrieved):
        key=f'stratum:{m.semantic_stratum_id}' if m.semantic_stratum_id else f'episodic:{m.memory_class}'
        g=grouped[key];g['mass']+=w;g['kind']='semantic-stratum' if m.semantic_stratum_id else 'episodic'
        if m.isotopy_component_id:g['components'].add(str(m.isotopy_component_id))
        c=(m.logical_coordinates+[0.0]*8)[:8]
        for i,x in enumerate(c):g['coords'][i]+=w*x
    sigma_n=out.entropy_production/(1.0+out.entropy_production)
    response_n=irg_state.response_potential/(1.0+irg_state.response_potential)
    global_drive=math.sqrt((sigma_n*sigma_n+response_n*response_n)/2.0)
    rows=[]
    for key,g in grouped.items():
        mass=max(0.0,float(g['mass']));activation=mass*global_drive
        local=[x/max(mass,1e-12) for x in g['coords']]
        rows.append(EGRRegionalActivation(region_id=key,region_kind=g['kind'],support_mass=mass,activation=activation,
            isotopy_component_ids=sorted(g['components']),logical_center=local))
    # Ordering is audit serialization only; exact activation ties have no winner semantics.
    rows.sort(key=lambda r:(-r.activation,r.region_id))
    z=sum(r.activation for r in rows)
    probs=[r.activation/z for r in rows if z>0.0 and r.activation>0]
    entropy=-sum(x*math.log(x) for x in probs) if probs else 0.0
    entropy_norm=entropy/math.log(len(probs)) if len(probs)>1 else 0.0
    active,coverage=_all_nonzero_active_rows(rows)

    activation_vector=[0.0]*8
    az=sum(r.activation for r in active)
    if az>0.0:
        for r in active:
            local=(r.logical_center+[0.0]*8)[:8]; w=r.activation/az
            for i,x in enumerate(local):activation_vector[i]+=w*global_drive*x
    activation_vector[3]=max(0.0,activation_vector[3])

    relations,coherence=_pairwise_stratified_relations(active)
    out.regional_activations=rows
    out.dominant_activation_region=_unique_max_region(rows)
    out.regional_activation_entropy=clamp(entropy_norm,0.0,1.0)
    out.simultaneous_active_regions=[r.region_id for r in active]
    out.active_region_coverage=coverage
    out.participation_policy='all-nonzero-regions-causal-v0.7.3.4'
    out.stratified_activation_path=relations
    out.activation_path_coherence=coherence
    out.activation_vector=activation_vector
    return out


def _regional_affective_field(egr_state, global_axes):
    """Project computational coordinates over every participating EGR region.

    Local separation is measured from the activation barycenter, never from a
    storage/order-selected dominant region.  These are engineered continuous state
    coordinates only; they have no authority over communication or preference.
    """
    A,U,N,T,C,P=global_axes
    active=[r for r in egr_state.regional_activations if getattr(r,'materially_active',False)]
    if not active:
        return StratifiedAffectiveField(global_summary=list(global_axes),coverage_target=1.0,
            achieved_coverage=0.0,active_region_count=0,total_region_count=len(egr_state.regional_activations),
            selection_policy='all-nonzero-regions-causal-v0.7.3.4')
    z=sum(r.normalized_weight for r in active) or 1.0
    bary=[sum((r.normalized_weight/z)*(r.logical_center+[0.0]*8)[i] for r in active) for i in range(8)]
    rows=[]
    for r in active:
        rel=clamp(r.normalized_weight/z,0.0,1.0)
        dist=_dist(bary,r.logical_center)
        dnorm=dist/(1.0+dist)
        local_activation=clamp(math.sqrt((A*A+rel*rel)/2.0),0.0,1.0)
        local_uncertainty=clamp(math.sqrt((U*U+(1.0-rel)**2)/2.0),0.0,1.0)
        local_novelty=clamp(math.sqrt((N*N+dnorm*dnorm)/2.0),0.0,1.0)
        local_tension=clamp(math.sqrt((T*T+local_uncertainty**2+dnorm**2)/3.0),0.0,1.0)
        proximity=1.0/(1.0+dist)
        local_coherence=clamp(math.sqrt((C*C+rel*rel+proximity*proximity)/3.0),0.0,1.0)
        local_approach=clamp(local_coherence-local_uncertainty,-1.0,1.0)
        rows.append(RegionalAffectiveActivation(
            region_id=r.region_id,region_kind=r.region_kind,support_mass=r.support_mass,egr_activation=r.activation,
            normalized_weight=r.normalized_weight,participation_score=r.participation_score,
            activation_intensity=local_activation,uncertainty=local_uncertainty,novelty=local_novelty,
            tension=local_tension,coherence=local_coherence,approach_bias=local_approach,
            logical_distance_from_dominant=dist,logical_distance_from_activation_barycenter=dist,
            logical_center=list(r.logical_center),isotopy_component_ids=list(r.isotopy_component_ids)))
    ps=[x.normalized_weight for x in rows];pz=sum(ps) or 1.0;ps=[x/pz for x in ps]
    h=-sum(q*math.log(q) for q in ps if q>0)
    hn=h/math.log(len(ps)) if len(ps)>1 else 0.0
    return StratifiedAffectiveField(selection_policy='all-nonzero-regions-causal-v0.7.3.4',coverage_target=1.0,
        achieved_coverage=egr_state.active_region_coverage,active_region_count=len(rows),
        total_region_count=len(egr_state.regional_activations),participation_entropy=clamp(hn,0.0,1.0),
        regional_axes=rows,global_summary=list(global_axes),
        note='Distributed computational coordinates over all nonzero EGR regions; barycentric geometry only; no subjective-emotion or preference claim.')


def proto_affective_state(irg_state,egr_state,reasoning,frenet_state,dkt_displacement:float)->ProtoAffectiveMathState:
    """Unnamed computational activation geometry without hand-weighted affect utilities."""
    sigma_n=egr_state.entropy_production/(1.0+egr_state.entropy_production)
    interaction_n=irg_state.response_potential/(1.0+irg_state.response_potential)
    novelty=dkt_displacement/(1.0+dkt_displacement)
    # Lack of proof/evidence support is uncertainty. No fixed 0.35 pseudo-belief is injected.
    confidence=reasoning.confidence if reasoning.active else 0.0
    coherence=reasoning.structural_agreement if reasoning.active else 0.0
    uncertainty=clamp(1.0-confidence,0.0,1.0)
    dispersion=(reasoning.within_bundle_hs_dispersion/(1.0+reasoning.within_bundle_hs_dispersion) if reasoning.active else 0.0)
    bend=frenet_state.first_curvature/(1.0+frenet_state.first_curvature)
    tension=clamp(math.sqrt((uncertainty**2+dispersion**2+bend**2+sigma_n**2)/4.0),0.0,1.0)
    activation=clamp(math.sqrt((sigma_n**2+interaction_n**2+novelty**2)/3.0),0.0,1.0)
    approach=clamp(coherence-uncertainty,-1.0,1.0)
    axes=[activation,uncertainty,novelty,tension,coherence,approach]
    field=_regional_affective_field(egr_state,axes)

    # Proto-affect is diagnostic state in v0.7.3.4.  It does not inject an
    # independently authored deformation into DKT; the causal regional EGR field
    # already acts through the RL/Frenet trajectory before DKT closure.
    k=None
    bins=[int(round(clamp(x,0.0,1.0)*9)) for x in [activation,uncertainty,novelty,tension,coherence]]
    approach_bin=int(round(clamp(approach,-1.0,1.0)*4))
    pattern=f'A{bins[0]}-U{bins[1]}-N{bins[2]}-T{bins[3]}-C{bins[4]}-P{approach_bin:+d}-R{field.active_region_count}'
    return ProtoAffectiveMathState(activation_intensity=activation,uncertainty=uncertainty,novelty=novelty,tension=tension,
        coherence=coherence,approach_bias=approach,dominant_activation_region=egr_state.dominant_activation_region,
        affect_knot=k,pattern_signature=pattern,regional_field=field,
        note='Unnamed distributed computational activation geometry. Axes are direct/RMS geometric observables, not authored human-emotion utilities, a claim of subjective emotion, subjective-feeling claims, or choices.')



def upgrade_existing_distributed_field(egr_state, affect_state):
    """Reproject a persisted v0.6.9 snapshot into v0.7.1 field coordinates.

    This is representational migration only: it consumes already-persisted regional
    activations/global affect axes, creates no event, no memory and no conversational
    turn.
    """
    e=egr_state.model_copy(deep=True); a=affect_state.model_copy(deep=True)
    rows=list(e.regional_activations)
    rows.sort(key=lambda r:r.activation,reverse=True)
    active,coverage=_all_nonzero_active_rows(rows)
    e.regional_activations=rows;e.simultaneous_active_regions=[r.region_id for r in active]
    e.dominant_activation_region=_unique_max_region(rows)
    e.active_region_coverage=coverage;e.participation_policy='all-nonzero-regions-causal-v0.7.3.4'
    e.stratified_activation_path,e.activation_path_coherence=_pairwise_stratified_relations(active)
    # Preserve existing drive scale while moving the causal vector onto active field.
    drive=sum(max(0.0,r.activation) for r in rows)
    az=sum(max(0.0,r.activation) for r in active) or 1.0
    vec=[0.0]*8
    for r in active:
        w=max(0.0,r.activation)/az
        for i,x in enumerate((r.logical_center+[0.0]*8)[:8]):vec[i]+=w*drive*x
    vec[3]=max(0.0,vec[3]);e.activation_vector=vec
    axes=[a.activation_intensity,a.uncertainty,a.novelty,a.tension,a.coherence,a.approach_bias]
    a.regional_field=_regional_affective_field(e,axes)
    # Keep old signature's scalar bins, but append the active-region cardinality.
    if '-R' not in a.pattern_signature:a.pattern_signature=f'{a.pattern_signature}-R{a.regional_field.active_region_count}'
    a.note='Unnamed distributed computational activation field; migrated without replaying experience; no subjective-emotion claim.'
    return e,a
