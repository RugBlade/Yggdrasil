from __future__ import annotations

import math


def dot(a: list[float], b: list[float]) -> float:
    return sum(x * y for x, y in zip(a, b))


def norm(a: list[float]) -> float:
    return math.sqrt(max(0.0, dot(a, a)))


def add(a: list[float], b: list[float]) -> list[float]:
    return [x + y for x, y in zip(a, b)]


def sub(a: list[float], b: list[float]) -> list[float]:
    return [x - y for x, y in zip(a, b)]


def scale(a: list[float], c: float) -> list[float]:
    return [c * x for x in a]


def mat_vec(a: list[list[float]], x: list[float]) -> list[float]:
    return [dot(row, x) for row in a]


def quad(a: list[list[float]], x: list[float]) -> float:
    return dot(x, mat_vec(a, x))


def eye(n: int) -> list[list[float]]:
    return [[1.0 if i == j else 0.0 for j in range(n)] for i in range(n)]


def inverse(a: list[list[float]]) -> list[list[float]]:
    n = len(a)
    aug = [list(map(float, row)) + ident for row, ident in zip(a, eye(n))]
    for col in range(n):
        pivot = max(range(col, n), key=lambda r: abs(aug[r][col]))
        if abs(aug[pivot][col]) < 1e-12:
            raise ValueError('Singular metric matrix')
        aug[col], aug[pivot] = aug[pivot], aug[col]
        piv = aug[col][col]
        aug[col] = [v / piv for v in aug[col]]
        for r in range(n):
            if r == col:
                continue
            fac = aug[r][col]
            if fac:
                aug[r] = [x - fac * y for x, y in zip(aug[r], aug[col])]
    return [row[n:] for row in aug]



def numerically_tied(a: float, b: float) -> bool:
    """One-ULP equality for choice/ranking ties; no authored semantic tolerance."""
    aa=float(a); bb=float(b)
    scale=max(1.0,abs(aa),abs(bb))
    return math.isclose(aa,bb,rel_tol=0.0,abs_tol=math.ulp(scale))


def clamp(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, x))
