from __future__ import annotations

import math

from noeron.math.frenet import deform_metric
from noeron.math.linalg import inverse, mat_vec, norm, quad, sub, clamp
from noeron.math.models import RLMathState

_EPS=1e-9


def _alpha_derivative(i: int, u: float, lam: list[float]) -> float:
    """Finite chart realization of the manuscript alpha_i derivative entering g_ij."""
    li=lam[i]; n=len(lam)
    base=(i+1)*li*math.cos((i+1)*u)
    nonlinear=0.18*(li*li)*(i+2)*math.cos((i+2)*u)
    coupling=0.0
    for j,lj in enumerate(lam):
        if j==i: continue
        freq=1+((i+j+1)%7)
        coupling += 0.025*li*lj*freq*math.cos(freq*u)
    return base+nonlinear+coupling


def manuscript_metric(coords: list[float], samples: int=32) -> list[list[float]]:
    """Finite quadrature of g_ij=delta_ij ∫(d alpha_i/ds)^2 ds, with a small positive regularizer."""
    n=len(coords); g=[[0.0]*n for _ in range(n)]
    for i in range(n):
        integral=0.0
        for k in range(samples):
            u=2.0*math.pi*(k+0.5)/samples
            d=_alpha_derivative(i,u,coords)
            integral += d*d
        integral *= 2.0*math.pi/samples
        g[i][i]=0.25+integral
    return g


def logical_metric(coords: list[float], frenet_tangent: list[float]|None=None, frenet_strength: float=0.0) -> list[list[float]]:
    base=manuscript_metric(coords)
    return deform_metric(base,frenet_tangent or [],frenet_strength)


def _metric_derivatives(coords: list[float], tangent: list[float], strength: float, h: float=2e-4):
    n=len(coords); deriv=[]
    for a in range(n):
        p=coords[:]; m=coords[:]; p[a]+=h; m[a]-=h
        gp=logical_metric(p,tangent,strength); gm=logical_metric(m,tangent,strength)
        deriv.append([[(gp[i][j]-gm[i][j])/(2*h) for j in range(n)] for i in range(n)])
    return deriv


def christoffel(coords: list[float], tangent: list[float]|None=None, strength: float=0.0) -> list[list[list[float]]]:
    tangent=tangent or [0.0]*len(coords)
    g=logical_metric(coords,tangent,strength); gi=inverse(g); dg=_metric_derivatives(coords,tangent,strength)
    n=len(coords); G=[[[0.0]*n for _ in range(n)] for __ in range(n)]
    for k in range(n):
        for i in range(n):
            for j in range(n):
                G[k][i][j]=0.5*sum(gi[k][l]*(dg[i][l][j]+dg[j][l][i]-dg[l][i][j]) for l in range(n))
    return G


def scalar_curvature(coords: list[float], tangent: list[float]|None=None, strength: float=0.0, h: float=5e-4) -> float:
    tangent=tangent or [0.0]*len(coords); n=len(coords)
    g=logical_metric(coords,tangent,strength); gi=inverse(g); G=christoffel(coords,tangent,strength)
    dG=[]
    for a in range(n):
        p=coords[:]; m=coords[:]; p[a]+=h; m[a]-=h
        gp=christoffel(p,tangent,strength); gm=christoffel(m,tangent,strength)
        dG.append([[[ (gp[k][i][j]-gm[k][i][j])/(2*h) for j in range(n)] for i in range(n)] for k in range(n)])
    ric=[[0.0]*n for _ in range(n)]
    for i in range(n):
        for j in range(n):
            term=0.0
            for k in range(n):
                term += dG[k][k][i][j] - dG[j][k][i][k]
                for m in range(n):
                    term += G[k][i][j]*G[m][k][m] - G[m][i][k]*G[k][j][m]
            ric[i][j]=term
    R=sum(gi[i][j]*ric[i][j] for i in range(n) for j in range(n))
    if not math.isfinite(R):
        return 0.0
    return clamp(R,-30.0,30.0)


def entropy_from_curvatures(curvatures: list[float]) -> tuple[list[float],float,float,float,float]:
    if not curvatures: return [],1.0,0.0,0.0,0.0
    vals=[clamp(float(r),-20.0,20.0) for r in curvatures]
    weights=[math.exp(-r) for r in vals]; z=sum(weights); p=[w/z for w in weights]
    mean=sum(pi*r for pi,r in zip(p,vals)); S=mean+math.log(z)
    normalized=0.0 if len(vals)<=1 else clamp(S/math.log(len(vals)),0.0,1.0)
    return p,z,mean,S,normalized


def irg_force(irg, egr, previous_entropy: float) -> list[float]:
    """IRG forcing with EGR supplying the entropy direction.

    The first four distinguished coordinates are (x1,x2,x3,S).  IRG supplies
    spatial/environmental interaction.  The fourth component is not an arbitrary
    heuristic: it is pulled from the upstream EGR entropy-current target.
    """
    entropy_gap = float(egr.target_logical_entropy) - float(previous_entropy)
    return [
        0.08*irg.location[0], 0.08*irg.location[1], 0.08*irg.location[2],
        0.85*entropy_gap + 0.35*egr.entropy_production,
        0.50*irg.interaction_magnitude,
        0.45*irg.curvature_response,
        0.50*irg.memory_response,
        0.40*irg.topology_response,
    ]


def weighted_memory_target(retrieved, n: int=8) -> list[float]:
    if not retrieved: return [0.0]*n
    weights=[1.0/(0.05+d) for d,_ in retrieved]; z=sum(weights)
    out=[0.0]*n
    for w,(_d,m) in zip(weights,retrieved):
        coords=(m.logical_coordinates+[0.0]*n)[:n]
        for i,x in enumerate(coords): out[i]+=w*x/z
    return out


def geodesic_step(previous: RLMathState, irg, egr, retrieved, frenet_tangent: list[float], frenet_strength: float, dt: float=0.18, memory_target_override: list[float]|None=None) -> tuple[list[float],list[float],list[float],float]:
    x=(previous.coordinates+[0.0]*8)[:8]; v=(previous.velocity+[0.0]*8)[:8]
    # EGR is upstream: its entropy current sets the orientation before this step.
    f=irg_force(irg,egr,x[3]); target=(list(memory_target_override) if memory_target_override is not None else weighted_memory_target(retrieved))
    # v0.6.7 NOERON_EXTENSION: regionally projected EGR activation biases the
    # logical trajectory after the global entropy direction has been fixed.
    av=(list(getattr(egr,'activation_vector',[]))+[0.0]*8)[:8]
    for i in range(8):
        if i==3:
            f[i]+=0.04*max(0.0,av[i])
        else:
            f[i]+=0.06*av[i]
    # DKT-selected memories exert a geometric memory potential on RL.
    if retrieved:
        for i in range(8):
            f[i]+=0.12*(target[i]-x[i])
    # Do not let memory attraction reverse the EGR entropy arrow on coordinate S.
    f[3]=max(f[3], 0.15*egr.entropy_production)
    G=christoffel(x,frenet_tangent,frenet_strength)
    geo=[sum(G[k][i][j]*v[i]*v[j] for i in range(8) for j in range(8)) for k in range(8)]
    a=[f[k]-geo[k]-0.12*v[k] for k in range(8)]
    nv=[clamp(v[k]+dt*a[k],-2.5,2.5) for k in range(8)]
    nx=[]
    for k in range(8):
        candidate=x[k]+dt*nv[k]
        # The EGR entropy coordinate is intentionally not clipped to [-4,4] or [0,1].
        nx.append(candidate if k==3 else clamp(candidate,-4.0,4.0))
    nx[3]=max(x[3],nx[3])
    return nx,nv,f,norm(a)

def build_state(coords: list[float], velocity: list[float], force: list[float], trajectory: list[list[float]], memory_target: list[float], frenet_tangent: list[float], frenet_strength: float, logical_time: float, acceleration_norm: float) -> RLMathState:
    metric=logical_metric(coords,frenet_tangent,frenet_strength)
    sample_points=(trajectory[-3:] if trajectory else [])+[coords]
    curv=[scalar_curvature(p,frenet_tangent,frenet_strength) for p in sample_points]
    probs,z,mean,S,Sn=entropy_from_curvatures(curv)
    arithmetic_mean=(sum(curv)/len(curv)) if curv else 0.0
    variance=(sum((r-arithmetic_mean)**2 for r in curv)/len(curv)) if curv else 0.0
    contrast=(max(curv)-min(curv)) if curv else 0.0
    return RLMathState(coordinates=coords,velocity=velocity,force=force,metric=metric,scalar_curvature=curv[-1] if curv else 0.0,
                       curvatures=curv,probabilities=probs,partition_function=z,mean_curvature=mean,entropy_raw=S,
                       entropy_normalized=Sn,curvature_entropy_raw=S,curvature_entropy_normalized=Sn,
                       curvature_variance=variance,curvature_contrast=contrast,
                       egr_entropy_coordinate=(coords[3] if len(coords)>3 else 0.0),logical_time=logical_time,
                       geodesic_acceleration_norm=acceleration_norm,memory_target=memory_target)
