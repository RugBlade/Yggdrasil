from __future__ import annotations

"""Stage 8B transparent surface-composition diagnostics.

This module is deliberately grammatical/structural rather than semantic.  It may
recognize surface relations such as question form, conditionals, negation,
modality, quantification, causal/temporal links, contrast, analogy and
correction.  It has no authority to assert proposition truth, activate
cognitive memory, select an answer, invoke Terra, alter relationships, write
source, or deploy code.

Semantic/factual authority remains the existing IRG/DKT/provenance-gated native
reasoning path.
"""

import re
from typing import Iterable

COMPOSITION_VERSION = "0.8.1-stage8B-composition-v1"
LANGUAGE_MECHANISM_VERSION = "0.8.1-stage8B-native-language-v1"

_WORD_RE = re.compile(r"[A-Za-z]+(?:[-'][A-Za-z]+)*")
_SENTENCE_RE = re.compile(r"(?<=[.!?])\s+|\n+")

QUESTION_WORDS = ("why", "how", "when", "where", "who", "which", "what")
YESNO_START = (
    "am", "is", "are", "was", "were", "do", "does", "did",
    "have", "has", "had", "can", "could", "may", "might",
    "will", "would", "should", "must",
)
MODALS = ("can", "could", "may", "might", "will", "would", "should", "must")
UNCERTAINTY = (
    "maybe", "perhaps", "possibly", "probably", "likely", "unlikely",
    "uncertain", "apparently", "seems", "seem", "appears", "appear",
)
NEGATORS = ("not", "never", "neither", "nor", "nothing", "nobody", "nowhere")
UNIVERSAL = ("all", "every", "each", "any")
EXISTENTIAL = ("some", "someone", "something", "there")
CORRECTION_MARKERS = ("actually", "rather", "instead", "i mean", "correction")
CONTRAST_MARKERS = ("but", "however", "although", "though", "yet", "whereas")
ANALOGY_MARKERS = ("like", "similar to", "analogous to", "as if", "as though")


def _words(text: str) -> list[str]:
    return [w.lower() for w in _WORD_RE.findall(text)]


def _contains_phrase(low: str, phrase: str) -> bool:
    if " " in phrase:
        return phrase in low
    return re.search(rf"\b{re.escape(phrase)}\b", low) is not None


def _question_family(sentence: str) -> str:
    stripped = sentence.strip()
    low = stripped.lower().lstrip(" \t\"'")
    words = _words(low)
    if not words:
        return ""
    first = words[0]
    if first in QUESTION_WORDS:
        return f"{first}-question"
    if first in YESNO_START and stripped.endswith("?"):
        return "yes-no-question"
    if stripped.endswith("?"):
        return "open-question"
    return ""


def _quantifier_frames(words: list[str]) -> list[str]:
    frames: list[str] = []
    wordset = set(words)
    if wordset.intersection(UNIVERSAL):
        frames.append("quantifier:universal")
    if wordset.intersection(EXISTENTIAL):
        frames.append("quantifier:existential")
    # "no <noun>" is a quantificational surface form distinct from ordinary "not".
    if "no" in wordset:
        frames.append("quantifier:negative")
    return frames


def _tense_aspect(words: list[str]) -> list[str]:
    frames: list[str] = []
    ws = set(words)
    if ws.intersection({"was", "were", "had", "did"}) or any(w.endswith("ed") for w in words):
        frames.append("tense:past-surface")
    if ws.intersection({"will", "shall"}):
        frames.append("tense:future-surface")
    if ws.intersection({"is", "are", "am", "do", "does", "has", "have"}):
        frames.append("tense:present-surface")
    if ws.intersection({"been", "being"}) or any(w.endswith("ing") for w in words):
        frames.append("aspect:progressive-or-participial-surface")
    if ws.intersection({"has", "have", "had"}) and ("been" in ws or any(w.endswith("ed") for w in words)):
        frames.append("aspect:perfect-surface")
    return frames


def _split_once(sentence: str, marker_pattern: str) -> tuple[str, str] | None:
    m = re.search(marker_pattern, sentence, flags=re.I)
    if not m:
        return None
    left = sentence[:m.start()].strip(" ,;:-")
    right = sentence[m.end():].strip(" ,;:-?.!")
    if not left or not right:
        return None
    return left, right


def _conditional(sentence: str) -> tuple[list[dict], list[dict], list[str]]:
    s = sentence.strip().rstrip(".!?")
    low = s.lower()
    clauses: list[dict] = []
    links: list[dict] = []
    frames: list[str] = []
    # Canonical if ... then ... / if ... , ...
    if re.match(r"^\s*if\b", low):
        body = re.sub(r"^\s*if\b", "", s, count=1, flags=re.I).strip()
        parts = re.split(r"\bthen\b|,", body, maxsplit=1, flags=re.I)
        if len(parts) == 2 and all(x.strip() for x in parts):
            a, b = parts[0].strip(), re.sub(r'^\s*then\b', '', parts[1], count=1, flags=re.I).strip()
            clauses.extend([
                {"role": "antecedent", "text": a},
                {"role": "consequent", "text": b},
            ])
            links.append({
                "relation": "conditional",
                "from_role": "antecedent",
                "to_role": "consequent",
                "authority": "surface-composition-only",
            })
            frames.append("conditional")
            return clauses, links, frames
    # ... if ... (surface dependency only; do not infer truth direction)
    split = _split_once(s, r"\bif\b")
    if split:
        left, right = split
        clauses.extend([
            {"role": "matrix-clause", "text": left},
            {"role": "condition-clause", "text": right},
        ])
        links.append({
            "relation": "conditional",
            "from_role": "condition-clause",
            "to_role": "matrix-clause",
            "authority": "surface-composition-only",
        })
        frames.append("conditional")
    return clauses, links, frames


def _binary_link(sentence: str, relation: str, marker_pattern: str, left_role: str, right_role: str):
    split = _split_once(sentence.strip().rstrip(".!?"), marker_pattern)
    if not split:
        return [], [], []
    left, right = split
    return (
        [{"role": left_role, "text": left}, {"role": right_role, "text": right}],
        [{
            "relation": relation,
            "from_role": left_role,
            "to_role": right_role,
            "authority": "surface-composition-only",
        }],
        [relation],
    )


def analyze_surface_composition(text: str) -> dict:
    """Return inspectable surface grammar diagnostics with zero semantic authority."""
    sentences = [s.strip() for s in _SENTENCE_RE.split(text.strip()) if s.strip()]
    sentence_rows: list[dict] = []
    aggregate_frames: list[str] = []

    for index, sentence in enumerate(sentences):
        low = sentence.lower()
        words = _words(sentence)
        frames: list[str] = []
        clauses: list[dict] = []
        links: list[dict] = []

        q = _question_family(sentence)
        if q:
            frames.extend(["question", q])

        qframes = _quantifier_frames(words)
        frames.extend(qframes)

        if any(_contains_phrase(low, x) for x in NEGATORS) or re.search(r"\bno\s+[a-z]", low):
            frames.append("negation")

        present_modals = [m for m in MODALS if _contains_phrase(low, m)]
        frames.extend(f"modality:{m}" for m in present_modals)

        uncertainty = [u for u in UNCERTAINTY if _contains_phrase(low, u)]
        if uncertainty:
            frames.append("uncertainty-marker")

        frames.extend(_tense_aspect(words))

        cclauses, clinks, cframes = _conditional(sentence)
        if cframes:
            clauses.extend(cclauses); links.extend(clinks); frames.extend(cframes)

        # Add other discourse relations only when a conditional has not already
        # consumed the same top-level surface structure.
        for relation, pattern, lrole, rrole in (
            ("causal-because", r"\bbecause\b", "effect-clause", "cause-clause"),
            ("temporal-before", r"\bbefore\b", "earlier-clause", "later-clause"),
            ("temporal-after", r"\bafter\b", "later-clause", "earlier-clause"),
            ("contrast", r"\bbut\b|\bhowever\b|\bwhereas\b|\byet\b", "contrast-left", "contrast-right"),
        ):
            a, b, c = _binary_link(sentence, relation, pattern, lrole, rrole)
            if c:
                clauses.extend(a); links.extend(b); frames.extend(c)

        if any(_contains_phrase(low, m) for m in CONTRAST_MARKERS):
            frames.append("contrast")
        if any(_contains_phrase(low, m) for m in ANALOGY_MARKERS):
            frames.append("analogy")
        if any(_contains_phrase(low, m) for m in CORRECTION_MARKERS):
            frames.append("correction")
        if " and " in f" {low} " or " or " in f" {low} ":
            frames.append("coordination")

        # A coarse subject/predicate diagnostic is allowed only as structure.
        stripped = sentence.strip().rstrip(".!?")
        toks = _words(stripped)
        if toks and not q:
            frames.append("declarative-surface")
            if len(toks) >= 2:
                clauses.append({
                    "role": "surface-clause",
                    "text": stripped,
                    "subject_candidate": toks[0],
                    "predicate_tail": " ".join(toks[1:]),
                    "authority": "surface-composition-only",
                })

        # Stable order with duplicates removed.
        frames = list(dict.fromkeys(frames))
        aggregate_frames.extend(frames)
        sentence_rows.append({
            "index": index,
            "text": sentence,
            "question_family": q,
            "quantifier_frames": qframes,
            "negated": "negation" in frames,
            "modalities": present_modals,
            "uncertainty_markers": uncertainty,
            "frames": frames,
            "clauses": clauses,
            "links": links,
        })

    counts: dict[str, int] = {}
    for frame in aggregate_frames:
        counts[frame] = counts.get(frame, 0) + 1

    return {
        "version": COMPOSITION_VERSION,
        "status": "read-only-surface-composition",
        "sentence_count": len(sentences),
        "sentences": sentence_rows,
        "frame_counts": counts,
        "semantic_authority": False,
        "cognitive_memory_authority": False,
        "answer_selection_authority": False,
        "terra_authority": False,
        "relationship_authority": False,
        "source_write_authority": False,
        "deployment_authority": False,
        "note": (
            "Programmed transparent grammar diagnostics only. Truth, persistent "
            "premise authority and answer support remain IRG/DKT/provenance-gated."
        ),
    }


def merge_frame_counts(existing: dict[str, int], audit: dict) -> dict[str, int]:
    """Prospectively add observed grammar-frame counts; no historical replay."""
    out = dict(existing)
    for key, value in (audit.get("frame_counts") or {}).items():
        out[str(key)] = int(out.get(str(key), 0)) + int(value)
    return out
