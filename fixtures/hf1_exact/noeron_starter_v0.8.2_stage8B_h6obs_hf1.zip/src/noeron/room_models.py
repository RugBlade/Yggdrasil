from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Literal
from uuid import UUID, uuid4

from pydantic import BaseModel, Field


class NativeVoiceProfile(BaseModel):
    """Continuous actuator coordinates only; never a named/pretrained speaker identity."""
    base_frequency: float = 0.0
    overtone_ratio: float = 0.0
    modulation: float = 0.0
    articulation: float = 0.0
    pulse_shape: float = 0.0
    tempo: float = 0.0


class RendererConfiguration(BaseModel):
    id: str
    domain: Literal['embodiment', 'environment']
    visible: bool = True
    primitive_profile: list[float] = Field(default_factory=list)
    material_profile: list[float] = Field(default_factory=list)
    motion_profile: list[float] = Field(default_factory=list)
    color_profile: list[float] = Field(default_factory=list)
    field_profile: list[float] = Field(default_factory=list)
    voice_profile: NativeVoiceProfile | None = None
    source_dkt_signature: str = ''
    source: str = 'neutral-renderer-affordance'


class NativeRoomDecision(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    domain: str
    candidates: list[str] = Field(default_factory=list)
    candidate_residuals: dict[str, float] = Field(default_factory=dict)
    admissible_candidates: list[str] = Field(default_factory=list)
    minimum_candidates: list[str] = Field(default_factory=list)
    selected_action: str = ''
    selection_status: str = 'unresolved'
    decision_layer: str = 'unresolved'
    native_choice_claim: bool = False
    causal_trace: list[str] = Field(default_factory=list)


class RoomDevelopmentState(BaseModel):
    version: str = '0.7.6.1'
    schema_version: str = '0.7.6'
    mechanism_version: str = '0.7.6.1-room-completion-patch'
    migration_complete: bool = False
    embodiment_configuration: RendererConfiguration | None = None
    environment_configuration: RendererConfiguration | None = None
    embodiment_morph_epoch: int = 0
    environment_epoch: int = 0
    last_embodiment_decision: NativeRoomDecision | None = None
    last_environment_decision: NativeRoomDecision | None = None
    last_camera_decision: NativeRoomDecision | None = None
    last_microphone_decision: NativeRoomDecision | None = None
    last_file_decision: NativeRoomDecision | None = None
    last_file_publication_decision: NativeRoomDecision | None = None
    last_voice_decision: NativeRoomDecision | None = None
    autonomous_configuration_opportunities: int = 0
    journal_cognitive_authority: bool = False
    native_audio_decoder_cognitive_authority: bool = False
    presentation_mode: Literal['native-audio-only', 'native-audio+decoded-subtitles', 'decoded-text'] = 'native-audio+decoded-subtitles'
    notes: list[str] = Field(default_factory=lambda: [
        'No human/humanoid/gender/body-family/voice/environment default is assigned.',
        'Renderer and modality candidates are programmed affordances only; a native choice claim requires a unique admissible consequence minimum.',
        'Room journal/files/decoder output are noncognitive presentation/provenance substrate.',
    ])


class RoomJournalEntry(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    kind: str
    payload: dict[str, Any] = Field(default_factory=dict)
    cognitive_authority: bool = False


class RoomArtifactRecord(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    direction: Literal['owner-to-noeron', 'noeron-to-owner']
    filename: str
    media_type: str = 'application/octet-stream'
    size: int = 0
    sha256: str = ''
    storage_path: str = ''
    cognitive_authority: bool = False
    publication_native_choice_claim: bool = False
    publication_decision_id: UUID | None = None


class NativePresentationRecord(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    source: str
    native_text_sha256: str
    native_text_private: str
    audio_artifact_id: UUID | None = None
    audio_sha256: str = ''
    decoded_text: str = ''
    decoder_ran_after_native_utterance: bool = False
    decoder_cognitive_authority: bool = False
    decoder_realization_authority: bool = False
    voice_native_choice_claim: bool = False
    voice_decision_id: UUID | None = None
