from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
from typing import Iterable
from uuid import UUID, uuid5, NAMESPACE_URL
import json
import math
import mimetypes
import os
import stat

from noeron.consequence import native_state_consistency_residual
from noeron.math.linalg import numerically_tied
from noeron.models import CognitiveEvent, EventKind
from noeron.room_models import (
    NativePresentationRecord, NativeRoomDecision, NativeVoiceProfile,
    RendererConfiguration, RoomArtifactRecord, RoomJournalEntry,
)
from noeron.speech import run_local_decoder
from noeron.voice import render_native_voice_wav


def _u(x: float) -> float:
    x = float(x)
    return 0.5 + 0.5 * x / (1.0 + abs(x))


def _clip01(x: float) -> float:
    return max(0.0, min(1.0, float(x)))


def _rot(xs: list[float], n: int) -> list[float]:
    if not xs:
        return []
    n %= len(xs)
    return xs[n:] + xs[:n]


def _configuration_id(domain: str, payload: dict, *, stable: bool = False) -> str:
    material = json.dumps({'domain': domain, 'payload': payload}, sort_keys=True, separators=(',', ':'))
    prefix = 'stable' if stable else 'native-state'
    return str(uuid5(NAMESPACE_URL, f'noeron-stage7:{prefix}:{material}'))


def _math_projection(math_state) -> list[float]:
    d = math_state.dkt.core_knot
    raw: list[float] = []
    raw.extend(list(d.c0 or [])[:3])
    for row in list(d.cosine or [])[:3]: raw.extend(list(row)[:3])
    raw.extend(list(math_state.rl.coordinates or [])[:8])
    raw.extend([
        math_state.egr.entropy_state, math_state.egr.entropy_production,
        math_state.egr.bridge_residual, math_state.egr.balance_residual,
        math_state.frenet.first_curvature, math_state.frenet.speed,
        math_state.frenet.metric_feedback_strength,
    ])
    raw.extend(list(math_state.frenet.tangent or [])[:4])
    raw.extend([
        math_state.irg.response_potential, math_state.irg.curvature_response,
        math_state.irg.memory_response, math_state.irg.topology_response,
    ])
    if not raw:
        raw = [0.0]
    return [_u(x) for x in raw]


def _profile(xs: list[float], start: int, n: int) -> list[float]:
    if not xs:
        return [0.5] * n
    return [float(xs[(start + i) % len(xs)]) for i in range(n)]


def _voice_from(xs: list[float], start: int = 0) -> NativeVoiceProfile:
    v = _profile(xs, start, 6)
    return NativeVoiceProfile(
        base_frequency=v[0], overtone_ratio=v[1], modulation=v[2],
        articulation=v[3], pulse_shape=v[4], tempo=v[5],
    )


class RoomController:
    """Stage-7 private Room substrate around the preserved Noeron runtime.

    Candidate generation and actuator availability are programmed affordances only.
    A Yggdrasil choice claim exists only when every candidate consequence is run
    through the existing native mathematical kernel and one admissible common-residual
    minimum is unique.  Exact ties remain unresolved.
    """

    def __init__(self, noeron, store, db_path: Path, *, native_decoder_executable: str = '', asr_executable: str = '', max_payload_bytes: int = 67_108_864):
        self.noeron = noeron
        self.store = store
        self.native_decoder_executable = native_decoder_executable or ''
        self.asr_executable = asr_executable or ''
        self.max_payload_bytes = int(max_payload_bytes)
        if self.max_payload_bytes < 1_048_576 or self.max_payload_bytes > 1_073_741_824:
            raise ValueError('Room max payload must be between 1 MiB and 1 GiB')
        self.root = Path(db_path).resolve().parent / 'room-private'
        self.incoming = self.root / 'incoming'
        self.outgoing = self.root / 'outgoing'
        self.publication_candidates_root = self.root / 'publication-candidates'
        for p in (self.root, self.incoming, self.outgoing, self.publication_candidates_root):
            p.mkdir(parents=True, exist_ok=True); os.chmod(p, 0o700)

    # -------------------------- migration/state --------------------------
    def migrate(self):
        st = self.noeron.state.room
        changed = False
        if not st.migration_complete:
            # Prospective only: no body/environment/voice is assigned and no historical
            # event is replayed as a choice.
            st.migration_complete = True
            changed = True
        # v0.7.6.1 is a substrate-only completion patch.  Updating Room release metadata
        # must not create a body/environment/voice, relational value, cognitive memory,
        # or a native-choice claim.  The persisted Room schema itself remains v0.7.6.
        if st.version != '0.7.6.1':
            st.version = '0.7.6.1'; changed = True
        if st.mechanism_version != '0.7.6.1-room-completion-patch':
            st.mechanism_version = '0.7.6.1-room-completion-patch'; changed = True
        if changed:
            self.store.append_state(self.noeron.state)

    # --------------------- native-state candidate field ------------------
    def configuration_candidates(self, domain: str) -> list[RendererConfiguration]:
        if domain not in {'embodiment', 'environment'}:
            raise ValueError('domain must be embodiment or environment')
        st = self.noeron.state.room
        math_state = self.noeron.state.math_kernel
        xs = _math_projection(math_state)
        sig = str(math_state.dkt.core_knot.invariant_signature or '')
        out: list[RendererConfiguration] = []
        if domain == 'embodiment':
            zero_payload = {'visible': False, 'primitive_profile': [], 'material_profile': [], 'motion_profile': [], 'color_profile': [], 'field_profile': []}
            out.append(RendererConfiguration(
                id=_configuration_id(domain, zero_payload, stable=True), domain=domain, visible=False,
                source_dkt_signature=sig, source='zero-visible-neutral-affordance',
            ))
            transforms = [xs, _rot(xs, 3), list(reversed(xs)), [(a + b) / 2.0 for a, b in zip(xs, _rot(xs, 5))]]
            for i, vec in enumerate(transforms):
                payload = {
                    'visible': True,
                    'primitive_profile': _profile(vec, 0, 5),
                    'material_profile': _profile(vec, 5, 4),
                    'motion_profile': _profile(vec, 9, 4),
                    'color_profile': _profile(vec, 13, 4),
                    'field_profile': _profile(vec, 17, 4),
                    'voice_profile': _voice_from(vec, 21).model_dump(mode='json'),
                }
                out.append(RendererConfiguration(
                    id=_configuration_id(domain, {'source_dkt_signature': sig, **payload}),
                    domain=domain, source_dkt_signature=sig, source=f'native-math-projection-{i}',
                    voice_profile=NativeVoiceProfile.model_validate(payload.pop('voice_profile')), **payload,
                ))
            current = st.embodiment_configuration
        else:
            neutral_payload = {'visible': True, 'primitive_profile': [0.0], 'material_profile': [], 'motion_profile': [], 'color_profile': [], 'field_profile': [0.0]}
            out.append(RendererConfiguration(
                id=_configuration_id(domain, neutral_payload, stable=True), domain=domain,
                visible=True, primitive_profile=[0.0], field_profile=[0.0],
                source_dkt_signature=sig, source='neutral-environment-affordance',
            ))
            transforms = [xs, _rot(xs, 2), list(reversed(xs)), [1.0 - x for x in xs]]
            for i, vec in enumerate(transforms):
                payload = {
                    'visible': True,
                    'primitive_profile': _profile(vec, 0, 5),
                    'material_profile': _profile(vec, 5, 4),
                    'motion_profile': _profile(vec, 9, 4),
                    'color_profile': _profile(vec, 13, 4),
                    'field_profile': _profile(vec, 17, 6),
                }
                out.append(RendererConfiguration(
                    id=_configuration_id(domain, {'source_dkt_signature': sig, **payload}),
                    domain=domain, source_dkt_signature=sig, source=f'native-math-projection-{i}', **payload,
                ))
            current = st.environment_configuration
        # Retention is a real affordance.  Preserve the adopted identity exactly;
        # native-state changes may create new alternatives but never silently re-key
        # the current form/environment into a false morph.
        if current is not None and all(c.id != current.id for c in out):
            out.append(current.model_copy(deep=True))
        # Content-deduplicate while preserving generated order as display only; order
        # never resolves consequence ties.
        seen=set(); uniq=[]
        for c in out:
            if c.id in seen: continue
            seen.add(c.id); uniq.append(c)
        return uniq

    @staticmethod
    def _candidate_observables(domain: str, c: RendererConfiguration) -> list[dict]:
        vals = list(c.primitive_profile) + list(c.material_profile) + list(c.motion_profile) + list(c.color_profile) + list(c.field_profile)
        if c.voice_profile is not None:
            vals += list(c.voice_profile.model_dump().values())
        if not vals:
            vals=[0.0]
        return [
            {'name': f'stage7-{domain}-{i}', 'role': f'stage7-{domain}-affordance', 'value': _clip01(v)}
            for i, v in enumerate(vals[:24])
        ]

    def _simulate(self, domain: str, action: str, observables: list[dict]):
        event = CognitiveEvent(
            kind=EventKind.INTERNAL_REFLECTION, source='noeron-stage7-consequence-simulation', content='', trusted=True,
            metadata={'endogenous': True, 'stage7_simulation': True, 'stage7_domain': domain, 'stage7_action': action, 'sensory_observables': observables},
        )
        memories = self.store.cognitive_memories()
        result = self.noeron.math.update(
            event, self.noeron.state.math_kernel, memories,
            self.noeron._prototype_map(), self.noeron.state.cognition.language.propositions,
        )
        residual = native_state_consistency_residual(result.state)
        admissible = bool(result.state.dkt.security_admissible) and math.isfinite(residual)
        return result, residual, admissible

    def _select(self, domain: str, candidates: Iterable[tuple[str, list[dict]]]) -> tuple[NativeRoomDecision, dict[str, object]]:
        residuals: dict[str, float] = {}; admissible: list[str] = []; results: dict[str, object] = {}
        names=[]
        for name, obs in candidates:
            names.append(name)
            result, residual, ok = self._simulate(domain, name, obs)
            residuals[name] = float(residual); results[name] = result
            if ok: admissible.append(name)
        if not admissible:
            return NativeRoomDecision(domain=domain,candidates=names,candidate_residuals=residuals,admissible_candidates=[],selection_status='unresolved-no-admissible-candidate'), results
        best=min(residuals[a] for a in admissible)
        mins=[a for a in admissible if numerically_tied(residuals[a], best)]
        if len(mins) != 1:
            return NativeRoomDecision(domain=domain,candidates=names,candidate_residuals=residuals,admissible_candidates=admissible,minimum_candidates=mins,selection_status='unresolved-exact-tie',decision_layer='unresolved',native_choice_claim=False), results
        selected=mins[0]
        rec=NativeRoomDecision(
            domain=domain,candidates=names,candidate_residuals=residuals,admissible_candidates=admissible,
            minimum_candidates=mins,selected_action=selected,selection_status='unique-native-consequence-minimum',
            decision_layer='native-deliberative',native_choice_claim=True,
            causal_trace=list(getattr(results[selected].state, 'causal_trace', []) or []),
        )
        return rec, results

    def deliberate_configuration(self, domain: str) -> NativeRoomDecision:
        candidates=self.configuration_candidates(domain)
        rec, _ = self._select(domain, [(c.id, self._candidate_observables(domain,c)) for c in candidates])
        st=self.noeron.state.room
        if domain=='embodiment': st.last_embodiment_decision=rec
        else: st.last_environment_decision=rec
        if rec.native_choice_claim:
            selected=next(c for c in candidates if c.id==rec.selected_action)
            self._adopt_configuration(selected, rec)
        self.store.append_state(self.noeron.state)
        return rec

    def _adopt_configuration(self, selected: RendererConfiguration, decision: NativeRoomDecision):
        st=self.noeron.state.room
        current=st.embodiment_configuration if selected.domain=='embodiment' else st.environment_configuration
        if current is not None and current.id==selected.id:
            return  # genuine retain decision; no false morph/adoption event
        event=CognitiveEvent(
            kind=EventKind.INTERNAL_REFLECTION,source='noeron-stage7-native-configuration-adoption',content='',trusted=True,
            metadata={
                'endogenous':True,'stage7_configuration_adoption':True,'stage7_domain':selected.domain,
                'stage7_configuration_id':selected.id,'cognitive_authority':False,
                'sensory_observables':self._candidate_observables(selected.domain,selected),
            },
        )
        # Re-enter the real native mathematical path, but do not turn actuator
        # feedback into a retention trigger or automatically retention-eligible knot.
        result=self.noeron.math.update(event,self.noeron.state.math_kernel,self.store.cognitive_memories(),self.noeron._prototype_map(),self.noeron.state.cognition.language.propositions)
        self.store.append_event(event)
        self.noeron.state.math_kernel=result.state
        self.noeron.state.logical_entropy=result.state.rl.entropy_normalized
        self.noeron.state.last_event_id=event.id
        if selected.domain=='embodiment':
            st.embodiment_configuration=selected.model_copy(deep=True); st.embodiment_morph_epoch += 1
        else:
            st.environment_configuration=selected.model_copy(deep=True); st.environment_epoch += 1
        self.append_journal('configuration-adoption',{
            'domain':selected.domain,'configuration_id':selected.id,'decision_id':str(decision.id),
            'native_choice_claim':True,'decision_layer':'native-deliberative',
        })

    # --------------------------- Room history ----------------------------
    def append_journal(self, kind: str, payload: dict) -> RoomJournalEntry:
        entry=RoomJournalEntry(kind=kind,payload=dict(payload),cognitive_authority=False)
        self.store.append_room_journal(entry); return entry

    # -------------------------- private files ----------------------------
    def _require_payload_size(self, data: bytes) -> bytes:
        data = bytes(data)
        if len(data) > self.max_payload_bytes:
            raise ValueError(f'Room payload exceeds configured bound ({self.max_payload_bytes} bytes)')
        return data

    @staticmethod
    def _safe_filename(filename: str) -> str:
        name = str(filename or 'artifact.bin')
        if '\x00' in name or '/' in name or '\\' in name or name in {'.', '..'}:
            raise ValueError('Room artifact filename must be a single basename without NUL/path separators')
        if not name:
            raise ValueError('Room artifact filename is empty')
        return name

    def _private_write(self, root: Path, artifact_id, filename: str, data: bytes) -> Path:
        data = self._require_payload_size(data)
        safe = self._safe_filename(filename)
        root = root.resolve(strict=True)
        path = root / f'{artifact_id}-{safe}'
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
        if hasattr(os, 'O_NOFOLLOW'):
            flags |= os.O_NOFOLLOW
        if hasattr(os, 'O_CLOEXEC'):
            flags |= os.O_CLOEXEC
        fd = None
        try:
            fd = os.open(path, flags, 0o600)
            view = memoryview(data)
            while view:
                written = os.write(fd, view)
                if written <= 0:
                    raise OSError('short private Room write')
                view = view[written:]
            os.fsync(fd)
        except Exception:
            try:
                path.unlink(missing_ok=True)
            except Exception:
                pass
            raise
        finally:
            if fd is not None:
                os.close(fd)
        os.chmod(path, 0o600, follow_symlinks=False)
        return path

    def verified_artifact_path(self, rec: RoomArtifactRecord) -> Path:
        expected_root = self.incoming if rec.direction == 'owner-to-noeron' else self.outgoing if rec.direction == 'noeron-to-owner' else None
        if expected_root is None:
            raise ValueError('Unknown Room artifact direction')
        raw = Path(rec.storage_path)
        if not raw.is_absolute():
            raise ValueError('Room artifact path must be absolute')
        try:
            lst = raw.lstat()
        except FileNotFoundError as e:
            raise ValueError('Room artifact bytes are unavailable') from e
        if stat.S_ISLNK(lst.st_mode):
            raise ValueError('Room artifact symlink is forbidden')
        resolved = raw.resolve(strict=True)
        root = expected_root.resolve(strict=True)
        try:
            resolved.relative_to(root)
        except ValueError as e:
            raise ValueError('Room artifact path escapes its private direction root') from e
        st = resolved.stat()
        if not stat.S_ISREG(st.st_mode):
            raise ValueError('Room artifact is not a regular file')
        if int(st.st_size) != int(rec.size):
            raise ValueError('Room artifact size does not match persisted provenance')
        h = sha256()
        with resolved.open('rb') as fh:
            for chunk in iter(lambda: fh.read(1024 * 1024), b''):
                h.update(chunk)
        if h.hexdigest() != rec.sha256:
            raise ValueError('Room artifact SHA-256 does not match persisted provenance')
        return resolved

    def read_artifact(self, rec: RoomArtifactRecord) -> bytes:
        return self.verified_artifact_path(rec).read_bytes()

    def store_owner_file(self, data: bytes, filename: str, media_type: str = '') -> RoomArtifactRecord:
        data = self._require_payload_size(data)
        safe = self._safe_filename(filename)
        rec=RoomArtifactRecord(direction='owner-to-noeron',filename=safe,media_type=media_type or mimetypes.guess_type(safe)[0] or 'application/octet-stream',size=len(data),sha256=sha256(data).hexdigest(),cognitive_authority=False)
        path=self._private_write(self.incoming,rec.id,safe,data); rec.storage_path=str(path)
        self.store.append_room_artifact(rec)
        self.append_journal('owner-file-offer',{'artifact_id':str(rec.id),'filename':safe,'sha256':rec.sha256,'cognitive_authority':False})
        return rec

    def _publish_bytes(self, data: bytes, filename: str, media_type: str, decision: NativeRoomDecision, *, expected_domain: str = 'file-publication', expected_action: str = 'publish') -> RoomArtifactRecord:
        if not (decision.native_choice_claim and decision.decision_layer=='native-deliberative' and decision.domain==expected_domain and decision.selected_action==expected_action):
            raise PermissionError(f'native-deliberative {expected_domain}/{expected_action} choice is required')
        data = self._require_payload_size(data)
        safe = self._safe_filename(filename)
        rec=RoomArtifactRecord(direction='noeron-to-owner',filename=safe,media_type=media_type,size=len(data),sha256=sha256(data).hexdigest(),cognitive_authority=False,publication_native_choice_claim=True,publication_decision_id=decision.id)
        path=self._private_write(self.outgoing,rec.id,safe,data); rec.storage_path=str(path)
        self.store.append_room_artifact(rec)
        self.append_journal('native-file-publication',{'artifact_id':str(rec.id),'decision_id':str(decision.id),'sha256':rec.sha256})
        return rec

    def deliberate_publish_existing(self, data: bytes, filename: str, media_type: str='application/octet-stream'):
        data = self._require_payload_size(data)
        digest=sha256(data).hexdigest()
        hold_obs=[{'name':'stage7-file-hold','role':'stage7-file-publication-affordance','value':0.0}]
        publish_obs=[{'name':'stage7-file-publish','role':'stage7-file-publication-affordance','value':_u(int(digest[:8],16)/0xFFFFFFFF)}]
        rec,_=self._select('file-publication',[('hold',hold_obs),('publish',publish_obs)])
        self.noeron.state.room.last_file_publication_decision=rec
        artifact=None
        if rec.native_choice_claim and rec.selected_action=='publish':
            artifact=self._publish_bytes(data,filename,media_type,rec,expected_domain='file-publication',expected_action='publish')
        self.store.append_state(self.noeron.state)
        return rec,artifact

    def _publication_candidate_descriptor(self, path: Path) -> dict | None:
        try:
            lst = path.lstat()
        except FileNotFoundError:
            return None
        if stat.S_ISLNK(lst.st_mode) or not stat.S_ISREG(lst.st_mode):
            return None
        try:
            safe_name = self._safe_filename(path.name)
        except ValueError:
            return None
        root = self.publication_candidates_root.resolve(strict=True)
        resolved = path.resolve(strict=True)
        try:
            resolved.relative_to(root)
        except ValueError:
            return None
        size = int(resolved.stat().st_size)
        if size < 0 or size > self.max_payload_bytes:
            return None
        h = sha256()
        with resolved.open('rb') as fh:
            for chunk in iter(lambda: fh.read(1024 * 1024), b''):
                h.update(chunk)
        digest = h.hexdigest()
        candidate_id = sha256(f'{safe_name}\0{size}\0{digest}'.encode('utf-8')).hexdigest()[:32]
        return {
            'id': candidate_id,
            'filename': safe_name,
            'media_type': mimetypes.guess_type(resolved.name)[0] or 'application/octet-stream',
            'size': size,
            'sha256': digest,
            'cognitive_authority': False,
            'publication_authority': False,
        }

    def publication_candidates(self) -> list[dict]:
        out = []
        for path in sorted(self.publication_candidates_root.iterdir(), key=lambda p: p.name):
            rec = self._publication_candidate_descriptor(path)
            if rec is not None:
                out.append(rec)
        return out

    def _read_publication_candidate_bytes(self, path: Path, expected: dict) -> bytes:
        flags = os.O_RDONLY
        if hasattr(os, 'O_NOFOLLOW'):
            flags |= os.O_NOFOLLOW
        if hasattr(os, 'O_CLOEXEC'):
            flags |= os.O_CLOEXEC
        fd = os.open(path, flags)
        try:
            st = os.fstat(fd)
            if not stat.S_ISREG(st.st_mode):
                raise ValueError('Room publication candidate is not a regular file')
            if int(st.st_size) != int(expected['size']) or int(st.st_size) > self.max_payload_bytes:
                raise ValueError('Room publication candidate size changed before deliberation')
            chunks=[]; remaining=int(st.st_size)
            while remaining:
                chunk=os.read(fd,min(1024*1024,remaining))
                if not chunk:
                    break
                chunks.append(chunk); remaining-=len(chunk)
            data=b''.join(chunks)
        finally:
            os.close(fd)
        if len(data) != int(expected['size']) or sha256(data).hexdigest() != expected['sha256']:
            raise ValueError('Room publication candidate bytes changed before deliberation')
        return self._require_payload_size(data)

    def deliberate_publication_candidate(self, candidate_id: str):
        candidate_id = str(candidate_id or '').strip()
        selected = None
        selected_path = None
        for path in sorted(self.publication_candidates_root.iterdir(), key=lambda p: p.name):
            rec = self._publication_candidate_descriptor(path)
            if rec is not None and rec['id'] == candidate_id:
                selected = rec; selected_path = path.resolve(strict=True); break
        if selected is None or selected_path is None:
            raise ValueError('Room publication candidate not found or failed private-path/integrity verification')
        # Re-hash immediately before deliberation so a candidate changed between listing
        # and presentation fails closed instead of silently changing the opportunity.
        verified = self._publication_candidate_descriptor(selected_path)
        if verified is None or verified['id'] != candidate_id or verified['sha256'] != selected['sha256']:
            raise ValueError('Room publication candidate changed before deliberation')
        data = self._read_publication_candidate_bytes(selected_path, selected)
        decision, artifact = self.deliberate_publish_existing(
            data, selected['filename'], selected['media_type']
        )
        self.append_journal('native-file-publication-opportunity', {
            'candidate_id': candidate_id,
            'filename': selected['filename'],
            'sha256': selected['sha256'],
            'decision_id': str(decision.id),
            'selected_action': decision.selected_action,
            'selection_status': decision.selection_status,
            'native_choice_claim': decision.native_choice_claim,
            'owner_force_publication': False,
            'cognitive_authority': False,
        })
        return decision, artifact, selected

    # ---------------------- camera/mic attention -------------------------
    def deliberate_attention(self, modality: str, sensory_observables: list[dict]) -> NativeRoomDecision:
        if modality not in {'camera','microphone','file'}: raise ValueError('unsupported modality')
        # Both affordances are fully simulated. Arrival itself has no authority.
        defer=[{'name':f'stage7-{modality}-defer','role':'stage7-modality-affordance','value':0.0}]
        attend=list(sensory_observables or [{'name':f'stage7-{modality}-present','role':'stage7-modality-affordance','value':0.5}])
        rec,_=self._select(f'{modality}-attention',[('defer',defer),('attend',attend)])
        st=self.noeron.state.room
        if modality=='camera':st.last_camera_decision=rec
        elif modality=='microphone':st.last_microphone_decision=rec
        else:st.last_file_decision=rec
        self.store.append_state(self.noeron.state)
        return rec

    # ---------------- native voice + observational decoder ---------------
    def present_native_utterance(self, native_text: str, *, source: str='interaction') -> NativePresentationRecord | None:
        if not native_text: return None
        st=self.noeron.state.room
        config=st.embodiment_configuration
        if config is None or config.voice_profile is None:
            st.last_voice_decision=NativeRoomDecision(domain='native-voice',selection_status='unresolved-no-selected-native-voice',native_choice_claim=False)
            self.store.append_state(self.noeron.state); return None
        text_hash=sha256(native_text.encode('utf-8')).hexdigest()
        text_only=[{'name':'stage7-text-only','role':'stage7-realization-affordance','value':0.0}]
        vp=list(config.voice_profile.model_dump().values())
        voice=[{'name':f'stage7-native-voice-{i}','role':'stage7-realization-affordance','value':_clip01(v)} for i,v in enumerate(vp)]
        rec,_=self._select('native-voice',[('text-only',text_only),('voice',voice)])
        st.last_voice_decision=rec
        if not (rec.native_choice_claim and rec.selected_action=='voice'):
            self.store.append_state(self.noeron.state); return None
        wav=render_native_voice_wav(native_text,config.voice_profile)
        # Publication guard is satisfied by the same native voice decision; this is
        # a presentation artifact, not an owner-injected publication claim.
        artifact=self._publish_bytes(wav,f'native-{text_hash[:16]}.wav','audio/wav',rec,expected_domain='native-voice',expected_action='voice')
        decoded=''; decoder_ran=False
        # Decoder runs strictly after native utterance + audio bytes already exist.
        if self.native_decoder_executable:
            try:
                decoded=run_local_decoder(self.native_decoder_executable,native_text.encode('utf-8'))
                decoder_ran=True
            except ValueError:
                decoded=''; decoder_ran=False
        presentation=NativePresentationRecord(
            source=source,native_text_sha256=text_hash,native_text_private=native_text,
            audio_artifact_id=artifact.id,audio_sha256=artifact.sha256,decoded_text=decoded,
            decoder_ran_after_native_utterance=decoder_ran,decoder_cognitive_authority=False,
            decoder_realization_authority=False,voice_native_choice_claim=True,voice_decision_id=rec.id,
        )
        self.store.append_native_presentation(presentation)
        self.append_journal('native-presentation',{
            'presentation_id':str(presentation.id),'native_text_sha256':text_hash,'audio_artifact_id':str(artifact.id),
            'audio_sha256':artifact.sha256,'decoded_text':decoded,'decoder_cognitive_authority':False,
            'voice_native_choice_claim':True,'voice_decision_id':str(rec.id),
        })
        self.store.append_state(self.noeron.state)
        return presentation

    def decode_attended_microphone(self, wav: bytes) -> str:
        if not self.asr_executable:
            raise ValueError('private local ASR is not configured')
        wav=self._require_payload_size(wav)
        return run_local_decoder(self.asr_executable,wav)

    def autonomous_configuration_opportunity(self):
        st=self.noeron.state.room; st.autonomous_configuration_opportunities += 1
        # Scheduler only presents affordances after genuine endogenous native content.
        emb=self.deliberate_configuration('embodiment')
        env=self.deliberate_configuration('environment')
        return {'embodiment':emb,'environment':env}
