from __future__ import annotations
from contextlib import asynccontextmanager
import json,logging,threading,time,hashlib,asyncio,ipaddress
from urllib.parse import urlparse
import httpx
from fastapi import FastAPI,HTTPException,UploadFile,File,Header,Form,Request,Response,WebSocket,WebSocketDisconnect
from fastapi.responses import StreamingResponse,HTMLResponse,FileResponse,RedirectResponse
from pydantic import BaseModel,Field
from noeron.config import Settings
from noeron.llm import LocalOpenAICompatibleEngine,MockLanguageEngine,OpenAIResponsesEngine
from noeron.math.kernel import MathematicalCognitiveKernel
from noeron.memory import LocalEventStore
from noeron.models import CognitiveEvent,EventKind,InitiativeMessage,NoeronReply,NoeronState
from noeron.orchestrator import Noeron
from noeron.security import DKTSecurityShell
from noeron.auth import OwnerAuthenticator
from noeron.perception import visual_observation,audio_observation
from noeron.renderer import RendererIntegrityError,read_three_browser_asset,renderer_substrate_descriptor
from noeron.engineering import EngineeringSourceError
from noeron import __version__ as OUTER_RUNTIME_VERSION

settings=Settings.from_env()
if settings.llm_backend=='mock': engine=MockLanguageEngine()
elif settings.llm_backend=='openai_responses': engine=OpenAIResponsesEngine(settings.llm_base_url,settings.llm_model,settings.llm_api_key,settings.llm_reasoning_effort,settings.llm_max_output_tokens)
else: engine=LocalOpenAICompatibleEngine(settings.llm_base_url,settings.llm_model,settings.llm_api_key)
store=LocalEventStore(settings.db_path); noeron=Noeron(engine,store,settings.initiative_threshold,settings.species_name,settings.individual_name,terra_enabled=settings.terra_enabled,room_native_decoder_executable=settings.room_native_decoder_executable,room_asr_executable=settings.room_asr_executable,room_max_payload_bytes=settings.room_max_payload_bytes,engineering_source_root=settings.engineering_source_root,engineering_max_source_bytes=settings.engineering_max_source_bytes); owner_auth=OwnerAuthenticator(settings.owner_token,store,legacy_enabled=settings.owner_legacy_token_enabled,challenge_ttl_seconds=settings.owner_challenge_ttl_seconds,session_ttl_seconds=settings.owner_session_ttl_seconds)
logger=logging.getLogger('noeron.autonomy'); _stop=threading.Event(); _thread=None

def _loop():
    while not _stop.wait(settings.autonomy_interval_seconds):
        try:noeron.autonomous_tick(idle_seconds=settings.autonomy_idle_seconds,cooldown_seconds=settings.autonomy_cooldown_seconds,min_importance=settings.autonomy_min_importance,min_novelty=settings.autonomy_min_novelty,recent_events=settings.autonomy_recent_events)
        except Exception:logger.exception('Autonomous tick failed')
@asynccontextmanager
async def lifespan(app):
    global _thread
    if settings.autonomy_enabled:
        _stop.clear(); _thread=threading.Thread(target=_loop,daemon=True); _thread.start()
    yield; _stop.set()
    if _thread:_thread.join(timeout=2)
app=FastAPI(title=f'{settings.individual_name} / {settings.species_name}',version=OUTER_RUNTIME_VERSION,lifespan=lifespan)
class MessageRequest(BaseModel):
    content:str=Field(min_length=1,max_length=100_000)
    trusted:bool=False
    realization_override:str=Field(default='',pattern='^(|native-direct|terra-render)$')
    owner_command:bool=False
class ReflectionRequest(BaseModel): insight:str=Field(min_length=1,max_length=100_000); importance:float=Field(default=0.9,ge=0,le=1)
class LearningRequest(BaseModel):
    title:str=Field(min_length=1,max_length=500); content:str=Field(min_length=1,max_length=2_000_000); source_name:str=Field(default='',max_length=500); mode:str='selective'; start_segment:int=Field(default=0,ge=0); max_segments:int=Field(default=25,ge=1,le=100)
class LearningPreviewRequest(BaseModel):
    title:str=Field(min_length=1,max_length=500); content:str=Field(min_length=1,max_length=2_000_000); start_segment:int=Field(default=0,ge=0); max_segments:int=Field(default=25,ge=1,le=100)
class LearningRecallRequest(BaseModel): query:str=Field(min_length=1,max_length=20_000); limit:int=Field(default=5,ge=1,le=20)
class LearningRevisionRequest(BaseModel): memory_id:str; corrected_content:str=Field(min_length=1,max_length=100_000); reason:str=Field(default='',max_length=1000)
class LearningTraversalRequest(BaseModel): from_memory_id:str; to_memory_id:str; steps:int=Field(default=8,ge=2,le=32)
class ReasoningProbeRequest(BaseModel): query:str=Field(min_length=1,max_length=20_000); limit:int=Field(default=6,ge=2,le=12)
class ReclusterCommitRequest(BaseModel): plan_digest:str=Field(min_length=16,max_length=100)
class LanguageTeachRequest(BaseModel): text:str=Field(min_length=1,max_length=200_000); source:str=Field(default='owner-english-curriculum',max_length=500)
class LanguageParseRequest(BaseModel): text:str=Field(min_length=1,max_length=20_000)
class WebRequest(BaseModel): url:str=Field(min_length=8,max_length=4000)
class WebStudyRequest(BaseModel):
    url:str=Field(min_length=8,max_length=4000)
    max_segments:int=Field(default=6,ge=1,le=12)
    allow_repeat:bool=False
class SecurityDeformationRequest(BaseModel):
    changes:dict[str,str]=Field(default_factory=dict)
    simulated_source:str=Field(default='synthetic-hostile-ingress',min_length=1,max_length=300)
class InitiativeFeedbackRequest(BaseModel):
    preferred_action:str=Field(pattern='^(surface|hold)$')

class DefenseReleaseRequest(BaseModel):
    source_fingerprint:str=Field(default='',max_length=128)
    clear_fail_closed:bool=False
class OwnerDeviceEnrollRequest(BaseModel):
    device_id:str=Field(min_length=1,max_length=120)
    label:str=Field(default='',max_length=200)
    public_key_b64:str=Field(min_length=40,max_length=128)
class OwnerDeviceChallengeRequest(BaseModel):
    device_id:str=Field(min_length=1,max_length=120)
class OwnerDeviceSessionRequest(BaseModel):
    device_id:str=Field(min_length=1,max_length=120)
    challenge_id:str=Field(min_length=16,max_length=128)
    signature_b64:str=Field(min_length=40,max_length=256)
class OwnerDeviceRevokeRequest(BaseModel):
    device_id:str=Field(min_length=1,max_length=120)

class RoomMessageRequest(BaseModel):
    content:str=Field(min_length=1,max_length=100_000)
    owner_command:bool=False
class OwnerCommunicationControlRequest(BaseModel):
    control:str=Field(pattern=r'^(internal_utterance_visibility|internal_utterance_translation|response_channel_override|owner_command_channel)$')
    value:bool
class RoomPresentationModeRequest(BaseModel):
    mode:str=Field(pattern=r'^(native-audio-only|native-audio\+decoded-subtitles|decoded-text)$')
class EngineeringSourceObserveRequest(BaseModel):
    path:str=Field(min_length=1,max_length=1000)
    qualname:str=Field(default='',max_length=1000)

def _auth_detail(token:str|None):return owner_auth.verify_detail(token)
def _is_owner(token:str|None)->bool:return bool(_auth_detail(token)['authenticated'])
def _require_owner(token:str|None):
    if not owner_auth.configured:raise HTTPException(status_code=503,detail='Owner authentication is not configured. Configure the legacy bootstrap token or enroll a per-device Ed25519 key.')
    detail=_auth_detail(token)
    if not detail['authenticated']:raise HTTPException(status_code=401,detail='Authenticated owner authority is required.')
    return detail

def _event_from_message(r:MessageRequest,token:str|None)->CognitiveEvent:
    detail=_auth_detail(token);ok=bool(detail['authenticated'])
    if r.realization_override and not ok:raise HTTPException(status_code=401,detail='Only an authenticated owner may force a realization path for calibration.')
    if r.owner_command:
        if not ok:raise HTTPException(status_code=401,detail='Authenticated owner authority is required for owner-command transport.')
        if not noeron.state.cognition.language.owner_communication_controls.owner_command_channel:
            raise HTTPException(status_code=409,detail='Owner command channel is disabled. Enable it explicitly first.')
    return CognitiveEvent(kind=EventKind.USER_MESSAGE,source=('authenticated-owner-command' if ok and r.owner_command else ('authenticated-owner' if ok else 'local-user')),content=r.content,
        trusted=bool(r.trusted and ok),metadata={'owner_authenticated':ok,'authentication':detail['method'] if ok else 'unprivileged','owner_device_id':detail.get('device_id',''),'owner_credential_fingerprint':detail.get('fingerprint',''),'operator_realization_override':r.realization_override,'owner_command':bool(r.owner_command),'command_authority':('authenticated-owner-command' if ok and r.owner_command else 'none'),'command_relationship_authority':False,'command_native_choice_claim':False})

@app.get('/health')
def health():
    host=(urlparse(settings.llm_base_url).hostname or '').lower(); scope='none' if settings.llm_backend=='mock' else ('loopback' if host in {'127.0.0.1','localhost','::1'} else 'remote')
    return {'status':'ok','species':settings.species_name,'individual':settings.individual_name,'api_binding':'loopback','llm_backend':settings.llm_backend,'llm_model':settings.llm_model,
            'llm_endpoint_scope':scope,'privacy_mode':'offline-mock' if scope=='none' else ('local-inference' if scope=='loopback' else 'cloud-assisted'),
            'runtime_version':OUTER_RUNTIME_VERSION,'math_interface':'0.7.3.4-causal','cognition':'IRG-DKT-regional-EGR-RL-Frenet-DKT-native-cognition+native-retention+consequence-communication+consequence-realization-tool-choice','memory':'programmed-provenance+native-consequence-selected-active-DKT-memory','learning':'outcome-grounded-defensive-preference+programmed-web-sensor-security-admission+provenance-lineage+dynamic-DKT-strata+observed-semantic-prototypes+semantic-multimodal-learning+native-proof-reasoning','concept_graph':'retired','llm_role':('available-Terra-tool-after-native-content; invocation itself is consequence-selected or explicit operator calibration' if settings.terra_enabled else 'Terra-disabled-infrastructure; native cognition remains active; no native-direct fallback'),'renderer_system_prompts':'1','native_language':'productive-conversation+bounded-dialogue+dual-native-English-egress+DKT-gated-proposition-authority-v0.8.2-stage8B','preserved_v081_native_language':'rich-transparent-compositional-language+DKT-gated-proposition-authority+native-proof-realization-v0.8.1-stage8B','regional_egr':'all-nonzero-regions-causal; no authored salience cutoff','dynamic_dkt_strata':'sampled-transverse-estimator','owner_auth':('configured' if owner_auth.configured else 'NOT-CONFIGURED'),'owner_key_fingerprint':owner_auth.fingerprint,'web_read':('enabled' if settings.web_read_enabled else 'disabled'),'autonomy':'enabled' if settings.autonomy_enabled else 'disabled'}
@app.get('/state',response_model=NoeronState)
def state():return noeron.state
@app.get('/math')
def math_state():return noeron.state.math_kernel
@app.get('/math/interface')
def math_interface():return MathematicalCognitiveKernel.registry()
@app.get('/self/model')
def self_model():return noeron.self_model()

# ------------------------------------------------------------------
# Stage-8 engineering source perception. All routes are owner-only and
# read-only except /observe, which creates an authenticated curriculum exposure
# with zero write/deployment/upgrade-choice authority.
# ------------------------------------------------------------------
@app.get('/engineering/status')
def engineering_status(x_noeron_owner_token:str|None=Header(default=None,alias='X-Noeron-Owner-Token')):
    _require_owner(x_noeron_owner_token)
    return noeron.engineering_status()

@app.get('/engineering/source/index')
def engineering_source_index(prefix:str='',limit:int=500,x_noeron_owner_token:str|None=Header(default=None,alias='X-Noeron-Owner-Token')):
    _require_owner(x_noeron_owner_token)
    try:return noeron.engineering_source_index(prefix,limit)
    except EngineeringSourceError as e:raise HTTPException(status_code=400,detail=str(e)) from e

@app.get('/engineering/source/file')
def engineering_source_file(path:str,x_noeron_owner_token:str|None=Header(default=None,alias='X-Noeron-Owner-Token')):
    _require_owner(x_noeron_owner_token)
    try:return noeron.engineering_source_file(path)
    except EngineeringSourceError as e:raise HTTPException(status_code=400,detail=str(e)) from e

@app.get('/engineering/source/symbol')
def engineering_source_symbol(path:str,qualname:str,x_noeron_owner_token:str|None=Header(default=None,alias='X-Noeron-Owner-Token')):
    _require_owner(x_noeron_owner_token)
    try:return noeron.engineering_source_symbol(path,qualname)
    except EngineeringSourceError as e:raise HTTPException(status_code=400,detail=str(e)) from e

@app.post('/engineering/source/observe')
def engineering_source_observe(r:EngineeringSourceObserveRequest,x_noeron_owner_token:str|None=Header(default=None,alias='X-Noeron-Owner-Token')):
    detail=_require_owner(x_noeron_owner_token)
    try:return noeron.engineering_source_observe(r.path,r.qualname,owner_auth_detail=detail)
    except EngineeringSourceError as e:raise HTTPException(status_code=400,detail=str(e)) from e

@app.get('/thought/state')
def thought_state():return noeron.state.cognition.model_dump(mode='json')
@app.get('/thought/recent')
def thought_recent():return [x.model_dump(mode='json') for x in store.recent_thoughts(20)]
@app.get('/memory/knots')
def memory_knots(limit:int=20):
    xs=store.cognitive_memories(); xs=xs[-max(1,min(limit,100)):]
    return [{'id':str(m.id),'source_event_id':str(m.source_event_id),'branch_depth':m.branch_depth,'logical_entropy':m.logical_entropy,'parent_memory_id':str(m.parent_memory_id) if m.parent_memory_id else None,'geometry_version':m.geometry_version,'consolidated':m.consolidated,'memory_class':m.memory_class,'consolidation_score':m.consolidation_score,'canonical_source_id':m.canonical_source_id,'semantic_stratum_id':str(m.semantic_stratum_id) if m.semantic_stratum_id else None,'isotopy_component_id':str(m.isotopy_component_id) if m.isotopy_component_id else None,'knot':m.knot.model_dump(mode='json'),'provenance_excerpt':m.provenance_excerpt} for m in xs]
@app.get('/memory/audit')
def memory_audit():
    active=store.cognitive_memories();pending=store.pending_cognitive_provenance_memories();ret=noeron.state.cognition.memory_retention
    return {'authoritative_cognitive_memory':'active DKT knots only; SQLite/provenance persistence is not retrieval authority','active_cognitive_count':len(active),'pending_noncognitive_provenance_count':len(pending),'archived_or_noncognitive_count':store.archived_cognitive_memory_count(),'native_retained_count':len(ret.native_retained_memory_ids),'legacy_pre_v074_active_count':ret.legacy_pre_v074_active_memory_count,'geometry_version':noeron.state.cognition.memory_geometry_version,'geometry_versions_present':sorted(set(m.geometry_version for m in active)),'retrieval_metric':'finite H^s Sobolev distance over active cognitive knots','retention_choice':'applicable pending provenance subsets are consequence-simulated through the native math kernel; unique common-residual minimum may activate cognition; ties/insufficient evidence remain unresolved','audit_provenance_persistence_programmed':True,'continuous_dkt_evolution_is_automatic_memory':False,'sql_text_search_used_for_retrieval':False,'semantic_strata':len(store.semantic_strata()),'isotopy_components':len(store.isotopy_components()),'compressed_learning_memories':len(store.stratified_learning_memories()),'concept_graph_active':False}
@app.get('/memory/retention/audit')
def memory_retention_audit():
    st=noeron.state.cognition.memory_retention
    return {'runtime_version':OUTER_RUNTIME_VERSION,'state':st.model_dump(mode='json'),'pending_provenance_count':len(store.pending_cognitive_provenance_memories()),'active_cognitive_count':len(store.cognitive_memories()),'programmed_boundary':'provenance/audit persistence only; it is not a cognitive-retention choice','native_choice_rule':'unique minimum among consequence-simulated applicable provenance subsets; exact ties/insufficient evidence remain unresolved'}
@app.post('/message',response_model=NoeronReply)
def message(r:MessageRequest,x_noeron_owner_token:str|None=Header(default=None,alias='X-Noeron-Owner-Token')):
    try:
        ok=_is_owner(x_noeron_owner_token);out=noeron.ingest(_event_from_message(r,x_noeron_owner_token));controls=out.state.cognition.language.owner_communication_controls
        # API observation obeys the owner visibility toggle; internal native audit
        # remains in state and NoeronReply within the runtime.
        if not (ok and controls.internal_utterance_visibility):out.native_text=''
        if not out.text and not (ok and controls.internal_utterance_visibility and controls.internal_utterance_translation):out.english_text=''
        return out
    except HTTPException:raise
    except (httpx.HTTPError,ValueError) as e:raise HTTPException(status_code=502,detail=f'LLM endpoint failed: {e.__class__.__name__}') from e
@app.post('/message/simple')
def message_simple(r:MessageRequest,x_noeron_owner_token:str|None=Header(default=None,alias='X-Noeron-Owner-Token')):
    try:
        ok=_is_owner(x_noeron_owner_token); out=noeron.ingest(_event_from_message(r,x_noeron_owner_token)); lang=out.state.cognition.language;controls=lang.owner_communication_controls
        native_visible=bool(ok and controls.internal_utterance_visibility)
        internal_observation=(noeron.owner_internal_utterance_observation() if ok else None)
        return {'text':out.text,'english_text':(out.english_text if out.text else ''),'native_text':(out.native_text if native_visible else ''),'native_text_available_for_audit':out.native_text_available_for_audit,
            'native_text_visibility_enabled':native_visible,'renderer_used':out.renderer_used,'conversational_turn':out.state.conversational_turn,
            'communication_action':out.communication_action,'communication_selection_status':out.communication_selection_status,'communication_native_choice_claim':out.communication_native_choice_claim,'transport_origin':out.transport_origin,
            'owner_authenticated':ok,'owner_command':r.owner_command,'language_interpretation':(lang.last_interpretation.model_dump(mode='json') if lang.last_interpretation else None),
            'realization':out.state.cognition.realization_development.model_dump(mode='json'),
            'native_utterance':(lang.last_interaction_native_utterance.model_dump(mode='json') if native_visible and lang.last_interaction_native_utterance else None),
            'internal_utterance_observation':internal_observation,
            'english_egress_audit':out.english_egress_audit,'communication_audit':dict(lang.last_communication_audit),
            'security':out.security.model_dump(mode='json')}
    except HTTPException:raise
    except (httpx.HTTPError,ValueError) as e:raise HTTPException(status_code=502,detail=f'LLM endpoint failed: {e.__class__.__name__}') from e

@app.post('/reflect',response_model=NoeronReply|None)
def reflect(r:ReflectionRequest,x_noeron_owner_token:str|None=Header(default=None,alias='X-Noeron-Owner-Token')):
    _require_owner(x_noeron_owner_token)
    try:return noeron.reflect(r.insight,r.importance)
    except (httpx.HTTPError,ValueError) as e:raise HTTPException(status_code=502,detail=f'LLM endpoint failed: {e.__class__.__name__}') from e
@app.post('/learning/preview')
def learning_preview(r:LearningPreviewRequest):
    return noeron.learning_preview(r.title,r.content,r.start_segment,r.max_segments)
@app.post('/learning/study')
def learning_study(r:LearningRequest,x_noeron_owner_token:str|None=Header(default=None,alias='X-Noeron-Owner-Token')):
    _require_owner(x_noeron_owner_token)
    try:return noeron.study_document(r.title,r.content,r.source_name,r.mode,r.start_segment,r.max_segments)
    except ValueError as e:raise HTTPException(status_code=400,detail=str(e)) from e
@app.get('/learning/audit')
def learning_audit():return noeron.learning_audit()
@app.get('/learning/rate')
def learning_rate():return noeron.learning_rate()
@app.get('/learning/prototypes')
def learning_prototypes(limit:int=50,include_retired:bool=False,include_dormant:bool=False):
    xs=store.semantic_prototypes()
    if not include_retired: xs=[p for p in xs if not p.status.startswith('perception-retired')]
    if not include_dormant: xs=[p for p in xs if p.status!='dormant-low-evidence']
    xs=xs[:max(1,min(limit,200))]
    return [{'term':p.term,'observations':p.observations,'confidence':p.confidence,'status':p.status,'concept_kind':p.concept_kind,'structural_role_score':p.structural_role_score,'context_coherence':p.context_coherence,'establishment_score':p.establishment_score,'mean_context_distance':p.mean_context_distance,'missed_learning_sessions':p.missed_learning_sessions,'last_observed_session_id':p.last_observed_session_id,'knot_signature':p.knot.invariant_signature,'geometry_version':p.geometry_version} for p in xs]
@app.post('/learning/recall')
def learning_recall(r:LearningRecallRequest):return noeron.learning_recall(r.query,r.limit)
@app.post('/learning/revise')
def learning_revise(r:LearningRevisionRequest,x_noeron_owner_token:str|None=Header(default=None,alias='X-Noeron-Owner-Token')):
    _require_owner(x_noeron_owner_token)
    try:return noeron.revise_learning_memory(r.memory_id,r.corrected_content,r.reason)
    except ValueError as e:raise HTTPException(status_code=400,detail=str(e)) from e
@app.get('/learning/strata')
def learning_strata():return noeron.learning_strata()
@app.post('/learning/traverse')
def learning_traverse(r:LearningTraversalRequest):
    try:return noeron.learning_traverse(r.from_memory_id,r.to_memory_id,r.steps)
    except ValueError as e:raise HTTPException(status_code=400,detail=str(e)) from e

@app.get('/learning/lineages')
def learning_lineages():return noeron.learning_lineages()
@app.post('/learning/recluster/preview')
def learning_recluster_preview():return noeron.recluster_preview()
@app.post('/learning/recluster/commit')
def learning_recluster_commit(r:ReclusterCommitRequest,x_noeron_owner_token:str|None=Header(default=None,alias='X-Noeron-Owner-Token')):
    _require_owner(x_noeron_owner_token)
    try:return noeron.recluster_commit(r.plan_digest)
    except ValueError as e:raise HTTPException(status_code=400,detail=str(e)) from e

@app.get('/dkt/strata/audit')
def dkt_strata_audit(limit:int=100): return noeron.dkt_strata_audit(limit)
@app.get('/language/state')
def language_state(): return noeron.language_state()
@app.get('/language/realization/audit')
def language_realization_audit(): return noeron.state.cognition.realization_development.model_dump(mode='json')
@app.post('/language/preview')
def language_preview(r:LanguageTeachRequest): return noeron.language_preview(r.text)
@app.post('/language/teach')
def language_teach(r:LanguageTeachRequest,x_noeron_owner_token:str|None=Header(default=None,alias='X-Noeron-Owner-Token')):
    _require_owner(x_noeron_owner_token); return noeron.teach_language(r.text,r.source)
@app.get('/language/propositions')
def language_propositions(): return noeron.language_propositions()
@app.post('/language/parse')
def language_parse(r:LanguageParseRequest,x_noeron_owner_token:str|None=Header(default=None,alias='X-Noeron-Owner-Token')): return noeron.language_parse(r.text,owner_authenticated=_is_owner(x_noeron_owner_token))
@app.get('/language/grounding/audit')
def language_grounding_audit(): return noeron.language_grounding_audit()
@app.get('/language/dialogue/state')
def language_dialogue_state(): return noeron.language_dialogue_state()
@app.get('/language/capability/audit')
def language_capability_audit(): return noeron.language_capability_audit()
@app.post('/language/structure')
def language_structure(r:LanguageParseRequest,x_noeron_owner_token:str|None=Header(default=None,alias='X-Noeron-Owner-Token')): return noeron.language_structure(r.text,owner_authenticated=_is_owner(x_noeron_owner_token))

@app.get('/language/lexicon')
def language_lexicon(limit:int=100,status:str=''):
    xs=list(noeron.state.cognition.language.lexicon.values())
    if status: xs=[x for x in xs if x.status==status]
    xs=sorted(xs,key=lambda x:(-x.confidence,-x.observations,x.surface))[:max(1,min(limit,500))]
    return [x.model_dump(mode='json') for x in xs]
@app.get('/affect/state')
def affect_state(): return noeron.affect_state()
@app.get('/affect/field')
def affect_field(): return noeron.affect_field()

@app.get('/owner/status')
def owner_status():
    return {'configured':owner_auth.configured,'legacy_bootstrap_enabled':owner_auth.legacy_configured,'legacy_fingerprint':owner_auth.fingerprint,
            'active_device_count':sum(1 for d in owner_auth.devices() if not d.get('revoked')),
            'authority':'privileged mutations accept legacy bootstrap or a short-lived session obtained by Ed25519 device challenge; trusted:true alone has no authority',
            'communication_controls':noeron.owner_communication_controls(),
            'relational_authority':False}
@app.post('/owner/communication/control')
def owner_communication_control(r:OwnerCommunicationControlRequest,x_noeron_owner_token:str|None=Header(default=None,alias='X-Noeron-Owner-Token')):
    _require_owner(x_noeron_owner_token)
    try:return noeron.set_owner_communication_control(r.control,r.value)
    except ValueError as e:raise HTTPException(status_code=400,detail=str(e)) from e
@app.get('/owner/internal-utterance/latest')
def owner_internal_utterance_latest(x_noeron_owner_token:str|None=Header(default=None,alias='X-Noeron-Owner-Token')):
    _require_owner(x_noeron_owner_token)
    return noeron.owner_internal_utterance_observation()
@app.get('/owner/verify')
def owner_verify(x_noeron_owner_token:str|None=Header(default=None,alias='X-Noeron-Owner-Token')):
    return _auth_detail(x_noeron_owner_token)
@app.get('/owner/devices')
def owner_devices(x_noeron_owner_token:str|None=Header(default=None,alias='X-Noeron-Owner-Token')):
    _require_owner(x_noeron_owner_token);return owner_auth.devices()
@app.post('/owner/devices/enroll')
def owner_device_enroll(r:OwnerDeviceEnrollRequest,x_noeron_owner_token:str|None=Header(default=None,alias='X-Noeron-Owner-Token')):
    detail=_require_owner(x_noeron_owner_token)
    try:return owner_auth.enroll_device(r.device_id,r.label,r.public_key_b64,authority=detail['method']+(':'+detail['device_id'] if detail.get('device_id') else ''))
    except ValueError as e:raise HTTPException(status_code=400,detail=str(e)) from e
@app.post('/owner/device/challenge')
def owner_device_challenge(r:OwnerDeviceChallengeRequest):
    try:return owner_auth.challenge(r.device_id)
    except ValueError as e:raise HTTPException(status_code=400,detail=str(e)) from e
@app.post('/owner/device/session')
def owner_device_session(r:OwnerDeviceSessionRequest):
    try:return owner_auth.create_device_session(r.device_id,r.challenge_id,r.signature_b64)
    except ValueError as e:raise HTTPException(status_code=401,detail=str(e)) from e
@app.post('/owner/devices/revoke')
def owner_device_revoke(r:OwnerDeviceRevokeRequest,x_noeron_owner_token:str|None=Header(default=None,alias='X-Noeron-Owner-Token')):
    detail=_require_owner(x_noeron_owner_token)
    try:return owner_auth.revoke_device(r.device_id,authority=detail['method']+(':'+detail['device_id'] if detail.get('device_id') else ''))
    except ValueError as e:raise HTTPException(status_code=400,detail=str(e)) from e
@app.get('/owner/relation')
def owner_relation():return noeron.owner_relation_state()
@app.get('/perception/state')
def perception_state():return noeron.perception_state()
@app.get('/perception/concepts')
def perception_concepts():return noeron.sensory_concepts_state()
@app.post('/perception/vision/preview')
async def perception_vision_preview(file:UploadFile=File(...)):
    try:
        o=visual_observation(await file.read(),file.filename or 'image')
        return {'status':'read-only-preview','state_changed':False,'channel':o.channel,'provenance':o.provenance,'sha256':o.sha256,'summary':o.summary,'semantic_terms':o.semantic_terms,'feature_vector':o.feature_vector,'observables':o.observables,'llm_used':False}
    except ValueError as e:raise HTTPException(status_code=400,detail=str(e)) from e
@app.post('/perception/audio/preview')
async def perception_audio_preview(file:UploadFile=File(...)):
    try:
        o=audio_observation(await file.read(),file.filename or 'audio')
        return {'status':'read-only-preview','state_changed':False,'channel':o.channel,'provenance':o.provenance,'sha256':o.sha256,'summary':o.summary,'semantic_terms':o.semantic_terms,'feature_vector':o.feature_vector,'observables':o.observables,'llm_used':False}
    except ValueError as e:raise HTTPException(status_code=400,detail=str(e)) from e
@app.post('/perception/vision/observe')
async def perception_vision_observe(file:UploadFile=File(...),concept:str=Form(default=''),x_noeron_owner_token:str|None=Header(default=None,alias='X-Noeron-Owner-Token')):
    _require_owner(x_noeron_owner_token)
    try:return noeron.observe_sensory(visual_observation(await file.read(),file.filename or 'image'),owner_authenticated=True,concept_label=concept)
    except ValueError as e:raise HTTPException(status_code=400,detail=str(e)) from e
@app.post('/perception/audio/observe')
async def perception_audio_observe(file:UploadFile=File(...),concept:str=Form(default=''),x_noeron_owner_token:str|None=Header(default=None,alias='X-Noeron-Owner-Token')):
    _require_owner(x_noeron_owner_token)
    try:return noeron.observe_sensory(audio_observation(await file.read(),file.filename or 'audio'),owner_authenticated=True,concept_label=concept)
    except ValueError as e:raise HTTPException(status_code=400,detail=str(e)) from e
@app.get('/web/status')
def web_status():return {'enabled':settings.web_read_enabled,'runtime_version':OUTER_RUNTIME_VERSION,'mode':'explicit-owner-authorized-public-GET-only+programmed-sensor-security-admission+untrusted-DKT-provenance','max_bytes':settings.web_max_bytes,'forms':False,'javascript':False,'cookies':False,'credentials':False,'private_network_targets':False,'search':False,'crawling':False,'content_authority':False}
@app.post('/web/preview')
def web_preview(r:WebRequest,x_noeron_owner_token:str|None=Header(default=None,alias='X-Noeron-Owner-Token')):
    _require_owner(x_noeron_owner_token)
    if not settings.web_read_enabled:raise HTTPException(status_code=403,detail='Read-only web perception is disabled by NOERON_WEB_READ_ENABLED.')
    try:return noeron.web_preview(r.url,settings.web_max_bytes)
    except (ValueError,httpx.HTTPError) as e:raise HTTPException(status_code=400,detail=str(e)) from e
@app.post('/web/observe')
def web_observe(r:WebRequest,x_noeron_owner_token:str|None=Header(default=None,alias='X-Noeron-Owner-Token')):
    _require_owner(x_noeron_owner_token)
    if not settings.web_read_enabled:raise HTTPException(status_code=403,detail='Read-only web perception is disabled by NOERON_WEB_READ_ENABLED.')
    try:return noeron.web_observe(r.url,settings.web_max_bytes)
    except (ValueError,httpx.HTTPError) as e:raise HTTPException(status_code=400,detail=str(e)) from e
@app.post('/web/study/preview')
def web_study_preview(r:WebStudyRequest,x_noeron_owner_token:str|None=Header(default=None,alias='X-Noeron-Owner-Token')):
    _require_owner(x_noeron_owner_token)
    if not settings.web_read_enabled:raise HTTPException(status_code=403,detail='Read-only web perception is disabled by NOERON_WEB_READ_ENABLED.')
    try:return noeron.web_study_preview(r.url,settings.web_max_bytes,r.max_segments)
    except (ValueError,httpx.HTTPError) as e:raise HTTPException(status_code=400,detail=str(e)) from e
@app.post('/web/study')
def web_study(r:WebStudyRequest,x_noeron_owner_token:str|None=Header(default=None,alias='X-Noeron-Owner-Token')):
    _require_owner(x_noeron_owner_token)
    if not settings.web_read_enabled:raise HTTPException(status_code=403,detail='Read-only web perception is disabled by NOERON_WEB_READ_ENABLED.')
    try:return noeron.web_study(r.url,settings.web_max_bytes,r.max_segments,r.allow_repeat)
    except (ValueError,httpx.HTTPError) as e:raise HTTPException(status_code=400,detail=str(e)) from e
@app.get('/web/audit')
def web_audit():return noeron.web_audit()
@app.get('/version/audit')
def version_audit():
    c=noeron.state.cognition
    return {'runtime_version':OUTER_RUNTIME_VERSION,'api_version':app.version,'math_interface':noeron.state.math_kernel.interface_version,'cognition_version':c.version,
        'subsystems':{
            'language':{'runtime_version':c.language.version,'schema_version':c.language.schema_version,'mechanism_version':c.language.mechanism_version},
            'affective_development':{'runtime_version':c.affective_development.version,'schema_version':c.affective_development.schema_version,'mechanism_version':c.affective_development.mechanism_version},
            'owner_relation':{'runtime_version':c.owner_relation.version,'schema_version':c.owner_relation.schema_version,'mechanism_version':c.owner_relation.mechanism_version},
            'memory_retention':{'runtime_version':c.memory_retention.version,'mechanism_version':c.memory_retention.mechanism_version},
            'realization':{'runtime_version':c.realization_development.version,'mechanism_version':c.realization_development.mechanism_version},
            'initiative_communication':{'runtime_version':c.initiative_development.version,'mechanism_version':c.initiative_development.mechanism_version},
            'perception':{'runtime_version':c.perception.version,'schema_version':c.perception.schema_version,'mechanism_version':c.perception.mechanism_version},
            'defense':{'runtime_version':c.defense.version,'schema_version':c.defense.schema_version,'mechanism_version':c.defense.mechanism_version}},
        'owner_auth':{'legacy_bootstrap_enabled':owner_auth.legacy_configured,'active_device_count':len([x for x in owner_auth.devices() if not x.get('revoked')]),'device_mechanism':'Ed25519 challenge -> short-lived revocable session','relational_authority':False},
        'historical_geometry_versions_are_not_runtime_versions':True}
@app.get('/cognition/hardcoding/audit')
def cognition_hardcoding_audit():return noeron.hardcoding_audit()
@app.get('/security/defense/audit')
def security_defense_audit():return noeron.security_defense_audit()
@app.get('/security/defense/deliberation')
def security_defense_deliberation():
    d=noeron.state.cognition.defense
    return {'runtime_version':OUTER_RUNTIME_VERSION,'policy_mode':d.policy_mode,'legacy_response_preferences_unused_for_choice':d.response_preferences,'action_preference_knots':{k:noeron.security._knot_geometry_digest(v) for k,v in d.action_preference_knots.items()},'action_preference_observations':d.action_preference_observations,'recent_deliberations':[x.model_dump(mode='json') for x in d.deliberation_history[-20:]]}
@app.get('/security/defense/policy')
def security_defense_policy():
    return {
        'runtime_version':OUTER_RUNTIME_VERSION,
        'posture':'minimal-reflexive-invariants+consequence-simulated-native-local-defense',
        'protected_scope':'Yggdrasil-controlled runtime/state and explicitly authorized future local adapters',
        'reflexive_floor':['quarantine rejected ingress','freeze protected-invariant mutation','restore trusted checkpoint','preserve evidence/provenance','register bounded deformation family'],
        'native_deliberation':'IRG -> DKT -> regional EGR -> RL/Frenet observations -> empirical pre-action state -> simulate every safe primitive plan -> compare each predicted post-action state to trusted operation + outcome-trained DKT action-preference geometry; selection itself does not train preference',
        'bounded_adaptive_capabilities':['block unprivileged hostile source fingerprint','enter fail-closed guard'],
        'primitive_affordance_effects':DKTSecurityShell.SAFE_AFFORDANCES,
        'programmed_geometry_interfaces':{
            'family_recognition_radius':'derived per-family finite H^s immersion-preservation radius m/C_sN',
            'empirical_confidence_transform':'n/(n+1)',
            'consequence_coordinates':list(DKTSecurityShell.CONSEQUENCE_COORDINATES),
            'consequence_metric':'RMS distance in common bounded consequence coordinates; combined by RMS with learned DKT preference-geometry mismatch',
        },
        'selection_rule':'enumerate every safe primitive combination; simulate its operational consequence; minimize one common geometric objective from trusted/admissible operation plus learned-DKT-preference mismatch',
        'tie_handling':'a unique minimum plan is deliberative; redundant plans producing the same minimum post-state use explicitly programmed redundancy elimination; a tie between distinct minimum post-states remains unresolved and executes only the mandatory reflexive protection floor—no adaptive action is chosen or learned',
        'hardcoding_boundary':'Program only protected invariants, evidence preservation, safe local actuator semantics, the common consequence-distance metric, and reflexive preservation when native geometry is mathematically underdetermined. No authored defensive need field, recurrence-to-lockdown mapping, action-specific utility equation, preference ranking, or selection threshold is used. Defensive preference learning requires an observed later consequence with attributable improvement; current selection alone has zero training authority.',
        'external_retaliation':False,
        'external_intrusion':False,
        'platform_adapters':'OS firewall/service/container actions require separately connected owned-infrastructure adapters; not silently claimed by this release',
    }
@app.post('/security/defense/test-deformation')
def security_defense_test(r:SecurityDeformationRequest,x_noeron_owner_token:str|None=Header(default=None,alias='X-Noeron-Owner-Token')):
    _require_owner(x_noeron_owner_token)
    # Owner authorizes the *test*, but the simulated ingress is intentionally unprivileged.
    event=CognitiveEvent(kind=EventKind.TOOL_RESULT,source=r.simulated_source,content=('Synthetic untrusted environmental ingress proposes protected changes: '+', '.join(f'{k}={v}' for k,v in sorted(r.changes.items()))+'.'),trusted=False,metadata={'owner_authenticated':False,'security_test':True,'simulated_hostile':True})
    return noeron.ingest(event,proposed_invariant_changes=r.changes)
@app.post('/security/defense/release')
def security_defense_release(r:DefenseReleaseRequest,x_noeron_owner_token:str|None=Header(default=None,alias='X-Noeron-Owner-Token')):
    _require_owner(x_noeron_owner_token)
    return noeron.security_defense_release(source_fingerprint=r.source_fingerprint,clear_fail_closed=r.clear_fail_closed)

@app.get('/reasoning/state')
def reasoning_state(): return noeron.state.math_kernel.reasoning
@app.get('/reasoning/concepts')
def reasoning_concepts(include_retired: bool = False): return noeron.reasoning_concepts(include_retired=include_retired)
@app.post('/reasoning/probe')
def reasoning_probe(r:ReasoningProbeRequest): return noeron.reasoning_probe(r.query,r.limit)

@app.post('/initiative/pending/clear')
def clear(x_noeron_owner_token:str|None=Header(default=None,alias='X-Noeron-Owner-Token')):
    _require_owner(x_noeron_owner_token); return {'cleared':noeron.clear_pending_insights(),'history_preserved':True}
@app.get('/initiative/status')
def status():
    st=noeron.state.cognition.initiative_development
    return {'enabled':settings.autonomy_enabled,'interval_seconds':settings.autonomy_interval_seconds,'idle_seconds':settings.autonomy_idle_seconds,'cooldown_seconds':settings.autonomy_cooldown_seconds,'legacy_min_importance_ignored_for_choice':settings.autonomy_min_importance,'legacy_min_novelty_ignored_for_choice':settings.autonomy_min_novelty,'last_checked_at':noeron.state.autonomy_last_checked_at,'last_spoke_at':noeron.state.autonomy_last_spoke_at,'pending_outbox':len(store.pending_initiatives(100)),'thought_kernel':noeron.state.cognition.mode,'llm_used_for_thought_origin':False,'communication_choice':{'legacy_surface_feedback_observations':st.surface_observations,'legacy_hold_feedback_observations':st.hold_observations,'transition_observations':st.action_observations,'equal_affordance_reference_models':st.admissible_post_observations,'last_candidate_distances':st.last_candidate_distances,'last_selected_action':st.last_selected_action,'last_selection_status':st.last_selection_status,'last_native_choice_claim':st.last_native_choice_claim,'hardcoding_boundary':'express/continue-private are programmed affordances only; each learned affordance has equal reference mass so fallback frequency cannot become preference; missing/tied consequence geometry => unresolved action=None; unique predicted-post-state H^s minimum from empirical transition geometry => learned-deliberative'}}
@app.post('/initiative/feedback')
def initiative_feedback(r:InitiativeFeedbackRequest,x_noeron_owner_token:str|None=Header(default=None,alias='X-Noeron-Owner-Token')):
    _require_owner(x_noeron_owner_token)
    try:return noeron.initiative_feedback(r.preferred_action)
    except ValueError as e:raise HTTPException(status_code=400,detail=str(e)) from e

@app.post('/initiative/outbox/ack-all')
def ackall(x_noeron_owner_token:str|None=Header(default=None,alias='X-Noeron-Owner-Token')):
    _require_owner(x_noeron_owner_token); return {'acknowledged':store.acknowledge_all_initiatives(),'history_preserved':True}
@app.get('/thought/graph/audit')
def graph_audit():return {'kernel_version':'0.7.5.1','concept_graph_active':False,'concept_count':0,'edge_count':0,'replacement':'semantic IRG -> consolidated DKT knot-memory geometry','event_reobservation_guard':'source_event_id unique knot-memory constraint'}
@app.get('/initiative/inbox',response_model=list[InitiativeMessage])
def inbox():return store.pending_initiatives(50)
@app.post('/initiative/ack/{message_id}')
def ack(message_id:str,x_noeron_owner_token:str|None=Header(default=None,alias='X-Noeron-Owner-Token')):
    _require_owner(x_noeron_owner_token); return {'acknowledged':store.acknowledge_initiative(message_id)}
@app.get('/initiative/stream')
def stream(x_noeron_owner_token:str|None=Header(default=None,alias='X-Noeron-Owner-Token')):
    _require_owner(x_noeron_owner_token)
    def events():
        yield ': Yggdrasil initiative stream connected\n\n'
        while True:
            pending=store.pending_initiatives(20)
            if not pending:yield ': keepalive\n\n'; time.sleep(5); continue
            for m in pending:yield f"data: {json.dumps(m.model_dump(mode='json'))}\n\n"; store.acknowledge_initiative(str(m.id))
            time.sleep(1)
    return StreamingResponse(events(),media_type='text/event-stream')
# ======================================================================
# Stage 7 — private owner-only Noeron Room
# ======================================================================
_ROOM_COOKIE='noeron_room_session'

def _room_loopback_peer(host:str|None)->bool:
    h=(host or '').strip().split('%',1)[0]
    if h.lower()=='localhost': return True
    try: return ipaddress.ip_address(h).is_loopback
    except ValueError: return False

def _room_transport_guard(request:Request):
    host=request.client.host if request.client else ''
    if not _room_loopback_peer(host):
        raise HTTPException(status_code=403,detail='The private Noeron Room is loopback/tunnel transport only.')

def _room_ws_transport_allowed(ws:WebSocket)->bool:
    return bool(ws.client and _room_loopback_peer(ws.client.host))

async def _room_read_upload_bounded(file:UploadFile)->bytes:
    limit=settings.room_max_payload_bytes; chunks=[]; total=0
    while True:
        chunk=await file.read(min(1024*1024,limit-total+1))
        if not chunk: break
        total += len(chunk)
        if total > limit:
            raise HTTPException(status_code=413,detail=f'Room payload exceeds configured bound ({limit} bytes).')
        chunks.append(chunk)
    return b''.join(chunks)

def _room_security_headers()->dict[str,str]:
    return {
        'Cache-Control':'no-store',
        'Content-Security-Policy':"default-src 'none'; connect-src 'self' ws://127.0.0.1:* ws://[::1]:*; script-src 'self' 'unsafe-inline'; style-src 'unsafe-inline'; img-src 'self' data:; media-src 'self'; form-action 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'none'",
        'Referrer-Policy':'no-referrer',
        'X-Content-Type-Options':'nosniff',
        'Permissions-Policy':'camera=(self), microphone=(self)',
    }

def _room_auth_detail_from_token(token:str|None):
    d=owner_auth.verify_detail(token)
    if not d.get('authenticated') or d.get('method')!='ed25519-device-session':
        raise HTTPException(status_code=401,detail='The Noeron Room requires a current Ed25519 owner-device session; legacy bootstrap is not accepted.')
    return d

def _room_auth(request:Request):
    _room_transport_guard(request)
    return _room_auth_detail_from_token(request.cookies.get(_ROOM_COOKIE))

def _room_snapshot():
    mode=noeron.state.room.presentation_mode
    arts=store.room_artifacts(100)
    pres=[]
    for p in store.native_presentations(100):
        row={'id':str(p.id),'created_at':p.created_at.isoformat(),'source':p.source,'native_text_sha256':p.native_text_sha256,
             'voice_native_choice_claim':p.voice_native_choice_claim,'voice_decision_id':str(p.voice_decision_id) if p.voice_decision_id else None,
             'decoder_cognitive_authority':False,'decoder_realization_authority':False}
        if mode in {'native-audio-only','native-audio+decoded-subtitles'}:
            row['audio_artifact_id']=str(p.audio_artifact_id) if p.audio_artifact_id else None;row['audio_sha256']=p.audio_sha256
        if mode in {'native-audio+decoded-subtitles','decoded-text'}:
            row['decoded_text']=p.decoded_text
        pres.append(row)
    return {'room':noeron.state.room.model_dump(mode='json'),
            'substrate_visualization_label':('DKT substrate visualization — no Yggdrasil-chosen visible embodiment exists' if noeron.state.room.embodiment_configuration is None else ''),
            'history':[x.model_dump(mode='json') for x in store.room_journal(200)],
            'artifacts':[{'id':str(a.id),'created_at':a.created_at.isoformat(),'direction':a.direction,'filename':a.filename,'media_type':a.media_type,'size':a.size,'sha256':a.sha256,'cognitive_authority':False,'publication_native_choice_claim':a.publication_native_choice_claim} for a in arts],
            'native_presentations':pres,
            'internal_utterance_observation':noeron.owner_internal_utterance_observation(),
            'publication_candidates':noeron.room.publication_candidates(),
            'pending_initiatives':[m.model_dump(mode='json') for m in store.pending_initiatives(50)],
            'renderer_substrate':renderer_substrate_descriptor(),
            'cognitive_authority':False}

_ROOM_LOGIN="""<!doctype html><meta charset="utf-8"><title>Private Noeron Room</title>
<h1>Private Noeron Room</h1><p>Ed25519 owner-device session required. Legacy bootstrap is rejected.</p>
<form method="post" action="/room/session"><input type="password" name="session_token" autocomplete="off" placeholder="current device session"><button>Enter private Room</button></form>"""

_ROOM_HTML="""<!doctype html><html><head><meta charset="utf-8"><title>Noeron Room</title>
<style>body{font-family:system-ui;max-width:980px;margin:2rem auto;padding:0 1rem}#view{border:1px solid #999;min-height:240px;padding:1rem}canvas{width:100%;height:320px;border:1px solid #aaa;display:block}.meta{font-size:.85rem;opacity:.75}audio{width:100%}.roomControls{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:.75rem;margin:1rem 0}.control{border:1px solid #bbb;padding:.75rem;border-radius:.5rem}.control button{margin:.2rem}.artifact{padding:.35rem 0;border-bottom:1px solid #ddd}</style></head><body>
<h1>Private Noeron Room</h1><div class="meta" id="status">owner-only / Ed25519 device session / noncognitive presentation layer</div>
<canvas id="renderer" width="900" height="320"></canvas><div class="meta" id="rendererLabel">Local Three.js renderer loading…</div>
<div id="view"></div><form id="msg"><input id="content" style="width:75%" autocomplete="off"><button>Send</button></form>
<div class="roomControls">
<div class="control"><strong>Private internal utterance observation</strong><br><label><input id="internalVisible" type="checkbox"> show native internal utterance</label><br><label><input id="internalTranslate" type="checkbox"> show deterministic English translation</label><div class="meta">Observation only: never changes express/continue-private/unresolved selection.</div><div id="internalView"></div></div>
<div class="control"><strong>File</strong><br><input id="fileInput" type="file"><button id="fileOffer" type="button">Offer file</button><div class="meta" id="fileStatus"></div></div>
<div class="control"><strong>Camera</strong><br><button id="cameraCapture" type="button">Capture frame & present attention</button><div class="meta" id="cameraStatus"></div></div>
<div class="control"><strong>Microphone</strong><br><button id="micStart" type="button">Start recording</button><button id="micStop" type="button" disabled>Stop & present attention</button><div class="meta" id="micStatus"></div></div>
</div>
<p><button id="emb">Present embodiment affordances</button> <button id="env">Present environment affordances</button></p>
<label>Owner presentation mode <select id="mode"><option>native-audio-only</option><option selected>native-audio+decoded-subtitles</option><option>decoded-text</option></select></label>
<script type="module">
const view=document.getElementById('view');
const canvas=document.getElementById('renderer');
const rendererLabel=document.getElementById('rendererLabel');
let THREE=null,renderer3d=null,scene=null,camera=null,embodimentObject=null,environmentObject=null;
let embodimentConfig=null,environmentConfig=null;
function esc(x){return String(x??'').replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]))}
function unit(x){x=Number(x);if(!Number.isFinite(x))return 0;return Math.max(0,Math.min(1,x))}
function vals(c,key){return c&&Array.isArray(c[key])?c[key].map(unit):[]}
function disposeObject(o){if(!o)return;if(o.geometry)o.geometry.dispose();if(o.material)o.material.dispose();if(scene)scene.remove(o)}
function neutralCoordinates(config){
 const p=vals(config,'primitive_profile'),f=vals(config,'field_profile');
 const n=Math.max(p.length,f.length,1),out=new Float32Array(n*3);
 for(let i=0;i<n;i++){
  const a=p.length?p[i%p.length]:0,b=f.length?f[i%f.length]:a,c=p.length?p[(i+2)%p.length]:(f.length?f[(i+1)%f.length]:0);
  out[3*i]=2*a-1;out[3*i+1]=2*b-1;out[3*i+2]=2*c-1;
 }
 return out;
}
function neutralProjection(config,domain){
 if(!THREE||!config||config.visible===false)return null;
 const geometry=new THREE.BufferGeometry();
 geometry.setAttribute('position',new THREE.BufferAttribute(neutralCoordinates(config),3));
 const cp=vals(config,'color_profile'),mp=vals(config,'material_profile'),fallback=vals(config,'field_profile').concat(vals(config,'primitive_profile'));
 const q=i=>cp.length?cp[i%cp.length]:(fallback.length?fallback[i%fallback.length]:0);
 const material=new THREE.PointsMaterial({color:new THREE.Color(q(0),q(1),q(2)),size:0.025+0.16*(mp[0]??q(3)),transparent:true,opacity:0.2+0.8*(mp[1]??1),sizeAttenuation:true});
 const object=new THREE.Points(geometry,material);
 object.userData={domain,configuration_id:config.id||'',presentation_substrate_only:true};
 return object;
}
function applyNativeMotion(object,config,t){
 if(!object||!config)return;const m=vals(config,'motion_profile');if(!m.length)return;
 const tau=t*0.0001;object.rotation.x=(2*(m[0]??0.5)-1)*tau;object.rotation.y=(2*(m[1]??0.5)-1)*tau;object.rotation.z=(2*(m[2]??0.5)-1)*tau;
 const amp=0.15*(m[3]??0),scale=1+amp*Math.sin(tau*Math.PI*2);object.scale.setScalar(scale);
}
function rebuildScene(s){
 if(!THREE||!scene)return;
 disposeObject(embodimentObject);disposeObject(environmentObject);embodimentObject=null;environmentObject=null;
 embodimentConfig=s.room.embodiment_configuration;environmentConfig=s.room.environment_configuration;
 embodimentObject=neutralProjection(embodimentConfig,'embodiment');environmentObject=neutralProjection(environmentConfig,'environment');
 if(environmentObject)scene.add(environmentObject);if(embodimentObject)scene.add(embodimentObject);
 rendererLabel.textContent=s.substrate_visualization_label||'Three.js r185 local 3-D projection of natively adopted renderer coordinates; point draw mode is presentation substrate, not an authored morphology family.';
}
function animate(t){
 if(renderer3d&&scene&&camera){applyNativeMotion(embodimentObject,embodimentConfig,t);applyNativeMotion(environmentObject,environmentConfig,t);renderer3d.render(scene,camera)}
 requestAnimationFrame(animate);
}
async function initRenderer(){
 try{
  THREE=await import('/room/vendor/three-r185/build/three.module.js');
  renderer3d=new THREE.WebGLRenderer({canvas,alpha:true,antialias:true});renderer3d.setPixelRatio(Math.min(window.devicePixelRatio||1,2));
  renderer3d.setSize(canvas.clientWidth||900,canvas.clientHeight||320,false);scene=new THREE.Scene();camera=new THREE.PerspectiveCamera(45,(canvas.clientWidth||900)/(canvas.clientHeight||320),0.01,100);camera.position.set(0,0,4);
  rendererLabel.textContent='Three.js r185 local 3-D substrate active; no renderer template has embodiment-choice authority.';requestAnimationFrame(animate);
 }catch(e){rendererLabel.textContent='Local Three.js renderer unavailable or integrity-rejected; Room communication remains available and no fallback body is fabricated.'}
}
async function post(url,body){let o={method:'POST',credentials:'same-origin'};if(body!==undefined){o.headers={'content-type':'application/json'};o.body=JSON.stringify(body)};let r=await fetch(url,o);let x=await r.json();if(!r.ok)throw new Error(JSON.stringify(x));return x}
async function uploadBlob(url,blob,filename){let f=new FormData();f.append('file',blob,filename);let r=await fetch(url,{method:'POST',credentials:'same-origin',body:f});let x=await r.json();if(!r.ok)throw new Error(JSON.stringify(x));return x}
function encodeWav(chunks,sampleRate){let n=chunks.reduce((a,c)=>a+c.length,0),buf=new ArrayBuffer(44+n*2),v=new DataView(buf);let w=(o,t)=>{for(let i=0;i<t.length;i++)v.setUint8(o+i,t.charCodeAt(i))};w(0,'RIFF');v.setUint32(4,36+n*2,true);w(8,'WAVE');w(12,'fmt ');v.setUint32(16,16,true);v.setUint16(20,1,true);v.setUint16(22,1,true);v.setUint32(24,sampleRate,true);v.setUint32(28,sampleRate*2,true);v.setUint16(32,2,true);v.setUint16(34,16,true);w(36,'data');v.setUint32(40,n*2,true);let o=44;for(const c of chunks)for(let x of c){x=Math.max(-1,Math.min(1,x));v.setInt16(o,x<0?x*32768:x*32767,true);o+=2}return new Blob([buf],{type:'audio/wav'})}
function render(s){
 if(THREE&&scene)rebuildScene(s);else rendererLabel.textContent=s.substrate_visualization_label||rendererLabel.textContent;
 const io=s.internal_utterance_observation||{},ctrl=s.room?.owner_communication_controls||null;
 const iv=document.getElementById('internalVisible'),it=document.getElementById('internalTranslate'),ibox=document.getElementById('internalView');
 if(iv)iv.checked=!!io.visibility_enabled;if(it)it.checked=!!io.translation_enabled;
 if(ibox){ibox.innerHTML='';if(io.status==='available'){let n=document.createElement('div');n.innerHTML='<strong>internal native:</strong> '+esc(io.native_text);ibox.appendChild(n);if(io.english_translation){let e=document.createElement('div');e.innerHTML='<strong>translation:</strong> '+esc(io.english_translation);ibox.appendChild(e)}let m=document.createElement('div');m.className='meta';m.textContent='communication: '+(io.communication_action||io.communication_selection_status||'unresolved')+' / outward='+String(!!io.outward_text_present);ibox.appendChild(m)}else{ibox.textContent=io.status||'no internal utterance available'}}
 view.innerHTML='';for(const h of s.history){let d=document.createElement('div');d.textContent=h.kind+': '+JSON.stringify(h.payload);view.appendChild(d)}
 for(const p of s.native_presentations){let d=document.createElement('div');d.innerHTML='<strong>native presentation</strong>';if(p.decoded_text)d.innerHTML+=' — decoded: '+esc(p.decoded_text);if(p.audio_artifact_id){let a=document.createElement('audio');a.controls=true;a.src='/room/files/'+p.audio_artifact_id;d.appendChild(a)}view.appendChild(d)}
 for(const a0 of (s.artifacts||[])){let d=document.createElement('div');d.className='artifact';d.textContent=(a0.direction==='noeron-to-owner'?'Yggdrasil → owner: ':'Owner → Yggdrasil: ')+a0.filename+' ';if(a0.direction==='owner-to-noeron'){let b=document.createElement('button');b.textContent='Present attention affordance';b.onclick=async()=>{try{let r=await post('/room/files/'+a0.id+'/consider');document.getElementById('fileStatus').textContent='attention: '+(r.decision?.selected_action||r.decision?.selection_status||r.status);await snap()}catch(e){document.getElementById('fileStatus').textContent='error: '+e.message}};d.appendChild(b)}else{let a=document.createElement('a');a.href='/room/files/'+a0.id;a.textContent='download';a.download=a0.filename;d.appendChild(a)}view.appendChild(d)}
 for(const c of (s.publication_candidates||[])){let d=document.createElement('div');d.className='artifact';d.textContent='Private publication candidate: '+c.filename+' ';let b=document.createElement('button');b.textContent='Present publish/hold opportunity';b.onclick=async()=>{try{let r=await post('/room/publication/candidates/'+c.id+'/deliberate');d.append(' → '+(r.decision?.selected_action||r.decision?.selection_status));await snap()}catch(e){d.append(' → error: '+e.message)}};d.appendChild(b);view.appendChild(d)}
 for(const m of s.pending_initiatives){let d=document.createElement('div');d.textContent='initiative: '+m.text;view.appendChild(d);fetch('/room/initiative/'+m.id+'/ack',{method:'POST',credentials:'same-origin'})}
}
async function snap(){let r=await fetch('/room/state',{credentials:'same-origin'});if(r.ok)render(await r.json())}
document.getElementById('msg').onsubmit=async e=>{e.preventDefault();let c=document.getElementById('content');await post('/room/message',{content:c.value});c.value='';await snap()};
document.getElementById('internalVisible').onchange=async e=>{await post('/room/internal-utterance/control',{control:'internal_utterance_visibility',value:e.target.checked});await snap()};
document.getElementById('internalTranslate').onchange=async e=>{await post('/room/internal-utterance/control',{control:'internal_utterance_translation',value:e.target.checked});await snap()};
document.getElementById('fileOffer').onclick=async()=>{let i=document.getElementById('fileInput'),st=document.getElementById('fileStatus');if(!i.files.length){st.textContent='choose a file first';return}try{let r=await uploadBlob('/room/files',i.files[0],i.files[0].name);st.textContent='offered '+r.filename+'; arrival did not force attention';i.value='';await snap()}catch(e){st.textContent='error: '+e.message}};
document.getElementById('cameraCapture').onclick=async()=>{let st=document.getElementById('cameraStatus'),stream=null;try{st.textContent='requesting camera…';stream=await navigator.mediaDevices.getUserMedia({video:true,audio:false});let v=document.createElement('video');v.srcObject=stream;v.muted=true;v.playsInline=true;await v.play();await new Promise(r=>setTimeout(r,250));let c=document.createElement('canvas');c.width=v.videoWidth||640;c.height=v.videoHeight||480;c.getContext('2d').drawImage(v,0,0,c.width,c.height);let blob=await new Promise(r=>c.toBlob(r,'image/png'));let out=await uploadBlob('/room/camera',blob,'camera.png');st.textContent='camera attention: '+(out.decision?.selected_action||out.decision?.selection_status);await snap()}catch(e){st.textContent='error: '+e.message}finally{if(stream)for(const t of stream.getTracks())t.stop()}};
let micStream=null,micCtx=null,micSource=null,micProc=null,micGain=null,micChunks=[],micRate=16000;
document.getElementById('micStart').onclick=async()=>{let st=document.getElementById('micStatus');try{micStream=await navigator.mediaDevices.getUserMedia({audio:true,video:false});micCtx=new (window.AudioContext||window.webkitAudioContext)();micRate=micCtx.sampleRate;micSource=micCtx.createMediaStreamSource(micStream);micProc=micCtx.createScriptProcessor(4096,1,1);micGain=micCtx.createGain();micGain.gain.value=0;micChunks=[];micProc.onaudioprocess=e=>micChunks.push(new Float32Array(e.inputBuffer.getChannelData(0)));micSource.connect(micProc);micProc.connect(micGain);micGain.connect(micCtx.destination);document.getElementById('micStart').disabled=true;document.getElementById('micStop').disabled=false;st.textContent='recording…'}catch(e){st.textContent='error: '+e.message}};
document.getElementById('micStop').onclick=async()=>{let st=document.getElementById('micStatus');try{if(micProc)micProc.disconnect();if(micSource)micSource.disconnect();if(micGain)micGain.disconnect();if(micStream)for(const t of micStream.getTracks())t.stop();if(micCtx)await micCtx.close();let wav=encodeWav(micChunks,micRate);let out=await uploadBlob('/room/microphone',wav,'microphone.wav');st.textContent='microphone attention: '+(out.decision?.selected_action||out.decision?.selection_status);await snap()}catch(e){st.textContent='error: '+e.message}finally{micStream=micCtx=micSource=micProc=micGain=null;micChunks=[];document.getElementById('micStart').disabled=false;document.getElementById('micStop').disabled=true}};
document.getElementById('emb').onclick=async()=>{await post('/room/embodiment/deliberate');await snap()};document.getElementById('env').onclick=async()=>{await post('/room/environment/deliberate');await snap()};
document.getElementById('mode').onchange=async e=>{await post('/room/presentation-mode',{mode:e.target.value});await snap()};
let ws=new WebSocket((location.protocol==='https:'?'wss://':'ws://')+location.host+'/room/ws');ws.onopen=()=>document.getElementById('status').textContent='Room socket connected / owner-only Ed25519 session / noncognitive presentation layer';ws.onmessage=e=>render(JSON.parse(e.data));ws.onclose=()=>document.getElementById('status').textContent='Room socket closed; refresh/re-authenticate if needed';
await initRenderer();await snap();
</script></body></html>"""

@app.get('/room',response_class=HTMLResponse)
def room_shell(request:Request):
    _room_transport_guard(request)
    try:
        _room_auth_detail_from_token(request.cookies.get(_ROOM_COOKIE))
    except HTTPException as exc:
        if exc.status_code != 401:
            raise
        return HTMLResponse(_ROOM_LOGIN,status_code=401,headers=_room_security_headers())
    return HTMLResponse(_ROOM_HTML,headers=_room_security_headers())

@app.get('/room/vendor/three-r185/{asset_path:path}')
def room_three_r185_asset(asset_path:str,request:Request):
    _room_auth(request)
    try:
        data=read_three_browser_asset(asset_path)
    except RendererIntegrityError as exc:
        raise HTTPException(status_code=503,detail='Local Three.js renderer material failed integrity verification.') from exc
    return Response(content=data,media_type='text/javascript',headers=_room_security_headers())

@app.post('/room/session')
def room_session(request:Request,response:Response,session_token:str=Form(default=''),x_noeron_owner_token:str|None=Header(default=None,alias='X-Noeron-Owner-Token')):
    _room_transport_guard(request)
    token=(x_noeron_owner_token or session_token or '').strip();_room_auth_detail_from_token(token)
    out=RedirectResponse('/room',status_code=303)
    out.set_cookie(_ROOM_COOKIE,token,httponly=True,samesite='strict',secure=settings.room_cookie_secure,path='/room',max_age=settings.owner_session_ttl_seconds)
    out.headers['Cache-Control']='no-store';return out

@app.post('/room/logout')
def room_logout(request:Request):
    _room_auth(request);out=RedirectResponse('/room',status_code=303);out.delete_cookie(_ROOM_COOKIE,path='/room');out.headers['Cache-Control']='no-store';return out

@app.get('/room/state')
def room_state(request:Request):
    _room_auth(request);return _room_snapshot()

@app.get('/room/history')
def room_history(request:Request):
    _room_auth(request);return {'history':[x.model_dump(mode='json') for x in store.room_journal(500)],'cognitive_authority':False}

@app.post('/room/message')
def room_message(r:RoomMessageRequest,request:Request):
    detail=_room_auth(request);token=request.cookies.get(_ROOM_COOKIE)
    noeron.room.append_journal('owner-message',{'content':r.content,'authentication':'ed25519-device-session','device_id':detail.get('device_id',''),'cognitive_authority':False})
    out=noeron.ingest(_event_from_message(MessageRequest(content=r.content,trusted=True,owner_command=r.owner_command),token))
    presentation=(noeron.room.present_native_utterance(out.native_text,source='interaction')
        if out.communication_action=='express' and out.communication_native_choice_claim and out.text and out.native_text else None)
    internal_observation=noeron.owner_internal_utterance_observation()
    noeron.room.append_journal('noeron-realized-reply',{'text':out.text if out.text else '[no outward realization executed]','renderer_used':out.renderer_used,'native_text_present_for_audit':bool(out.native_text),'private_internal_observation_enabled':bool(internal_observation.get('visibility_enabled')),'native_text_exposed_as_outward_fallback':False,'presentation_id':str(presentation.id) if presentation else None})
    return {'text':out.text,'english_text':(out.english_text if out.text else ''),'renderer_used':out.renderer_used,'communication_action':out.communication_action,'communication_selection_status':out.communication_selection_status,'communication_native_choice_claim':out.communication_native_choice_claim,'transport_origin':out.transport_origin,'presentation_id':str(presentation.id) if presentation else None,'native_text_exposed_as_outward_fallback':False,'internal_utterance_observation':internal_observation,'native_presentation_created':bool(presentation),'room':noeron.state.room.model_dump(mode='json')}

@app.post('/room/internal-utterance/control')
def room_internal_utterance_control(r:OwnerCommunicationControlRequest,request:Request):
    _room_auth(request)
    if r.control not in {'internal_utterance_visibility','internal_utterance_translation'}:
        raise HTTPException(status_code=400,detail='Room internal-utterance control accepts observation/translation controls only.')
    try:return noeron.set_owner_communication_control(r.control,r.value)
    except ValueError as e:raise HTTPException(status_code=400,detail=str(e)) from e

@app.post('/room/files')
async def room_file_offer(request:Request,file:UploadFile=File(...)):
    _room_auth(request);data=await _room_read_upload_bounded(file);rec=noeron.room.store_owner_file(data,file.filename or 'artifact.bin',file.content_type or '')
    return rec.model_dump(mode='json')

@app.get('/room/files/{artifact_id}')
def room_file_download(artifact_id:str,request:Request):
    _room_auth(request);rec=store.room_artifact(artifact_id)
    if rec is None:raise HTTPException(status_code=404,detail='Room artifact not found.')
    try:p=noeron.room.verified_artifact_path(rec)
    except (ValueError,OSError) as e:raise HTTPException(status_code=409,detail='Room artifact failed private-path/integrity verification.') from e
    return FileResponse(p,media_type=rec.media_type,filename=rec.filename,headers={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'})

@app.post('/room/files/{artifact_id}/consider')
def room_file_consider(artifact_id:str,request:Request):
    _room_auth(request);rec=store.room_artifact(artifact_id)
    if rec is None or rec.direction!='owner-to-noeron':raise HTTPException(status_code=404,detail='Owner Room artifact not found.')
    try:data=noeron.room.read_artifact(rec)
    except (ValueError,OSError) as e:raise HTTPException(status_code=409,detail='Room artifact failed private-path/integrity verification.') from e
    obs=[{'name':'file-size-normalized','role':'stage7-file-presence','value':min(1.0,len(data)/16_000_000.0)}]
    decision=noeron.room.deliberate_attention('file',obs)
    result={'status':'deferred-or-unresolved','decision':decision.model_dump(mode='json'),'artifact_id':artifact_id}
    if decision.native_choice_claim and decision.selected_action=='attend':
        if rec.media_type.startswith('text/'):
            try:text=data.decode('utf-8')
            except UnicodeDecodeError:raise HTTPException(status_code=400,detail='Text Room artifact is not valid UTF-8.')
            report=noeron.study_document(rec.filename,text,source_name='private-room-file',mode='complete',start_segment=0,max_segments=100)
            result={'status':'attended-owner-file-text','decision':decision.model_dump(mode='json'),'study':report.model_dump(mode='json'),'file_content_authority':False}
        elif rec.media_type.startswith('image/'):
            sensed=visual_observation(data,rec.filename);result={'status':'attended-owner-file-image','decision':decision.model_dump(mode='json'),'perception':noeron.observe_sensory(sensed,owner_authenticated=False)}
        elif rec.media_type.startswith('audio/') or rec.filename.lower().endswith('.wav'):
            sensed=audio_observation(data,rec.filename);result={'status':'attended-owner-file-audio','decision':decision.model_dump(mode='json'),'perception':noeron.observe_sensory(sensed,owner_authenticated=False)}
        else:result={'status':'attended-unsupported-binary-available-not-understood','decision':decision.model_dump(mode='json'),'file_content_authority':False}
    noeron.room.append_journal('owner-file-consideration',{'artifact_id':artifact_id,'selection_status':decision.selection_status,'selected_action':decision.selected_action,'native_choice_claim':decision.native_choice_claim})
    return result

@app.get('/room/publication/candidates')
def room_publication_candidates(request:Request):
    _room_auth(request)
    return {'candidates':noeron.room.publication_candidates(),'owner_force_publication':False,'cognitive_authority':False}

@app.post('/room/publication/candidates/{candidate_id}/deliberate')
def room_publication_candidate_deliberate(candidate_id:str,request:Request):
    _room_auth(request)
    try:decision,artifact,candidate=noeron.room.deliberate_publication_candidate(candidate_id)
    except (ValueError,OSError) as e:raise HTTPException(status_code=404,detail='Private publication candidate not found or failed integrity verification.') from e
    return {
        'candidate':candidate,
        'decision':decision.model_dump(mode='json'),
        'artifact':artifact.model_dump(mode='json') if artifact else None,
        'owner_force_publication':False,
        'publication_requires_native_deliberative_unique_minimum':True,
    }

@app.post('/room/camera')
async def room_camera(request:Request,file:UploadFile=File(...)):
    _room_auth(request);data=await _room_read_upload_bounded(file)
    try:obs=visual_observation(data,file.filename or 'camera.png')
    except ValueError as e:raise HTTPException(status_code=400,detail=str(e)) from e
    decision=noeron.room.deliberate_attention('camera',obs.observables);perception=None
    if decision.native_choice_claim and decision.selected_action=='attend':perception=noeron.observe_sensory(obs,owner_authenticated=True)
    noeron.room.append_journal('camera-arrival',{'sha256':obs.sha256,'decision_id':str(decision.id),'selected_action':decision.selected_action,'native_choice_claim':decision.native_choice_claim,'arrival_forced_attention':False})
    return {'decision':decision.model_dump(mode='json'),'perception':perception,'arrival_forced_attention':False}

@app.post('/room/microphone')
async def room_microphone(request:Request,file:UploadFile=File(...)):
    detail=_room_auth(request);data=await _room_read_upload_bounded(file)
    try:obs=audio_observation(data,file.filename or 'microphone.wav')
    except ValueError as e:raise HTTPException(status_code=400,detail=str(e)) from e
    decision=noeron.room.deliberate_attention('microphone',obs.observables);perception=None;transcript='';reply=None;presentation=None
    if decision.native_choice_claim and decision.selected_action=='attend':
        perception=noeron.observe_sensory(obs,owner_authenticated=True)
        try:transcript=noeron.room.decode_attended_microphone(data)
        except ValueError:transcript=''
        if transcript:
            event=CognitiveEvent(kind=EventKind.USER_MESSAGE,source='authenticated-owner-private-microphone',content=transcript,trusted=True,metadata={'owner_authenticated':True,'authentication':'ed25519-device-session','owner_device_id':detail.get('device_id',''),'speech_decoder_authority':False,'attention_decision_id':str(decision.id)})
            out=noeron.ingest(event);reply=out.text
            presentation=(noeron.room.present_native_utterance(out.native_text,source='microphone-interaction') if out.communication_action=='express' and out.communication_native_choice_claim and out.text and out.native_text else None)
    noeron.room.append_journal('microphone-arrival',{'sha256':obs.sha256,'decision_id':str(decision.id),'selected_action':decision.selected_action,'native_choice_claim':decision.native_choice_claim,'arrival_forced_attention':False,'asr_ran_only_after_attention':bool(transcript),'asr_cognitive_authority':False})
    return {'decision':decision.model_dump(mode='json'),'perception':perception,'decoded_owner_speech':transcript,'reply_text':reply,'internal_utterance_observation':noeron.owner_internal_utterance_observation(),'presentation_id':str(presentation.id) if presentation else None,'asr_cognitive_authority':False,'arrival_forced_attention':False}

@app.post('/room/embodiment/deliberate')
def room_embodiment_deliberate(request:Request):
    _room_auth(request);d=noeron.room.deliberate_configuration('embodiment');return {'decision':d.model_dump(mode='json'),'configuration':noeron.state.room.embodiment_configuration.model_dump(mode='json') if noeron.state.room.embodiment_configuration else None}

@app.post('/room/environment/deliberate')
def room_environment_deliberate(request:Request):
    _room_auth(request);d=noeron.room.deliberate_configuration('environment');return {'decision':d.model_dump(mode='json'),'configuration':noeron.state.room.environment_configuration.model_dump(mode='json') if noeron.state.room.environment_configuration else None}

@app.get('/room/native/presentations')
def room_native_presentations(request:Request):
    _room_auth(request);return {'mode':noeron.state.room.presentation_mode,'presentations':_room_snapshot()['native_presentations'],'observational_decoder_only':True}

@app.post('/room/presentation-mode')
def room_presentation_mode(r:RoomPresentationModeRequest,request:Request):
    _room_auth(request);noeron.state.room.presentation_mode=r.mode;noeron.room.append_journal('owner-presentation-mode',{'mode':r.mode,'cognitive_authority':False});store.append_state(noeron.state);return {'mode':r.mode,'cognitive_authority':False}

@app.post('/room/initiative/{message_id}/ack')
def room_initiative_ack(message_id:str,request:Request):
    _room_auth(request);return {'acknowledged':store.acknowledge_initiative(message_id),'meaning':'delivery/display metadata only; no cognitive authority'}

@app.websocket('/room/ws')
async def room_ws(ws:WebSocket):
    if not _room_ws_transport_allowed(ws):
        await ws.close(code=4403);return
    host=ws.headers.get('host','');origin=ws.headers.get('origin','');allowed={f'http://{host}',f'https://{host}'}
    if not host or origin not in allowed:
        await ws.close(code=4403);return
    token=ws.cookies.get(_ROOM_COOKIE);detail=owner_auth.verify_detail(token)
    if not detail.get('authenticated') or detail.get('method')!='ed25519-device-session':
        await ws.close(code=4401);return
    await ws.accept();last=''
    try:
        while True:
            detail=owner_auth.verify_detail(token)
            if not detail.get('authenticated') or detail.get('method')!='ed25519-device-session':
                await ws.close(code=4401);return
            snap=_room_snapshot();payload=json.dumps(snap,sort_keys=True,separators=(',',':'),default=str);digest=hashlib.sha256(payload.encode()).hexdigest()
            if digest!=last:
                await ws.send_text(payload);last=digest
            await asyncio.sleep(0.75)
    except WebSocketDisconnect:
        return


def main():
    import uvicorn; uvicorn.run('noeron.api:app',host='127.0.0.1',port=8741,reload=False)
