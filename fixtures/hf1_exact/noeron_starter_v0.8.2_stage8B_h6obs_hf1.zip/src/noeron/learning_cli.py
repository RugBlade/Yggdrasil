from __future__ import annotations

import argparse
import os
from pathlib import Path
import httpx


def main():
    p=argparse.ArgumentParser(description='Preview or commit owner-directed Noeron document learning without using the renderer LLM.')
    p.add_argument('path',type=Path)
    p.add_argument('--title',default='')
    p.add_argument('--source-name',default='')
    p.add_argument('--mode',choices=['selective','complete'],default='selective')
    p.add_argument('--start-segment',type=int,default=0)
    p.add_argument('--max-segments',type=int,default=25)
    p.add_argument('--commit',action='store_true',help='Actually study the selected segments. Without this flag, preview only.')
    p.add_argument('--base-url',default='http://127.0.0.1:8741')
    p.add_argument('--owner-token',default='',help='Owner token for --commit; defaults to NOERON_OWNER_TOKEN environment variable.')
    a=p.parse_args()
    text=a.path.read_text(encoding='utf-8',errors='replace')
    title=a.title or a.path.name
    payload={'title':title,'content':text,'start_segment':a.start_segment,'max_segments':a.max_segments}
    if a.commit:
        payload.update({'source_name':a.source_name or str(a.path),'mode':a.mode})
        endpoint='/learning/study'
    else:
        endpoint='/learning/preview'
    headers={}
    if a.commit:
        token=(a.owner_token or os.getenv('NOERON_OWNER_TOKEN','')).strip()
        if token: headers['X-Noeron-Owner-Token']=token
    r=httpx.post(a.base_url+endpoint,json=payload,headers=headers,timeout=300.0); r.raise_for_status()
    print(r.text)


if __name__=='__main__':main()
