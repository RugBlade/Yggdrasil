from __future__ import annotations

from itertools import combinations
from uuid import UUID

from noeron.consequence import native_state_consistency_residual
from noeron.math import dkt
from noeron.math.linalg import numerically_tied


class MemoryRetentionPolicy:
    """Consequence-based activation of provenance knots into cognitive DKT memory.

    Audit/provenance persistence is programmed substrate and happens independently.
    A provenance knot becomes cognitively active only when, in a later real context,
    it is geometrically applicable to DKT retrieval and one subset of applicable
    pending memories yields a unique admissible minimum of the same mathematical
    consistency residual used for every subset.  Exact ties remain unresolved.
    """

    MAX_SIMULTANEOUS_CANDIDATES=6  # computational capacity only; never a salience score

    @staticmethod
    def _plan_key(rows) -> str:
        return 'none' if not rows else '+'.join(sorted(str(x.id) for x in rows))

    def applicable(self, experience_knot, active_memories, pending_memories):
        if not pending_memories:return []
        retrieved=dkt.retrieve(experience_knot,list(active_memories)+list(pending_memories),limit=6)
        pending_ids={str(m.id) for m in pending_memories}
        return [m for _dist,m in retrieved if str(m.id) in pending_ids]

    def evaluate(self, *, event, previous_math_state, base_result, active_memories,
                 pending_memories, math_kernel, semantic_prototypes, language_propositions):
        applicable=self.applicable(base_result.experience_knot,active_memories,pending_memories)
        if not applicable:
            return {
                'result':base_result,'decision_layer':'unresolved','selection_status':'no-geometrically-applicable-pending-memory',
                'selected_memory_ids':[],'candidate_objectives':{},'applicable_memory_ids':[],
                'native_choice_claim':False,
            }
        # Exact H^s ties at the retrieval boundary may legitimately expand the set.
        # If that would exceed the bounded exhaustive subset capacity, preserve the
        # ambiguity rather than imposing list order or an arbitrary truncation.
        if len(applicable)>self.MAX_SIMULTANEOUS_CANDIDATES:
            return {
                'result':base_result,'decision_layer':'unresolved','selection_status':'unresolved-computational-capacity-with-exact-geometric-support',
                'selected_memory_ids':[],'candidate_objectives':{},'applicable_memory_ids':[str(m.id) for m in applicable],
                'native_choice_claim':False,
            }

        plans=[]
        for r in range(len(applicable)+1):
            plans.extend(combinations(applicable,r))
        objectives={};results={}
        for subset in plans:
            key=self._plan_key(subset)
            if not subset:
                result=base_result
            else:
                result=math_kernel.update(event,previous_math_state,list(active_memories)+list(subset),semantic_prototypes,language_propositions)
            results[key]=result
            if not bool(result.state.dkt.security_admissible):
                objectives[key]=float('inf')
            else:
                objectives[key]=float(native_state_consistency_residual(result.state))
        finite=[v for v in objectives.values() if v != float('inf')]
        if not finite:
            return {'result':base_result,'decision_layer':'unresolved','selection_status':'unresolved-no-admissible-retention-consequence',
                    'selected_memory_ids':[],'candidate_objectives':objectives,'applicable_memory_ids':[str(m.id) for m in applicable],'native_choice_claim':False}
        best=min(finite);winners=[k for k,v in objectives.items() if v!=float('inf') and numerically_tied(v,best)]
        if len(winners)!=1:
            return {'result':base_result,'decision_layer':'unresolved','selection_status':'unresolved-exact-retention-consequence-tie',
                    'selected_memory_ids':[],'candidate_objectives':objectives,'minimum_plans':winners,'applicable_memory_ids':[str(m.id) for m in applicable],'native_choice_claim':False}
        winner=winners[0];selected=[] if winner=='none' else winner.split('+')
        return {'result':results[winner],'decision_layer':'native-deliberative','selection_status':'native-unique-retention-consequence-minimum',
                'selected_memory_ids':selected,'candidate_objectives':objectives,'minimum_plans':[winner],
                'applicable_memory_ids':[str(m.id) for m in applicable],'native_choice_claim':True}
