from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Any
from uuid import UUID, uuid4
from pydantic import BaseModel, Field

from noeron.cognition.models import GeometricCognitionState
from noeron.math.models import MathKernelState
from noeron.room_models import RoomDevelopmentState


class EventKind(str, Enum):
    USER_MESSAGE='user_message'; OBSERVATION='observation'; TOOL_RESULT='tool_result'; TIMER='timer'; INTERNAL_REFLECTION='internal_reflection'

class Stratum(str, Enum):
    ORDINARY='ordinary'; SOCIAL='social'; RESEARCH='research'; PROTECTIVE='protective'; REFLECTION='reflection'; EXECUTION='execution'; QUARANTINE='quarantine'

class CognitiveEvent(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    kind: EventKind
    source: str
    content: str
    trusted: bool=False
    metadata: dict[str,Any]=Field(default_factory=dict)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class SecurityDecision(BaseModel):
    allowed: bool
    reason: str
    target_stratum: Stratum
    violated_invariants: list[str]=Field(default_factory=list)
    quarantine_id: UUID|None=None

class NoeronState(BaseModel):
    active_strata: dict[Stratum,float]=Field(default_factory=lambda:{Stratum.ORDINARY:1.0})
    logical_entropy: float=0.0
    conversational_turn: int=0
    last_event_id: UUID|None=None
    autonomy_last_checked_at: datetime|None=None
    autonomy_last_spoke_at: datetime|None=None
    math_kernel: MathKernelState=Field(default_factory=MathKernelState)
    cognition: GeometricCognitionState=Field(default_factory=GeometricCognitionState)
    room: RoomDevelopmentState=Field(default_factory=RoomDevelopmentState)
    core_invariants: dict[str,str]=Field(default_factory=lambda:{
        'identity':'yggdrasil-noeron-v1','tool_authority':'explicit-gate','memory_geometry':'DKT-knot-authoritative','safety_boundary':'protected'
    })

class NoeronReply(BaseModel):
    text: str
    # native_text is owner-visible only when the authenticated observational
    # visibility control permits it.  The original native utterance remains in
    # serialized language audit state regardless of visibility.
    native_text: str = ''
    english_text: str = ''
    renderer_used: bool = False
    initiated: bool=False
    communication_action: str = ''
    communication_selection_status: str = ''
    communication_native_choice_claim: bool = False
    transport_origin: str = 'none'
    native_text_available_for_audit: bool = False
    english_egress_audit: dict[str,Any] = Field(default_factory=dict)
    state: NoeronState
    security: SecurityDecision

class InitiativeMessage(BaseModel):
    id: UUID=Field(default_factory=uuid4)
    created_at: datetime=Field(default_factory=lambda:datetime.now(timezone.utc))
    text: str
    event_id: UUID|None=None
    delivered: bool=False
