from __future__ import annotations

"""Stage-8 engineering source-perception substrate.

This module exposes *objective source facts* only.  It does not choose upgrades,
rank candidate patches, write live code, or grant deployment authority.  Its job is
analogous to a sensor: make Yggdrasil's own configured source tree observable with
exact provenance (path, line range, SHA-256, AST structure) while keeping filesystem
access bounded to an explicit allow-list.
"""

import ast
import hashlib
from pathlib import Path
from typing import Iterable


class EngineeringSourceError(ValueError):
    pass


_ALLOWED_TOP_LEVEL = {
    "src",
    "tests",
    "scripts",
    "deploy",
    "docs",
    "pyproject.toml",
    "README.md",
    "CHECKPOINT_POLICY.md",
    "BUILD_PROVENANCE.txt",
    "RELEASE_COMMIT.txt",
    "LOCAL_CERTIFICATION.txt",
}
_IGNORED_PARTS = {
    ".git",
    ".venv",
    "venv",
    "__pycache__",
    ".pytest_cache",
    ".ruff_cache",
    "data",
    "vendor",
}
_TEXT_SUFFIXES = {".py", ".toml", ".md", ".txt", ".service", ".example", ".json"}


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _call_name(node: ast.AST) -> str:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        left = _call_name(node.value)
        return f"{left}.{node.attr}" if left else node.attr
    if isinstance(node, ast.Call):
        return _call_name(node.func)
    return ""


def _decorator_text(node: ast.AST) -> str:
    name = _call_name(node)
    if isinstance(node, ast.Call):
        args = []
        for a in node.args[:3]:
            if isinstance(a, ast.Constant) and isinstance(a.value, (str, int, float, bool)):
                args.append(repr(a.value))
            else:
                args.append(ast.dump(a, include_attributes=False))
        return f"{name}({', '.join(args)})" if name else ast.dump(node, include_attributes=False)
    return name or ast.dump(node, include_attributes=False)


def _route_fact(qualname: str, decorator: ast.AST) -> dict[str, str] | None:
    if not isinstance(decorator, ast.Call):
        return None
    name = _call_name(decorator.func)
    if not name:
        return None
    method = name.rsplit(".", 1)[-1].upper()
    if method not in {"GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "HEAD", "WEBSOCKET"}:
        return None
    if not decorator.args or not isinstance(decorator.args[0], ast.Constant) or not isinstance(decorator.args[0].value, str):
        return None
    route = decorator.args[0].value
    return {
        "subject": f"symbol:{qualname}",
        "relation": "exposes-route",
        "object": f"{method} {route}",
        "source": "python-ast-route-decorator",
    }


class _SymbolVisitor(ast.NodeVisitor):
    def __init__(self) -> None:
        self.stack: list[str] = []
        self.symbols: list[dict] = []

    def _visit_symbol(self, node: ast.AST, name: str, kind: str) -> None:
        qualname = ".".join(self.stack + [name])
        decorators = [_decorator_text(x) for x in getattr(node, "decorator_list", [])]
        calls = sorted({
            _call_name(x.func)
            for x in ast.walk(node)
            if isinstance(x, ast.Call) and _call_name(x.func)
        })
        decorator_lines=[int(getattr(x,"lineno",0) or 0) for x in getattr(node,"decorator_list",[]) if int(getattr(x,"lineno",0) or 0)>0]
        node_line=int(getattr(node,"lineno",0) or 0)
        start_line=min([node_line]+decorator_lines) if node_line else (min(decorator_lines) if decorator_lines else 0)
        self.symbols.append({
            "name": name,
            "qualname": qualname,
            "kind": kind,
            "lineno": start_line,
            "end_lineno": int(getattr(node, "end_lineno", getattr(node, "lineno", 0)) or 0),
            "decorators": decorators,
            "calls": calls,
        })
        self.stack.append(name)
        self.generic_visit(node)
        self.stack.pop()

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        self._visit_symbol(node, node.name, "class")

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._visit_symbol(node, node.name, "function")

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._visit_symbol(node, node.name, "async-function")


class SourceWorkspace:
    """Read-only, allow-listed view of a configured Noeron source tree."""

    def __init__(self, root: str | Path | None, *, max_source_bytes: int = 300_000) -> None:
        self.root = Path(root).expanduser().resolve() if root else None
        self.max_source_bytes = int(max_source_bytes)

    @property
    def enabled(self) -> bool:
        return bool(self.root and self.root.is_dir())

    def status(self) -> dict:
        return {
            "stage": "8A",
            "mechanism_version": "0.8.0-stage8A-engineering-source-perception-v1",
            "enabled": self.enabled,
            "root": str(self.root) if self.root else "",
            "read_only": True,
            "write_authority": False,
            "deployment_authority": False,
            "allowed_top_level": sorted(_ALLOWED_TOP_LEVEL),
            "max_source_bytes": self.max_source_bytes,
            "note": "Objective source perception only. This substrate cannot choose or deploy an upgrade.",
        }

    def _require_enabled(self) -> Path:
        if not self.enabled:
            raise EngineeringSourceError("engineering source perception is disabled or source root does not exist")
        assert self.root is not None
        return self.root

    def _resolve(self, relative_path: str) -> Path:
        root = self._require_enabled()
        raw = str(relative_path or "").strip().replace("\\", "/")
        if not raw or raw.startswith("/"):
            raise EngineeringSourceError("path must be a non-empty source-root-relative path")
        parts = Path(raw).parts
        if not parts or parts[0] not in _ALLOWED_TOP_LEVEL:
            raise EngineeringSourceError("path is outside the engineering source allow-list")
        if any(p in _IGNORED_PARTS or p.startswith(".") for p in parts):
            raise EngineeringSourceError("path contains an ignored/private source component")
        candidate = (root / Path(*parts)).resolve()
        try:
            candidate.relative_to(root)
        except ValueError as e:
            raise EngineeringSourceError("path escapes configured engineering source root") from e
        if not candidate.is_file():
            raise EngineeringSourceError("source path does not identify a regular file")
        return candidate

    def _read(self, relative_path: str) -> tuple[Path, bytes, str]:
        p = self._resolve(relative_path)
        data = p.read_bytes()
        if len(data) > self.max_source_bytes:
            raise EngineeringSourceError(
                f"source file is {len(data)} bytes; exceeds configured {self.max_source_bytes}-byte observation limit"
            )
        try:
            text = data.decode("utf-8")
        except UnicodeDecodeError as e:
            raise EngineeringSourceError("source file is not UTF-8 text") from e
        return p, data, text

    def index(self, *, prefix: str = "", limit: int = 500) -> dict:
        root = self._require_enabled()
        limit = max(1, min(int(limit), 5000))
        pref = str(prefix or "").strip().replace("\\", "/")
        out: list[dict] = []
        for p in sorted(root.rglob("*")):
            if not p.is_file():
                continue
            rel = p.relative_to(root)
            parts = rel.parts
            if not parts or parts[0] not in _ALLOWED_TOP_LEVEL:
                continue
            if any(x in _IGNORED_PARTS or x.startswith(".") for x in parts):
                continue
            # The index itself is a sensor and therefore must enforce the same
            # root-confinement guarantee as exact file reads.  Never follow a
            # symlink (including a symlinked parent component) into data outside
            # the configured engineering source tree.
            if any((root / Path(*parts[:i])).is_symlink() for i in range(1, len(parts) + 1)):
                continue
            try:
                resolved = p.resolve(strict=True)
                resolved.relative_to(root)
            except (OSError, ValueError):
                continue
            rels = rel.as_posix()
            if pref and not rels.startswith(pref):
                continue
            if p.suffix.lower() not in _TEXT_SUFFIXES and p.name not in _ALLOWED_TOP_LEVEL:
                continue
            size = resolved.stat().st_size
            h = hashlib.sha256()
            with resolved.open("rb") as fh:
                for chunk in iter(lambda: fh.read(1024 * 1024), b""):
                    h.update(chunk)
            out.append({"path": rels, "size": size, "sha256": h.hexdigest()})
            if len(out) >= limit:
                break
        return {
            "status": "read-only-source-index",
            "root": str(root),
            "prefix": pref,
            "count": len(out),
            "limit": limit,
            "files": out,
            "write_authority": False,
            "deployment_authority": False,
        }

    def file(self, relative_path: str) -> dict:
        p, data, text = self._read(relative_path)
        rel = p.relative_to(self._require_enabled()).as_posix()
        result = {
            "status": "read-only-source-file",
            "path": rel,
            "size": len(data),
            "sha256": _sha256(data),
            "content": text,
            "write_authority": False,
            "deployment_authority": False,
        }
        if p.suffix == ".py":
            result["python"] = self._python_structure(rel, text)
        return result

    def _python_structure(self, relative_path: str, text: str) -> dict:
        try:
            tree = ast.parse(text, filename=relative_path, type_comments=True)
        except SyntaxError as e:
            raise EngineeringSourceError(
                f"Python AST parse failed at line {e.lineno}: {e.msg}"
            ) from e
        visitor = _SymbolVisitor()
        visitor.visit(tree)
        imports: list[str] = []
        for node in tree.body:
            if isinstance(node, ast.Import):
                imports.extend(alias.name for alias in node.names)
            elif isinstance(node, ast.ImportFrom):
                base = node.module or ""
                for alias in node.names:
                    imports.append(f"{base}.{alias.name}".strip("."))
        return {
            "module_docstring": ast.get_docstring(tree) or "",
            "imports": sorted(set(imports)),
            "symbols": visitor.symbols,
        }

    def symbol(self, relative_path: str, qualname: str) -> dict:
        file_record = self.file(relative_path)
        if "python" not in file_record:
            raise EngineeringSourceError("symbol inspection requires a Python source file")
        q = str(qualname or "").strip()
        rows = [x for x in file_record["python"]["symbols"] if x["qualname"] == q]
        if len(rows) != 1:
            raise EngineeringSourceError(f"symbol {q!r} was not uniquely found in {relative_path!r}")
        row = rows[0]
        lines = file_record["content"].splitlines()
        start = max(1, int(row["lineno"]))
        end = min(len(lines), int(row["end_lineno"]))
        source = "\n".join(lines[start - 1:end]) + ("\n" if end >= start else "")
        facts = self._facts_for_symbol(relative_path, file_record, row)
        return {
            "status": "read-only-source-symbol",
            "path": relative_path,
            "file_sha256": file_record["sha256"],
            "qualname": q,
            "kind": row["kind"],
            "lineno": start,
            "end_lineno": end,
            "source": source,
            "source_sha256": _sha256(source.encode("utf-8")),
            "decorators": list(row["decorators"]),
            "calls": list(row["calls"]),
            "facts": facts,
            "write_authority": False,
            "deployment_authority": False,
        }

    def _facts_for_symbol(self, relative_path: str, file_record: dict, row: dict) -> list[dict[str, str]]:
        q = row["qualname"]
        facts: list[dict[str, str]] = [
            {
                "subject": f"symbol:{q}",
                "relation": "defined-in",
                "object": f"source-file:{relative_path}",
                "source": "python-ast",
            },
            {
                "subject": f"symbol:{q}",
                "relation": "syntax-kind",
                "object": row["kind"],
                "source": "python-ast",
            },
            {
                "subject": f"source-file:{relative_path}",
                "relation": "sha256",
                "object": file_record["sha256"],
                "source": "source-bytes",
            },
        ]
        for called in row.get("calls", []):
            facts.append({
                "subject": f"symbol:{q}",
                "relation": "calls",
                "object": f"symbol-ref:{called}",
                "source": "python-ast",
            })
        # Re-parse only the selected file to recover concrete decorator objects.
        tree = ast.parse(file_record["content"], filename=relative_path, type_comments=True)
        stack: list[str] = []

        def walk(nodes: Iterable[ast.stmt]) -> None:
            for node in nodes:
                if isinstance(node, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
                    current = ".".join(stack + [node.name])
                    if current == q:
                        for dec in node.decorator_list:
                            route = _route_fact(q, dec)
                            if route:
                                facts.append(route)
                    stack.append(node.name)
                    walk(getattr(node, "body", []))
                    stack.pop()

        walk(tree.body)
        return facts

    def observation(self, relative_path: str, *, qualname: str = "") -> dict:
        if qualname:
            record = self.symbol(relative_path, qualname)
            exact_source = record["source"]
            facts = record["facts"]
            source_sha = record["source_sha256"]
            line_range = [record["lineno"], record["end_lineno"]]
            target = f"{relative_path}::{qualname}"
        else:
            record = self.file(relative_path)
            exact_source = record["content"]
            source_sha = record["sha256"]
            line_range = [1, len(exact_source.splitlines())]
            target = relative_path
            facts = [
                {
                    "subject": f"source-file:{relative_path}",
                    "relation": "sha256",
                    "object": record["sha256"],
                    "source": "source-bytes",
                }
            ]
            if "python" in record:
                for sym in record["python"]["symbols"]:
                    facts.append({
                        "subject": f"source-file:{relative_path}",
                        "relation": "contains-symbol",
                        "object": f"symbol:{sym['qualname']}",
                        "source": "python-ast",
                    })
        # Exact source is included because Stage 8 must eventually learn code, not
        # merely a human-authored description of it.  The surrounding labels are
        # provenance facts and carry no upgrade-choice authority.
        cognitive_text = (
            f"Noeron source observation target {target}. "
            f"Exact source SHA256 {source_sha}. Lines {line_range[0]} through {line_range[1]}.\n"
            "--- exact source begins ---\n"
            f"{exact_source}"
            "--- exact source ends ---\n"
        )
        return {
            "status": "objective-source-observation",
            "target": target,
            "path": relative_path,
            "qualname": qualname,
            "source_sha256": source_sha,
            "line_range": line_range,
            "engineering_facts": facts,
            "cognitive_text": cognitive_text,
            "write_authority": False,
            "deployment_authority": False,
            "native_upgrade_choice_claim": False,
            "note": "Observation supplies exact source bytes plus parser facts. It does not tell Yggdrasil what to change.",
        }
