from __future__ import annotations

import math

from noeron.math import dkt
from noeron.math.models import KnotState


def native_state_consistency_residual(math_state) -> float:
    """Common coordinate-neutral residual for consequence admission/comparison.

    The components are existing mathematical consistency diagnostics, not semantic
    values or action-specific utilities.  IRG/DKT/EGR/RL/Frenet all influence the
    resulting state before this residual is measured.  DKT security admissibility is
    handled separately as a hard invariant rather than converted into a weight.
    """
    vals=[
        abs(float(math_state.egr.bridge_residual)),
        abs(float(math_state.egr.balance_residual)),
        abs(float(math_state.rl.geodesic_acceleration_norm)),
    ]
    return math.sqrt(sum(v*v for v in vals)/len(vals)) if vals else 0.0


def nonworsening(pre: float, post: float) -> bool:
    scale=max(1.0,abs(float(pre)),abs(float(post)))
    return float(post) <= float(pre) + math.ulp(scale)


def equal_affordance_post_manifold(action_post_knots: dict[str,KnotState], action_observations: dict[str,int], affordances: tuple[str,...]) -> tuple[KnotState|None,list[str]]:
    """Frequency-neutral common consequence reference.

    Each learned affordance contributes its current empirical post-state model exactly
    once.  Repeated observations refine that action's model but cannot give the action
    extra mass merely because a programmed fallback/calibration exposed it more often.
    The Fourier-coordinate barycenter is order independent.  If the equal-action mean
    is not numerically admissible, no common reference is asserted and choice remains
    unresolved.
    """
    actions=[a for a in affordances if int(action_observations.get(a,0))>0 and action_post_knots.get(a) is not None]
    if not actions:return None,[]
    knots=[action_post_knots[a] for a in actions]
    orders=[float(k.sobolev_order) for k in knots]
    if max(orders)-min(orders) > math.ulp(max(1.0,max(abs(x) for x in orders))):
        return None,actions
    modes=max(int(k.mode_radius) for k in knots); n=float(len(knots))
    out=dkt.reference_knot(s=orders[0],modes=modes)
    out.c0=[sum(float(k.c0[i]) for k in knots)/n for i in range(3)]
    pads=[dkt._pad(k,modes) for k in knots]
    out.cosine=[[sum(float(pc[j][axis]) for pc,_ in pads)/n for axis in range(3)] for j in range(modes+1)]
    out.sine=[[sum(float(ps[j][axis]) for _,ps in pads)/n for axis in range(3)] for j in range(modes+1)]
    est=dkt.estimate_whitney_stratum(out);out.stratum_index=est.estimated_index;out.invariant_signature=dkt.invariant_signature(out)
    if dkt.regularity_margin(out) <= dkt.numerical_regularity_floor(out):
        return None,actions
    return out,actions
