from __future__ import annotations

import hashlib
import math
from noeron.cognition.models import (
    KnotMemory, MathematicalProvenance, NativeProposition,
    NativeThought, NativeThoughtKind,
)
from noeron.cognition.self_model import NoeronSelfModel
from noeron.inference import render_logical_proposition
from noeron.math.kernel import CausalMathResult
from noeron.math.linalg import clamp
from noeron.models import CognitiveEvent, NoeronState


class GeometricCognitionKernel:
    """v0.7.5 compositional proposition formation after native mathematical cognition.

    Programmed here: proposition/grammar interfaces and factual runtime inspection.
    Not programmed here: domain conclusions or a menu of answers keyed by reasoning
    mode.  When the native inference workspace derives a proposition, its subject,
    relation and object are constructed from the proof object itself.
    """
    def __init__(self, species_name='Noeron', individual_name='Yggdrasil'):
        self.self_model = NoeronSelfModel(species_name, individual_name)

    @staticmethod
    def _sig(text: str) -> str:
        return hashlib.sha256(text.encode()).hexdigest()[:24]

    @staticmethod
    def _support_metrics(result: CausalMathResult) -> tuple[float, float, float]:
        """Geometry-derived audit scores without hand-weighted semantic features."""
        m = result.state
        distances = [d for d, _ in result.retrieved]
        d0 = distances[0] if distances else m.dkt.geodesic_displacement
        novelty = clamp(d0 / (1.0 + d0), 0.0, 1.0)
        # Event salience is the RMS magnitude of normalized independent causal
        # observables, not a hand-weighted utility or preference function.
        vals = [
            m.dkt.geodesic_displacement / (1.0 + m.dkt.geodesic_displacement),
            m.egr.entropy_production / (1.0 + m.egr.entropy_production),
            m.irg.response_potential / (1.0 + m.irg.response_potential),
            m.frenet.first_curvature / (1.0 + m.frenet.first_curvature),
        ]
        importance = math.sqrt(sum(x * x for x in vals) / len(vals))
        if m.reasoning.native_inference_active:
            confidence = m.reasoning.confidence
        else:
            residuals = [abs(m.egr.bridge_residual), abs(m.egr.balance_residual), m.rl.geodesic_acceleration_norm]
            confidence = 1.0 / (1.0 + math.sqrt(sum(x * x for x in residuals) / len(residuals)))
        return clamp(importance, 0.0, 1.0), novelty, clamp(confidence, 0.0, 1.0)

    @staticmethod
    def _realize(props: list[NativeProposition]) -> str:
        parts = []
        for p in props:
            grounds = (' Grounds: ' + '; '.join(p.grounds) + '.') if p.grounds else ''
            parts.append(f"{p.subject} {p.relation} {p.object}.{grounds}")
        return ' '.join(parts).strip()

    @staticmethod
    def _provenance(event: CognitiveEvent, result: CausalMathResult, consolidated_memory_id=None) -> MathematicalProvenance:
        m = result.state
        return MathematicalProvenance(
            source_event_id=event.id, source_knot_signature=result.experience_knot.invariant_signature,
            retrieved_memory_ids=[mem.id for _, mem in result.retrieved], dkt_distances=[d for d, _ in result.retrieved],
            rl_coordinates=list(m.rl.coordinates), rl_curvature_entropy=m.rl.curvature_entropy_normalized,
            egr_entropy_state=m.egr.entropy_state, egr_entropy_coordinate=m.egr.mapped_entropy, egr_sigma=m.egr.entropy_production,
            frenet_curvature=m.frenet.first_curvature, consolidation_score=result.consolidation.score,
            consolidated_memory_id=consolidated_memory_id,
        )

    @staticmethod
    def _proof_grounds(result: CausalMathResult, canonical: str) -> list[str]:
        r = result.state.reasoning
        grounds = []
        for step in r.inference_steps:
            if step.conclusion == canonical:
                grounds.append(f'rule={step.rule}')
                grounds.extend(f'premise={x}' for x in step.premises)
        if not grounds:
            grounds.append('direct proposition in current/DKT-gated persistent premise set')
        grounds.append(f'answer-selection={r.answer_selection_status}')
        return grounds

    def response(self, event: CognitiveEvent, state: NoeronState, result: CausalMathResult, consolidated_memory_id=None) -> NativeThought:
        """Realize only propositions actually supplied by the native proof field.

        No dialogue-act/query-class branch chooses a topic or diagnostic self-report.
        If the native workspace cannot derive an answer, the native content is empty;
        Terra is not allowed to manufacture an answer around that absence.
        """
        m=result.state
        evidence=[mem.id for _,mem in result.retrieved]
        distances=[d for d,_ in result.retrieved]
        importance,novelty,confidence=self._support_metrics(result)
        props=[]
        for a in m.reasoning.answer_candidates:
            subj,rel,obj=render_logical_proposition(a)
            props.append(NativeProposition(
                subject=subj,relation=rel,object=obj,
                grounds=self._proof_grounds(result,a.canonical()),
                epistemic_status=('native-derived-proof' if a.derived else 'proof-supported-premise'),
                confidence=a.confidence,
            ))
        statement=self._realize(props) if props else ''
        thought=NativeThought(
            kind=NativeThoughtKind.RESPONSE,statement=statement,propositions=props,
            evidence_memory_ids=evidence,dkt_distances=distances,importance=importance,
            novelty=novelty,confidence=confidence,should_surface=bool(statement),
            origin='noeron-native-compositional-proof-field-v0.7.5',causal_trace=m.causal_trace,
            mathematical_provenance=self._provenance(event,result,consolidated_memory_id),
        )
        if statement:
            state.cognition.last_thought=thought
        return thought

    def autonomous(self, state: NoeronState, memories: list[KnotMemory], event: CognitiveEvent, result: CausalMathResult, consolidated_memory_id=None) -> NativeThought:
        """Expose the endogenous native candidate field without choosing a topic.

        Candidate assertions are live proof consequences. Candidate questions are
        unresolved proposition paths selected only by post-RL/Frenet DKT support
        geometry.  No timer/event-class menu manufactures a topic.
        """
        m=result.state
        importance,novelty,confidence=self._support_metrics(result)
        props=[]
        for a in m.reasoning.derived_propositions:
            subj,rel,obj=render_logical_proposition(a)
            props.append(NativeProposition(
                subject=subj,relation=rel,object=obj,
                grounds=self._proof_grounds(result,a.canonical()),
                epistemic_status='native-derived-proof',confidence=a.confidence,
            ))
        questions=[
            f'What relation holds between {q.subject} and {q.object}?'
            for q in m.reasoning.native_question_candidates
            if q.kind=='relation-between' and q.subject and q.object
        ]
        statement=self._realize(props) if props else (' '.join(questions).strip())
        thought=NativeThought(
            kind=NativeThoughtKind.REFLECTION,statement=statement,propositions=props,
            question_candidates=questions,
            evidence_memory_ids=[mem.id for _,mem in result.retrieved],
            dkt_distances=[d for d,_ in result.retrieved],
            importance=importance,novelty=novelty,confidence=confidence,
            should_surface=False,
            origin='noeron-native-compositional-endogenous-field-v0.7.5',
            causal_trace=m.causal_trace,
            mathematical_provenance=self._provenance(event,result,consolidated_memory_id),
        )
        if statement or props or questions:
            state.cognition.last_thought=thought
        return thought
