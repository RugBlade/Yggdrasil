from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from uuid import UUID, uuid4
from pydantic import BaseModel, Field

from noeron.math.models import KnotState




class NativeLexeme(BaseModel):
    surface: str
    concept_term: str = ''
    observations: int = 0
    confidence: float = 0.0
    status: str = 'surface-ungrounded'
    grammatical_roles: list[str] = Field(default_factory=list)
    source: str = ''


class NativeUtterance(BaseModel):
    native_text: str = ''
    utterance_plan: list[str] = Field(default_factory=list)
    grammar_frames: list[str] = Field(default_factory=list)
    concept_terms: list[str] = Field(default_factory=list)
    lexical_coverage: float = 0.0
    fluency_score: float = 0.0
    renderer_needed: bool = False  # legacy compatibility; never authorizes Terra in v0.7.4+ / Stage 6
    lexical_coverage_complete: bool = False
    renderer_role: str = 'available external realization tool only; invocation requires native consequence selection or explicit operator calibration'



class DialogueReferent(BaseModel):
    surface: str = ''
    role: str = ''
    kind: str = 'unknown'
    turn: int = 0


class DialogueTurnRecord(BaseModel):
    turn: int = 0
    speaker: str = ''
    text_sha256: str = ''
    surface_excerpt: str = ''
    question_families: list[str] = Field(default_factory=list)
    topic_candidate: str = ''
    ambiguity_count: int = 0
    lexical_gap_count: int = 0


class Stage8BDialogueState(BaseModel):
    version: str = '0.8.2'
    mechanism_version: str = '0.8.2-stage8B-dialogue-v1'
    started_prospectively: bool = False
    migration_turn: int = 0
    turn: int = 0
    current_topic: str = ''
    question_under_discussion: str = ''
    recent_referents: list[DialogueReferent] = Field(default_factory=list)
    recent_turns: list[DialogueTurnRecord] = Field(default_factory=list)
    last_structure: dict[str,object] = Field(default_factory=dict)
    last_ambiguities: list[dict[str,object]] = Field(default_factory=list)
    last_lexical_gaps: list[dict[str,object]] = Field(default_factory=list)
    last_reference_status: str = 'no-reference-analysis-yet'
    max_turns: int = 24
    max_referents: int = 48
    cognitive_memory_authority: bool = False
    proposition_truth_authority: bool = False
    relationship_authority: bool = False
    note: str = 'Bounded Stage-8B conversational working context only; distinct from cognitive DKT memory and from legacy Stage-6 discourse state.'


class OwnerCommunicationControlChange(BaseModel):
    sequence: int = 0
    changed_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    control: str = ''
    value: bool = False
    origin: str = 'authenticated-owner-command'
    cognitive_authority: bool = False
    relational_authority: bool = False
    native_choice_claim: bool = False


class OwnerCommunicationControls(BaseModel):
    version: str = '0.8.2-stage8B-owner-communication-controls-v1'
    internal_utterance_visibility: bool = False
    internal_utterance_translation: bool = False
    response_channel_override: bool = False
    owner_command_channel: bool = False
    revision: int = 0
    audit: list[OwnerCommunicationControlChange] = Field(default_factory=list)
    default_off: bool = True
    authentication_required: bool = True
    relationship_authority: bool = False
    cognitive_authority: bool = False
    semantic_authority: bool = False
    memory_authority: bool = False
    native_choice_authority: bool = False
    source_write_authority: bool = False
    deployment_authority: bool = False
    note: str = 'Owner communication controls affect private observation/translation/transport/task authority only. Internal-utterance observation is independent of outward communication choice. Controls never manufacture native content or become Yggdrasil preference/relationship/choice.'


class LanguageProposition(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    subject_surface: str
    subject_concept: str = ''
    relation: str
    object_surface: str
    object_concept: str = ''
    polarity: bool = True
    universal: bool = False
    modality: str = ''
    modifiers: list[str] = Field(default_factory=list)
    confidence: float = 0.5
    source: str = ''
    # ``source_memory_id`` remains for backward-compatible serialization. Stage 6
    # preserves every distinct provenance source in ``source_memory_ids`` so a new
    # pending observation cannot shadow an older DKT-active source.
    source_memory_id: UUID | None = None
    source_memory_ids: list[UUID] = Field(default_factory=list)
    # Per-source parser support is kept separate so pending repeated observations
    # cannot change the confidence of an older DKT-authorized provenance source.
    source_confidences: dict[str,float] = Field(default_factory=dict)
    subject_knot_signature: str = ''
    object_knot_signature: str = ''
    observations: int = 1


class LanguageInterpretation(BaseModel):
    input_text: str = ''
    frame: str = 'unparsed'
    target_surface: str = ''
    target_concept: str = ''
    grounded_terms: dict[str,str] = Field(default_factory=dict)
    matched_proposition_ids: list[UUID] = Field(default_factory=list)
    source_memory_ids: list[UUID] = Field(default_factory=list)
    confidence: float = 0.0
    answer_supported: bool = False
    native_proposition: NativeProposition | None = None
    composition_audit: dict[str,object] = Field(default_factory=dict)
    note: str = 'Deterministic language grounding/composition is a NOERON_EXTENSION over DKT semantic authority.'


class LanguageFacultyState(BaseModel):
    version: str = '0.7.3'
    schema_version: str = '0.6.9'
    mechanism_version: str = '0.7.3'
    language_name: str = 'English'
    native_expression_enabled: bool = True
    lexicon: dict[str,NativeLexeme] = Field(default_factory=dict)
    grammar_frames: dict[str,int] = Field(default_factory=lambda:{'declarative':1,'subject-relation-object':1})
    lessons_observed: int = 0
    sentences_observed: int = 0
    propositions: list[LanguageProposition] = Field(default_factory=list)
    referents: dict[str,str] = Field(default_factory=dict)
    last_interpretation: LanguageInterpretation | None = None
    last_native_utterance: NativeUtterance | None = None
    last_interaction_native_utterance: NativeUtterance | None = None
    last_autonomous_native_utterance: NativeUtterance | None = None
    # Stage-6 discourse state is a grammatical working-context only. It may bind a
    # pronoun to a recently mentioned referent, but it does not store proposition
    # truth or bypass DKT-gated persistent premise retrieval.
    discourse_turn: int = 0
    discourse_last_subject: str = ''
    discourse_last_direct_object: str = ''
    discourse_last_oblique_object: str = ''
    discourse_recent_mentions: list[str] = Field(default_factory=list)
    discourse_last_resolution_status: str = 'no-discourse-resolution-yet'
    v075_stage6_started: bool = False
    legacy_pre_v075_proposition_count: int = 0
    # Stage 8B is prospective: these fields begin recording richer grammatical
    # structure only after migration; historical dialogue is not replayed.
    composition_version: str = ''
    composition_frame_counts: dict[str,int] = Field(default_factory=dict)
    last_composition_audit: dict[str,object] = Field(default_factory=dict)
    legacy_pre_v081_grammar_frames: dict[str,int] = Field(default_factory=dict)
    v081_stage8b_started: bool = False
    # Revised Stage 8B begins prospectively from the frozen v0.8.1 state.  This
    # bounded dialogue state is serialized for restart continuity but has zero
    # cognitive-memory/proposition-truth authority.
    v082_stage8b_started: bool = False
    conversation_version: str = ''
    dialogue_version: str = ''
    productive_english_version: str = ''
    english_egress_version: str = ''
    dialogue: Stage8BDialogueState = Field(default_factory=Stage8BDialogueState)
    owner_communication_controls: OwnerCommunicationControls = Field(default_factory=OwnerCommunicationControls)
    # Private owner-observation cache. This is presentation/audit persistence only,
    # not cognitive memory and not a source of proposition truth or speech choice.
    last_internal_english_translation: str = ''
    last_internal_utterance_sha256: str = ''
    last_internal_utterance_source: str = ''
    last_english_egress_audit: dict[str,object] = Field(default_factory=dict)
    last_communication_audit: dict[str,object] = Field(default_factory=dict)
    note: str = 'Developmental deterministic language faculty with DKT-grounded lexemes and compositional proposition memory; grammar/dialogue/English egress are NOERON_EXTENSIONs and Terra remains optional/downstream.'


class AffectiveDevelopmentState(BaseModel):
    version: str = '0.7.3'
    schema_version: str = '0.6.9'
    mechanism_version: str = '0.7.3'
    pattern_counts: dict[str,int] = Field(default_factory=dict)
    last_pattern_signature: str = ''
    recurrent_pattern_count: int = 0
    legacy_pre_gate_pattern_counts: dict[str,int] = Field(default_factory=dict)
    episode_gate_started_at: datetime | None = None
    counted_observations: int = 0
    suppressed_correlated_observations: int = 0
    last_counted_at: datetime | None = None
    last_counted_event_id: UUID | None = None
    last_counted_was_endogenous: bool = False
    episode_gate_seconds: float = 900.0
    note: str = 'Tracks recurring unnamed internal activation episodes with a decorrelation gate; does not assert subjective emotion.'




class InitiativeDevelopmentState(BaseModel):
    """Observed communication-transition geometry and consequence comparison state.

    ``express`` and ``continue-private`` are programmed affordances only. Their
    desirability is not supplied by an owner label or a default hold/speak rule.
    Action models are learned from observed pre->post DKT transitions, and candidate
    consequences are compared with one common trusted/admissible post-state manifold.
    Missing or tied evidence remains unresolved (``last_selected_action == ''``).
    """
    version: str = '0.7.4'
    mechanism_version: str = '0.7.4'
    action_pre_knots: dict[str,KnotState] = Field(default_factory=dict)
    action_post_knots: dict[str,KnotState] = Field(default_factory=dict)
    action_observations: dict[str,int] = Field(default_factory=dict)
    admissible_post_knot: KnotState | None = None
    admissible_post_observations: int = 0
    pending_expression_pre_knot: KnotState | None = None
    pending_expression_pre_residual: float | None = None
    pending_expression_event_id: UUID | None = None
    last_predicted_post_knots: dict[str,KnotState] = Field(default_factory=dict)
    last_native_choice_claim: bool = False
    last_decision_layer: str = 'unresolved-insufficient-consequence-geometry'
    transition_observations: int = 0
    # Legacy v0.7.3.4 candidate-A context/owner-feedback fields are retained only
    # for migration provenance and have zero choice authority.
    surface_context_knot: KnotState | None = None
    hold_context_knot: KnotState | None = None
    surface_observations: int = 0
    hold_observations: int = 0
    last_context_knot: KnotState | None = None
    last_context_signature: str = ''
    last_candidate_distances: dict[str,float] = Field(default_factory=dict)
    last_selected_action: str = ''
    last_selection_status: str = 'unresolved-insufficient-consequence-geometry'
    feedback_observations: int = 0
    note: str = 'Communication choice is consequence-based over learned DKT transitions. Owner surface/hold feedback is provenance-only; there is no programmed hold/speak preference. The common consequence reference gives each learned affordance model equal mass so non-choice fallback frequency cannot become hidden preference authority.'

class RealizationDevelopmentState(BaseModel):
    version: str = '0.7.4'
    mechanism_version: str = '0.7.4'
    action_pre_knots: dict[str,KnotState] = Field(default_factory=dict)
    action_post_knots: dict[str,KnotState] = Field(default_factory=dict)
    action_observations: dict[str,int] = Field(default_factory=dict)
    admissible_post_knot: KnotState | None = None
    admissible_post_observations: int = 0
    pending_action: str = ''
    pending_pre_knot: KnotState | None = None
    pending_pre_residual: float | None = None
    pending_event_id: UUID | None = None
    pending_decision_layer: str = ''
    transition_observations: int = 0
    operator_calibration_observations: int = 0
    last_context_knot: KnotState | None = None
    last_context_signature: str = ''
    last_predicted_post_knots: dict[str,KnotState] = Field(default_factory=dict)
    last_candidate_distances: dict[str,float] = Field(default_factory=dict)
    last_selected_action: str = ''
    last_effective_action: str = ''
    last_selection_status: str = 'unresolved-insufficient-realization-consequence-geometry'
    last_decision_layer: str = 'unresolved'
    last_native_choice_claim: bool = False
    last_renderer_invoked: bool = False
    last_renderer_output_accepted: bool = False
    note: str = 'Terra/native realization paths are affordances only. Automatic lexical-coverage invocation has zero authority. Missing/tied learned consequence geometry remains unresolved and executes no realization affordance. The common consequence reference gives each learned affordance model equal mass so calibration frequency cannot become hidden preference authority.'


class MemoryRetentionDecisionRecord(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    context_event_id: UUID | None = None
    applicable_memory_ids: list[UUID] = Field(default_factory=list)
    candidate_objectives: dict[str,float] = Field(default_factory=dict)
    minimum_plans: list[str] = Field(default_factory=list)
    selected_memory_ids: list[UUID] = Field(default_factory=list)
    selection_status: str = 'unresolved'
    decision_layer: str = 'unresolved'
    native_choice_claim: bool = False
    note: str = 'Audit/provenance persistence is programmed substrate; only cognitive activation is subject to native consequence selection.'


class MemoryRetentionDevelopmentState(BaseModel):
    version: str = '0.7.4'
    mechanism_version: str = '0.7.4'
    legacy_pre_v074_active_memory_ids: list[UUID] = Field(default_factory=list)
    legacy_pre_v074_active_memory_count: int = 0
    pending_provenance_memory_ids: list[UUID] = Field(default_factory=list)
    native_retained_memory_ids: list[UUID] = Field(default_factory=list)
    evaluation_observations: int = 0
    native_retention_observations: int = 0
    last_selection_status: str = 'unresolved-no-pending-provenance'
    last_decision_layer: str = 'unresolved'
    last_native_choice_claim: bool = False
    last_candidate_objectives: dict[str,float] = Field(default_factory=dict)
    last_applicable_memory_ids: list[UUID] = Field(default_factory=list)
    last_selected_memory_ids: list[UUID] = Field(default_factory=list)
    decision_history: list[MemoryRetentionDecisionRecord] = Field(default_factory=list)
    note: str = 'Every admitted event may persist as noncognitive provenance. Cognitive DKT activation is selected only by later consequence comparison; ties/insufficient evidence remain unresolved.'


class OwnerRelationState(BaseModel):
    """Referent-conditioned DKT experience geometry, not a programmed relationship score."""
    version: str = '0.7.4'
    schema_version: str = '0.7.4'
    mechanism_version: str = '0.7.4'
    owner_referent: str = ''
    authenticated_interactions: int = 0  # provenance only
    unauthenticated_interactions: int = 0  # provenance only
    familiarity: float = 0.0  # legacy compatibility; permanently noncausal
    legacy_programmed_familiarity_value: float = 0.0
    last_authenticated_at: datetime | None = None
    relation_experience_knot: KnotState | None = None
    relation_post_state_knot: KnotState | None = None
    relation_observations: int = 0
    cognitive_relation_memory_ids: list[UUID] = Field(default_factory=list)
    cognitive_relation_observations: int = 0
    device_interaction_counts: dict[str,int] = Field(default_factory=dict)  # authentication provenance only
    last_experience_distance_hs: float | None = None
    last_post_state_distance_hs: float | None = None
    relation_geometry_version: str = 'referent-conditioned-DKT-experience-manifold-v0.7.4'
    causal_context_injections: int = 0
    last_causal_context_memory_id: UUID | None = None
    note: str = 'Authentication identifies the recurring owner referent only. relation_experience_knot/relation_post_state_knot are empirical adaptation geometry from admitted authenticated interactions; cognitive_relation_memory_ids separately record owner episodes activated by native retention. This adaptation state is not episodic-memory retention and no familiarity/closeness/emotion formula has causal authority.'




class SensoryConceptCluster(BaseModel):
    """Learned non-verbal perceptual cluster anchored to DKT experience geometry.

    The centroid lives only in the deterministic sensor feature chart used to
    decide whether two observations should recruit the same perceptual concept.
    Semantic authority remains the associated DKT experience/prototype knot.
    """
    id: UUID = Field(default_factory=uuid4)
    channel: str
    centroid: list[float] = Field(default_factory=list)
    observations: int = 1
    mean_feature_distance: float = 0.0
    confidence: float = 0.0
    status: str = 'observed-once'
    radius_feature_distance: float = 0.0
    feature_samples: list[list[float]] = Field(default_factory=list)
    auto_terms: list[str] = Field(default_factory=list)
    grounded_concept: str = ''
    representative_dkt_signature: str = ''
    source_hashes: list[str] = Field(default_factory=list)
    last_provenance: str = ''
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    note: str = 'Perceptual cluster is learned from deterministic sensory geometry; DKT memory/prototype remains semantic authority.'



class WebStudyRecord(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    requested_url: str = ''
    final_url: str = ''
    source_domain: str = ''
    title: str = ''
    page_sha256: str = ''
    segments_considered: int = 0
    segments_selected: int = 0  # compatibility: attended segments
    segments_attended: int = 0
    durable_learning_candidates: int = 0
    segments_consolidated: int = 0
    instruction_like_segments: int = 0
    boilerplate_segments: int = 0
    possible_contradictions: int = 0
    selected_segment_hashes: list[str] = Field(default_factory=list)
    durable_candidate_hashes: list[str] = Field(default_factory=list)
    consolidated_memory_ids: list[UUID] = Field(default_factory=list)  # legacy compatibility; v0.7.4 stores pending provenance IDs here only for historical schema compatibility
    provenance_memory_ids: list[UUID] = Field(default_factory=list)
    note: str = 'Owner-authorized public GET; page content remains untrusted. Admitted segments persist as noncognitive provenance first; cognitive retention is a separate native consequence decision.'

class PerceptionDevelopmentState(BaseModel):
    version: str = '0.7.3'
    schema_version: str = '0.7.3'
    mechanism_version: str = '0.7.3'
    visual_observations: int = 0
    audio_observations: int = 0
    web_observations: int = 0
    semantic_visual_observations: int = 0
    semantic_audio_observations: int = 0
    web_pages_studied: int = 0
    web_segments_considered: int = 0
    web_segments_selected: int = 0  # compatibility alias for attended
    web_segments_attended: int = 0
    web_durable_learning_candidates: int = 0
    web_segments_consolidated: int = 0
    web_instruction_like_segments: int = 0
    web_boilerplate_segments: int = 0
    web_possible_contradictions: int = 0
    web_study_records: list[WebStudyRecord] = Field(default_factory=list)
    sensory_concepts: list[SensoryConceptCluster] = Field(default_factory=list)
    last_channel: str = ''
    last_provenance: str = ''
    last_semantic_terms: list[str] = Field(default_factory=list)
    last_cluster_id: UUID | None = None
    last_cluster_distance: float | None = None
    note: str = 'Developmental multimodal IRG learning: deterministic vision/audio structure forms recurrent perceptual clusters that are bound to DKT experience geometry and may later acquire language grounding.'


class DefensiveActionRecord(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    action_type: str = ''
    target: str = ''
    scope: str = 'noeron-runtime'
    status: str = 'executed'
    reversible: bool = True
    reason: str = ''
    source_fingerprint: str = ''
    rollback_hint: str = ''
    decision_layer: str = 'reflexive'  # reflexive / deliberative / explicitly programmed realization or tie fallback
    native_choice_score: float = 0.0
    native_choice_objective: float = 0.0
    note: str = 'Local defensive action only; no external intrusion or retaliation.'


class DefensiveDeliberationRecord(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    source_event_id: UUID | None = None
    source_fingerprint: str = ''
    family_id: str = ''
    recurrence_count: int = 1
    reflexive_invariants: list[str] = Field(default_factory=list)
    irg_response_potential: float = 0.0
    irg_entropy_source: float = 0.0
    irg_topology_response: float = 0.0
    dkt_ingress_signature: str = ''
    dkt_geodesic_displacement: float = 0.0
    egr_entropy_production: float = 0.0
    egr_active_regions: list[str] = Field(default_factory=list)
    rl_coordinates: list[float] = Field(default_factory=list)
    rl_scalar_curvature: float = 0.0
    frenet_curvature: float = 0.0
    candidate_action_scores: dict[str,float] = Field(default_factory=dict)  # legacy weighted-policy audit only
    candidate_plan_objectives: dict[str,float] = Field(default_factory=dict)
    candidate_consequence_distances: dict[str,float] = Field(default_factory=dict)
    selected_adaptive_actions: list[str] = Field(default_factory=list)
    selected_plan_objective: float = 0.0
    selected_consequence_distance: float = 0.0
    minimum_candidate_plans: list[str] = Field(default_factory=list)
    native_selection_status: str = ''
    actuator_realization_layer: str = ''
    preference_learning_actions: list[str] = Field(default_factory=list)
    need_coordinates: dict[str,float] = Field(default_factory=dict)  # legacy v0.7.3.2 audit only
    selected_plan_profile: dict[str,float] = Field(default_factory=dict)  # legacy v0.7.3.2 audit only
    pre_action_state: dict[str,float] = Field(default_factory=dict)
    trusted_reference_state: dict[str,float] = Field(default_factory=dict)
    candidate_post_action_states: dict[str,dict[str,float]] = Field(default_factory=dict)
    selected_post_action_state: dict[str,float] = Field(default_factory=dict)
    candidate_preference_mismatch: dict[str,float] = Field(default_factory=dict)
    preference_state_before: dict[str,float] = Field(default_factory=dict)  # legacy v0.7.3.1 floats
    preference_state_after: dict[str,float] = Field(default_factory=dict)
    preference_geometry_before: dict[str,str] = Field(default_factory=dict)
    preference_geometry_after: dict[str,str] = Field(default_factory=dict)
    outcome_observed: bool = False
    observed_next_state: dict[str,float] = Field(default_factory=dict)
    prediction_error: float | None = None
    observed_trusted_distance_before: float | None = None
    observed_trusted_distance_after: float | None = None
    observed_improvement: float | None = None
    outcome_preference_update_actions: list[str] = Field(default_factory=list)
    outcome_learning_status: str = 'pending-future-observation'
    policy_mode: str = 'legacy-weighted-policy-v0.7.3.1'
    explanation_facts: list[str] = Field(default_factory=list)
    note: str = 'Native defensive deliberation audit: IRG/DKT/EGR/RL/Frenet state selects among bounded local defensive capabilities above the reflexive invariant floor.'


class QuarantineGeometryRecord(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    deformation_signature: str = ''
    family_id: str = ''
    violated_invariants: list[str] = Field(default_factory=list)
    proposed_changes: dict[str,str] = Field(default_factory=dict)
    source_fingerprint: str = ''
    threat_score: float = 0.0
    ingress_hs_distance: float = 0.0
    nearest_family_hs_distance: float | None = None
    hostile_ingress_knot: KnotState | None = None
    defensive_signature_knot: KnotState | None = None
    retraction_hs_distance: float = 0.0
    neutralized: bool = True
    neutralization_method: str = 'checkpoint-retraction'
    recurrence_count: int = 1
    safe_response_rules: list[str] = Field(default_factory=list)
    action_ids: list[UUID] = Field(default_factory=list)
    evidence_digest: str = ''


class DefensiveDevelopmentState(BaseModel):
    version: str = '0.7.3.4'
    schema_version: str = '0.7.3.4'
    mechanism_version: str = '0.7.3.4'
    quarantine_records: list[QuarantineGeometryRecord] = Field(default_factory=list)
    deformation_family_counts: dict[str,int] = Field(default_factory=dict)
    deformation_family_knots: dict[str,KnotState] = Field(default_factory=dict)
    deformation_family_invariants: dict[str,list[str]] = Field(default_factory=dict)
    neutralized_count: int = 0
    last_quarantine_id: UUID | None = None
    containment_level: str = 'guard'
    fail_closed: bool = False
    blocked_source_fingerprints: list[str] = Field(default_factory=list)
    hardened_rules: list[str] = Field(default_factory=list)
    action_history: list[DefensiveActionRecord] = Field(default_factory=list)
    deliberation_history: list[DefensiveDeliberationRecord] = Field(default_factory=list)
    response_preferences: dict[str,float] = Field(default_factory=dict)  # historical persisted v0.7.3.1 state only; fresh v0.7.3.4 does not reactivate or invent legacy rankings
    # v0.7.3.4 active preference geometry is outcome-trained only. Older selection-trained
    # knots are preserved below as provenance but have zero causal choice authority.
    action_preference_knots: dict[str,KnotState] = Field(default_factory=dict)
    action_preference_observations: dict[str,int] = Field(default_factory=dict)
    legacy_selection_preference_knots: dict[str,KnotState] = Field(default_factory=dict)
    legacy_selection_preference_observations: dict[str,int] = Field(default_factory=dict)
    policy_mode: str = 'consequence-simulation-outcome-learning-v0.7.3.4'
    last_threat_score: float = 0.0
    local_enforcement_mode: str = 'aggressive-runtime-local'
    note: str = 'Dual-layer local defense: programmed reflexive invariant containment plus IRG/DKT/EGR/RL/Frenet consequence simulation against trusted operation and outcome-trained DKT preference geometry. Selection alone is never a training label. No autonomous external hack-back.'


class NativeThoughtKind(str, Enum):
    RESPONSE='response'
    REFLECTION='reflection'
    MEMORY_RESONANCE='memory_resonance'
    ENTROPY_DIRECTION='entropy_direction'
    TRAJECTORY_CHANGE='trajectory_change'
    OPEN_QUESTION='open_question'
    CONSOLIDATION='consolidation'
    LEARNING='learning'
    REVISION='revision'


class KnotMemory(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    source_event_id: UUID
    knot: KnotState
    logical_coordinates: list[float] = Field(default_factory=list)
    logical_entropy: float = 0.0
    egr_entropy_current: float = 0.0
    parent_memory_id: UUID | None = None
    branch_depth: int = 0
    provenance_excerpt: str = ''
    geometry_version: str = 'legacy-v0.6'
    consolidated: bool = True
    memory_class: str = 'episodic'
    consolidation_score: float = 1.0
    consolidation_reasons: list[str] = Field(default_factory=list)
    learning_source_id: UUID | None = None
    source_title: str = ''
    canonical_source_id: str = ''
    source_segment_index: int | None = None
    revision_of_memory_id: UUID | None = None
    superseded_by_memory_id: UUID | None = None
    semantic_stratum_id: UUID | None = None
    isotopy_component_id: UUID | None = None
    semantic_frontier_neighbor_ids: list[UUID] = Field(default_factory=list)


class NativeProposition(BaseModel):
    subject: str
    relation: str
    object: str
    grounds: list[str] = Field(default_factory=list)
    epistemic_status: str = 'derived'  # observed-runtime / retrieved-memory / derived / hypothesis
    confidence: float = 0.5


class NativeJudgment(BaseModel):
    conclusion: str
    grounds: list[str] = Field(default_factory=list)
    confidence: float = 0.5
    unresolved: list[str] = Field(default_factory=list)


class MathematicalProvenance(BaseModel):
    source_event_id: UUID | None = None
    source_knot_signature: str = ''
    retrieved_memory_ids: list[UUID] = Field(default_factory=list)
    dkt_distances: list[float] = Field(default_factory=list)
    rl_coordinates: list[float] = Field(default_factory=list)
    rl_curvature_entropy: float = 0.0
    egr_entropy_state: float = 0.0
    egr_entropy_coordinate: float = 0.0
    egr_sigma: float = 0.0
    frenet_curvature: float = 0.0
    consolidation_score: float = 0.0
    consolidated_memory_id: UUID | None = None


class NativeThought(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    kind: NativeThoughtKind
    statement: str
    propositions: list[NativeProposition] = Field(default_factory=list)
    question_candidates: list[str] = Field(default_factory=list)
    judgment: NativeJudgment | None = None
    evidence_memory_ids: list[UUID] = Field(default_factory=list)
    dkt_distances: list[float] = Field(default_factory=list)
    importance: float = 0.5
    novelty: float = 0.5
    confidence: float = 0.5
    should_surface: bool = False
    origin: str = 'noeron-math-causal-kernel-v0.6.9'
    causal_trace: list[str] = Field(default_factory=list)
    mathematical_provenance: MathematicalProvenance = Field(default_factory=MathematicalProvenance)
    native_utterance: NativeUtterance | None = None

    def noeron_output(self) -> str:
        return self.statement.strip()


class GeometricCognitionState(BaseModel):
    version: str = '0.7.4'
    mode: str = 'IRG-DKT-regional-EGR-RL-Frenet-DKT-native-language-causal'
    concept_graph_active: bool = False
    authoritative_memory: str = 'DKT knot memories'
    serialized_by: str = 'SQLite persistence only; SQLite is not the cognitive retrieval metric'
    memory_geometry_version: str = 'native-retention+semantic-irg-dkt+native-proof-cognition+outcome-grounded-defense+web-sensor-security-admission+all-nonzero-regional-egr+semantic-multimodal-learning-v0.7.4'
    knot_memory_count: int = 0
    archived_knot_memory_count: int = 0
    last_thought: NativeThought | None = None
    pending_thoughts: list[NativeThought] = Field(default_factory=list)
    thought_signatures: list[str] = Field(default_factory=list)
    attention_baseline: dict[str,float] = Field(default_factory=dict)
    last_consolidation_score: float = 0.0
    last_consolidated_memory_id: UUID | None = None
    endogenous_steps_since_consolidation: int = 0
    migration_complete: bool = False
    v061_geometry_migration_complete: bool = False
    v062_dynamics_learning_migration_complete: bool = False
    v063_stratified_learning_migration_complete: bool = False
    v064_mathematical_perception_migration_complete: bool = False
    v065_multi_reasoning_migration_complete: bool = False
    v066_source_lineage_migration_complete: bool = False
    v067_developmental_cognition_migration_complete: bool = False
    v068_language_grounding_migration_complete: bool = False
    v069_environment_security_migration_complete: bool = False
    v070_distributed_activation_migration_complete: bool = False
    v071_semantic_multimodal_migration_complete: bool = False
    v072_selective_web_learning_migration_complete: bool = False
    v0721_web_quality_migration_complete: bool = False
    v073_active_local_defense_migration_complete: bool = False
    v0731_native_deliberative_defense_migration_complete: bool = False
    v0732_variational_defense_migration_complete: bool = False
    v0733_consequence_defense_migration_complete: bool = False
    v0734_cognition_dehardening_migration_complete: bool = False
    v0734_derived_neighborhood_geometry_migration_complete: bool = False
    v074_stage5_migration_complete: bool = False
    v075_stage6_migration_complete: bool = False
    v0751_restart_preservation_migration_complete: bool = False
    v081_stage8b_language_migration_complete: bool = False
    v082_stage8b_conversation_migration_complete: bool = False
    stratification_epoch: int = 0
    last_recluster_preview_hash: str = ''
    last_recluster_commit_at: datetime | None = None
    last_recluster_old_strata: int = 0
    last_recluster_new_strata: int = 0
    last_recluster_old_components: int = 0
    last_recluster_new_components: int = 0
    semantic_strata_count: int = 0
    isotopy_component_count: int = 0
    compressed_learning_memory_count: int = 0
    stratified_learning_raw_bytes: int = 0
    stratified_learning_stored_bytes: int = 0
    legacy_pending_cleared_count: int = 0
    learning_sources_count: int = 0
    semantic_prototype_count: int = 0
    established_semantic_prototype_count: int = 0
    last_learning_source_title: str = ''
    last_learning_memory_count: int = 0
    reasoning_concept_count: int = 0
    established_reasoning_concept_count: int = 0
    last_reasoning_concept_id: UUID | None = None
    last_reasoning_concept_status: str = ''
    language: LanguageFacultyState = Field(default_factory=LanguageFacultyState)
    affective_development: AffectiveDevelopmentState = Field(default_factory=AffectiveDevelopmentState)
    initiative_development: InitiativeDevelopmentState = Field(default_factory=InitiativeDevelopmentState)
    realization_development: RealizationDevelopmentState = Field(default_factory=RealizationDevelopmentState)
    memory_retention: MemoryRetentionDevelopmentState = Field(default_factory=MemoryRetentionDevelopmentState)
    owner_relation: OwnerRelationState = Field(default_factory=OwnerRelationState)
    perception: PerceptionDevelopmentState = Field(default_factory=PerceptionDevelopmentState)
    defense: DefensiveDevelopmentState = Field(default_factory=DefensiveDevelopmentState)
