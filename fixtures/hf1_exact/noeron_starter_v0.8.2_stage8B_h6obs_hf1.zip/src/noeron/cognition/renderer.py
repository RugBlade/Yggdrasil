from __future__ import annotations

import re
from noeron.llm import LanguageEngine

RENDERER_SYSTEM_PROMPT=(
    'You are Yggdrasil, the first individual of the Noeron species.\n\n'
    'Output the supplied NOERON_OUTPUT in natural language without adding information.'
)

class RenderingGuard:
    TECHNICAL={'Yggdrasil','Noeron','DKT','IRG','RL','EGR','Frenet','Terra','Sigma'}
    @staticmethod
    def _numbers(text:str)->set[str]: return set(re.findall(r"(?<![A-Za-z])[-+]?\d+(?:\.\d+)?(?:e[-+]?\d+)?",text,re.I))
    @staticmethod
    def _words(text:str)->set[str]:
        stop={'the','and','that','this','with','from','into','only','your','you','are','was','for','but','not','have','has','its','will','would','should','could','can','may','might','being','been','than','then','when','where','which','output','supplied','natural','language','without','adding','information'}
        return {w for w in re.findall(r"[A-Za-z][A-Za-z0-9_-]{2,}",text.lower()) if w not in stop}
    def faithful(self,source:str,rendered:str)->bool:
        if not rendered.strip(): return False
        if not self._numbers(rendered).issubset(self._numbers(source)): return False
        for name in self.TECHNICAL:
            if name in rendered and name not in source: return False
        rw=self._words(rendered); sw=self._words(source)
        # Conservative surface boundary: Terra may reorder/remove source words but
        # may not introduce a new content-bearing token. No percentage heuristic
        # decides whether extra semantics are acceptable.
        return bool(rw) and rw.issubset(sw)

class LanguageRenderer:
    def __init__(self,engine:LanguageEngine): self.engine=engine; self.guard=RenderingGuard()
    def render_audited(self,noeron_output:str)->dict:
        rendered=self.engine.generate([{'role':'system','content':RENDERER_SYSTEM_PROMPT},{'role':'user','content':f'NOERON_OUTPUT:\n{noeron_output}'}])
        accepted=self.guard.faithful(noeron_output,rendered)
        return {'text':rendered if accepted else noeron_output,'invoked':True,'accepted':accepted,'raw_rendered':rendered}
    def render(self,noeron_output:str)->str:
        return self.render_audited(noeron_output)['text']
