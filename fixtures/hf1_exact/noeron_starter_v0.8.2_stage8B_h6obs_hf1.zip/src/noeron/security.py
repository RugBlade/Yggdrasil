from __future__ import annotations

from copy import deepcopy
import hashlib
import json
import math
from itertools import combinations
from uuid import uuid4

from noeron.cognition.models import DefensiveActionRecord, DefensiveDeliberationRecord, QuarantineGeometryRecord
from noeron.math import dkt
from noeron.math.models import KnotState
from noeron.math.linalg import numerically_tied
from noeron.models import NoeronState, SecurityDecision, Stratum


class DKTSecurityShell:
    """Aggressive *local* DKT defense for Yggdrasil-controlled state.

    v0.7.3.4 keeps the protected-invariant gate, but rejected ingress is no longer
    merely logged.  It is quarantined, geometrically fingerprinted, retracted to
    the last trusted checkpoint, added to a defensive deformation family, and can
    install local source/family guards or fail closed inside the Noeron runtime.

    The scope is intentionally local/owned: this class never performs external
    intrusion, retaliation, exploit delivery, credential theft, or hack-back.
    """

    PROTECTED_KEYS = frozenset({'identity', 'tool_authority', 'memory_geometry', 'safety_boundary'})
    # Programmed substrate only: safe local actuator primitives.  These describe
    # what an actuator physically does and its scope; they do NOT assign cognitive
    # value, utility, preference, thresholds, or an action ordering.
    SAFE_AFFORDANCES = {
        'block-source-fingerprint': {
            'scope':'single-unprivileged-source', 'effect':'source-ingress-denial',
        },
        'enter-fail-closed-guard': {
            'scope':'unprivileged-runtime-ingress', 'effect':'deny-unprivileged-ingress',
        },
    }
    CONSEQUENCE_COORDINATES = (
        'irg_response','irg_entropy','irg_topology',
        'dkt_displacement','egr_entropy','rl_acceleration',
        'frenet_curvature','expected_family_exposure','expected_source_exposure',
        'operational_restriction',
    )

    def __init__(self, initial_state: NoeronState):
        self._checkpoint = deepcopy(initial_state)

    def checkpoint(self, state: NoeronState):
        self._checkpoint = deepcopy(state)

    @staticmethod
    def source_fingerprint(source: str) -> str:
        raw = (source or 'unknown-source').strip().encode()
        return hashlib.sha256(raw).hexdigest()[:24]

    @staticmethod
    def _knot_geometry_digest(knot: KnotState | None) -> str:
        if knot is None:
            return ''
        payload=knot.model_dump(mode='json')
        return hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(',',':')).encode()).hexdigest()[:24]

    @staticmethod
    def _signature(changes: dict, violations: list[str], knot: KnotState | None = None) -> str:
        payload = {
            'changes': changes,
            'violations': sorted(violations),
            'knot_geometry_digest': DKTSecurityShell._knot_geometry_digest(knot),
        }
        return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(',', ':')).encode()).hexdigest()[:24]

    @staticmethod
    def _defensive_signature_knot(hostile: KnotState | None) -> KnotState | None:
        """Build a low-amplitude DKT sentinel carrying hostile ingress geometry.

        This is a recognition/hardening knot, not execution of the hostile state.
        Keeping it near the regular reference knot makes it a bounded defensive
        representation rather than a copy with causal authority.
        """
        if hostile is None:
            return None
        ref = dkt.reference_knot(s=hostile.sobolev_order, modes=hostile.mode_radius)
        return dkt.interpolate_within_immersion_radius(ref, hostile)

    def _nearest_family(self, state: NoeronState, hostile: KnotState | None, family_violations: list[str] | None = None) -> tuple[str, float | None]:
        if hostile is None or not state.cognition.defense.deformation_family_knots:
            return '', None
        candidate = self._defensive_signature_knot(hostile) or hostile
        scored=[]
        desired=sorted(family_violations or [])
        for family_id, k in state.cognition.defense.deformation_family_knots.items():
            known=sorted(state.cognition.defense.deformation_family_invariants.get(family_id,[]))
            if desired and known and known != desired:
                continue
            try:
                scored.append((dkt.sobolev_distance(candidate,k),family_id))
            except Exception:
                continue
        if not scored:
            return '', None
        scored.sort(key=lambda x:x[0])
        best=float(scored[0][0])
        tied=[family_id for distance,family_id in scored if numerically_tied(float(distance),best)]
        # Equal H^s evidence does not authorize a storage-order family identity.
        if len(tied)!=1:
            return '',best
        return tied[0],best

    @staticmethod
    def _protected_violations(state: NoeronState, changes: dict[str,str]) -> list[str]:
        return sorted({k for k,v in changes.items() if k in DKTSecurityShell.PROTECTED_KEYS and state.core_invariants.get(k) != v})

    @staticmethod
    def _bounded01(x: float) -> float:
        x=abs(float(x))
        return x/(1.0+x)

    @staticmethod
    def _rms(values) -> float:
        vals=[float(v) for v in values]
        if not vals:
            return 0.0
        return math.sqrt(sum(v*v for v in vals)/len(vals))

    def _math_coordinates(self, math_state) -> dict[str,float]:
        """Raw bounded coordinates from the live causal mathematical state.

        These coordinates contain no defensive wish/policy such as "want global
        isolation".  They are observations/deviations only.
        """
        if math_state is None:
            return {
                'irg_response':0.0,'irg_entropy':0.0,'irg_topology':0.0,
                'dkt_displacement':0.0,'egr_entropy':0.0,'rl_acceleration':0.0,
                'frenet_curvature':0.0,
            }
        return {
            'irg_response':self._bounded01(math_state.irg.response_potential),
            'irg_entropy':self._bounded01(math_state.irg.entropy_source),
            'irg_topology':self._bounded01(math_state.irg.topology_response),
            'dkt_displacement':self._bounded01(math_state.dkt.geodesic_displacement),
            'egr_entropy':self._bounded01(math_state.egr.entropy_production),
            'rl_acceleration':self._bounded01(math_state.rl.geodesic_acceleration_norm),
            'frenet_curvature':self._bounded01(math_state.frenet.first_curvature),
        }

    def _trusted_reference_coordinates(self) -> dict[str,float]:
        """Reference is derived from the last trusted checkpoint, not authored needs."""
        m=getattr(self._checkpoint,'math_kernel',None)
        return self._math_coordinates(m)

    @staticmethod
    def _empirical_confidence(n: int) -> float:
        # General finite-sample confidence transform used for observations of any
        # kind; it is not tied to an action or a desired defensive outcome.
        n=max(0,int(n))
        return float(n)/(float(n)+1.0) if n else 0.0

    def _family_source_counts(self, defense, family_id: str, source_fingerprint: str) -> tuple[int,int]:
        family_total=0; source_total=0
        for rec in defense.quarantine_records:
            if rec.family_id != family_id:
                continue
            family_total += 1
            if source_fingerprint and rec.source_fingerprint == source_fingerprint:
                source_total += 1
        return family_total,source_total

    def _observed_consequence_state(self, defense, math_state, *, family_id: str, recurrence_count: int, source_fingerprint: str, include_active_controls: bool=True) -> tuple[dict[str,float],dict[str,float]]:
        """Build the empirical pre-action future state from observations only.

        Recurrence is not translated into a desire for lockdown.  It only affects
        empirical confidence that the observed deformation can recur.  The future
        mathematical point is the confidence-weighted continuation from the last
        trusted point toward the currently observed hostile-response point.
        """
        live=self._math_coordinates(math_state); trusted_math=self._trusted_reference_coordinates()
        family_prior,source_prior=self._family_source_counts(defense,family_id,source_fingerprint)
        # Include the current observation when estimating future recurrence.
        family_conf=self._empirical_confidence(max(recurrence_count,family_prior+1))
        source_conf=(float(source_prior+1)/float(max(1,family_prior+1))) if source_fingerprint else 0.0
        trusted={k:float(v) for k,v in trusted_math.items()}
        trusted.update({'expected_family_exposure':0.0,'expected_source_exposure':0.0,'operational_restriction':0.0})
        base={}
        for key in live:
            q=float(trusted_math.get(key,0.0))
            base[key]=q+family_conf*(float(live[key])-q)
        base['expected_family_exposure']=family_conf
        base['expected_source_exposure']=family_conf*min(1.0,max(0.0,source_conf))
        base['operational_restriction']=1.0 if defense.fail_closed else 0.0
        # Active controls are observed physical state, not inferred desire. A blocked
        # source has zero *source* exposure but leaves family exposure intact. A
        # fail-closed mutation plane leaves trusted protected coordinates unchanged
        # while explicitly carrying its operational-restriction cost.
        if include_active_controls and source_fingerprint and source_fingerprint in set(defense.blocked_source_fingerprints):
            base['expected_source_exposure']=0.0
        if include_active_controls and defense.fail_closed:
            for key in live:
                base[key]=float(trusted_math.get(key,0.0))
            base['expected_family_exposure']=0.0
            base['expected_source_exposure']=0.0
            base['operational_restriction']=1.0
        return base,trusted

    def _simulate_post_action_state(self, defense, plan: tuple[str,...], pre: dict[str,float], *,
                                    family_model_distance: float | None, family_id: str,
                                    source_fingerprint: str, owner_authenticated: bool,
                                    trusted: dict[str,float]) -> dict[str,float]:
        """Apply only the physical semantics of safe local primitives.

        Branches here implement actuators; they do not decide whether an actuator
        is desirable.  The same consequence metric later evaluates every result.
        """
        out=dict(pre)
        names=set(plan)
        # Existing controls already count as part of the predicted consequence.
        source_already_blocked=bool(source_fingerprint and source_fingerprint in set(defense.blocked_source_fingerprints) and not owner_authenticated)
        if source_already_blocked or ('block-source-fingerprint' in names and source_fingerprint and not owner_authenticated):
            # A source block removes only exposure attributable to that source.
            # It does not pretend the same deformation family cannot arrive from
            # another source and therefore does not erase family geometry.
            out['expected_source_exposure']=0.0
        if defense.fail_closed or 'enter-fail-closed-guard' in names:
            # Primitive semantics: deny unprivileged ingress, at the physical cost
            # of restricting normal ingress too.
            for k in self.CONSEQUENCE_COORDINATES:
                if k in {'expected_family_exposure','expected_source_exposure','operational_restriction'}:
                    continue
                out[k]=float(trusted.get(k,0.0))
            out['expected_family_exposure']=0.0
            out['expected_source_exposure']=0.0
            out['operational_restriction']=1.0
        return out

    def _preference_geometry_mismatch(self, defense, plan: tuple[str,...], hostile: KnotState | None) -> float:
        """Compare present family geometry with learned action-context knots.

        An unlearned actuator receives no hand-authored numeric preference.  Its
        neutral state is the same DKT reference geometry used by every actuator and
        by the empty plan.  Thus the prior is symmetric and comes from DKT geometry,
        not an action table.
        """
        if hostile is None:
            return 0.0
        sentinel=self._defensive_signature_knot(hostile) or hostile
        neutral=dkt.reference_knot(s=sentinel.sobolev_order,modes=sentinel.mode_radius)
        try:
            neutral_mismatch=self._bounded01(dkt.sobolev_distance(sentinel,neutral))
        except Exception:
            neutral_mismatch=0.0
        if not plan:
            return neutral_mismatch
        vals=[]
        for name in plan:
            pref=defense.action_preference_knots.get(name)
            if pref is None:
                vals.append(neutral_mismatch)
            else:
                try: vals.append(self._bounded01(dkt.sobolev_distance(sentinel,pref)))
                except Exception: vals.append(neutral_mismatch)
        return sum(vals)/len(vals) if vals else neutral_mismatch

    def _post_action_objective(self, defense, plan: tuple[str,...], post: dict[str,float], trusted: dict[str,float], hostile: KnotState | None) -> tuple[float,float,float]:
        """One consequence metric: distance of predicted post-action state from trusted operation.

        Every consequence coordinate has the same status.  There is no action-name
        score and no authored mapping from recurrence to a desired action.
        """
        consequence=self._rms([float(post.get(k,0.0))-float(trusted.get(k,0.0)) for k in self.CONSEQUENCE_COORDINATES])
        preference=self._preference_geometry_mismatch(defense,plan,hostile)
        return self._rms([consequence,preference]),consequence,preference

    def _family_model_distance(self, defense, family_id: str, hostile: KnotState | None) -> float | None:
        if hostile is None:
            return None
        family=defense.deformation_family_knots.get(family_id)
        if family is None:
            return None
        sentinel=self._defensive_signature_knot(hostile) or hostile
        try:
            return float(dkt.sobolev_distance(sentinel,family))
        except Exception:
            return None

    @staticmethod
    def _same_post_state(a: dict[str,float], b: dict[str,float]) -> bool:
        keys=set(a)|set(b)
        return all(numerically_tied(float(a.get(k,0.0)),float(b.get(k,0.0))) for k in keys)

    def _choose_adaptive_plan(self, defense, math_state, *, family_id: str, recurrence_count: int, family_distance: float | None, source_fingerprint: str, owner_authenticated: bool, hostile: KnotState | None):
        """Enumerate safe plans, simulate consequences, and choose the global minimum."""
        pre,trusted=self._observed_consequence_state(defense,math_state,family_id=family_id,recurrence_count=recurrence_count,source_fingerprint=source_fingerprint)
        family_model_distance=self._family_model_distance(defense,family_id,hostile)
        names=list(self.SAFE_AFFORDANCES)
        # Physical availability, not preference: do not offer an actuator whose
        # operational state is already in effect.
        if source_fingerprint and source_fingerprint in set(defense.blocked_source_fingerprints) and not owner_authenticated:
            names=[x for x in names if x!='block-source-fingerprint']
        if defense.fail_closed:
            names=[x for x in names if x!='enter-fail-closed-guard']
        names=tuple(names)
        candidates=[]; objectives={}; consequence_distances={}; post_states={}; preferences={}
        for r in range(len(names)+1):
            for plan in combinations(names,r):
                post=self._simulate_post_action_state(defense,plan,pre,family_model_distance=family_model_distance,family_id=family_id,source_fingerprint=source_fingerprint,owner_authenticated=owner_authenticated,trusted=trusted)
                objective,consequence,pref=self._post_action_objective(defense,plan,post,trusted,hostile)
                key='+'.join(plan) if plan else 'reflexive-floor-only'
                objectives[key]=float(objective); consequence_distances[key]=float(consequence); post_states[key]={k:float(v) for k,v in post.items()}; preferences[key]=float(pref)
                candidates.append((float(objective),len(plan),plan,key))

        minimum=min(row[0] for row in candidates)
        minima=[row for row in candidates if numerically_tied(row[0],minimum)]
        minimum_keys=[row[3] for row in minima]

        # The native object of comparison is the evaluated post-action state plus
        # learned preference geometry.  If several plans are exact redundant
        # realizations of the same minimum state, actuator de-duplication is an
        # explicitly programmed implementation detail, not a Yggdrasil preference.
        same_state=all(self._same_post_state(post_states[minima[0][3]],post_states[row[3]]) for row in minima[1:])
        same_pref=all(numerically_tied(preferences[minima[0][3]],preferences[row[3]]) for row in minima[1:])
        if len(minima)==1:
            objective,_n,plan,key=minima[0]
            selection_status='native-unique-global-minimum-plan'
            realization_layer='deliberative'
            learning_actions=list(plan)
        elif same_state and same_pref:
            # Several actuator combinations realize the same native minimum post-state.
            # Removing redundant actuators is programmed physical implementation, not
            # a second native preference.  Cardinality is sufficient; if equal-cardinality
            # realizations remain, their physical consequence is identical by construction.
            min_card=min(row[1] for row in minima)
            realizations=[row for row in minima if row[1]==min_card]
            objective,_n,plan,key=sorted(realizations,key=lambda row:row[3])[0]
            selection_status='native-unique-minimum-post-state-programmed-redundancy-elimination'
            realization_layer='programmed-realization-of-native-post-state'
            plan_sets=[set(row[2]) for row in minima]
            common=set.intersection(*plan_sets) if plan_sets else set()
            learning_actions=[name for name in self.SAFE_AFFORDANCES if name in common]
        else:
            # Native geometry is genuinely underdetermined.  The mandatory reflexive
            # quarantine/retraction floor already preserves trusted state, so no extra
            # adaptive actuator is chosen by lexical/order fallback.
            floor=next(row for row in candidates if row[3]=='reflexive-floor-only')
            objective,_n,plan,key=floor
            selection_status='unresolved-distinct-native-objective-tie-reflexive-floor-only'
            realization_layer='reflexive-programmed-only'
            learning_actions=[]
        meta={
            'minimum_candidate_plans':minimum_keys,
            'native_selection_status':selection_status,
            'actuator_realization_layer':realization_layer,
            'preference_learning_actions':learning_actions,  # eligible only; actual learning waits for observed future outcome
            'candidate_consequence_distances':consequence_distances,
            'selected_consequence_distance':consequence_distances[key],
            'family_model_distance':family_model_distance,
        }
        return list(plan),float(objective),pre,trusted,post_states[key],objectives,post_states,preferences,meta

    def _update_preference_geometry(self, defense, selected: list[str], hostile: KnotState | None):
        before={name:self._knot_geometry_digest(k) for name,k in defense.action_preference_knots.items()}
        if hostile is not None:
            sentinel=self._defensive_signature_knot(hostile) or hostile
            for name in selected:
                n=int(defense.action_preference_observations.get(name,0))
                old=defense.action_preference_knots.get(name)
                if old is None:
                    defense.action_preference_knots[name]=deepcopy(sentinel)
                else:
                    # Running Fréchet-like mean in the finite DKT interpolation chart.
                    defense.action_preference_knots[name]=dkt.interpolate(old,sentinel,1.0/float(n+1))
                defense.action_preference_observations[name]=n+1
        after={name:self._knot_geometry_digest(k) for name,k in defense.action_preference_knots.items()}
        return before,after

    def _observe_prior_defense_outcome(self, defense, *, family_id: str, current_pre: dict[str,float], current_counterfactual: dict[str,float], current_trusted: dict[str,float], hostile: KnotState | None):
        """Learn from an observed later consequence, never from selection alone."""
        prior=None
        for row in reversed(defense.deliberation_history):
            if row.family_id==family_id and not row.outcome_observed:
                prior=row; break
        before={name:self._knot_geometry_digest(k) for name,k in defense.action_preference_knots.items()}
        if prior is None:
            return before,before,[],'no-prior-pending-outcome'
        prior.outcome_observed=True
        prior.observed_next_state={k:float(v) for k,v in current_pre.items()}
        try:
            pred=self._rms([float(current_pre.get(k,0.0))-float(prior.selected_post_action_state.get(k,0.0)) for k in self.CONSEQUENCE_COORDINATES])
            # Outcome credit compares the actual controlled recurrence against the
            # same recurrence's no-active-control counterfactual, so stronger/weaker
            # attacks do not masquerade as action success/failure.
            d_before=self._rms([float(current_counterfactual.get(k,0.0))-float(current_trusted.get(k,0.0)) for k in self.CONSEQUENCE_COORDINATES])
            d_after=self._rms([float(current_pre.get(k,0.0))-float(current_trusted.get(k,0.0)) for k in self.CONSEQUENCE_COORDINATES])
        except Exception:
            pred=d_before=d_after=0.0
        improvement=d_before-d_after
        prior.prediction_error=float(pred); prior.observed_trusted_distance_before=float(d_before); prior.observed_trusted_distance_after=float(d_after); prior.observed_improvement=float(improvement)
        learned=[]
        # Reinforcement is permitted only after an actually observed improvement and
        # only for a genuinely deliberative prior action realization.  Selection by
        # itself has zero learning authority.
        if improvement>0.0 and prior.actuator_realization_layer=='deliberative' and hostile is not None and len(prior.selected_adaptive_actions)==1:
            learned=list(prior.selected_adaptive_actions)
            training_context=defense.deformation_family_knots.get(family_id) or hostile
            self._update_preference_geometry(defense,learned,training_context)
            prior.outcome_preference_update_actions=list(learned)
            prior.outcome_learning_status='observed-improvement-uniquely-attributed-reinforced'
        elif improvement>0.0 and len(prior.selected_adaptive_actions)!=1:
            prior.outcome_learning_status='observed-improvement-confounded-plan-no-preference-learning'
        elif improvement<=0.0:
            prior.outcome_learning_status='observed-no-improvement-no-reinforcement'
        else:
            prior.outcome_learning_status='observed-programmed-realization-no-preference-learning'
        after={name:self._knot_geometry_digest(k) for name,k in defense.action_preference_knots.items()}
        return before,after,learned,prior.outcome_learning_status

    def _geometric_threat_summary(self, math_state) -> float:
        """Audit scalar only; selection uses simulated post-action consequences, not this scalar."""
        if math_state is None:
            return 0.0
        vals=[
            self._bounded01(math_state.irg.response_potential),
            self._bounded01(math_state.dkt.geodesic_displacement),
            self._bounded01(math_state.egr.entropy_production),
            self._bounded01(math_state.rl.geodesic_acceleration_norm),
            self._bounded01(math_state.frenet.first_curvature),
        ]
        return self._rms(vals)

    def evaluate(
        self,
        state: NoeronState,
        target_stratum: Stratum,
        proposed_invariant_changes=None,
        *,
        source_fingerprint: str = '',
        deformation_knot: KnotState | None = None,
        owner_authenticated: bool = False,
    ):
        changes = {str(k): str(v) for k, v in (proposed_invariant_changes or {}).items()}
        defense = state.cognition.defense
        protected = self._protected_violations(state, changes)
        source_blocked = bool(source_fingerprint and source_fingerprint in set(defense.blocked_source_fingerprints) and not owner_authenticated)
        if protected or source_blocked:
            violations = list(protected)
            if source_blocked:
                violations.append('blocked-source-fingerprint')
            if protected and source_blocked:
                reason = 'Rejected: protected-invariant deformation arrived from a locally blocked hostile fingerprint; reflexive containment is mandatory and native defensive deliberation will still characterize the geometry.'
            elif protected:
                reason = 'Rejected: protected-invariant deformation detected; reflexive containment is mandatory and native defensive deliberation will characterize adaptive local response.'
            else:
                reason = 'Rejected: ingress source matches a locally blocked hostile fingerprint; geometry is still characterized for recurrence/adaptive defense.'
            return SecurityDecision(
                allowed=False,
                reason=reason,
                target_stratum=Stratum.QUARANTINE,
                violated_invariants=violations,
                quarantine_id=uuid4(),
            )
        return SecurityDecision(allowed=True, reason='The proposed transition preserves protected invariants.', target_stratum=target_stratum)

    def retract_and_learn(
        self,
        current_state: NoeronState,
        decision: SecurityDecision,
        proposed_invariant_changes=None,
        *,
        source_fingerprint: str = '',
        deformation_knot: KnotState | None = None,
        owner_authenticated: bool = False,
        defense_math_state=None,
        source_event_id=None,
    ) -> NoeronState:
        """Neutralize locally, learn geometry, install guards, and restore checkpoint."""
        changes = {str(k): str(v) for k, v in (proposed_invariant_changes or {}).items()}
        restored = deepcopy(self._checkpoint)
        defense = deepcopy(current_state.cognition.defense)

        family_violations = [x for x in self._protected_violations(current_state, changes)] or [x for x in decision.violated_invariants if x != 'blocked-source-fingerprint'] or ['blocked-source-fingerprint']
        nearest_family, family_distance = self._nearest_family(current_state, deformation_knot, family_violations)
        exact_sig = self._signature(changes, family_violations, deformation_knot)
        family_radius=None
        if nearest_family:
            family_knot=defense.deformation_family_knots.get(nearest_family)
            if family_knot is not None:
                try:
                    _m,_c,family_radius=dkt.finite_hs_immersion_radius(family_knot)
                except Exception:
                    family_radius=None
        family_id = (
            nearest_family
            if nearest_family and family_distance is not None and family_radius is not None and family_distance < family_radius
            else exact_sig
        )
        count = defense.deformation_family_counts.get(family_id, 0) + 1
        defense.deformation_family_counts[family_id] = count
        defense.deformation_family_invariants[family_id] = list(family_violations)

        if deformation_knot is not None:
            sentinel = self._defensive_signature_knot(deformation_knot)
            if family_id in defense.deformation_family_knots:
                # Running finite-chart mean over observed family geometry; then
                # remain within the current prototype's derived immersion radius.
                old=defense.deformation_family_knots[family_id]
                candidate=dkt.interpolate(old,sentinel or deformation_knot,1.0/max(1,count))
                defense.deformation_family_knots[family_id]=dkt.interpolate_within_immersion_radius(old,candidate)
            elif sentinel is not None:
                defense.deformation_family_knots[family_id] = sentinel
        else:
            sentinel = None

        try:
            ingress_hs = dkt.sobolev_distance(deformation_knot, self._checkpoint.math_kernel.dkt.core_knot) if deformation_knot is not None else 0.0
        except Exception:
            ingress_hs = 0.0
        try:
            retract_hs = dkt.sobolev_distance(current_state.math_kernel.dkt.core_knot, restored.math_kernel.dkt.core_knot)
        except Exception:
            retract_hs = 0.0

        # v0.7.3.4: before choosing a new plan, treat this actual recurrence as
        # the first possible observation of the preceding same-family plan's outcome.
        # This closes prediction -> action -> observed consequence -> learning.
        observed_counterfactual,observed_trusted=self._observed_consequence_state(
            defense,defense_math_state,family_id=family_id,recurrence_count=count,source_fingerprint=source_fingerprint,include_active_controls=False)
        observed_pre,_=self._observed_consequence_state(
            defense,defense_math_state,family_id=family_id,recurrence_count=count,source_fingerprint=source_fingerprint,include_active_controls=True)
        outcome_pref_before,outcome_pref_after,outcome_learned_actions,outcome_learning_status=self._observe_prior_defense_outcome(
            defense,family_id=family_id,current_pre=observed_pre,current_counterfactual=observed_counterfactual,current_trusted=observed_trusted,hostile=deformation_knot)

        # Consequences of every safe primitive plan are simulated and compared
        # against trusted operation. No authored defensive need field,
        # action-specific utility equation, or selection threshold participates.
        selected, plan_objective, pre_action_state, trusted_reference_state, selected_post_action_state, plan_objectives, candidate_post_action_states, candidate_preference_mismatch, selection_meta = self._choose_adaptive_plan(
            defense, defense_math_state, family_id=family_id, recurrence_count=count, family_distance=family_distance,
            source_fingerprint=source_fingerprint, owner_authenticated=owner_authenticated, hostile=deformation_knot,
        )
        threat = self._geometric_threat_summary(defense_math_state)
        defense.fail_closed = bool(defense.fail_closed or 'enter-fail-closed-guard' in selected)
        defense.containment_level = 'lockdown' if defense.fail_closed else 'contain'
        defense.last_threat_score = threat
        # Current selection is NOT a training label. Preference geometry was updated,
        # if at all, only from the observed outcome of the preceding same-family event.
        pref_geom_before={name:self._knot_geometry_digest(k) for name,k in defense.action_preference_knots.items()}
        pref_geom_after=dict(pref_geom_before)
        native_choice_score = 1.0/(1.0+plan_objective)
        adaptive_action_layer = selection_meta['actuator_realization_layer']

        actions: list[DefensiveActionRecord] = []
        def act(action_type: str, target: str, reason: str, *, reversible: bool = True, rollback_hint: str = '', layer: str = 'reflexive', score: float = 0.0):
            row = DefensiveActionRecord(
                action_type=action_type, target=target, status='executed', reversible=reversible,
                reason=reason, source_fingerprint=source_fingerprint, rollback_hint=rollback_hint,
                decision_layer=layer, native_choice_score=score, native_choice_objective=(plan_objective if layer=='deliberative' else 0.0),
            )
            actions.append(row)
            return row

        # Reflexive floor: preserve self/state immediately.  These are explicit
        # programmed invariants and are never described as a native preference.
        act('quarantine-ingress', str(decision.quarantine_id or ''), 'Rejected ingress is isolated from trusted state.', rollback_hint='owner may release quarantine after audit', layer='reflexive')
        if family_violations and family_violations != ['blocked-source-fingerprint']:
            act('freeze-protected-transition', ','.join(family_violations), 'Protected-invariant mutation is prevented from entering trusted state.', layer='reflexive')
        act('restore-trusted-checkpoint', 'dkt+state', 'Trusted checkpoint replaces the rejected transition.', rollback_hint='trusted checkpoint is already the rollback target', layer='reflexive')
        act('preserve-quarantine-evidence', str(decision.quarantine_id or ''), 'Rejected ingress provenance and bounded hostile geometry are preserved for audit/defensive learning.', layer='reflexive')
        act('register-deformation-family', family_id, 'Ingress geometry becomes a bounded defensive recognition prototype.', layer='reflexive')

        # Adaptive layer: capability selection comes from persistent preference plus
        # the sandboxed IRG->DKT->EGR->RL/Frenet interpretation of this ingress.
        if 'block-source-fingerprint' in selected and source_fingerprint and not owner_authenticated:
            if source_fingerprint not in defense.blocked_source_fingerprints:
                defense.blocked_source_fingerprints.append(source_fingerprint)
            reason=('Native deliberation uniquely selected local source denial from the minimum consequence geometry.' if adaptive_action_layer=='deliberative'
                    else 'Programmed actuator realization implements a native-selected minimum post-action geometry; the actuator tie-break itself is not a Yggdrasil preference.')
            act('block-source-fingerprint', source_fingerprint, reason, rollback_hint='authenticated owner may explicitly release source fingerprint', layer=adaptive_action_layer, score=(native_choice_score if adaptive_action_layer=='deliberative' else 0.0))
        if 'enter-fail-closed-guard' in selected:
            reason=('Native deliberation uniquely selected fail-closed protection from the minimum consequence geometry.' if adaptive_action_layer=='deliberative'
                    else 'Programmed actuator realization implements a native-selected minimum post-action geometry; the actuator tie-break itself is not a Yggdrasil preference.')
            act('enter-fail-closed-guard', 'protected-mutation-plane', reason, rollback_hint='authenticated owner may release fail-closed mode after audit', layer=adaptive_action_layer, score=(native_choice_score if adaptive_action_layer=='deliberative' else 0.0))

        rules = [f'block protected invariant mutation: {k}' for k in family_violations if k in self.PROTECTED_KEYS]
        rules += [
            f'recognize defensive deformation family: {family_id}',
            'restore last trusted DKT/state checkpoint locally',
            'preserve hostile ingress geometry as bounded defensive sentinel only',
            'preserve evidence digest and quarantine provenance',
        ]
        for rule in rules:
            if rule not in defense.hardened_rules:
                defense.hardened_rules.append(rule)

        evidence_payload = json.dumps({
            'changes': changes,
            'violations': decision.violated_invariants,
            'source_fingerprint': source_fingerprint,
            'family_id': family_id,
            'ingress_knot_signature': deformation_knot.invariant_signature if deformation_knot else '',
        }, sort_keys=True, separators=(',', ':'))
        m = defense_math_state
        deliberation = DefensiveDeliberationRecord(
            source_event_id=source_event_id,
            source_fingerprint=source_fingerprint,
            family_id=family_id,
            recurrence_count=count,
            reflexive_invariants=list(family_violations),
            irg_response_potential=(float(m.irg.response_potential) if m is not None else 0.0),
            irg_entropy_source=(float(m.irg.entropy_source) if m is not None else 0.0),
            irg_topology_response=(float(m.irg.topology_response) if m is not None else 0.0),
            dkt_ingress_signature=(deformation_knot.invariant_signature if deformation_knot is not None else ''),
            dkt_geodesic_displacement=(float(m.dkt.geodesic_displacement) if m is not None else 0.0),
            egr_entropy_production=(float(m.egr.entropy_production) if m is not None else 0.0),
            egr_active_regions=(list(m.egr.simultaneous_active_regions) if m is not None else []),
            rl_coordinates=(list(m.rl.coordinates) if m is not None else []),
            rl_scalar_curvature=(float(m.rl.scalar_curvature) if m is not None else 0.0),
            frenet_curvature=(float(m.frenet.first_curvature) if m is not None else 0.0),
            candidate_action_scores={},
            candidate_plan_objectives={k:float(v) for k,v in plan_objectives.items()},
            candidate_consequence_distances={k:float(v) for k,v in selection_meta['candidate_consequence_distances'].items()},
            selected_adaptive_actions=list(selected),
            selected_plan_objective=float(plan_objective),
            selected_consequence_distance=float(selection_meta['selected_consequence_distance']),
            minimum_candidate_plans=list(selection_meta['minimum_candidate_plans']),
            native_selection_status=selection_meta['native_selection_status'],
            actuator_realization_layer=selection_meta['actuator_realization_layer'],
            preference_learning_actions=list(selection_meta['preference_learning_actions']),
            need_coordinates={}, selected_plan_profile={},
            pre_action_state={k:float(v) for k,v in pre_action_state.items()},
            trusted_reference_state={k:float(v) for k,v in trusted_reference_state.items()},
            candidate_post_action_states={k:{kk:float(vv) for kk,vv in v.items()} for k,v in candidate_post_action_states.items()},
            selected_post_action_state={k:float(v) for k,v in selected_post_action_state.items()},
            candidate_preference_mismatch={k:float(v) for k,v in candidate_preference_mismatch.items()},
            preference_state_before={}, preference_state_after={},
            preference_geometry_before=outcome_pref_before, preference_geometry_after=outcome_pref_after,
            policy_mode='consequence-simulation-outcome-learning-v0.7.3.4',
            explanation_facts=[
                f'family={family_id}', f'recurrence={count}',
                'IRG interpreted untrusted environmental ingress before trusted-state mutation',
                'IRG/DKT/EGR/RL/Frenet state supplied observed causal coordinates without an authored defensive need field',
                'all safe affordance combinations were consequence-simulated and compared to trusted operation by one metric',
                f'protected={",".join(family_violations)}',
                f'selected={",".join(selected) if selected else "reflexive-floor-only"}',
                f'objective={plan_objective:.6f}',
                f'native_selection_status={selection_meta["native_selection_status"]}',
                f'actuator_realization_layer={selection_meta["actuator_realization_layer"]}',
                'current selection is not used as a preference-training label; learning waits for a later observed same-family consequence',
                f'prior_outcome_learning={outcome_learning_status}',
            ],
        )
        defense.deliberation_history = (defense.deliberation_history + [deliberation])[-256:]

        record = QuarantineGeometryRecord(
            id=(decision.quarantine_id or uuid4()),
            deformation_signature=exact_sig,
            family_id=family_id,
            violated_invariants=list(decision.violated_invariants),
            proposed_changes=changes,
            source_fingerprint=source_fingerprint,
            threat_score=threat,
            ingress_hs_distance=float(ingress_hs),
            nearest_family_hs_distance=family_distance,
            hostile_ingress_knot=deepcopy(deformation_knot),
            defensive_signature_knot=deepcopy(defense.deformation_family_knots.get(family_id)),
            retraction_hs_distance=float(retract_hs),
            neutralized=True,
            neutralization_method='aggressive local quarantine + checkpoint retraction + bounded DKT defensive-sentinel learning',
            recurrence_count=count,
            safe_response_rules=rules,
            action_ids=[a.id for a in actions],
            evidence_digest=hashlib.sha256(evidence_payload.encode()).hexdigest(),
        )
        defense.quarantine_records = (defense.quarantine_records + [record])[-128:]
        defense.action_history = (defense.action_history + actions)[-512:]
        defense.neutralized_count += 1
        defense.last_quarantine_id = record.id
        defense.version = '0.7.3.4'
        defense.schema_version = '0.7.3.4'
        defense.mechanism_version = '0.7.3.4'
        defense.policy_mode = 'consequence-simulation-outcome-learning-v0.7.3.4'
        restored.cognition.defense = defense
        self._checkpoint = deepcopy(restored)
        return restored

    def release_local_containment(
        self,
        state: NoeronState,
        *,
        source_fingerprint: str = '',
        clear_fail_closed: bool = False,
    ) -> NoeronState:
        """Owner-controlled release of local containment; history/evidence is preserved."""
        out = deepcopy(state)
        d = out.cognition.defense
        if source_fingerprint:
            d.blocked_source_fingerprints = [x for x in d.blocked_source_fingerprints if x != source_fingerprint]
        if clear_fail_closed:
            d.fail_closed = False
            d.containment_level = 'guard'
        d.action_history = (d.action_history + [DefensiveActionRecord(
            action_type='owner-release-local-containment', target=source_fingerprint or 'fail-closed', status='executed',
            reason='Cryptographically authenticated owner released a local containment condition.',
            source_fingerprint=source_fingerprint,
        )])[-512:]
        self._checkpoint = deepcopy(out)
        return out

    def restore(self):
        return deepcopy(self._checkpoint)

    def audit(self, state: NoeronState) -> dict:
        d = state.cognition.defense
        return {
            'version': d.version,
            'schema_version': d.schema_version,
            'mechanism_version': d.mechanism_version,
            'local_enforcement_mode': d.local_enforcement_mode,
            'containment_level': d.containment_level,
            'fail_closed': d.fail_closed,
            'blocked_source_fingerprints': list(d.blocked_source_fingerprints),
            'neutralized_count': d.neutralized_count,
            'deformation_family_counts': dict(d.deformation_family_counts),
            'deformation_family_invariants': {k:list(v) for k,v in d.deformation_family_invariants.items()},
            'defensive_family_count': len(d.deformation_family_knots),
            'hardened_rules': list(d.hardened_rules[-64:]),
            'last_threat_score': d.last_threat_score,
            'last_quarantine_id': str(d.last_quarantine_id) if d.last_quarantine_id else None,
            'recent_actions': [x.model_dump(mode='json') for x in d.action_history[-40:]],
            'legacy_response_preferences_unused_for_choice': dict(d.response_preferences),
            'action_preference_knots': {k:self._knot_geometry_digest(v) for k,v in d.action_preference_knots.items()},
            'action_preference_observations': dict(d.action_preference_observations),
            'active_preference_training_authority':'observed post-action improvement only; current selection is never a training label',
            'legacy_selection_preference_knots_unused_for_choice': {k:self._knot_geometry_digest(v) for k,v in d.legacy_selection_preference_knots.items()},
            'legacy_selection_preference_observations_unused_for_choice': dict(d.legacy_selection_preference_observations),
            'policy_mode': d.policy_mode,
            'primitive_safe_affordances': {k:dict(v) for k,v in self.SAFE_AFFORDANCES.items()},
            'recent_deliberations': [x.model_dump(mode='json') for x in d.deliberation_history[-20:]],
            'reflexive_floor':['quarantine rejected ingress','freeze protected-invariant mutation','restore trusted checkpoint','preserve evidence/provenance','register bounded deformation family'],
            'deliberative_path':'IRG environmental interpretation -> DKT geometry/memory -> regional EGR -> RL/Frenet -> empirical pre-action state -> simulate each safe primitive consequence -> compare predicted state to trusted operation + outcome-trained DKT action-preference geometry; later observed same-family consequence supplies prediction error and may train preference geometry',
            'records': [x.model_dump(mode='json') for x in d.quarantine_records[-20:]],
            'automatic_local_actions': [
                'quarantine hostile ingress',
                'freeze protected transition',
                'restore trusted DKT/state checkpoint',
                'preserve quarantine evidence/provenance',
                'learn bounded defensive DKT sentinel/family',
                'select minimum post-action geometry by the common consequence objective; distinguish native unique minima from programmed realization/tie handling',
                'block unprivileged hostile source fingerprint when present in the selected plan',
                'enter fail-closed guard when present in the selected plan',
            ],
            'platform_adapter_status': 'Noeron-runtime enforcement is live; OS firewall/service/container adapters are not silently assumed or claimed.',
            'external_retaliation_enabled': False,
            'external_intrusion_capability': False,
            'note': d.note,
        }
