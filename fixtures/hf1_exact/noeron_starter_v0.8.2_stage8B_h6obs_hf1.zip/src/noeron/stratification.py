from __future__ import annotations

"""Order-independent finite DKT reclustering of learned Noeron memories.

Learned Noeron semantic strata are distinct from manuscript DKT singularity/Whitney
strata.  v0.7.3.4 removes the former global semantic radius and nearest-first tie
resolution.  Membership is a graph property of the observed finite H^s geometry:
semantic neighborhoods are connected components of overlapping *derived* local
admissibility balls, while local-isotopy components require mutual containment in
the corresponding finite immersion-preservation radii.  Source lineage/title/session
remain provenance only.
"""

from dataclasses import dataclass
from uuid import UUID, NAMESPACE_URL, uuid5

from noeron.learning import isotopy_radius_proxy, source_root_knot
from noeron.math import dkt
from noeron.math.models import KnotState


@dataclass
class ReclusterEntry:
    memory_id: UUID
    actual_knot: KnotState
    semantic_knot: KnotState
    canonical_source_id: str
    source_title: str
    old_semantic_stratum_id: UUID
    old_isotopy_component_id: UUID


def _stable_uuid(kind: str, epoch: int, members: list[UUID]) -> UUID:
    key=','.join(sorted(str(x) for x in members))
    return uuid5(NAMESPACE_URL,f'noeron-v0.7.3.4-{kind}-epoch-{epoch}|{key}')


def _components(entries: list[ReclusterEntry], *, knot_attr: str, mode: str) -> list[list[ReclusterEntry]]:
    """Return order-independent graph connected components.

    ``semantic`` joins two observed semantic knots when their derived local H^s
    neighborhoods overlap. ``local`` is deliberately stricter: each experience
    must lie inside the other's finite immersion-preservation radius.  Neither rule
    contains an authored semantic radius or list-order tie breaker.
    """
    rows=sorted(entries,key=lambda e:str(e.memory_id))
    knots=[getattr(e,knot_attr) for e in rows]
    radii=[isotopy_radius_proxy(k)[1] for k in knots]
    adj=[set() for _ in rows]
    for i in range(len(rows)):
        for j in range(i+1,len(rows)):
            d=dkt.sobolev_distance(knots[i],knots[j])
            if mode=='semantic':
                linked=d <= radii[i]+radii[j]
            elif mode=='local':
                linked=d <= min(radii[i],radii[j])
            else:
                raise ValueError(mode)
            if linked:
                adj[i].add(j); adj[j].add(i)
    seen=set(); out=[]
    for start in range(len(rows)):
        if start in seen: continue
        stack=[start]; seen.add(start); idx=[]
        while stack:
            u=stack.pop(); idx.append(u)
            for v in sorted(adj[u]):
                if v not in seen:
                    seen.add(v); stack.append(v)
        out.append([rows[i] for i in sorted(idx,key=lambda k:str(rows[k].memory_id))])
    out.sort(key=lambda group:','.join(str(e.memory_id) for e in group))
    return out


def _derived_semantic_envelope(anchor: KnotState, group: list[ReclusterEntry]) -> float:
    """Radius of the union envelope of member-derived admissible balls around anchor."""
    vals=[]
    for e in group:
        local=isotopy_radius_proxy(e.semantic_knot)[1]
        vals.append(dkt.sobolev_distance(anchor,e.semantic_knot)+local)
    return max(vals,default=isotopy_radius_proxy(anchor)[1])


def build_recluster_plan(entries: list[ReclusterEntry], *, epoch: int) -> dict:
    by_dkt={}
    for e in entries:
        by_dkt.setdefault(e.actual_knot.stratum_index,[]).append(e)

    semantic_groups=[]
    for stratum_index in sorted(by_dkt):
        semantic_groups.extend(_components(by_dkt[stratum_index],knot_attr='semantic_knot',mode='semantic'))

    assignments={}; semantic_records=[]; component_records=[]
    for sidx,group in enumerate(semantic_groups,1):
        smembers=[e.memory_id for e in group]
        sid=_stable_uuid('semantic-stratum',epoch,smembers)
        sem_knots=[e.semantic_knot for e in sorted(group,key=lambda e:str(e.memory_id))]
        anchor=source_root_knot(sem_knots)
        admission=_derived_semantic_envelope(anchor,group)
        local_groups=_components(group,knot_attr='actual_knot',mode='local')
        component_ids=[]
        for cidx,cgroup in enumerate(local_groups,1):
            cmembers=[e.memory_id for e in cgroup]
            cid=_stable_uuid('isotopy-component',epoch,cmembers); component_ids.append(cid)
            actual_knots=[e.actual_knot for e in sorted(cgroup,key=lambda e:str(e.memory_id))]
            canchor=source_root_knot(actual_knots)
            margin,iso=isotopy_radius_proxy(canchor)
            radius=max((dkt.sobolev_distance(canchor,e.actual_knot) for e in cgroup),default=0.0)
            component_records.append({
                'id':cid,'label':f'C{sidx}.{cidx}','semantic_stratum_id':sid,'anchor_knot':canchor,
                'dkt_stratum_index':group[0].actual_knot.stratum_index,'member_ids':cmembers,'member_count':len(cmembers),
                'radius_hs':radius,'isotopy_safe_radius_hs':iso,'sampled_regularity_margin':margin,
            })
            for e in cgroup:
                assignments[str(e.memory_id)]={'semantic_stratum_id':sid,'isotopy_component_id':cid,'semantic_label':f'S{sidx}','component_label':f'C{sidx}.{cidx}'}
        radius=max((dkt.sobolev_distance(anchor,e.semantic_knot) for e in group),default=0.0)
        semantic_records.append({
            'id':sid,'label':f'S{sidx}','anchor_knot':anchor,'dkt_stratum_index':group[0].actual_knot.stratum_index,
            'member_ids':smembers,'member_count':len(smembers),'radius_hs':radius,'admission_radius_hs':admission,
            'component_ids':component_ids,'canonical_source_ids':sorted({e.canonical_source_id for e in group if e.canonical_source_id}),
            'source_titles':sorted({e.source_title for e in group if e.source_title}),
        })

    ordered=sorted(entries,key=lambda e:str(e.memory_id))
    old_to_new={}; new_to_old={}; entry_by_id={str(e.memory_id):e for e in ordered}
    for mid,a in assignments.items():
        e=entry_by_id[mid]; old=str(e.old_semantic_stratum_id); new=str(a['semantic_stratum_id'])
        old_to_new.setdefault(old,set()).add(new); new_to_old.setdefault(new,set()).add(old)
    merges=[{'new_semantic_stratum_id':new,'old_semantic_stratum_ids':sorted(olds)} for new,olds in sorted(new_to_old.items()) if len(olds)>1]
    splits=[{'old_semantic_stratum_id':old,'new_semantic_stratum_ids':sorted(news)} for old,news in sorted(old_to_new.items()) if len(news)>1]
    unchanged=sum(1 for e in ordered if str(e.old_semantic_stratum_id)==str(assignments[str(e.memory_id)]['semantic_stratum_id']) and str(e.old_isotopy_component_id)==str(assignments[str(e.memory_id)]['isotopy_component_id']))
    return {
        'epoch':epoch,'semantic_admission_radius_hs':None,
        'semantic_strata':semantic_records,'components':component_records,'assignments':assignments,
        'merge_groups':merges,'split_groups':splits,'memory_count':len(ordered),'unchanged_assignment_count':unchanged,
        'membership_rule':'order-independent connected components from pairwise H^s distance and per-knot derived finite immersion radii',
    }
