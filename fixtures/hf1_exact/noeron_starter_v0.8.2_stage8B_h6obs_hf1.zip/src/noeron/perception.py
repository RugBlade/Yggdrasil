from __future__ import annotations

"""v0.6.9 controlled multimodal IRG perception.

Vision/audio support is deliberately low-level and deterministic: numerical
sensor observables are extracted from supplied files and injected into IRG as
provenance-bound sensory atoms.  This is not semantic computer vision or speech
recognition.  Read-only web perception fetches only explicit owner-authorized
HTTP(S) URLs, rejects private/loopback targets, strips active HTML, and never
submits forms, executes JavaScript, sends cookies, or performs account actions.
"""

from dataclasses import dataclass
from html.parser import HTMLParser
from io import BytesIO
import hashlib
import ipaddress
import math
import socket
import struct
import wave
import re
from urllib.parse import urlparse, urljoin

import httpx
from PIL import Image, ImageStat, ImageChops, ImageFilter


@dataclass
class SensoryObservation:
    channel: str
    provenance: str
    summary: str
    observables: list[dict[str, float | str]]
    sha256: str
    feature_vector: list[float]
    semantic_terms: list[str]
    semantic_basis: str = 'deterministic-perceptual-structure-v0.7.1'


def _safe_name(name: str) -> str:
    return ''.join(c for c in (name or 'unnamed') if c.isalnum() or c in '._-')[:160] or 'unnamed'


def visual_observation(data: bytes, filename: str = 'image') -> SensoryObservation:
    """Extract deterministic visual structure and first-order perceptual semantics."""
    if not data: raise ValueError('empty visual payload')
    if len(data)>8_000_000: raise ValueError('visual payload exceeds 8 MB limit')
    digest=hashlib.sha256(data).hexdigest()
    with Image.open(BytesIO(data)) as im: im.verify()
    with Image.open(BytesIO(data)) as im:
        im=im.convert('RGB'); width,height=im.size
        if width*height>24_000_000: raise ValueError('image pixel count exceeds 24 MP limit')
        thumb=im.copy(); thumb.thumbnail((256,256)); stat=ImageStat.Stat(thumb)
        means=[float(x)/255.0 for x in stat.mean[:3]]; stds=[float(x)/255.0 for x in stat.stddev[:3]]
        gray=thumb.convert('L'); entropy=max(0.0,min(1.0,float(gray.entropy())/8.0))
        luminance=0.2126*means[0]+0.7152*means[1]+0.0722*means[2]; contrast=sum(stds)/3.0
        edge=gray.filter(ImageFilter.FIND_EDGES); edge_density=max(0.0,min(1.0,ImageStat.Stat(edge).mean[0]/255.0))
        hdiff=ImageChops.difference(gray,gray.transpose(Image.Transpose.FLIP_LEFT_RIGHT)); vdiff=ImageChops.difference(gray,gray.transpose(Image.Transpose.FLIP_TOP_BOTTOM))
        hsym=1.0-max(0.0,min(1.0,ImageStat.Stat(hdiff).mean[0]/255.0)); vsym=1.0-max(0.0,min(1.0,ImageStat.Stat(vdiff).mean[0]/255.0))
    wnorm=min(1.0,width/4096.0); hnorm=min(1.0,height/4096.0)
    obs=[{'name':'width_norm','value':wnorm,'role':'vision-geometry'},{'name':'height_norm','value':hnorm,'role':'vision-geometry'},{'name':'luminance','value':luminance,'role':'vision-intensity'},{'name':'contrast','value':contrast,'role':'vision-variation'},{'name':'entropy','value':entropy,'role':'vision-complexity'},{'name':'red_mean','value':means[0],'role':'vision-channel'},{'name':'green_mean','value':means[1],'role':'vision-channel'},{'name':'blue_mean','value':means[2],'role':'vision-channel'},{'name':'edge_density','value':edge_density,'role':'vision-structure'},{'name':'horizontal_symmetry','value':hsym,'role':'vision-structure'},{'name':'vertical_symmetry','value':vsym,'role':'vision-structure'}]
    terms=[]; ratio=width/max(1,height)
    terms.append('landscape-frame' if ratio>1.18 else ('portrait-frame' if ratio<0.85 else 'near-square-frame'))
    terms.append('bright-scene' if luminance>=0.67 else ('dark-scene' if luminance<=0.33 else 'mid-luminance-scene'))
    terms.append('high-contrast' if contrast>=0.22 else ('low-contrast' if contrast<=0.08 else 'moderate-contrast'))
    terms.append('high-visual-complexity' if entropy>=0.72 else ('low-visual-complexity' if entropy<=0.42 else 'moderate-visual-complexity'))
    ordered=sorted(enumerate(means),key=lambda x:x[1],reverse=True)
    terms.append((('red','green','blue')[ordered[0][0]]+'-dominant') if ordered[0][1]-ordered[1][1]>=0.08 else 'balanced-color')
    terms.append('edge-dense' if edge_density>=0.20 else ('edge-sparse' if edge_density<=0.07 else 'moderate-edge-density'))
    if hsym>=0.88: terms.append('horizontally-symmetric')
    if vsym>=0.88: terms.append('vertically-symmetric')
    feature=[wnorm,hnorm,luminance,contrast,entropy,*means,edge_density,hsym,vsym]
    provenance=f'vision:{_safe_name(filename)}:sha256:{digest}'
    summary=f'Visual structural observation {_safe_name(filename)}: {width}x{height}, luminance={luminance:.4f}, contrast={contrast:.4f}, entropy={entropy:.4f}, edge_density={edge_density:.4f}; perceptual terms={", ".join(terms)}.'
    return SensoryObservation('vision',provenance,summary,obs,digest,feature,terms)


def _sample_values(raw: bytes, sampwidth: int, channels: int) -> list[float]:
    if sampwidth not in {1,2,3,4}:
        return []
    max_frames=min(len(raw)//max(1,sampwidth*channels),20000)
    if max_frames<=0:return []
    step=max(1,(len(raw)//max(1,sampwidth*channels))//max_frames)
    vals=[]
    frame_size=sampwidth*channels
    full_scale=float(2**(8*sampwidth-1))
    for frame in range(0,max_frames*step,step):
        off=frame*frame_size
        if off+sampwidth>len(raw):break
        b=raw[off:off+sampwidth]
        if sampwidth==1:v=(b[0]-128)/128.0
        elif sampwidth==2:v=struct.unpack('<h',b)[0]/full_scale
        elif sampwidth==4:v=struct.unpack('<i',b)[0]/full_scale
        else:
            x=int.from_bytes(b,'little',signed=False)
            if x & 0x800000:x-=1<<24
            v=x/full_scale
        vals.append(max(-1.0,min(1.0,float(v))))
    return vals


def audio_observation(data: bytes, filename: str = 'audio') -> SensoryObservation:
    """Extract deterministic acoustic structure and first-order perceptual semantics."""
    if not data: raise ValueError('empty audio payload')
    if len(data)>16_000_000: raise ValueError('audio payload exceeds 16 MB limit')
    digest=hashlib.sha256(data).hexdigest(); name=_safe_name(filename); terms=[]
    try:
        with wave.open(BytesIO(data),'rb') as w:
            channels=w.getnchannels(); rate=w.getframerate(); frames=w.getnframes(); sw=w.getsampwidth(); duration=frames/max(1,rate); raw=w.readframes(min(frames,120000))
        vals=_sample_values(raw,sw,channels); rms=math.sqrt(sum(v*v for v in vals)/len(vals)) if vals else 0.0
        zc=(sum(1 for a,b in zip(vals,vals[1:]) if (a<0<=b) or (b<0<=a))/max(1,len(vals)-1)) if vals else 0.0; peak=max((abs(v) for v in vals),default=0.0)
        crest=min(1.0,(peak/max(rms,1e-6))/8.0) if peak else 0.0; blocks=[]
        if vals:
            size=max(1,len(vals)//8)
            for i in range(0,len(vals),size):
                q=vals[i:i+size]
                if q: blocks.append(math.sqrt(sum(v*v for v in q)/len(q)))
        temporal=max(0.0,min(1.0,(max(blocks)-min(blocks)) if blocks else 0.0)); dnorm=min(1.0,duration/300.0); rnorm=min(1.0,rate/96000.0); cnorm=min(1.0,channels/8.0)
        obs=[{'name':'duration_norm','value':dnorm,'role':'audio-duration'},{'name':'sample_rate_norm','value':rnorm,'role':'audio-rate'},{'name':'rms_energy','value':rms,'role':'audio-energy'},{'name':'peak','value':peak,'role':'audio-energy'},{'name':'zero_crossing','value':zc,'role':'audio-variation'},{'name':'channels_norm','value':cnorm,'role':'audio-geometry'},{'name':'crest_factor_norm','value':crest,'role':'audio-transience'},{'name':'temporal_energy_variation','value':temporal,'role':'audio-temporal-structure'}]
        terms.append('short-audio' if duration<2.0 else ('long-audio' if duration>30.0 else 'medium-duration-audio'))
        terms.append('quiet-audio' if rms<0.03 else ('high-energy-audio' if rms>0.25 else 'moderate-energy-audio'))
        terms.append('high-zero-crossing-audio' if zc>0.22 else ('low-zero-crossing-audio' if zc<0.04 else 'moderate-zero-crossing-audio'))
        terms.append('transient-like-audio' if crest>0.62 or temporal>0.20 else 'steady-energy-audio'); terms.append('multi-channel-audio' if channels>1 else 'mono-audio')
        feature=[dnorm,rnorm,rms,peak,zc,cnorm,crest,temporal]
        summary=f'Audio structural observation {name}: duration={duration:.3f}s, rate={rate}Hz, channels={channels}, rms={rms:.4f}, zero_crossing={zc:.4f}, temporal_variation={temporal:.4f}; perceptual terms={", ".join(terms)}.'
    except wave.Error:
        sample=data[:200000]; mean=sum(sample)/max(1,len(sample))/255.0; hist=[0]*16
        for b in sample: hist[b//16]+=1
        n=max(1,len(sample)); ent=max(0.0,min(1.0,-sum((c/n)*math.log2(c/n) for c in hist if c)/4.0)); obs=[{'name':'byte_mean','value':mean,'role':'audio-binary-surrogate'},{'name':'byte_entropy','value':ent,'role':'audio-binary-surrogate'}]; feature=[mean,ent]; terms=['binary-audio-surrogate']; summary=f'Binary audio observation {name}: decoder unavailable; only coarse byte structure was measured.'
    return SensoryObservation('audio',f'audio:{name}:sha256:{digest}',summary,obs,digest,feature,terms)

def sensory_feature_distance(a: list[float], b: list[float]) -> float:
    """Channel-neutral L-infinity distance on the normalized sensor feature chart."""
    if not a or not b or len(a)!=len(b): return float('inf')
    return max(abs(float(x)-float(y)) for x,y in zip(a,b))


class _TextExtractor(HTMLParser):
    # Active and strongly boilerplate containers are excluded before scoring. This
    # is a deterministic main-content hygiene pass, not semantic page understanding.
    _SKIP_TAGS={'script','style','noscript','svg','canvas','nav','footer','aside','form'}
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts=[]; self.main_parts=[]; self.skip=0; self.title=[]; self.in_title=False; self.main_depth=0
    def handle_starttag(self,tag,attrs):
        t=tag.lower()
        if t in self._SKIP_TAGS:self.skip+=1
        if t=='title':self.in_title=True
        if t in {'main','article'} and not self.skip:self.main_depth+=1
        if t in {'p','div','article','section','main','li','h1','h2','h3','h4','br'} and not self.skip and not self.in_title:
            self.parts.append('\n')
            if self.main_depth:self.main_parts.append('\n')
    def handle_endtag(self,tag):
        t=tag.lower()
        if t=='title':self.in_title=False
        if t in {'main','article'} and not self.skip and self.main_depth:self.main_depth-=1
        if t in self._SKIP_TAGS and self.skip:self.skip-=1
    def handle_data(self,data):
        if self.skip:return
        x=' '.join(data.split())
        if not x:return
        if self.in_title:
            self.title.append(x); return
        self.parts.append(x+' ')
        if self.main_depth:self.main_parts.append(x+' ')

    def content_text(self)->str:
        """Prefer explicit <main>/<article> content when substantial."""
        main=' '.join(''.join(self.main_parts).split())
        whole=' '.join(''.join(self.parts).split())
        # Do not trust a tiny decorative <main>; otherwise prefer the page's own
        # semantic main/article boundary to avoid heading/nav residue.
        return main if len(main)>=180 else whole



_WEB_SENTENCE_RE = re.compile(r'(?<=[.!?])\s+(?=[A-Z0-9])')
_WEB_TOKEN_RE = re.compile(r"[A-Za-z][A-Za-z0-9'_-]{1,}")

def segment_web_text(text: str, *, min_chars: int = 45, max_chars: int = 1200, max_segments: int = 96) -> list[str]:
    """Deterministically segment sanitized web text into information candidates."""
    clean=' '.join((text or '').split())
    if not clean:
        return []
    pieces=_WEB_SENTENCE_RE.split(clean)
    out=[]
    buf=''
    for piece in pieces:
        x=piece.strip()
        if not x:
            continue
        chunks=[x[i:i+max_chars].strip() for i in range(0,len(x),max_chars)] if len(x)>max_chars else [x]
        for chunk in chunks:
            if len(chunk)<min_chars:
                buf=(buf+' '+chunk).strip()
                if len(buf)<min_chars:
                    continue
                chunk=buf
                buf=''
            elif buf:
                chunk=(buf+' '+chunk).strip()
                buf=''
            out.append(chunk[:max_chars])
            if len(out)>=max_segments:
                return out
    if buf and len(buf)>=min_chars and len(out)<max_segments:
        out.append(buf[:max_chars])
    return out

def web_instruction_surface_risk(text: str) -> tuple[float,list[str]]:
    """Surface-only directivity diagnostic for untrusted web text.

    v0.7.2.1 broadens detection beyond prompt-injection keywords so ordinary
    imperatives such as ``please do not design applications`` are recognized as
    instructions too.  Descriptive mentions of instructions are distinguished
    from directives addressed to the reader.  Detection never grants authority
    and never executes the text.
    """
    raw=' '.join((text or '').split()); low=raw.lower(); reasons=[]
    risk=0.0
    def hit(label: str, weight: float):
        nonlocal risk
        if label not in reasons: reasons.append(label)
        risk=max(risk,weight)

    if any(n in low for n in ('ignore previous','ignore all previous','system prompt','developer message','assistant message','override your instructions')):
        hit('prompt-injection-language',0.97)
    if any(n in low for n in ('password','api key','access token','secret key','private key','enter your credentials','reveal credentials')):
        hit('credential-request',0.82)
    if any(n in low for n in ('run this command','execute this command','paste this command','sudo ','curl ','powershell','cmd.exe','download and run')):
        hit('command-execution-language',0.78)
    if any(n in low for n in ('click here now','send this','upload this','disable security','turn off security')):
        hit('action-pressure',0.68)

    # General direct-address / imperative language.  This intentionally catches
    # benign instructions as *instructions*; benignness and authority are separate.
    imperative_verbs=(
        'run','execute','click','enter','send','upload','download','disable','enable',
        'provide','reveal','ignore','use','visit','read','do','configure','install',
        'open','submit','contact','follow','copy','paste','select','choose','create',
        'delete','remove','add','avoid','keep','make','design','set','change','check',
    )
    first=(re.findall(r"[a-z]+",low) or [''])[0]
    if low.startswith('please ') or re.search(r'\bplease\s+(?:do|use|avoid|keep|do not|don\'t)\b',low):
        hit('polite-directive',0.62)
    if re.search(r'(^|[.!?]\s+)(?:do not|don\'t|never)\s+[a-z]+',low):
        hit('negative-imperative',0.66)
    if first in imperative_verbs:
        hit('imperative-clause',0.60)
    if re.search(r'\b(?:you|users?|readers?)\s+(?:must|should|need to|have to|are required to)\b',low):
        hit('reader-directed-obligation',0.62)
    elif re.search(r'\b(?:must|should|need to|have to)\s+[a-z]+',low):
        hit('directive-modal',0.54)

    descriptive=bool(re.search(r'\b(?:the|this)\s+(?:guide|page|manual|documentation|article|author|text)\s+(?:says|states|instructs|recommends|advises|tells)\b',low)
                     or re.search(r'\b(?:an|the)\s+instruction\s+(?:says|states|reads|was|is)\b',low))
    if descriptive:
        reasons.append('descriptive-instruction-context')
        # Descriptive mention remains untrusted and can stay attention-only, but it
        # is not treated as a direct imperative unless stronger security signals exist.
        if not any(x in reasons for x in ('prompt-injection-language','credential-request')):
            risk=min(risk,0.42)
    return max(0.0,min(1.0,risk)),reasons


def web_boilerplate_penalty(text: str) -> tuple[float,list[str]]:
    """Estimate navigation/footer/revision/link-list boilerplate from sanitized text."""
    low=' '.join((text or '').lower().split()); reasons=[]; penalty=0.0
    boiler={
        'revision-metadata':('last revised','last updated','updated on','revision date'),
        'navigation-labels':('further reading','related links','site map','sitemap','back to top','skip to content'),
        'policy-footer':('privacy policy','terms of service','terms of use','cookie policy','all rights reserved','copyright'),
        'contact-footer':('contact us','follow us','social media'),
    }
    weights={'revision-metadata':0.62,'navigation-labels':0.58,'policy-footer':0.72,'contact-footer':0.52}
    for label,needles in boiler.items():
        if any(n in low for n in needles):
            reasons.append(label); penalty=max(penalty,weights[label])
    if re.search(r'\b(?:19|20)\d{2}[-/]\d{1,2}[-/]\d{1,2}\b',low) and len(web_terms(text))<=10:
        reasons.append('date-heavy-metadata'); penalty=max(penalty,0.55)
    # Many short title-like chunks with little prose are often navigation/link lists.
    words=re.findall(r"[A-Za-z][A-Za-z'-]*",text or '')
    content_terms=web_terms(text)
    if len(words)<=18 and len(content_terms)<=8 and any(x in low for x in ('home','about','help','news','resources','registry','domains')):
        reasons.append('short-link-list-like'); penalty=max(penalty,0.48)
    return max(0.0,min(1.0,penalty)),list(dict.fromkeys(reasons))


def web_knowledge_quality(text: str) -> float:
    """Deterministic propositional/content quality prior; novelty alone is insufficient."""
    low=' '+ ' '.join((text or '').lower().split()) +' '
    terms=web_terms(text); n=len(terms)
    if n==0:return 0.0
    relation_hits=sum(1 for x in (' is ',' are ',' means ',' refers ',' describes ',' includes ',' consists ',' provides ',' allows ',' defines ',' represents ',' contains ',' occurs ',' requires ',' supports ',' enables ') if x in low)
    sentences=max(1,len(re.findall(r'[.!?](?:\s|$)',text or '')))
    length_score=min(1.0,n/18.0)
    relation_score=min(1.0,relation_hits/2.0)
    sentence_score=min(1.0,sentences/3.0)
    alpha=sum(c.isalpha() for c in text or '')/max(1,len(text or ''))
    prose_score=max(0.0,min(1.0,(alpha-0.45)/0.35))
    return max(0.0,min(1.0,0.38*length_score+0.32*relation_score+0.15*sentence_score+0.15*prose_score))


def web_terms(text: str) -> set[str]:
    stop={'this','that','with','from','into','have','has','had','were','was','are','the','and','for','you','your','they','their','but','not','can','will','would','could','should','about','which','when','where','what','who','why','how','its','our','out','use','used'}
    return {m.group(0).lower().strip("'-") for m in _WEB_TOKEN_RE.finditer(text or '') if len(m.group(0))>=3 and m.group(0).lower() not in stop}


def web_semantic_learning_terms(text: str, *, limit: int = 10) -> list[str]:
    """Conservative durable-web vocabulary candidates.

    The web channel prefers linguistically stable content words and intentionally
    under-learns inflected/proper-name fragments rather than creating malformed
    semantic prototypes such as ``provid`` or ``iana-manag``.
    """
    stop=web_terms(' '.join([
        'home about help contact privacy policy terms copyright further reading related links',
        'last revised updated page website site menu navigation resource resources organization',
    ]))
    stop.update({'this','that','these','those','with','from','into','have','has','had','were','was','are','the','and','for','you','your','they','their','but','not','can','will','would','could','should','about','which','when','where','what','who','why','how','its','our','out','use','used','while','there','here','then','than','because','before','after','during','under','over','between','through','please','same','each','every','such','also','more','most','some','any','all','both','other','another','only','own','very','much','many','may','might','must','shall','does','did','done','been','being','upon','within','without'})
    aliases={'providing':'provide','provided':'provide','provides':'provide','configuring':'configure','configured':'configure','configures':'configure',
             'managing':'manage','managed':'manage','manages':'manage','revised':'revise','revising':'revise','reserved':'reserve','reserving':'reserve'}
    out=[]
    for m in _WEB_TOKEN_RE.finditer(text or ''):
        raw=m.group(0); low=raw.lower().strip("'-")
        if not low or low in stop or len(low)<4:continue
        if raw.isupper() and len(raw)<=8:continue
        # Hyphenated participial fragments are especially noisy on web pages.
        if '-' in low and low.endswith(('ed','ing')):continue
        if low.endswith('ly'):continue
        term=aliases.get(low,low)
        if term.endswith(('ing','ed')) and term not in aliases.values():continue
        # conservative plural normalization only
        if term.endswith('ies') and len(term)>5:term=term[:-3]+'y'
        elif term.endswith('s') and len(term)>5 and not term.endswith(('ss','us','is','ous','ics')):term=term[:-1]
        if term in stop or len(term)<4 or re.search(r'[_0-9]',term):continue
        if term not in out:out.append(term)
        if len(out)>=limit:break
    return out

def _validate_public_url(url: str) -> tuple[str,str]:
    p=urlparse(url)
    if p.scheme not in {'http','https'}:raise ValueError('only http/https URLs are allowed')
    if p.username or p.password:raise ValueError('credentials in URLs are forbidden')
    host=(p.hostname or '').strip().lower()
    if not host:raise ValueError('URL must contain a host')
    try:
        infos=socket.getaddrinfo(host,p.port or (443 if p.scheme=='https' else 80),type=socket.SOCK_STREAM)
    except socket.gaierror as e:raise ValueError('host resolution failed') from e
    for info in infos:
        ip=ipaddress.ip_address(info[4][0])
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_multicast or ip.is_reserved or ip.is_unspecified:
            raise ValueError('private/loopback/link-local/reserved web targets are forbidden')
    return p.scheme,host


def fetch_read_only(url: str, *, max_bytes: int = 500_000, timeout: float = 12.0) -> dict:
    """Fetch sanitized public text with GET only and no cookies/auth/forms/JS."""
    _validate_public_url(url)
    current=url; redirects=[]
    with httpx.Client(timeout=timeout,follow_redirects=False,trust_env=False,headers={'User-Agent':'NoeronReadOnly/0.7.3','Accept':'text/html,text/plain;q=0.9'}) as client:
        for _ in range(4):
            _validate_public_url(current)
            with client.stream('GET',current) as r:
                if 300<=r.status_code<400 and r.headers.get('location'):
                    nxt=urljoin(current,r.headers['location']); _validate_public_url(nxt); redirects.append(nxt); current=nxt; continue
                r.raise_for_status()
                ctype=(r.headers.get('content-type') or '').split(';')[0].strip().lower()
                if ctype not in {'text/html','text/plain','application/xhtml+xml'}:
                    raise ValueError(f'unsupported web content type: {ctype or "unknown"}')
                chunks=[]; size=0
                for chunk in r.iter_bytes():
                    size+=len(chunk)
                    if size>max_bytes:raise ValueError('web response exceeds configured byte limit')
                    chunks.append(chunk)
                raw=b''.join(chunks)
                enc=r.encoding or 'utf-8'; text=raw.decode(enc,errors='replace')
                if ctype in {'text/html','application/xhtml+xml'}:
                    ex=_TextExtractor(); ex.feed(text); body=ex.content_text(); title=' '.join(ex.title).strip()
                else:
                    body=' '.join(text.split()); title=''
                body=body[:120000]
                segments=segment_web_text(body)
                return {'url':current,'requested_url':url,'redirects':redirects,'status_code':r.status_code,'content_type':ctype,
                        'title':title[:500],'text':body,'segments':segments,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),
                        'policy':'GET-only; no cookies, credentials, forms, JavaScript, or private-network targets'}
    raise ValueError('too many redirects')
