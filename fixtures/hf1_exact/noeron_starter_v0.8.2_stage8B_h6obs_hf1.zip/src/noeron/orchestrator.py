from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
from threading import RLock
from pathlib import Path
from uuid import UUID, uuid4, uuid5, NAMESPACE_URL
from urllib.parse import urlparse
import hashlib
import math
import re

from noeron.cognition.kernel import GeometricCognitionKernel
from noeron.cognition.models import KnotMemory, NativeProposition, NativeThought, NativeThoughtKind, SensoryConceptCluster, WebStudyRecord, MemoryRetentionDecisionRecord
from noeron.cognition.renderer import LanguageRenderer
from noeron.development import NativeLanguageFaculty
from noeron.initiative import InitiativePolicy
from noeron.realization import RealizationPolicy
from noeron.memory_retention import MemoryRetentionPolicy
from noeron.consequence import native_state_consistency_residual, nonworsening
from noeron.learning import (
    preview_document, segment_document, segment_is_structural, source_root_knot,
    update_semantic_prototypes, normalize_learning_document, concept_structural_role, _LEARNING_BACKGROUND,
    isotopy_radius_proxy, encode_sparse_deformation, lineage_semantic_knot,
    estimated_knot_json_bytes, estimated_deformation_json_bytes,
)
from noeron.learning_models import (
    LearningReport, LearningRecallHit, LearningRevisionReport, LearningSourceRecord, LearningRateReport,
    NoeronSemanticStratumRecord, IsotopyComponentRecord, StratifiedLearningMemory,
    SemanticStratumAssignment, LearningTraversalReport, ReasoningConceptRecord, SemanticKnotPrototype,
)
from noeron.math import dkt
from noeron.math.linalg import numerically_tied
from noeron.math.affect import upgrade_existing_distributed_field
from noeron.math.irg import interaction_geometry
from noeron.math.kernel import MathematicalCognitiveKernel
from noeron.reasoning import build_multi_memory_reasoning
from noeron.inference import parse_surface_logic_detailed
from noeron.language_composition import COMPOSITION_VERSION, LANGUAGE_MECHANISM_VERSION, analyze_surface_composition
from noeron.language_dialogue import CONVERSATION_VERSION, DIALOGUE_VERSION, PRODUCTIVE_ENGLISH_VERSION
from noeron.english_egress import ENGLISH_EGRESS_VERSION, realize_native_thought
from noeron.source_identity import identify_source, provenance_digest
from noeron.stratification import ReclusterEntry, build_recluster_plan
from noeron.llm import LanguageEngine
from noeron.memory import LocalEventStore
from noeron.models import CognitiveEvent, EventKind, InitiativeMessage, NoeronReply, NoeronState, Stratum
from noeron.security import DKTSecurityShell
from noeron.perception import (SensoryObservation, fetch_read_only, sensory_feature_distance, web_instruction_surface_risk, web_terms, web_boilerplate_penalty, web_knowledge_quality, web_semantic_learning_terms)
from noeron.room import RoomController
from noeron.engineering import SourceWorkspace, EngineeringSourceError


class Noeron:
    """Yggdrasil v0.8.2 candidate: revised Stage-8B productive conversation over preserved native cognition."""
    def __init__(self,engine:LanguageEngine,store:LocalEventStore,initiative_threshold=0.55,species_name='Noeron',individual_name='Yggdrasil',terra_enabled:bool=True,room_native_decoder_executable:str='',room_asr_executable:str='',room_max_payload_bytes:int=67_108_864,engineering_source_root:str='',engineering_max_source_bytes:int=300_000):
        self.store=store; self.state=store.latest_state() or NoeronState(); self.math=MathematicalCognitiveKernel(); self.cognition=GeometricCognitionKernel(species_name,individual_name)
        self.renderer=LanguageRenderer(engine); self.language=NativeLanguageFaculty(); self.security=DKTSecurityShell(self.state); self.initiative=InitiativePolicy(initiative_threshold); self.realization=RealizationPolicy(); self.memory_retention=MemoryRetentionPolicy(); self.species_name=species_name; self.individual_name=individual_name; self.terra_enabled=bool(terra_enabled); self.engineering=SourceWorkspace(engineering_source_root,max_source_bytes=engineering_max_source_bytes); self._lock=RLock()
        if not self.state.math_kernel.dkt.core_knot.cosine:self.state.math_kernel.dkt.core_knot=dkt.reference_knot()
        self._migrate_history_to_knots_if_needed()
        self._migrate_v061_geometry()
        self._migrate_v062_dynamics_learning()
        self._migrate_v063_stratified_learning()
        self._migrate_v064_mathematical_perception()
        self._migrate_v065_multi_reasoning()
        self._migrate_v066_source_lineage()
        self._migrate_v067_developmental_cognition()
        self._migrate_v068_language_grounding()
        self._migrate_v069_environment_security()
        self._migrate_v070_distributed_activation()
        self._migrate_v071_semantic_multimodal_learning()
        self._migrate_v072_selective_web_learning()
        self._migrate_v0721_web_quality()
        self._migrate_v073_active_local_defense()
        self._migrate_v0731_native_deliberative_defense()
        self._migrate_v0732_variational_defense()
        self._migrate_v0733_consequence_defense()
        self._migrate_v0734_cognition_dehardening()
        self._migrate_v0734_derived_neighborhood_geometry()
        self._migrate_v074_stage5()
        self._migrate_v075_stage6()
        self._migrate_v0751_restart_preservation()
        self._migrate_v081_stage8b_language()
        self._migrate_v082_stage8b_conversation()
        self.room=RoomController(self,store,store.path,native_decoder_executable=room_native_decoder_executable,asr_executable=room_asr_executable,max_payload_bytes=room_max_payload_bytes)
        self.room.migrate()
        self.security.checkpoint(self.state)

    def _prototype_map(self): return self.store.semantic_prototype_map()

    # ------------------------------------------------------------------
    # Migrations
    # ------------------------------------------------------------------
    def _migrate_history_to_knots_if_needed(self):
        if self.store.all_knot_memories():
            self.state.cognition.migration_complete=True; return
        state=NoeronState(conversational_turn=self.state.conversational_turn,last_event_id=self.state.last_event_id,core_invariants=self.state.core_invariants)
        parent=None; depth=0
        for event in self.store.all_external_events():
            result=self.math.update(event,state.math_kernel,self.store.knot_memories(),self._prototype_map(),self.state.cognition.language.propositions); state.math_kernel=result.state; state.logical_entropy=result.state.rl.entropy_normalized
            mem=KnotMemory(source_event_id=event.id,knot=result.experience_knot,logical_coordinates=result.state.rl.coordinates,logical_entropy=result.state.rl.entropy_normalized,egr_entropy_current=result.state.egr.entropy_current,parent_memory_id=parent.id if parent else None,branch_depth=depth+1,provenance_excerpt=event.content[:500].replace('\n',' '),geometry_version='semantic-irg-dkt-v0.6.1',consolidated=True,memory_class='episodic',consolidation_score=max(result.consolidation.score,0.5),consolidation_reasons=['direct legacy external-event migration'])
            self.store.append_knot_memory(mem); parent=mem; depth=mem.branch_depth
        if self.store.all_external_events():self.state.math_kernel=state.math_kernel
        self.state.cognition.migration_complete=True; self.store.append_state(self.state)

    def _migrate_v061_geometry(self):
        """One-way v0.6.0 -> v0.6.1 migration.

        The migration-complete flag is authoritative.  More importantly, even when
        recovering an interrupted legacy migration, only rows that are *actually*
        encoded as the v0.6 legacy geometry are candidates.  Later provenance and
        native-retained DKT rows must never be reclassified by an old migration.
        """
        target='semantic-irg-dkt-v0.6.1'; allm=self.store.all_knot_memories()
        if self.state.cognition.v061_geometry_migration_complete:
            self._refresh_memory_counts(); return

        legacy=[m for m in allm if str(m.geometry_version or '')=='legacy-v0.6']
        migrated_active=False
        for m in legacy:
            event=self.store.event_by_id(str(m.source_event_id))
            if event is None:continue
            if event.source.startswith('noeron-endogenous') or bool(event.metadata.get('endogenous')):
                m.consolidated=False; m.memory_class='transient-legacy-endogenous'; m.geometry_version='legacy-v0.6-archived'; m.consolidation_reasons=['v0.6.1 separates continuous endogenous evolution from durable memory']; self.store.upsert_knot_memory(m); continue
            irg=interaction_geometry(event); m.knot=dkt.experience_knot(irg,s=m.knot.sobolev_order or 2.0,modes=m.knot.mode_radius or 8)
            m.geometry_version=target; m.consolidated=True; m.memory_class='episodic'; m.consolidation_reasons=list(dict.fromkeys(m.consolidation_reasons+['re-encoded by v0.6.1 semantic IRG->DKT geometry']))
            self.store.upsert_knot_memory(m); migrated_active=True

        # Rebuild the old v0.6.1 core only when this invocation actually migrated
        # an active legacy external memory.  A restart of a later Noeron therefore
        # cannot perturb core DKT geometry merely because modern rows exist.
        if migrated_active:
            active=self.store.knot_memories()
            if active:
                base=active[-1].knot.model_copy(deep=True)
                self.state.math_kernel.dkt.core_knot=dkt.evolve_core(base,base,self.state.math_kernel.rl.coordinates,sigma=self.state.math_kernel.egr.entropy_production,frenet_curvature=self.state.math_kernel.frenet.first_curvature)
                self.state.math_kernel.dkt.invariant_signature=self.state.math_kernel.dkt.core_knot.invariant_signature
                self.state.math_kernel.dkt.sobolev_norm_sq=dkt.sobolev_norm_sq(self.state.math_kernel.dkt.core_knot)
        # Likewise, only concrete legacy-memory evidence authorizes the old EGR
        # chart conversion.  A stale/false migration flag on a later database must
        # not be enough to perturb modern EGR state.
        if legacy and not self.state.math_kernel.egr.bridge_name.startswith('chi-log1p-causal-v0.6.'):
            old=max(0.0,float(self.state.math_kernel.rl.coordinates[3] if len(self.state.math_kernel.rl.coordinates)>3 else self.state.math_kernel.egr.mapped_entropy))
            self.state.math_kernel.egr.entropy_state=math.expm1(old); self.state.math_kernel.egr.previous_entropy_state=self.state.math_kernel.egr.entropy_state
            self.state.math_kernel.egr.mapped_entropy=old; self.state.math_kernel.egr.target_logical_entropy=old
        self.state.cognition.v061_geometry_migration_complete=True; self._refresh_memory_counts(); self.store.append_state(self.state)

    def _migrate_v062_dynamics_learning(self):
        if not self.state.cognition.v062_dynamics_learning_migration_complete:
            cleared=len(self.state.cognition.pending_thoughts); self.state.cognition.pending_thoughts=[]; self.state.cognition.legacy_pending_cleared_count+=cleared; self.state.cognition.thought_signatures=[]
            m=self.state.math_kernel
            self.state.cognition.attention_baseline={'sigma':m.egr.entropy_production,'sigma_change':0.0,'entropy_coordinate':m.egr.mapped_entropy,'frenet':m.frenet.first_curvature,'dkt_norm':m.dkt.sobolev_norm_sq,'rl_curvature_contrast':getattr(m.rl,'curvature_contrast',0.0)}
            self.state.cognition.v062_dynamics_learning_migration_complete=True
        self._refresh_memory_counts(); self._refresh_learning_counts(); self.store.append_state(self.state)

    def _migrate_v063_stratified_learning(self):
        """Compress any active v0.6.2 learned segments into semantic strata/components.

        Source roots stay as full DKT knots. Segment history is preserved; the old
        full segment row is archived after an equivalent deformation memory exists.
        """
        if not self.state.cognition.v063_stratified_learning_migration_complete:
            for old in list(self.store.knot_memories()):
                if old.memory_class not in {'learned-source-segment','learned-source-revision'}: continue
                if self.store.stratified_learning_memory_by_id(str(old.id),include_archived=True): continue
                self._store_stratified_memory(
                    knot=old.knot,source_event_id=old.source_event_id,parent_memory_id=old.parent_memory_id,
                    branch_depth=old.branch_depth,provenance_excerpt=old.provenance_excerpt,
                    logical_coordinates=old.logical_coordinates,logical_entropy=old.logical_entropy,egr_entropy_current=old.egr_entropy_current,
                    consolidation_score=old.consolidation_score,consolidation_reasons=old.consolidation_reasons,
                    learning_source_id=old.learning_source_id,source_title=old.source_title,source_segment_index=old.source_segment_index,
                    memory_class='learned-stratified-revision' if old.memory_class.endswith('revision') else 'learned-stratified-segment',
                    memory_id=old.id,revision_of_memory_id=old.revision_of_memory_id,
                )
                old.consolidated=False; old.memory_class='legacy-v062-learning-full-archived'; old.consolidation_reasons=list(dict.fromkeys(old.consolidation_reasons+['v0.6.3 compressed equivalent stored in stratified deformation memory']))
                self.store.upsert_knot_memory(old)
            self.state.cognition.v063_stratified_learning_migration_complete=True
        self.state.cognition.version='0.6.3'; self.state.cognition.memory_geometry_version='semantic-irg-dkt+stratified-learning-v0.6.3'
        self.state.math_kernel.interface_version='0.6.3'; self.state.math_kernel.egr.bridge_name='chi-log1p-causal-v0.6.3'
        self._refresh_memory_counts(); self._refresh_learning_counts(); self.store.append_state(self.state)

    def _migrate_v064_mathematical_perception(self):
        """Repair v0.6.3 lexical artifacts and re-gate concept establishment.

        No learned geometry is deleted.  Structural/background artifacts are kept in
        provenance with a non-active status.  Two deterministic stemming artifacts
        (spher/mechanic) are copied to corrected aliases while their old rows are
        retired.
        """
        if not getattr(self.state.cognition,'v064_mathematical_perception_migration_complete',False):
            alias_map={'spher':'sphere','mechanic':'mechanics'}
            for old in list(self.store.semantic_prototypes()):
                term=old.term
                if term in alias_map:
                    repaired=old.model_copy(deep=True)
                    repaired.term=alias_map[term]
                    repaired.geometry_version='learned-semantic-knot-v0.6.4'
                    role,_role_score=concept_structural_role(repaired.term,'')
                    repaired.concept_kind=role; repaired.structural_role_score=0.0
                    repaired.context_coherence=(1.0/(1.0+repaired.mean_context_distance)) if repaired.observations>1 else None
                    repaired.establishment_score=0.0
                    repaired.confidence=float(repaired.context_coherence or 0.0)
                    repaired.status='observed-recurrent' if repaired.observations>1 else 'observed-once'
                    self.store.upsert_semantic_prototype(repaired)
                    old.status='perception-retired-alias'; old.geometry_version='legacy-semantic-token-v0.6.3-retired'; self.store.upsert_semantic_prototype(old)
                    continue
                if term in _LEARNING_BACKGROUND:
                    old.status='perception-retired-background'; old.geometry_version='legacy-semantic-token-v0.6.3-retired'; self.store.upsert_semantic_prototype(old); continue
                role,_role_score=concept_structural_role(term,'')
                coherence=(1.0/(1.0+old.mean_context_distance)) if old.observations>1 else None
                old.concept_kind=role; old.structural_role_score=0.0; old.context_coherence=coherence; old.establishment_score=0.0
                old.confidence=float(coherence or 0.0)
                old.status='observed-recurrent' if old.observations>1 else 'observed-once'
                old.geometry_version='learned-semantic-knot-v0.6.4'
                self.store.upsert_semantic_prototype(old)
            self.state.cognition.v064_mathematical_perception_migration_complete=True
        self.state.cognition.version='0.6.4'; self.state.cognition.memory_geometry_version='semantic-irg-dkt+stratified-learning+math-perception-v0.6.4'
        self.state.math_kernel.interface_version='0.6.4'; self.state.math_kernel.egr.bridge_name='chi-log1p-causal-v0.6.4'
        self._refresh_memory_counts(); self._refresh_learning_counts(); self.store.append_state(self.state)

    def _migrate_v065_multi_reasoning(self):
        """Enable v0.6.5 multi-memory reasoning without rewriting learned history.

        Single-observation prototype coherence becomes unestimated (None), not zero.
        Existing learned strata/components/memories are preserved byte-for-byte in
        persistence; only runtime version metadata and prototype diagnostics change.
        """
        if not getattr(self.state.cognition,'v065_multi_reasoning_migration_complete',False):
            for p in self.store.semantic_prototypes():
                if p.status.startswith('perception-retired'):
                    continue
                if p.observations < 2:
                    p.context_coherence=None
                else:
                    p.context_coherence=1.0/(1.0+max(0.0,p.mean_context_distance))
                p.structural_role_score=0.0
                p.establishment_score=0.0
                p.confidence=float(p.context_coherence or 0.0)
                p.status='observed-recurrent' if p.observations>1 else 'observed-once'
                p.geometry_version='learned-semantic-knot-v0.6.5'
                self.store.upsert_semantic_prototype(p)
            self.state.cognition.v065_multi_reasoning_migration_complete=True
        self.state.cognition.version='0.6.5'
        self.state.cognition.memory_geometry_version='semantic-irg-dkt+stratified-learning+math-perception+multi-reasoning-v0.6.5'
        self.state.math_kernel.interface_version='0.6.5'
        self.state.math_kernel.egr.bridge_name='chi-log1p-causal-v0.6.5'
        self._refresh_memory_counts(); self._refresh_learning_counts(); self.store.append_state(self.state)

    def _migrate_v066_source_lineage(self):
        """Attach canonical source lineage/session metadata without reclustering yet.

        v0.6.6 deliberately separates the safe metadata migration from the geometry
        rewrite. Existing semantic strata/components remain active until the owner
        previews and explicitly commits a lineage-aware recluster.
        """
        if not getattr(self.state.cognition,'v066_source_lineage_migration_complete',False):
            sessions=self.store.learning_sources(); lineage_counts={}; source_map={}
            for src in sessions:
                content=None
                if src.source_name:
                    try:
                        fp=Path(src.source_name)
                        if fp.is_file() and fp.stat().st_size<=5_000_000:
                            content=fp.read_text(encoding='utf-8',errors='replace')
                    except Exception:
                        content=None
                ident=identify_source(src.source_name,src.title,content)
                src.canonical_source_id=ident.canonical_source_id
                src.canonical_source_name=ident.canonical_source_name
                if ident.source_version_sha256:
                    src.source_version_sha256=ident.source_version_sha256
                    src.source_version_id=ident.source_version_id
                lineage_counts[ident.canonical_source_id]=lineage_counts.get(ident.canonical_source_id,0)+1
                src.session_index=lineage_counts[ident.canonical_source_id]
                self.store.append_learning_source(src); source_map[str(src.id)]=ident.canonical_source_id
            for sm in self.store.all_stratified_learning_memories():
                cid=source_map.get(str(sm.learning_source_id),'') if sm.learning_source_id else ''
                if cid and sm.canonical_source_id!=cid:
                    sm.canonical_source_id=cid; self.store.upsert_stratified_learning_memory(sm)
            for km in self.store.all_knot_memories():
                cid=source_map.get(str(km.learning_source_id),'') if km.learning_source_id else ''
                if cid and km.canonical_source_id!=cid:
                    km.canonical_source_id=cid; self.store.upsert_knot_memory(km)
            # Initialize prototype hygiene from session history. Missing later sessions
            # do not erase a concept; they only accumulate evidence for future dormancy.
            session_ids=[str(x.id) for x in sessions]
            idx={sid:i for i,sid in enumerate(session_ids)}
            for p in self.store.semantic_prototypes():
                seen=[idx[x] for x in p.source_ids if x in idx]
                if seen:
                    last=max(seen); p.missed_learning_sessions=max(0,len(session_ids)-1-last); p.last_observed_session_id=session_ids[last]
                else:
                    p.missed_learning_sessions=0
                if not p.status.startswith('perception-retired'):
                    p.geometry_version='learned-semantic-knot-v0.6.6'
                self.store.upsert_semantic_prototype(p)
            self.state.cognition.v066_source_lineage_migration_complete=True
        self.state.cognition.version='0.6.6'
        self.state.cognition.memory_geometry_version='semantic-irg-dkt+stratified-learning+source-lineage+multi-reasoning-v0.6.6'
        self.state.math_kernel.interface_version='0.6.6'
        self.state.math_kernel.egr.bridge_name='chi-log1p-causal-v0.6.6'
        self._refresh_memory_counts(); self._refresh_learning_counts(); self.store.append_state(self.state)

    def _migrate_v067_developmental_cognition(self):
        """Attach developmental faculties without rewriting epoch-1 learned topology."""
        if not getattr(self.state.cognition,'v067_developmental_cognition_migration_complete',False):
            self.state.cognition.language=self.language.seed_from_semantics(self.state.cognition.language,self._prototype_map())
            # Existing knots are preserved exactly.  Dynamic DKT stratum detection is
            # applied to future states and exposed as a read-only audit for legacy memory.
            self.state.cognition.v067_developmental_cognition_migration_complete=True
        self.state.cognition.version='0.6.7'
        self.state.cognition.mode='IRG-DKT-regional-EGR-RL-Frenet-DKT-native-language-causal'
        self.state.cognition.memory_geometry_version='semantic-irg-dkt+developmental-language+regional-egr+dynamic-dkt-v0.6.7'
        self.state.math_kernel.interface_version='0.6.7'
        self.state.math_kernel.egr.bridge_name='chi-log1p-causal-v0.6.7'
        self._refresh_memory_counts(); self._refresh_learning_counts(); self.store.append_state(self.state)

    def _migrate_v068_language_grounding(self):
        """Ground prior owner language lessons compositionally without replaying them as new experiences."""
        if not getattr(self.state.cognition,'v068_language_grounding_migration_complete',False):
            lang=self.state.cognition.language
            protos=self._prototype_map()
            for mem in self.store.cognitive_memories():
                if mem.memory_class!='language-learning' or not mem.provenance_excerpt.strip():
                    continue
                lang=self.language.migrate_existing_lesson(mem.provenance_excerpt,lang,protos,'v0.6.8 migration:'+mem.geometry_version,mem.id)
            self.state.cognition.language=lang
            # v0.6.7 recurrence counts were tick-correlated. Preserve them as legacy
            # diagnostics but start v0.6.8 affect development from independent episodes.
            ad=self.state.cognition.affective_development
            if ad.pattern_counts and not ad.legacy_pre_gate_pattern_counts:
                ad.legacy_pre_gate_pattern_counts=dict(ad.pattern_counts)
                ad.pattern_counts={}; ad.recurrent_pattern_count=0; ad.counted_observations=0; ad.suppressed_correlated_observations=0
                ad.last_pattern_signature=''; ad.last_counted_at=None; ad.last_counted_event_id=None; ad.last_counted_was_endogenous=False
            ad.episode_gate_started_at=datetime.now(timezone.utc)
            self.state.cognition.v068_language_grounding_migration_complete=True
        self.state.cognition.version='0.6.8'
        self.state.cognition.mode='IRG-DKT-grounded-language-regional-EGR-RL-Frenet-DKT-native-language-causal'
        self.state.cognition.memory_geometry_version='semantic-irg-dkt+grounded-language+regional-egr+dynamic-dkt-v0.6.8'
        self.state.math_kernel.interface_version='0.6.8'
        self.state.math_kernel.egr.bridge_name='chi-log1p-causal-v0.6.8'
        self.state.cognition.affective_development.version='0.6.8'
        self._refresh_memory_counts(); self._refresh_learning_counts(); self.store.append_state(self.state)

    def _migrate_v069_environment_security(self):
        """Add perspective, multimodal, stratified-activation, owner-relation and defensive state without replaying experience."""
        if not getattr(self.state.cognition,'v069_environment_security_migration_complete',False):
            # Re-run proposition extraction over preserved language-learning memories so
            # v0.6.8 lessons gain newly supported compositional frames without being
            # counted or replayed as new experiences.
            lang=self.language.seed_from_semantics(self.state.cognition.language,self._prototype_map()); protos=self._prototype_map()
            for mem in self.store.cognitive_memories():
                if mem.memory_class=='language-learning' and mem.provenance_excerpt.strip():
                    lang=self.language.migrate_existing_lesson(mem.provenance_excerpt,lang,protos,'v0.6.9 compositional repair:'+mem.geometry_version,mem.id)
            self.state.cognition.language=lang
            owner=self.state.cognition.language.referents.get('you','')
            if owner:self.state.cognition.owner_relation.owner_referent=owner
            self.state.cognition.v069_environment_security_migration_complete=True
        self.state.cognition.version='0.6.9'
        self.state.cognition.mode='multimodal-IRG-DKT-perspective-language-stratified-EGR-RL-Frenet-DKT-native-language-causal'
        self.state.cognition.memory_geometry_version='semantic-irg-dkt+perspective-language+stratified-activation+multimodal-irg+defensive-plasticity-v0.6.9'
        self.state.math_kernel.interface_version='0.6.9'
        self.state.math_kernel.egr.bridge_name='chi-log1p-causal-v0.6.9'
        self.state.cognition.language.version='0.6.9'; self.state.cognition.affective_development.version='0.6.9'
        self.state.cognition.owner_relation.version='0.6.9'; self.state.cognition.perception.version='0.6.9'; self.state.cognition.defense.version='0.6.9'
        self._refresh_memory_counts(); self._refresh_learning_counts(); self.store.append_state(self.state)

    def _migrate_v070_distributed_activation(self):
        """Reproject persisted v0.6.9 regional state without replaying experience."""
        if not getattr(self.state.cognition,'v070_distributed_activation_migration_complete',False):
            e,a=upgrade_existing_distributed_field(self.state.math_kernel.egr,self.state.math_kernel.affect)
            self.state.math_kernel.egr=e; self.state.math_kernel.affect=a
            self.state.cognition.v070_distributed_activation_migration_complete=True
        self.state.cognition.version='0.7.0'
        self.state.cognition.mode='multimodal-IRG-DKT-distributed-stratified-EGR-RL-Frenet-DKT-native-language-causal'
        self.state.cognition.memory_geometry_version='semantic-irg-dkt+distributed-stratified-field+perspective-language+multimodal-irg+defensive-plasticity-v0.7.0'
        self.state.math_kernel.interface_version='0.7.0'; self.state.math_kernel.egr.bridge_name='chi-log1p-causal-v0.7.0'
        self._refresh_memory_counts(); self._refresh_learning_counts(); self.store.append_state(self.state)

    def _migrate_v071_semantic_multimodal_learning(self):
        if not getattr(self.state.cognition,'v071_semantic_multimodal_migration_complete',False):
            self.state.cognition.v071_semantic_multimodal_migration_complete=True
        self.state.cognition.version='0.7.1'
        self.state.cognition.mode='semantic-multimodal-IRG-DKT-distributed-stratified-EGR-RL-Frenet-DKT-native-language-causal'
        self.state.cognition.memory_geometry_version='semantic-irg-dkt+distributed-stratified-field+semantic-multimodal-learning+perspective-language+defensive-plasticity-v0.7.1'
        self.state.math_kernel.interface_version='0.7.1'; self.state.math_kernel.egr.bridge_name='chi-log1p-causal-v0.7.1'
        self.state.cognition.perception.version='0.7.1'
        self._refresh_memory_counts(); self._refresh_learning_counts(); self.store.append_state(self.state)

    def _migrate_v072_selective_web_learning(self):
        """Normalize subsystem metadata and install selective untrusted-web learning state."""
        if not getattr(self.state.cognition,'v072_selective_web_learning_migration_complete',False):
            self.state.cognition.v072_selective_web_learning_migration_complete=True
        self.state.cognition.version='0.7.2'
        self.state.cognition.mode='selective-web+semantic-multimodal-IRG-DKT-distributed-stratified-EGR-RL-Frenet-DKT-native-language-causal'
        self.state.cognition.memory_geometry_version='semantic-irg-dkt+selective-untrusted-web+distributed-stratified-field+semantic-multimodal-learning+perspective-language+defensive-plasticity-v0.7.2'
        self.state.math_kernel.interface_version='0.7.2'; self.state.math_kernel.egr.bridge_name='chi-log1p-causal-v0.7.2'
        # Compatibility `version` now means current runtime release. Historical lineage stays in schema/mechanism fields.
        lang=self.state.cognition.language; lang.version='0.7.2'; lang.schema_version='0.6.9'; lang.mechanism_version='0.7.2'
        aff=self.state.cognition.affective_development; aff.version='0.7.2'; aff.schema_version='0.6.9'; aff.mechanism_version='0.7.2'
        own=self.state.cognition.owner_relation; own.version='0.7.2'; own.schema_version='0.6.9'; own.mechanism_version='0.7.2'
        per=self.state.cognition.perception; per.version='0.7.2'; per.schema_version='0.7.2'; per.mechanism_version='0.7.2'
        dfn=self.state.cognition.defense; dfn.version='0.7.2'; dfn.schema_version='0.6.9'; dfn.mechanism_version='0.7.2'
        self._refresh_memory_counts(); self._refresh_learning_counts(); self.store.append_state(self.state)


    def _migrate_v0721_web_quality(self):
        """Install v0.7.3 web-quality gates without replaying web experience."""
        c=self.state.cognition
        if not getattr(c,'v0721_web_quality_migration_complete',False):
            c.v0721_web_quality_migration_complete=True
        c.version='0.7.3'
        c.mode='quality-gated-selective-web+semantic-multimodal-IRG-DKT-distributed-stratified-EGR-RL-Frenet-DKT-native-language-causal'
        c.memory_geometry_version='semantic-irg-dkt+web-quality-gated+selective-untrusted-web+distributed-stratified-field+semantic-multimodal-learning+perspective-language+defensive-plasticity-v0.7.3'
        self.state.math_kernel.interface_version='0.7.3'; self.state.math_kernel.egr.bridge_name='chi-log1p-causal-v0.7.3'
        lang=c.language; lang.version='0.7.3'; lang.schema_version='0.6.9'; lang.mechanism_version='0.7.3'
        aff=c.affective_development; aff.version='0.7.3'; aff.schema_version='0.6.9'; aff.mechanism_version='0.7.3'
        own=c.owner_relation; own.version='0.7.3'; own.schema_version='0.6.9'; own.mechanism_version='0.7.3'
        per=c.perception; per.version='0.7.3'; per.schema_version='0.7.3'; per.mechanism_version='0.7.3'
        dfn=c.defense; dfn.version='0.7.3'; dfn.schema_version='0.6.9'; dfn.mechanism_version='0.7.3'
        self._refresh_memory_counts(); self._refresh_learning_counts(); self.store.append_state(self.state)

    def _migrate_v073_active_local_defense(self):
        """Install aggressive local defensive containment without replaying history.

        Historical quarantine records are preserved.  Current defense gets explicit
        runtime/schema/mechanism metadata and local enforcement state.
        """
        c=self.state.cognition
        if not getattr(c,'v073_active_local_defense_migration_complete',False):
            c.v073_active_local_defense_migration_complete=True
        c.version='0.7.3'
        c.mode='active-local-defense+quality-gated-selective-web+semantic-multimodal-IRG-DKT-distributed-stratified-EGR-RL-Frenet-DKT-native-language-causal'
        c.memory_geometry_version='semantic-irg-dkt+active-local-defense+web-quality-gated+selective-untrusted-web+distributed-stratified-field+semantic-multimodal-learning+perspective-language-v0.7.3'
        self.state.math_kernel.interface_version='0.7.3'; self.state.math_kernel.egr.bridge_name='chi-log1p-causal-v0.7.3'
        lang=c.language; lang.version='0.7.3'; lang.mechanism_version='0.7.3'
        aff=c.affective_development; aff.version='0.7.3'; aff.mechanism_version='0.7.3'
        own=c.owner_relation; own.version='0.7.3'; own.mechanism_version='0.7.3'
        per=c.perception; per.version='0.7.3'; per.mechanism_version='0.7.3'
        dfn=c.defense; dfn.version='0.7.3'; dfn.schema_version='0.7.3'; dfn.mechanism_version='0.7.3'
        self._refresh_memory_counts(); self._refresh_learning_counts(); self.store.append_state(self.state)

    def _migrate_v0731_native_deliberative_defense(self):
        """Add IRG/DKT/EGR/RL/Frenet defensive deliberation without replaying history."""
        c=self.state.cognition
        if not getattr(c,'v0731_native_deliberative_defense_migration_complete',False):
            c.v0731_native_deliberative_defense_migration_complete=True
        c.version='0.7.3.1'
        c.mode='dual-layer-reflexive+native-deliberative-defense+quality-gated-selective-web+semantic-multimodal-IRG-DKT-distributed-stratified-EGR-RL-Frenet-DKT-native-language-causal'
        c.memory_geometry_version='semantic-irg-dkt+native-deliberative-defense+web-quality-gated+selective-untrusted-web+distributed-stratified-field+semantic-multimodal-learning+perspective-language-v0.7.3.1'
        self.state.math_kernel.interface_version='0.7.3.1'; self.state.math_kernel.egr.bridge_name='chi-log1p-causal-v0.7.3.1'
        for subsystem in (c.language,c.affective_development,c.owner_relation,c.perception):
            subsystem.version='0.7.3.1'; subsystem.mechanism_version='0.7.3.1'
        dfn=c.defense; dfn.version='0.7.3.1'; dfn.schema_version='0.7.3.1'; dfn.mechanism_version='0.7.3.1'
        # Historical v0.7.3 actions were programmed policy executions, not native
        # deliberative choices. Preserve them and label that distinction explicitly.
        if not dfn.deliberation_history:
            for action in dfn.action_history:
                if action.decision_layer=='reflexive' and action.native_choice_score==0.0:
                    action.decision_layer='legacy-programmed-v0.7.3'
        for rec in dfn.quarantine_records:
            if rec.family_id and rec.family_id not in dfn.deformation_family_invariants:
                dfn.deformation_family_invariants[rec.family_id]=[x for x in rec.violated_invariants if x in self.security.PROTECTED_KEYS] or [x for x in rec.violated_invariants if x!='blocked-source-fingerprint'] or ['blocked-source-fingerprint']
        # Preserve any learned preferences from persisted v0.7.3.1 states; when
        # upgrading from v0.7.3 the schema supplies neutral baseline preferences.
        self._refresh_memory_counts(); self._refresh_learning_counts(); self.store.append_state(self.state)

    def _migrate_v0732_variational_defense(self):
        """Remove v0.7.3.1 hand-weighted action policy without replaying history.

        Historical weighted-policy deliberations remain preserved and explicitly
        labeled. New choices use only the reflexive invariant floor, safe primitive
        affordances, one general variational objective, and learned DKT action
        preference geometry. Legacy float preferences are retained for provenance
        but have zero causal authority in v0.7.3.2 selection.
        """
        c=self.state.cognition
        if not getattr(c,'v0732_variational_defense_migration_complete',False):
            c.v0732_variational_defense_migration_complete=True
        c.version='0.7.3.2'
        c.mode='reflexive-invariants+variational-native-defense+quality-gated-selective-web+semantic-multimodal-IRG-DKT-distributed-stratified-EGR-RL-Frenet-DKT-native-language-causal'
        c.memory_geometry_version='semantic-irg-dkt+variational-native-defense+web-quality-gated+selective-untrusted-web+distributed-stratified-field+semantic-multimodal-learning+perspective-language-v0.7.3.2'
        self.state.math_kernel.interface_version='0.7.3.2'; self.state.math_kernel.egr.bridge_name='chi-log1p-causal-v0.7.3.2'
        for subsystem in (c.language,c.affective_development,c.owner_relation,c.perception):
            subsystem.version='0.7.3.2'; subsystem.mechanism_version='0.7.3.2'
        dfn=c.defense; dfn.version='0.7.3.2'; dfn.schema_version='0.7.3.2'; dfn.mechanism_version='0.7.3.2'; dfn.policy_mode='variational-affordance-geometry-v0.7.3.2'
        # Never translate our old hand-written float rankings into native preference
        # geometry. That would smuggle the programmed v0.7.3.1 policy into the new
        # chooser. Historical values remain serialized only as provenance.
        for row in dfn.deliberation_history:
            if row.policy_mode=='legacy-weighted-policy-v0.7.3.1' or row.candidate_action_scores:
                row.policy_mode='legacy-weighted-policy-v0.7.3.1'
        self._refresh_memory_counts(); self._refresh_learning_counts(); self.store.append_state(self.state)


    def _migrate_v0733_consequence_defense(self):
        """Remove the authored defensive need-field mapping without replaying history.

        v0.7.3.3 keeps only the reflexive invariant floor and safe local actuator
        primitives.  Adaptive choice simulates each primitive plan's post-action
        consequence and compares it against the last trusted operating state plus
        learned DKT action-preference geometry. Historical v0.7.3.2 need-field
        deliberations remain preserved as provenance and have no causal authority.
        """
        c=self.state.cognition
        if not getattr(c,'v0733_consequence_defense_migration_complete',False):
            c.v0733_consequence_defense_migration_complete=True
        c.version='0.7.3.3'
        c.mode='reflexive-invariants+consequence-simulated-native-defense+quality-gated-selective-web+semantic-multimodal-IRG-DKT-distributed-stratified-EGR-RL-Frenet-DKT-native-language-causal'
        c.memory_geometry_version='semantic-irg-dkt+consequence-simulated-native-defense+web-quality-gated+selective-untrusted-web+distributed-stratified-field+semantic-multimodal-learning+perspective-language-v0.7.3.3'
        self.state.math_kernel.interface_version='0.7.3.3'; self.state.math_kernel.egr.bridge_name='chi-log1p-causal-v0.7.3.3'
        for subsystem in (c.language,c.affective_development,c.owner_relation,c.perception):
            subsystem.version='0.7.3.3'; subsystem.mechanism_version='0.7.3.3'
        dfn=c.defense; dfn.version='0.7.3.3'; dfn.schema_version='0.7.3.3'; dfn.mechanism_version='0.7.3.3'; dfn.policy_mode='consequence-simulation-geometry-v0.7.3.3'
        # Preserve earlier deliberations verbatim. They remain historical evidence,
        # not training labels or hidden choice authority for the new mechanism.
        self._refresh_memory_counts(); self._refresh_learning_counts(); self.store.append_state(self.state)


    def _migrate_v0734_cognition_dehardening(self):
        """Deactivate selection-trained preference history and install v0.7.3.4 mechanisms.

        Historical records are preserved.  Any defensive preference knots produced by
        v0.7.3.2/v0.7.3.3 merely because an action was selected are moved to explicit
        legacy provenance and removed from the active objective. Fresh active defensive
        preference geometry may then be learned only from later observed outcomes.
        No event is replayed and no historical audit record is rewritten.
        """
        c=self.state.cognition
        if not getattr(c,'v0734_cognition_dehardening_migration_complete',False):
            dfn=c.defense
            if dfn.action_preference_knots:
                for name,k in dfn.action_preference_knots.items():
                    if name not in dfn.legacy_selection_preference_knots:
                        dfn.legacy_selection_preference_knots[name]=k.model_copy(deep=True)
                for name,n in dfn.action_preference_observations.items():
                    dfn.legacy_selection_preference_observations[name]=max(int(n),int(dfn.legacy_selection_preference_observations.get(name,0)))
                dfn.action_preference_knots={}
                dfn.action_preference_observations={}
            c.v0734_cognition_dehardening_migration_complete=True
        c.version='0.7.3.4'
        c.mode='reflexive-invariants+outcome-grounded-consequence-defense+native-proposition-question-field+consequence-communication+learned-DKT-semantics+all-nonzero-regional-EGR-RL-Frenet-DKT+optional-Terra'
        c.memory_geometry_version='semantic-irg-dkt+native-proof-cognition+consequence-communication+outcome-grounded-defense+web-sensor-security-admission+all-nonzero-regional-egr+semantic-multimodal-learning-v0.7.3.4'
        self.state.math_kernel.interface_version='0.7.3.4'; self.state.math_kernel.egr.bridge_name='chi-log1p-causal-v0.7.3.4'
        for subsystem in (c.language,c.affective_development,c.owner_relation,c.perception,c.initiative_development):
            subsystem.version='0.7.3.4'; subsystem.mechanism_version='0.7.3.4'
        dfn=c.defense; dfn.version='0.7.3.4'; dfn.schema_version='0.7.3.4'; dfn.mechanism_version='0.7.3.4'; dfn.policy_mode='consequence-simulation-outcome-learning-v0.7.3.4'
        dfn.note='Programmed reflexive preservation floor plus consequence simulation. Active DKT defensive preference geometry is outcome-trained only; legacy selection-trained geometry is preserved but causally inactive. No autonomous external hack-back.'
        self._refresh_memory_counts(); self._refresh_learning_counts(); self.store.append_state(self.state)


    def _migrate_v0734_derived_neighborhood_geometry(self):
        """Replace legacy authored semantic/component radii with derived H^s bounds.

        Earlier releases persisted fixed default neighborhood radii (1.65 for learned
        semantic strata and 0.8 for local components).  Those values could still
        influence preserved-state cognition even after new records switched to the
        finite-H^s immersion bound.  This migration recomputes every active persisted
        neighborhood from its actual anchor knot and then rebuilds frontier adjacency.
        Historical records are not deleted or replayed.
        """
        c=self.state.cognition
        if getattr(c,'v0734_derived_neighborhood_geometry_migration_complete',False):
            return
        strata=list(self.store.semantic_strata())
        components=list(self.store.isotopy_components())
        for s in strata:
            if s.status.startswith('retired-'):
                continue
            _margin,radius=isotopy_radius_proxy(s.anchor_knot)
            s.admission_radius_hs=float(radius)
            s.geometry_version='derived-finite-hs-semantic-neighborhood-v0.7.3.4'
            s.frontier_neighbors=[]
        for comp in components:
            if comp.status.startswith('retired-'):
                continue
            margin,radius=isotopy_radius_proxy(comp.anchor_knot)
            comp.sampled_regularity_margin=float(margin)
            comp.isotopy_safe_radius_hs=float(radius)
            comp.geometry_version='derived-finite-hs-local-component-v0.7.3.4'
            self.store.upsert_isotopy_component(comp)
        active=[s for s in strata if not s.status.startswith('retired-')]
        for i,a in enumerate(active):
            for b in active[i+1:]:
                if a.dkt_stratum_index!=b.dkt_stratum_index:
                    continue
                sep=dkt.sobolev_distance(a.anchor_knot,b.anchor_knot)
                if sep <= a.admission_radius_hs+b.admission_radius_hs:
                    a.frontier_neighbors.append(b.id)
                    b.frontier_neighbors.append(a.id)
        for s in active:
            s.updated_at=datetime.now(timezone.utc)
            self.store.upsert_semantic_stratum(s)
        c.v0734_derived_neighborhood_geometry_migration_complete=True
        self.store.append_state(self.state)

    def _migrate_v074_stage5(self):
        """Install Stage-5 state without rewriting pre-v0.7.4 cognitive history.

        Existing active DKT memories remain active historical memory.  Their IDs are
        recorded explicitly as legacy-pre-v0.7.4 so the new consequence selector is
        not falsely credited for having chosen them.  New ordinary experiences enter
        provenance first and may become cognitive only through native retention.
        Any programmed familiarity scalar from an older state is preserved only as a
        legacy audit value and then removed from relational authority.  Historical
        renderer records are not replayed; v0.7.4 simply stops consulting
        ``renderer_needed`` for future tool use.
        """
        c=self.state.cognition
        if not getattr(c,'v074_stage5_migration_complete',False):
            retention=c.memory_retention
            if not retention.legacy_pre_v074_active_memory_ids:
                ids=[m.id for m in self.store.cognitive_memories()]
                retention.legacy_pre_v074_active_memory_ids=list(ids)
                retention.legacy_pre_v074_active_memory_count=len(ids)
            retention.pending_provenance_memory_ids=[m.id for m in self.store.pending_cognitive_provenance_memories()]
            rel=c.owner_relation
            legacy=float(getattr(rel,'familiarity',0.0) or 0.0)
            rel.legacy_programmed_familiarity_value=max(float(getattr(rel,'legacy_programmed_familiarity_value',0.0) or 0.0),legacy)
            rel.familiarity=0.0
            # Old serialized note text is metadata, not history-bearing cognition.
            # Rewrite it to the current truthful Stage-5 boundary while preserving
            # counters/legacy familiarity separately; otherwise preserved v0.7.3.4
            # state could expose a stale relational description after migration.
            rel.note='Authentication identifies the recurring owner referent only. relation_experience_knot/relation_post_state_knot are empirical adaptation geometry from admitted authenticated interactions; cognitive_relation_memory_ids separately record owner episodes activated by native retention. This adaptation state is not episodic-memory retention and no familiarity/closeness/emotion formula has causal authority.'
            # Stage-5 selectors start with no fabricated evidence.  Pydantic defaults
            # already create the fresh realization/retention state on old snapshots.
            c.v074_stage5_migration_complete=True
        c.version='0.7.4'
        c.mode='IRG-DKT-regional-EGR-RL-Frenet-DKT-native-thought+native-retention+native-communication+native-realization-tool-choice'
        c.memory_geometry_version='native-retention+semantic-irg-dkt+native-proof-cognition+consequence-communication+outcome-grounded-defense+web-sensor-security-admission+all-nonzero-regional-egr+semantic-multimodal-learning-v0.7.4'
        c.owner_relation.version='0.7.4';c.owner_relation.schema_version='0.7.4';c.owner_relation.mechanism_version='0.7.4';c.owner_relation.familiarity=0.0
        c.memory_retention.version='0.7.4';c.memory_retention.mechanism_version='0.7.4'
        c.initiative_development.version='0.7.4';c.initiative_development.mechanism_version='0.7.4'
        c.realization_development.version='0.7.4';c.realization_development.mechanism_version='0.7.4'
        self._refresh_memory_counts();self._refresh_learning_counts();self.store.append_state(self.state)

    def _migrate_v075_stage6(self):
        """Prospective Stage-6 migration; never replay historical conversations.

        Existing v0.7.4 language proposition rows remain historical records.  Their
        count is snapshotted once and existing singular provenance IDs are copied
        only into the compatibility plural provenance field.  No old event is parsed
        again and no old pending provenance is promoted to cognitive memory.
        """
        c=self.state.cognition; lang=c.language
        if not getattr(c,'v075_stage6_migration_complete',False):
            lang.legacy_pre_v075_proposition_count=len(lang.propositions)
            for prop in lang.propositions:
                if prop.source_memory_id is not None and prop.source_memory_id not in prop.source_memory_ids:
                    prop.source_memory_ids.append(prop.source_memory_id)
            lang.v075_stage6_started=True
            c.v075_stage6_migration_complete=True
        c.version='0.7.5'
        c.mode='IRG-DKT-regional-EGR-RL-Frenet-DKT-native-compositional-language+native-retention+native-communication+native-realization-tool-choice'
        c.memory_geometry_version='native-retention+semantic-irg-dkt+native-proof-cognition+compositional-discourse+provenance-gated-language+consequence-communication+outcome-grounded-defense+web-sensor-security-admission-v0.7.5'
        lang=self.language.seed_from_semantics(lang,self._prototype_map());lang.v075_stage6_started=True;c.language=lang
        # Stage-5 mechanisms retain their certified mechanism versions; Stage 6 does
        # not relabel their learning history as new language development.
        self._refresh_memory_counts();self._refresh_learning_counts();self.store.append_state(self.state)

    def _migrate_v0751_restart_preservation(self):
        """Register the preservation hotfix without rewriting cognitive history.

        v0.7.5.1 changes legacy-migration idempotency only.  It does not relabel
        Stage-5/6 memory rows, replay language, or manufacture retention choices.
        """
        c=self.state.cognition
        if not getattr(c,'v0751_restart_preservation_migration_complete',False):
            c.v0751_restart_preservation_migration_complete=True
        c.version='0.7.5.1'
        c.memory_geometry_version='native-retention+semantic-irg-dkt+native-proof-cognition+compositional-discourse+provenance-gated-language+consequence-communication+outcome-grounded-defense+web-sensor-security-admission+restart-preservation-hotfix-v0.7.5.1'
        self._refresh_memory_counts(); self._refresh_learning_counts(); self.store.append_state(self.state)

    def _migrate_v081_stage8b_language(self):
        """Prospective Stage-8B language migration with no historical replay.

        Existing lexemes, propositions, utterances, provenance IDs and discourse
        state are preserved.  A compact snapshot of the pre-8B grammar-frame
        counters is recorded once; richer composition counters start from zero and
        grow only from future admitted language observations.
        """
        c=self.state.cognition
        lang=c.language
        if not getattr(c,'v081_stage8b_language_migration_complete',False):
            if not lang.legacy_pre_v081_grammar_frames:
                lang.legacy_pre_v081_grammar_frames=dict(lang.grammar_frames)
            lang.composition_frame_counts=dict(lang.composition_frame_counts)
            lang.last_composition_audit={}
            lang.composition_version=COMPOSITION_VERSION
            lang.v081_stage8b_started=True
            c.v081_stage8b_language_migration_complete=True
        lang.v081_stage8b_started=True
        lang=self.language.seed_from_semantics(lang,self._prototype_map())
        c.language=lang
        # Preserve the certified cognition-core identity; Stage 8B changes the
        # language mechanism, not the underlying cognition/retention mechanisms.
        c.version='0.7.5.1'
        self._refresh_memory_counts()
        self._refresh_learning_counts()
        self.store.append_state(self.state)

    def _migrate_v082_stage8b_conversation(self):
        """Prospective v0.8.1 -> v0.8.2 conversation migration.

        No historical conversation is replayed. Existing lexemes, propositions,
        utterances, memory identities, composition counts and Stage-6 discourse
        fields are preserved byte-for-value through model migration. The new
        bounded dialogue context begins empty at the current conversational turn.
        Owner communication controls default OFF.
        """
        c=self.state.cognition;lang=c.language
        if not getattr(c,'v082_stage8b_conversation_migration_complete',False):
            lang.v082_stage8b_started=True
            lang.conversation_version=CONVERSATION_VERSION
            lang.dialogue_version=DIALOGUE_VERSION
            lang.productive_english_version=PRODUCTIVE_ENGLISH_VERSION
            lang.english_egress_version=ENGLISH_EGRESS_VERSION
            lang.dialogue.started_prospectively=True
            lang.dialogue.migration_turn=int(self.state.conversational_turn)
            lang.dialogue.turn=0
            lang.dialogue.recent_turns=[];lang.dialogue.recent_referents=[]
            lang.dialogue.last_structure={};lang.dialogue.last_ambiguities=[];lang.dialogue.last_lexical_gaps=[]
            # Explicitly do not import legacy discourse rows into the new dialogue
            # state. They remain separate compatibility state.
            controls=lang.owner_communication_controls
            controls.internal_utterance_visibility=False
            controls.internal_utterance_translation=False
            controls.response_channel_override=False
            controls.owner_command_channel=False
            c.v082_stage8b_conversation_migration_complete=True
        lang.v082_stage8b_started=True
        c.language=self.language.seed_from_semantics(lang,self._prototype_map())
        self._refresh_memory_counts();self._refresh_learning_counts();self.store.append_state(self.state)

    def _owner_referent(self)->str:
        return self.state.cognition.language.referents.get('you') or self.state.cognition.owner_relation.owner_referent or 'owner:authenticated-owner'

    def _self_referent(self)->str:
        return self.state.cognition.language.referents.get('i') or f'identity:{self.individual_name.lower()}'

    def _relation_context_memory(self,event:CognitiveEvent)->KnotMemory | None:
        """Return an ephemeral owner-history DKT support knot for authenticated interaction.

        Authentication only binds the recurring referent.  The knot itself is the
        empirical relation experience manifold learned from prior interactions.  It
        competes under the same H^s retrieval geometry as every other support and
        carries no authored valence, closeness or priority weight.
        """
        rel=self.state.cognition.owner_relation
        if not bool(event.metadata.get('owner_authenticated')) or rel.relation_experience_knot is None or rel.relation_observations<=0:
            return None
        referent=rel.owner_referent or self._owner_referent()
        rid=uuid5(NAMESPACE_URL,f'noeron-v0.7.4-owner-relation-context|{referent}|{rel.relation_experience_knot.invariant_signature}')
        return KnotMemory(
            id=rid,source_event_id=rid,knot=rel.relation_experience_knot.model_copy(deep=True),
            provenance_excerpt='[ephemeral empirical owner-relation DKT context]',
            geometry_version=rel.relation_geometry_version,consolidated=True,
            memory_class='owner-relation-context-ephemeral',consolidation_score=0.0,
            consolidation_reasons=['empirical relation context competes under ordinary H^s retrieval; authentication supplies referent identity only'],
        )

    def _contextual_math_memories(self,event:CognitiveEvent,memories:list[KnotMemory])->list[KnotMemory]:
        ctx=self._relation_context_memory(event)
        return memories+([ctx] if ctx is not None else [])

    @staticmethod
    def _empirical_knot_mean(old, new, n_old:int):
        if old is None or n_old<=0:return new.model_copy(deep=True)
        candidate=dkt.interpolate(old,new,1.0/float(n_old+1))
        safe,_=dkt.retract_to_admissible(old,candidate)
        return safe

    def _observe_owner_relation(self,event:CognitiveEvent,result):
        """Bind actual authenticated experience geometry to the owner referent.

        Authentication decides only which referent this experience belongs to.  The
        resulting manifold is the equal-observation DKT geometry of what actually
        happened; no closeness, affection, trust or preference value is authored.
        """
        rel=self.state.cognition.owner_relation
        if event.kind!=EventKind.USER_MESSAGE:return
        if not bool(event.metadata.get('owner_authenticated')):
            rel.unauthenticated_interactions+=1;return
        rel.authenticated_interactions+=1;rel.last_authenticated_at=datetime.now(timezone.utc);rel.owner_referent=self._owner_referent();rel.familiarity=0.0
        device=str(event.metadata.get('owner_device_id') or 'legacy-bootstrap')
        rel.device_interaction_counts[device]=int(rel.device_interaction_counts.get(device,0))+1
        n=int(rel.relation_observations)
        if rel.relation_experience_knot is not None:
            rel.last_experience_distance_hs=float(dkt.sobolev_distance(result.experience_knot,rel.relation_experience_knot))
        if rel.relation_post_state_knot is not None:
            rel.last_post_state_distance_hs=float(dkt.sobolev_distance(result.state.dkt.core_knot,rel.relation_post_state_knot))
        prior_ctx=self._relation_context_memory(event)
        if prior_ctx is not None and str(prior_ctx.id) in set(result.state.dkt.retrieved_memory_ids):
            rel.causal_context_injections+=1;rel.last_causal_context_memory_id=prior_ctx.id
        rel.relation_experience_knot=self._empirical_knot_mean(rel.relation_experience_knot,result.experience_knot,n)
        rel.relation_post_state_knot=self._empirical_knot_mean(rel.relation_post_state_knot,result.state.dkt.core_knot,n)
        rel.relation_observations=n+1

    def _observe_owner_cognitive_memory(self,mem:KnotMemory):
        rel=self.state.cognition.owner_relation
        if mem.id not in rel.cognitive_relation_memory_ids:
            rel.cognitive_relation_memory_ids.append(mem.id);rel.cognitive_relation_observations+=1

    @staticmethod
    def _communication_consistency_residual(math_state)->float:
        return native_state_consistency_residual(math_state)

    @staticmethod
    def _nonworsening(pre:float,post:float)->bool:
        return nonworsening(pre,post)

    def _resolve_pending_expression_outcome(self,result,event):
        st=self.state.cognition.initiative_development
        if st.pending_expression_pre_knot is None or st.pending_expression_pre_residual is None:
            return None
        post_residual=self._communication_consistency_residual(result.state)
        admissible=bool(result.state.dkt.security_admissible) and self._nonworsening(st.pending_expression_pre_residual,post_residual)
        out=self.initiative.observe_transition(
            st,'express',st.pending_expression_pre_knot,result.state.dkt.core_knot,
            admissible=admissible,source=f'observed-environment-response:{event.source}',
        )
        st.pending_expression_pre_knot=None;st.pending_expression_pre_residual=None;st.pending_expression_event_id=None
        return out

    def _mark_expression_pending(self,event_id=None):
        st=self.state.cognition.initiative_development
        st.pending_expression_pre_knot=self.state.math_kernel.dkt.core_knot.model_copy(deep=True)
        st.pending_expression_pre_residual=self._communication_consistency_residual(self.state.math_kernel)
        st.pending_expression_event_id=event_id

    def _resolve_pending_realization_outcome(self,result,event):
        st=self.state.cognition.realization_development
        if not st.pending_action or st.pending_pre_knot is None or st.pending_pre_residual is None:return None
        post_residual=native_state_consistency_residual(result.state)
        admissible=bool(result.state.dkt.security_admissible) and nonworsening(st.pending_pre_residual,post_residual)
        out=self.realization.observe_transition(
            st,st.pending_action,st.pending_pre_knot,result.state.dkt.core_knot,
            admissible=admissible,source=f'observed-environment-response:{event.source};decision-layer={st.pending_decision_layer}',
        )
        st.pending_action='';st.pending_pre_knot=None;st.pending_pre_residual=None;st.pending_event_id=None;st.pending_decision_layer=''
        return out

    def _mark_realization_pending(self,action:str,event_id=None,decision_layer:str=''):
        st=self.state.cognition.realization_development
        st.pending_action=action;st.pending_pre_knot=self.state.math_kernel.dkt.core_knot.model_copy(deep=True)
        st.pending_pre_residual=native_state_consistency_residual(self.state.math_kernel);st.pending_event_id=event_id;st.pending_decision_layer=decision_layer

    def _realize_output(self,native:str,event:CognitiveEvent,*,source:str)->tuple[str,bool,dict]:
        """Select external realization tool use without lexical-coverage authority."""
        st=self.state.cognition.realization_development
        override=str(event.metadata.get('operator_realization_override') or '')
        if override:
            if override not in self.realization.AFFORDANCES:raise ValueError('invalid operator realization override')
            action=override;st.operator_calibration_observations+=1
            st.last_selected_action='';st.last_native_choice_claim=False;st.last_decision_layer='operator-directed-calibration';st.last_selection_status='operator-directed-calibration-not-native-choice'
            selection={'action':action,'selection_status':st.last_selection_status,'decision_layer':st.last_decision_layer,'native_choice_claim':False,'candidate_distances':{}}
        else:
            selection=self.realization.choose(self.state.math_kernel.dkt.core_knot,st);action=selection.get('action')
        # Under-determined realization never becomes a hidden native-direct or
        # Terra preference.  The native cognition remains auditable in
        # ``native_text``, but *no realization affordance is executed* until an
        # authenticated operator explicitly supplies a calibration exposure or
        # learned consequence geometry yields a unique native minimum.
        if action is None:
            st.last_effective_action='';st.last_renderer_invoked=False;st.last_renderer_output_accepted=False
            return '',False,selection
        effective=action;st.last_effective_action=effective
        if effective=='terra-render':
            if not self.terra_enabled:
                # Availability is infrastructure, not a language preference.  A
                # learned/calibration selection of an unavailable actuator executes
                # nothing and never falls back to native-direct.
                st.last_effective_action='';st.last_renderer_invoked=False;st.last_renderer_output_accepted=False
                selection=dict(selection);selection['execution_status']='selected-terra-affordance-unavailable-no-fallback'
                return '',False,selection
            audited=self.renderer.render_audited(native);text=audited['text'];renderer_used=True
            st.last_renderer_invoked=True;st.last_renderer_output_accepted=bool(audited['accepted'])
        elif effective=='native-direct':
            text=native;renderer_used=False;st.last_renderer_invoked=False;st.last_renderer_output_accepted=False
        else:raise RuntimeError(f'unknown realization affordance: {effective!r}')
        layer=selection.get('decision_layer') or 'unresolved'
        self._mark_realization_pending(effective,event.id,layer)
        return text,renderer_used,selection

    def _observe_affective_pattern(self,result,event=None):
        a=result.state.affect
        if not a.pattern_signature:return False
        st=self.state.cognition.affective_development; now=datetime.now(timezone.utc)
        endogenous=bool(getattr(event,'metadata',{}).get('endogenous')) if event is not None else False
        # Correlated autonomous ticks do not count as independent affective episodes.
        if endogenous and st.last_counted_was_endogenous and st.last_pattern_signature==a.pattern_signature and st.last_counted_at is not None:
            if (now-st.last_counted_at).total_seconds() < st.episode_gate_seconds:
                st.suppressed_correlated_observations+=1
                return False
        st.last_pattern_signature=a.pattern_signature
        st.pattern_counts[a.pattern_signature]=st.pattern_counts.get(a.pattern_signature,0)+1
        st.pattern_counts=dict(sorted(st.pattern_counts.items(), key=lambda kv:kv[1], reverse=True)[:128])
        st.recurrent_pattern_count=sum(1 for n in st.pattern_counts.values() if n>=3)
        st.counted_observations+=1; st.last_counted_at=now; st.last_counted_event_id=(event.id if event is not None else None); st.last_counted_was_endogenous=endogenous
        return True

    def _native_realize(self,thought,source:str='interaction'):
        self.state.cognition.language=self.language.seed_from_semantics(self.state.cognition.language,self._prototype_map())
        utterance=self.language.realize(thought,self.state.cognition.language)
        thought.native_utterance=utterance; self.state.cognition.language.last_native_utterance=utterance
        if source=='interaction': self.state.cognition.language.last_interaction_native_utterance=utterance
        elif source=='autonomous': self.state.cognition.language.last_autonomous_native_utterance=utterance
        return utterance



    def _conversation_transport(self,thought,utterance,event,*,nonconversational_observation:bool=False):
        """Gate outward conversation by native communication consequence.

        Deterministic English egress realizes *existing* native content only. An
        authenticated owner transport override may expose that content without
        changing the native communication selection; it is labelled owner-directed.
        """
        native=str(utterance.native_text or '').strip()
        english,egress_audit=realize_native_thought(thought,utterance)
        controls=self.state.cognition.language.owner_communication_controls
        owner_authenticated=bool(event.metadata.get('owner_authenticated'))
        owner_command=bool(event.metadata.get('owner_command'))
        operator_override=str(event.metadata.get('operator_realization_override') or '')
        selection={'action':None,'selection_status':'not-evaluated-no-native-content','decision_layer':'unresolved','native_choice_claim':False,'candidate_distances':{}}
        text='';renderer_used=False;transport_origin='none'

        if not native or nonconversational_observation:
            status='nonconversational-observation-no-outward-act' if nonconversational_observation else 'no-native-content'
            audit={'communication_action':'','selection_status':status,'native_choice_claim':False,'transport_origin':'none','owner_override_used':False,'owner_command':owner_command}
            return text,renderer_used,native,english,selection,audit,egress_audit

        # Historical explicit realization calibration remains an authenticated
        # operator-directed actuator test. It is never reclassified as native
        # communication choice.
        if operator_override:
            text,renderer_used,realization=self._realize_output(native,event,source='interaction')
            transport_origin='authenticated-owner-realization-calibration'
            audit={'communication_action':'','selection_status':'operator-directed-calibration-not-native-choice','native_choice_claim':False,'transport_origin':transport_origin,'owner_override_used':True,'owner_command':owner_command,'realization':realization}
            return text,renderer_used,native,english,selection,audit,egress_audit

        selection=self.initiative.choose(self.state.math_kernel.dkt.core_knot,self.state.cognition.initiative_development)
        action=selection.get('action')
        if action=='express' and bool(selection.get('native_choice_claim')):
            # English egress is observational realization of content already
            # selected for expression. It contributes zero speech-act authority.
            text=english
            transport_origin='native-consequence-selected-expression'
            self._mark_expression_pending(event.id)
        elif action not in {None,'continue-private'}:
            raise RuntimeError(f'unknown communication affordance selected: {action!r}')
        else:
            command_transport=owner_authenticated and owner_command and controls.owner_command_channel
            response_transport=owner_authenticated and controls.response_channel_override
            if english and (command_transport or response_transport):
                text=english
                transport_origin=('authenticated-owner-command-response-transport' if command_transport else 'authenticated-owner-response-channel-override')
            # Crucially, owner transport never marks an express consequence and
            # never changes the native selection result.

        audit={
            'communication_action':(action or ''),
            'selection_status':str(selection.get('selection_status') or ''),
            'decision_layer':str(selection.get('decision_layer') or ''),
            'native_choice_claim':bool(selection.get('native_choice_claim')),
            'candidate_distances':dict(selection.get('candidate_distances') or {}),
            'transport_origin':transport_origin,
            'owner_override_used':transport_origin.startswith('authenticated-owner-'),
            'owner_command':owner_command,
            'owner_command_authority':bool(owner_authenticated and owner_command and controls.owner_command_channel),
            'response_channel_override_enabled':bool(controls.response_channel_override),
            'english_egress_content_authority':False,
            'grammar_answer_authority':False,
            'terra_answer_authority':False,
        }
        return text,renderer_used,native,english,selection,audit,egress_audit

    # ------------------------------------------------------------------
    # Stratified semantic organization
    # ------------------------------------------------------------------
    def _assign_semantic_location(self,knot,memory_id:UUID,source_title:str='',canonical_source_id:str='',semantic_knot=None)->SemanticStratumAssignment:
        # Idempotence for migration/replay.
        for c in self.store.isotopy_components():
            if memory_id in c.member_memory_ids:
                s=self.store.semantic_stratum_by_id(str(c.semantic_stratum_id))
                return SemanticStratumAssignment(semantic_stratum_id=c.semantic_stratum_id,isotopy_component_id=c.id,distance_to_stratum_anchor=dkt.sobolev_distance(knot,s.anchor_knot) if s else 0.0,distance_to_component_anchor=dkt.sobolev_distance(knot,c.anchor_knot),transition_kind='existing-member')

        strata=self.store.semantic_strata(); comps=self.store.isotopy_components(); semantic_knot=semantic_knot or knot
        # Learned Noeron semantic strata use a context-conditioned semantic knot;
        # local isotopy components still use the actual experience knot.
        compatible=[x for x in strata if x.dkt_stratum_index==knot.stratum_index]
        s=None; ds=float('inf')
        scored_s=sorted((dkt.sobolev_distance(semantic_knot,cand.anchor_knot),cand) for cand in compatible)
        if scored_s:
            ds=scored_s[0][0]
            tied=[cand for dist,cand in scored_s if numerically_tied(dist,ds)]
            if len(tied)==1 and ds<=tied[0].admission_radius_hs:
                s=tied[0]
        c=None; dc=float('inf')
        if s is not None:
            scored_c=sorted((dkt.sobolev_distance(knot,cand.anchor_knot),cand) for cand in comps if cand.semantic_stratum_id==s.id and cand.dkt_stratum_index==knot.stratum_index)
            if scored_c:
                dc=scored_c[0][0]
                tied=[cand for dist,cand in scored_c if numerically_tied(dist,dc)]
                if len(tied)==1 and dc<=tied[0].isotopy_safe_radius_hs:
                    c=tied[0]
        created_s=False; created_c=False; now=datetime.now(timezone.utc)
        if s is None:
            _semantic_margin,semantic_radius=isotopy_radius_proxy(semantic_knot)
            margin,iso=isotopy_radius_proxy(knot)
            s=NoeronSemanticStratumRecord(anchor_knot=semantic_knot.model_copy(deep=True),dkt_stratum_index=knot.stratum_index,admission_radius_hs=semantic_radius,source_titles=[source_title] if source_title else [],canonical_source_ids=[canonical_source_id] if canonical_source_id else [],geometry_version='derived-finite-hs-semantic-neighborhood-v0.7.3.4')
            c=IsotopyComponentRecord(semantic_stratum_id=s.id,anchor_knot=knot.model_copy(deep=True),dkt_stratum_index=knot.stratum_index,isotopy_safe_radius_hs=iso,sampled_regularity_margin=margin)
            s.component_ids=[c.id]; created_s=True; created_c=True; ds=0.0; dc=0.0
        elif c is None:
            margin,iso=isotopy_radius_proxy(knot)
            c=IsotopyComponentRecord(semantic_stratum_id=s.id,anchor_knot=knot.model_copy(deep=True),dkt_stratum_index=knot.stratum_index,isotopy_safe_radius_hs=iso,sampled_regularity_margin=margin)
            if c.id not in s.component_ids:s.component_ids.append(c.id)
            created_c=True; dc=0.0

        old_sn=s.member_count; old_cn=c.member_count
        s.member_count=old_sn+1; s.radius_hs=max(s.radius_hs,dkt.sobolev_distance(s.anchor_knot,semantic_knot)); s.updated_at=now
        if source_title and source_title not in s.source_titles:s.source_titles=(s.source_titles+[source_title])[-32:]
        if canonical_source_id and canonical_source_id not in s.canonical_source_ids:s.canonical_source_ids=(s.canonical_source_ids+[canonical_source_id])[-32:]
        c.member_count=old_cn+1; c.radius_hs=max(c.radius_hs,dkt.sobolev_distance(c.anchor_knot,knot)); c.updated_at=now
        if memory_id not in c.member_memory_ids:c.member_memory_ids.append(memory_id)

        # Candidate frontier adjacency. This is a Noeron learned-semantic relation,
        # not a claim that manuscript DKT Whitney-frontier order has been proved.
        for other in self.store.semantic_strata():
            if other.id==s.id or other.dkt_stratum_index!=s.dkt_stratum_index: continue
            sep=dkt.sobolev_distance(s.anchor_knot,other.anchor_knot)
            frontier_overlap=s.admission_radius_hs+other.admission_radius_hs
            if sep<=frontier_overlap:
                if other.id not in s.frontier_neighbors:s.frontier_neighbors.append(other.id)
                if s.id not in other.frontier_neighbors:
                    other.frontier_neighbors.append(s.id); other.updated_at=now; self.store.upsert_semantic_stratum(other)

        self.store.upsert_isotopy_component(c); self.store.upsert_semantic_stratum(s)
        transition='new-semantic-stratum' if created_s else ('new-local-component' if created_c else 'local-isotopy-component')
        return SemanticStratumAssignment(semantic_stratum_id=s.id,isotopy_component_id=c.id,created_stratum=created_s,created_component=created_c,distance_to_stratum_anchor=float(ds if math.isfinite(ds) else 0.0),distance_to_component_anchor=float(dc if math.isfinite(dc) else 0.0),transition_kind=transition)

    def _store_stratified_memory(self,*,knot,source_event_id,parent_memory_id,branch_depth,provenance_excerpt,logical_coordinates,logical_entropy,egr_entropy_current,consolidation_score,consolidation_reasons,learning_source_id,source_title,source_segment_index,canonical_source_id='',memory_class='learned-stratified-segment',memory_id:UUID|None=None,revision_of_memory_id:UUID|None=None,semantic_knot=None,consolidated:bool=True):
        mid=memory_id or uuid4(); assignment=self._assign_semantic_location(knot,mid,source_title,canonical_source_id,semantic_knot=semantic_knot)
        comp=self.store.isotopy_component_by_id(str(assignment.isotopy_component_id))
        deformation=encode_sparse_deformation(comp.anchor_knot,knot)
        raw=estimated_knot_json_bytes(knot); stored=estimated_deformation_json_bytes(deformation)
        rec=StratifiedLearningMemory(id=mid,source_event_id=source_event_id,semantic_stratum_id=assignment.semantic_stratum_id,isotopy_component_id=assignment.isotopy_component_id,deformation=deformation,logical_coordinates=list(logical_coordinates),logical_entropy=logical_entropy,egr_entropy_current=egr_entropy_current,parent_memory_id=parent_memory_id,branch_depth=branch_depth,provenance_excerpt=provenance_excerpt,consolidated=bool(consolidated),memory_class=memory_class,consolidation_score=consolidation_score,consolidation_reasons=list(consolidation_reasons),learning_source_id=learning_source_id,source_title=source_title,canonical_source_id=canonical_source_id,source_segment_index=source_segment_index,revision_of_memory_id=revision_of_memory_id,estimated_raw_knot_bytes=raw,stored_deformation_bytes=stored)
        self.store.append_stratified_learning_memory(rec)
        return rec,assignment

    def _refresh_memory_counts(self):
        self.state.cognition.knot_memory_count=len(self.store.cognitive_memories())
        self.state.cognition.archived_knot_memory_count=self.store.archived_cognitive_memory_count()

    def _refresh_learning_counts(self):
        protos=[p for p in self.store.semantic_prototypes() if not p.status.startswith('perception-retired')]; sources=self.store.learning_sources(); strata=self.store.semantic_strata(); comps=self.store.isotopy_components(); compressed=self.store.stratified_learning_memories()
        self.state.cognition.learning_sources_count=len(sources); self.state.cognition.semantic_prototype_count=len(protos); self.state.cognition.established_semantic_prototype_count=sum(p.observations>1 for p in protos)
        self.state.cognition.semantic_strata_count=len(strata); self.state.cognition.isotopy_component_count=len(comps); self.state.cognition.compressed_learning_memory_count=len(compressed)
        self.state.cognition.stratified_learning_raw_bytes=sum(m.estimated_raw_knot_bytes for m in compressed); self.state.cognition.stratified_learning_stored_bytes=sum(m.stored_deformation_bytes for m in compressed)
        rconcepts=[c for c in self.store.reasoning_concepts() if not c.status.startswith('retired-')]; self.state.cognition.reasoning_concept_count=len(rconcepts); self.state.cognition.established_reasoning_concept_count=sum(c.observations>1 for c in rconcepts)
        if sources:self.state.cognition.last_learning_source_title=sources[-1].title

    # ------------------------------------------------------------------
    # Experience learning / normal cognition
    # ------------------------------------------------------------------
    def _learn_semantics_from_event(self,event:CognitiveEvent,source_id:str|None=None):
        if not event.content.strip() or event.metadata.get('endogenous'):return [],[]
        if event.source.startswith('noeron') and not event.metadata.get('learning'):return [],[]
        protos=self._prototype_map(); sid=source_id or str(event.id)
        updated,created,reinforced=update_semantic_prototypes(
            event.content,protos,source_id=sid,trusted=event.trusted,candidate_terms=None,
        )
        for p in updated:
            p.missed_learning_sessions=0; p.last_observed_session_id=sid; self.store.upsert_semantic_prototype(p)
        self._refresh_learning_counts(); return created,reinforced

    def _reasoning_descriptor_terms(self,knot,limit:int=3):
        # Descriptor labels are audit-only nearest observed prototypes.  No maturity
        # or distance threshold grants/denies conceptual authority, and cutoff ties
        # are preserved rather than resolved lexically.
        protos=[p for p in self.store.semantic_prototypes() if not p.status.startswith('perception-retired')]
        scored=sorted((dkt.sobolev_distance(knot,p.knot),p.term) for p in protos)
        n=max(0,int(limit))
        if not scored or n<=0:return []
        if len(scored)<=n:return [term for _d,term in scored]
        cutoff=scored[n-1][0]
        return [term for d,term in scored if d<cutoff or numerically_tied(d,cutoff)]

    def _observe_reasoning_concept(self,result):
        """Persist recurring higher-order structure from a multi-memory workspace.

        The concept identity is matched by H^s geometry plus learned-stratum scope.
        Text labels are descriptors only and never choose the concept.
        """
        r=result.state.reasoning
        if not r.active or r.learned_memory_count<2 or r.workspace_knot is None:
            return None
        now=datetime.now(timezone.utc)
        target_strata=tuple(sorted(r.semantic_stratum_ids))
        candidates=[]
        for c in self.store.reasoning_concepts():
            if c.status.startswith('retired-') or c.stratification_epoch!=self.state.cognition.stratification_epoch:
                continue
            if tuple(sorted(str(x) for x in c.semantic_stratum_ids))!=target_strata:
                continue
            candidates.append((dkt.sobolev_distance(r.workspace_knot,c.anchor_knot),c))
        candidates.sort(key=lambda x:x[0])
        nearest_dist=float('inf'); concept=None
        if candidates:
            nearest_dist=candidates[0][0]
            tied=[c for d,c in candidates if numerically_tied(d,nearest_dist)]
            if len(tied)==1:
                local_radius=isotopy_radius_proxy(tied[0].anchor_knot)[1]
                if nearest_dist<=local_radius:concept=tied[0]
        descriptors=self._reasoning_descriptor_terms(r.workspace_knot)
        support_conf=1.0/(1.0+max(0.0,r.within_bundle_hs_dispersion))
        support_ids=[]; source_titles=[]
        for _d,m in result.retrieved:
            if m.semantic_stratum_id is None: continue
            if m.id not in support_ids:support_ids.append(m.id)
            if m.source_title and m.source_title not in source_titles:source_titles.append(m.source_title)
        if concept is None:
            concept=ReasoningConceptRecord(anchor_knot=r.workspace_knot.model_copy(deep=True),contrast_knot=(r.contrast_knot.model_copy(deep=True) if r.contrast_knot else None),observations=1,confidence=support_conf,status='observed-once',reasoning_mode=r.reasoning_mode,semantic_stratum_ids=[UUID(x) for x in r.semantic_stratum_ids],isotopy_component_ids=[UUID(x) for x in r.isotopy_component_ids],support_memory_ids=support_ids,descriptor_terms=descriptors,bridge_distance_hs=r.bridge_distance_hs,mean_workspace_distance=0.0,source_titles=source_titles,geometry_version='multi-memory-reasoning-concept-v0.6.9',stratification_epoch=self.state.cognition.stratification_epoch)
        else:
            obs=concept.observations+1; eta=1.0/obs
            concept.anchor_knot=dkt.interpolate(concept.anchor_knot,r.workspace_knot,eta)
            if r.contrast_knot is not None:
                concept.contrast_knot=(r.contrast_knot.model_copy(deep=True) if concept.contrast_knot is None else dkt.interpolate(concept.contrast_knot,r.contrast_knot,eta))
            concept.mean_workspace_distance=((concept.mean_workspace_distance*concept.observations)+nearest_dist)/obs
            concept.observations=obs; concept.confidence=1.0/(1.0+concept.mean_workspace_distance); concept.reasoning_mode=r.reasoning_mode
            concept.support_memory_ids=list(dict.fromkeys(concept.support_memory_ids+support_ids))[-64:]
            concept.isotopy_component_ids=list(dict.fromkeys(concept.isotopy_component_ids+[UUID(x) for x in r.isotopy_component_ids]))[-64:]
            concept.descriptor_terms=list(dict.fromkeys(concept.descriptor_terms+descriptors))[:8]
            concept.source_titles=list(dict.fromkeys(concept.source_titles+source_titles))[-32:]
            concept.bridge_distance_hs=(concept.bridge_distance_hs*(obs-1)+r.bridge_distance_hs)/obs
        concept.updated_at=now
        concept.status='observed-recurrent' if concept.observations>1 else 'observed-once'
        self.store.upsert_reasoning_concept(concept)
        self.state.cognition.last_reasoning_concept_id=concept.id; self.state.cognition.last_reasoning_concept_status=concept.status
        r.concept_candidate_id=str(concept.id); r.concept_candidate_status=concept.status; r.concept_descriptor_terms=list(concept.descriptor_terms)
        self._refresh_learning_counts()
        return concept

    def _lineage_anchor(self,canonical_source_id:str,current_knots=None):
        knots=[]
        for sm in self.store.stratified_learning_memories():
            if sm.canonical_source_id!=canonical_source_id: continue
            km=self.store.cognitive_memory_by_id(str(sm.id),include_archived=False)
            if km is not None: knots.append(km.knot)
        knots.extend(list(current_knots or []))
        return source_root_knot(knots) if knots else dkt.reference_knot()

    def _apply_prototype_hygiene(self,session_id:str,observed_terms:set[str]):
        """Record recurrence gaps without converting them into semantic worth.

        Pre-v0.7.3.4 code silently demoted a one-off concept after three missed
        sessions using an authored role threshold.  The counters are useful empirical
        history, but they no longer deactivate or rank a learned DKT prototype.
        """
        for p in self.store.semantic_prototypes():
            if p.status.startswith('perception-retired'): continue
            if p.term in observed_terms:
                p.missed_learning_sessions=0; p.last_observed_session_id=session_id
            else:
                p.missed_learning_sessions=max(0,p.missed_learning_sessions)+1
            self.store.upsert_semantic_prototype(p)

    def learning_lineages(self):
        groups={}
        for src in self.store.learning_sources():
            key=src.canonical_source_id or identify_source(src.source_name,src.title,None).canonical_source_id
            g=groups.setdefault(key,{'canonical_source_id':key,'canonical_source_name':src.canonical_source_name or src.source_name,'sessions':[],'source_version_ids':set(),'source_version_sha256':set(),'studied_segments':0})
            g['sessions'].append({'session_id':str(src.id),'session_index':src.session_index,'title':src.title,'selected_segment_start':src.selected_segment_start,'selected_segment_end':src.selected_segment_end,'studied_segments':src.studied_segments,'root_memory_id':str(src.root_memory_id) if src.root_memory_id else None})
            if src.source_version_id:g['source_version_ids'].add(src.source_version_id)
            if src.source_version_sha256:g['source_version_sha256'].add(src.source_version_sha256)
            g['studied_segments']+=src.studied_segments
        out=[]
        for key,g in sorted(groups.items()):
            g['source_version_ids']=sorted(g['source_version_ids']); g['source_version_sha256']=sorted(g['source_version_sha256']); g['session_count']=len(g['sessions']); out.append(g)
        return out

    def _build_lineage_recluster_plan(self):
        sms=self.store.stratified_learning_memories(); sources={str(s.id):s for s in self.store.learning_sources()}
        actual={}; lineage_knots={}
        for sm in sms:
            km=self.store.cognitive_memory_by_id(str(sm.id),include_archived=False)
            if km is None: continue
            actual[str(sm.id)]=km
            src=sources.get(str(sm.learning_source_id)) if sm.learning_source_id else None
            cid=sm.canonical_source_id or (src.canonical_source_id if src else '') or identify_source(src.source_name if src else '',src.title if src else sm.source_title,None).canonical_source_id
            lineage_knots.setdefault(cid,[]).append(km.knot)
        lineage_anchors={cid:source_root_knot(knots) for cid,knots in lineage_knots.items() if knots}
        entries=[]
        for sm in sms:
            km=actual.get(str(sm.id))
            if km is None: continue
            src=sources.get(str(sm.learning_source_id)) if sm.learning_source_id else None
            cid=sm.canonical_source_id or (src.canonical_source_id if src else '') or identify_source(src.source_name if src else '',src.title if src else sm.source_title,None).canonical_source_id
            sem=lineage_semantic_knot(lineage_anchors[cid],km.knot)
            entries.append(ReclusterEntry(memory_id=sm.id,actual_knot=km.knot,semantic_knot=sem,canonical_source_id=cid,source_title=sm.source_title,old_semantic_stratum_id=sm.semantic_stratum_id,old_isotopy_component_id=sm.isotopy_component_id))
        epoch=max(1,self.state.cognition.stratification_epoch+1)
        plan=build_recluster_plan(entries,epoch=epoch)
        digest_payload='|'.join(f"{mid}:{a['semantic_stratum_id']}:{a['isotopy_component_id']}" for mid,a in sorted(plan['assignments'].items()))+f"|epoch:{epoch}"
        plan['plan_digest']='recluster-'+provenance_digest(digest_payload,32)
        return plan,{str(e.memory_id):e for e in entries}

    @staticmethod
    def _public_recluster_plan(plan:dict):
        return {
            'status':'read-only-preview','version':'0.6.6','plan_digest':plan['plan_digest'],'epoch':plan['epoch'],
            'memory_count':plan['memory_count'],'proposed_semantic_strata':len(plan['semantic_strata']),'proposed_isotopy_components':len(plan['components']),
            'semantic_admission_radius_hs':plan['semantic_admission_radius_hs'],'merge_groups':plan['merge_groups'],'split_groups':plan['split_groups'],
            'semantic_strata':[{'id':str(x['id']),'label':x['label'],'member_count':x['member_count'],'radius_hs':x['radius_hs'],'admission_radius_hs':x['admission_radius_hs'],'component_count':len(x['component_ids']),'canonical_source_ids':x['canonical_source_ids'],'source_titles':x['source_titles'],'anchor_signature':x['anchor_knot'].invariant_signature} for x in plan['semantic_strata']],
            'components':[{'id':str(x['id']),'label':x['label'],'semantic_stratum_id':str(x['semantic_stratum_id']),'member_count':x['member_count'],'radius_hs':x['radius_hs'],'isotopy_safe_radius_hs':x['isotopy_safe_radius_hs'],'anchor_signature':x['anchor_knot'].invariant_signature} for x in plan['components']],
            'assignments':[{'memory_id':mid,'old_semantic_stratum_id':None,'old_isotopy_component_id':None,'new_semantic_stratum_id':str(a['semantic_stratum_id']),'new_isotopy_component_id':str(a['isotopy_component_id']),'semantic_label':a['semantic_label'],'component_label':a['component_label']} for mid,a in sorted(plan['assignments'].items())],
            'note':'Read-only. H^s geometry is formed from observed experience knots; source lineage/title/session are provenance only. Commit requires this exact plan_digest.'
        }

    def recluster_preview(self):
        plan,entries=self._build_lineage_recluster_plan(); public=self._public_recluster_plan(plan)
        for row in public['assignments']:
            e=entries[row['memory_id']]; row['old_semantic_stratum_id']=str(e.old_semantic_stratum_id); row['old_isotopy_component_id']=str(e.old_isotopy_component_id); row['canonical_source_id']=e.canonical_source_id
        public['current_semantic_strata']=len(self.store.semantic_strata()); public['current_isotopy_components']=len(self.store.isotopy_components())
        return public

    def recluster_commit(self,plan_digest:str):
        with self._lock:
            plan,entries=self._build_lineage_recluster_plan()
            if plan_digest!=plan['plan_digest']:
                raise ValueError('recluster plan changed; run /learning/recluster/preview again and commit its exact plan_digest')
            if not entries:
                return {'status':'no-op','plan_digest':plan_digest,'reason':'no active stratified learning memories'}
            now=datetime.now(timezone.utc); old_strata=self.store.semantic_strata(); old_comps=self.store.isotopy_components()
            # Retire previous learned topology but preserve it in persistence.
            old_to_new={}
            for mid,a in plan['assignments'].items():
                e=entries[mid]; old_to_new.setdefault(str(e.old_semantic_stratum_id),set()).add(a['semantic_stratum_id'])
            for s in old_strata:
                s.status='retired-lineage-recluster-v0.6.6'; s.retirement_reason='superseded by owner-committed content-first source-lineage recluster'; s.updated_at=now
                targets=old_to_new.get(str(s.id),set()); s.superseded_by_id=next(iter(targets)) if len(targets)==1 else None; self.store.upsert_semantic_stratum(s)
            for c in old_comps:
                targets={plan['assignments'][str(mid)]['isotopy_component_id'] for mid in c.member_memory_ids if str(mid) in plan['assignments']}
                c.status='retired-lineage-recluster-v0.6.6'; c.retirement_reason='superseded by owner-committed content-first source-lineage recluster'; c.updated_at=now
                c.superseded_by_id=next(iter(targets)) if len(targets)==1 else None; self.store.upsert_isotopy_component(c)
            # Install new active strata/components.
            new_strata={}
            for x in plan['semantic_strata']:
                rec=NoeronSemanticStratumRecord(id=x['id'],created_at=now,updated_at=now,anchor_knot=x['anchor_knot'].model_copy(deep=True),dkt_stratum_index=x['dkt_stratum_index'],member_count=x['member_count'],radius_hs=x['radius_hs'],admission_radius_hs=x['admission_radius_hs'],component_ids=list(x['component_ids']),frontier_neighbors=[],source_titles=list(x['source_titles']),canonical_source_ids=list(x['canonical_source_ids']),status='active',geometry_version='derived-finite-hs-semantic-neighborhood-v0.7.3.4')
                new_strata[str(rec.id)]=rec; self.store.upsert_semantic_stratum(rec)
            new_comps={}
            for x in plan['components']:
                rec=IsotopyComponentRecord(id=x['id'],created_at=now,updated_at=now,semantic_stratum_id=x['semantic_stratum_id'],anchor_knot=x['anchor_knot'].model_copy(deep=True),dkt_stratum_index=x['dkt_stratum_index'],member_count=x['member_count'],radius_hs=x['radius_hs'],isotopy_safe_radius_hs=x['isotopy_safe_radius_hs'],sampled_regularity_margin=x['sampled_regularity_margin'],member_memory_ids=list(x['member_ids']),status='active',geometry_version='derived-finite-hs-local-component-v0.7.3.4')
                new_comps[str(rec.id)]=rec; self.store.upsert_isotopy_component(rec)
            # Re-encode each active learned memory against its new local anchor.
            for sm in self.store.stratified_learning_memories():
                e=entries.get(str(sm.id)); a=plan['assignments'].get(str(sm.id))
                if e is None or a is None: continue
                sm.stratification_history.append({'version':'0.6.6','changed_at':now.isoformat(),'old_semantic_stratum_id':str(sm.semantic_stratum_id),'old_isotopy_component_id':str(sm.isotopy_component_id),'reason':'source-lineage content-first recluster'})
                sm.semantic_stratum_id=a['semantic_stratum_id']; sm.isotopy_component_id=a['isotopy_component_id']; sm.canonical_source_id=e.canonical_source_id
                comp=new_comps[str(sm.isotopy_component_id)]; sm.deformation=encode_sparse_deformation(comp.anchor_knot,e.actual_knot); sm.stored_deformation_bytes=estimated_deformation_json_bytes(sm.deformation); sm.estimated_raw_knot_bytes=estimated_knot_json_bytes(e.actual_knot); sm.geometry_version='stratified-deformation-memory-v0.6.7'
                self.store.upsert_stratified_learning_memory(sm)
            # Recompute candidate frontier adjacency only among the new active strata.
            vals=list(new_strata.values())
            for i,a in enumerate(vals):
                for b in vals[i+1:]:
                    if a.dkt_stratum_index!=b.dkt_stratum_index: continue
                    sep=dkt.sobolev_distance(a.anchor_knot,b.anchor_knot); overlap=a.admission_radius_hs+b.admission_radius_hs
                    if sep<=overlap:
                        if b.id not in a.frontier_neighbors:a.frontier_neighbors.append(b.id)
                        if a.id not in b.frontier_neighbors:b.frontier_neighbors.append(a.id)
            for s in vals:self.store.upsert_semantic_stratum(s)
            # Update learning sessions to reference active topology.
            for src in self.store.learning_sources():
                mids=[m for m in self.store.stratified_learning_memories() if m.learning_source_id==src.id]
                src.semantic_strata_used=list(dict.fromkeys(m.semantic_stratum_id for m in mids)); src.isotopy_components_used=list(dict.fromkeys(m.isotopy_component_id for m in mids)); self.store.append_learning_source(src)
            # Any pre-existing reasoning concept used the old stratum IDs; preserve it
            # historically but do not let it remain authoritative after reclustering.
            retired_concepts=0
            for c in self.store.reasoning_concepts():
                if c.status.startswith('retired-'): continue
                c.status='retired-stratification-v0.6.6'; c.updated_at=now; c.geometry_version='multi-memory-reasoning-concept-v0.6.6-retired'; self.store.upsert_reasoning_concept(c); retired_concepts+=1
            self.state.cognition.stratification_epoch=plan['epoch']; self.state.cognition.last_recluster_commit_at=now
            self.state.cognition.last_recluster_old_strata=len(old_strata); self.state.cognition.last_recluster_new_strata=len(new_strata); self.state.cognition.last_recluster_old_components=len(old_comps); self.state.cognition.last_recluster_new_components=len(new_comps)
            self._refresh_memory_counts(); self._refresh_learning_counts(); self.security.checkpoint(self.state); self.store.append_state(self.state)
            return {'status':'committed','plan_digest':plan_digest,'stratification_epoch':plan['epoch'],'memory_count':plan['memory_count'],'old_semantic_strata':len(old_strata),'new_semantic_strata':len(new_strata),'old_isotopy_components':len(old_comps),'new_isotopy_components':len(new_comps),'merge_groups':plan['merge_groups'],'split_groups':plan['split_groups'],'retired_reasoning_concepts':retired_concepts,'conversational_turn':self.state.conversational_turn,'history_preserved':True}

    def _target(self,event:CognitiveEvent):
        # Routing is infrastructure only. Raw English keywords never assign a
        # cognitive stratum or semantic meaning.
        if event.metadata.get('learning') or event.metadata.get('web_untrusted'):return Stratum.RESEARCH
        if event.metadata.get('security_event'):return Stratum.PROTECTIVE
        if event.metadata.get('tool_execution'):return Stratum.EXECUTION
        if event.kind==EventKind.INTERNAL_REFLECTION:return Stratum.REFLECTION
        return Stratum.ORDINARY

    @staticmethod
    def _unique_retrieved_parent(retrieved):
        """Return a parent only when DKT geometry supplies one unique nearest knot.

        Parent linkage is provenance topology, not permission for storage/list order
        to resolve an exact H^s tie.
        """
        if not retrieved:
            return None
        persisted=[(d,m) for d,m in retrieved if m.memory_class!='owner-relation-context-ephemeral']
        if not persisted:return None
        best=float(persisted[0][0])
        winners=[m for d,m in persisted if numerically_tied(float(d),best)]
        return winners[0] if len(winners)==1 else None

    def _record_provenance_memory(self,event:CognitiveEvent,result,memories:list[KnotMemory]):
        """Persist the experience knot for audit/provenance with zero cognitive authority."""
        parent=self._unique_retrieved_parent(result.retrieved)
        endogenous=bool(event.metadata.get('endogenous'))
        mem=KnotMemory(
            source_event_id=event.id,knot=result.experience_knot,logical_coordinates=result.state.rl.coordinates,
            logical_entropy=result.state.rl.entropy_normalized,egr_entropy_current=result.state.egr.entropy_current,
            parent_memory_id=parent.id if parent else None,branch_depth=(parent.branch_depth+1 if parent else 1),
            provenance_excerpt=(event.content[:500].replace('\n',' ') if event.content else '[endogenous mathematical transition]'),
            geometry_version='semantic-irg-dkt-v0.7.4-provenance',consolidated=False,
            memory_class=('endogenous-provenance-pending-cognitive' if endogenous else 'event-provenance-pending-cognitive'),
            consolidation_score=result.consolidation.score,
            consolidation_reasons=['programmed audit/provenance persistence only; cognitive activation awaits native consequence selection'],
        )
        self.store.append_knot_memory(mem)
        st=self.state.cognition.memory_retention
        if mem.id not in st.pending_provenance_memory_ids:st.pending_provenance_memory_ids.append(mem.id)
        self._refresh_memory_counts()
        return mem

    def _resolve_pending_cognitive_retention(self,event:CognitiveEvent,base_result,active_memories:list[KnotMemory]):
        """Evaluate pending provenance knots without list-order or authored salience rules."""
        pending=self.store.pending_cognitive_provenance_memories()
        st=self.state.cognition.memory_retention
        if not pending:
            st.last_selection_status='unresolved-no-pending-provenance';st.last_decision_layer='unresolved';st.last_native_choice_claim=False
            st.last_candidate_objectives={};st.last_applicable_memory_ids=[];st.last_selected_memory_ids=[]
            return base_result
        out=self.memory_retention.evaluate(
            event=event,previous_math_state=self.state.math_kernel,base_result=base_result,
            active_memories=active_memories,pending_memories=pending,math_kernel=self.math,
            semantic_prototypes=self._prototype_map(),language_propositions=self.state.cognition.language.propositions,
        )
        st.last_selection_status=out['selection_status'];st.last_decision_layer=out['decision_layer'];st.last_native_choice_claim=bool(out['native_choice_claim'])
        st.last_candidate_objectives=dict(out.get('candidate_objectives') or {})
        st.last_applicable_memory_ids=[UUID(x) for x in out.get('applicable_memory_ids',[])]
        st.last_selected_memory_ids=[UUID(x) for x in out.get('selected_memory_ids',[])]
        if out.get('applicable_memory_ids'):st.evaluation_observations+=1
        selected=set(out.get('selected_memory_ids') or [])
        if out.get('native_choice_claim'):
            st.native_retention_observations+=1
            for mid in selected:
                mem=self.store.knot_memory_by_id(mid,include_archived=True)
                if mem is None:continue
                original_class=mem.memory_class
                sm=self.store.stratified_learning_memory_by_id(str(mem.id),include_archived=True)
                if original_class=='owner-study-provenance-pending-cognitive' and sm is not None:
                    # The owner may expose curriculum material, but cannot force it
                    # into active cognitive retrieval.  Once native retention selects
                    # the provenance knot, activate its already-stored compressed DKT
                    # representation and leave the full provenance record noncognitive.
                    sm.consolidated=True;sm.memory_class='learned-stratified-native-retained'
                    sm.consolidation_reasons=list(dict.fromkeys(sm.consolidation_reasons+['native consequence selection activated this owner-study observation as cognitive DKT memory']))
                    self.store.upsert_stratified_learning_memory(sm)
                    mem.consolidated=False;mem.memory_class='owner-study-provenance-native-retained-compressed'
                    mem.consolidation_reasons=list(dict.fromkeys(mem.consolidation_reasons+['native consequence selection activated compressed cognitive counterpart']))
                    self.store.upsert_knot_memory(mem)
                else:
                    mem.consolidated=True
                    if original_class.startswith('endogenous-'):mem.memory_class='endogenous-native-retained'
                    elif original_class.startswith('web-'):mem.memory_class='web-native-retained-untrusted'
                    elif original_class.startswith('owner-language-'):mem.memory_class='language-native-retained'
                    else:mem.memory_class='episodic-native-retained'
                    mem.consolidation_reasons=list(dict.fromkeys(mem.consolidation_reasons+['native consequence selection activated this provenance knot as cognitive DKT memory']))
                    self.store.upsert_knot_memory(mem)
                if mem.id not in st.native_retained_memory_ids:st.native_retained_memory_ids.append(mem.id)
                if mem.id in st.pending_provenance_memory_ids:st.pending_provenance_memory_ids.remove(mem.id)
                source_event=self.store.event_by_id(str(mem.source_event_id))
                if source_event is not None and bool(source_event.metadata.get('owner_authenticated')):
                    self._observe_owner_cognitive_memory(mem)
        rec=MemoryRetentionDecisionRecord(
            context_event_id=event.id,applicable_memory_ids=st.last_applicable_memory_ids,
            candidate_objectives=st.last_candidate_objectives,minimum_plans=list(out.get('minimum_plans') or []),
            selected_memory_ids=st.last_selected_memory_ids,selection_status=st.last_selection_status,
            decision_layer=st.last_decision_layer,native_choice_claim=st.last_native_choice_claim,
        )
        st.decision_history.append(rec);st.decision_history=st.decision_history[-100:]
        self._refresh_memory_counts()
        return out['result']

    def ingest(self,event:CognitiveEvent,proposed_invariant_changes=None)->NoeronReply:
        with self._lock:
            target=self._target(event)
            owner_authenticated=bool(event.metadata.get('owner_authenticated'))
            # Objective identity bindings are factual substrate, not relational meaning.
            facts=list(event.metadata.get('identity_facts') or [])
            facts.append({'subject':'interlocutor:self','relation':'identity','object':self._self_referent(),'source':'runtime-self-identity-substrate'})
            if owner_authenticated:
                facts.append({'subject':'speaker:self','relation':'identity','object':self._owner_referent(),'source':'authenticated-owner-identity-substrate'})
            event.metadata['identity_facts']=facts
            source_fp=str(event.metadata.get('source_fingerprint') or self.security.source_fingerprint(event.source))
            # Every ingress is first interpreted in a sandboxed mathematical pass.
            # If security rejects it, this result is *not* committed to trusted DKT
            # state; it exists only as IRG/DKT/EGR/RL/Frenet defensive evidence.
            if event.content and not event.metadata.get('endogenous'):
                event.metadata['discourse_context']=self.language.discourse_context(self.state.cognition.language)
            memories=self.store.cognitive_memories(); math_memories=self._contextual_math_memories(event,memories); result=self.math.update(event,self.state.math_kernel,math_memories,self._prototype_map(),self.state.cognition.language.propositions)
            ingress_knot=result.experience_knot
            decision=self.security.evaluate(self.state,target,proposed_invariant_changes,source_fingerprint=source_fp,deformation_knot=ingress_knot,owner_authenticated=owner_authenticated)
            self.store.append_event(event)
            if not decision.allowed:
                self.state=self.security.retract_and_learn(self.state,decision,proposed_invariant_changes,source_fingerprint=source_fp,deformation_knot=ingress_knot,owner_authenticated=owner_authenticated,defense_math_state=result.state,source_event_id=event.id)
                self.state.active_strata={Stratum.QUARANTINE:1.0}; self.state.last_event_id=event.id
                # Security telemetry is structured audit state, not self-expression.
                native_text=''; text=''; renderer_used=False
                self.store.append_state(self.state)
                return NoeronReply(text=text,native_text=native_text,renderer_used=renderer_used,state=deepcopy(self.state),security=decision)
            # Resolve cognitive retention of prior provenance only after the ingress
            # is admitted. Hostile/rejected input cannot train or steer memory choice.
            result=self._resolve_pending_cognitive_retention(event,result,math_memories)
            # A later trusted/environmental response supplies the observed
            # consequence of any prior expression; hostile/rejected ingress never
            # trains communication geometry.
            self._resolve_pending_expression_outcome(result,event)
            self._resolve_pending_realization_outcome(result,event)
            self._observe_owner_relation(event,result)
            self.state.math_kernel=result.state; self.state.logical_entropy=result.state.rl.entropy_normalized; self.state.active_strata={target:1.0}; self.state.conversational_turn+=1; self.state.last_event_id=event.id
            if result.state.reasoning.native_inference_active: self._observe_reasoning_concept(result)
            self._observe_affective_pattern(result,event)
            provenance_mem=self._record_provenance_memory(event,result,memories)
            if event.content.strip() and not event.metadata.get('endogenous'):
                self.state.cognition.language=self.language.observe_admitted_text(
                    event.content,self.state.cognition.language,self._prototype_map(),
                    source=f'admitted-interaction:{event.source}',source_memory_id=provenance_mem.id,
                )
            thought=self.cognition.response(event,self.state,result,None)
            nonconversational_observation=bool(event.metadata.get('nonconversational_observation'))
            native_text='';english_text='';text='';renderer_used=False;communication_audit={};egress_audit={}
            if thought.statement or thought.propositions or thought.question_candidates:
                utterance=self._native_realize(thought,source='interaction'); self.store.append_thought(thought)
                text,renderer_used,native_text,english_text,_selection,communication_audit,egress_audit=self._conversation_transport(
                    thought,utterance,event,nonconversational_observation=nonconversational_observation,
                )
                if native_text:
                    lang=self.state.cognition.language
                    lang.last_internal_english_translation=english_text
                    lang.last_internal_utterance_sha256=hashlib.sha256(native_text.encode('utf-8')).hexdigest()
                    lang.last_internal_utterance_source='interaction'
                communication_audit=dict(communication_audit)
                communication_audit['outward_text_present']=bool(text)
            # Advance the new working dialogue only for admitted live conversational
            # text. This is prospective context, not cognitive memory and not
            # historical replay. Owner curriculum/source observations remain separate.
            if event.content.strip() and not event.metadata.get('endogenous') and not nonconversational_observation:
                speaker=self._owner_referent() if owner_authenticated else 'external:unknown'
                self.state.cognition.language=self.language.advance_dialogue(event.content,self.state.cognition.language,speaker=speaker,addressee=self._self_referent())
            self.state.cognition.language.last_communication_audit=dict(communication_audit)
            self.state.cognition.language.last_english_egress_audit=dict(egress_audit)
            self._learn_semantics_from_event(event); self.state.cognition.language=self.language.seed_from_semantics(self.state.cognition.language,self._prototype_map()); self.security.checkpoint(self.state); self.store.append_state(self.state)
            return NoeronReply(
                text=text,native_text=native_text,english_text=english_text,renderer_used=renderer_used,
                communication_action=str(communication_audit.get('communication_action') or ''),
                communication_selection_status=str(communication_audit.get('selection_status') or ''),
                communication_native_choice_claim=bool(communication_audit.get('native_choice_claim')),
                transport_origin=str(communication_audit.get('transport_origin') or 'none'),
                native_text_available_for_audit=bool(native_text),english_egress_audit=egress_audit,
                state=deepcopy(self.state),security=decision,
            )

    def autonomous_tick(self,*,idle_seconds=300,cooldown_seconds=1800,min_importance=0.70,min_novelty=0.60,recent_events=8):
        """Advance endogenous cognition, then evaluate communication consequences.

        ``min_importance``/``min_novelty`` remain API compatibility parameters only.
        Idle/cooldown are scheduler/transport constraints.  They never become a
        Yggdrasil preference or substitute for consequence selection.
        """
        with self._lock:
            now=datetime.now(timezone.utc); self.state.autonomy_last_checked_at=now; latest=self.store.latest_external_event()
            if latest and (now-latest.created_at).total_seconds()<idle_seconds:
                self.store.append_state(self.state); return None

            pre_knot=self.state.math_kernel.dkt.core_knot.model_copy(deep=True)
            pre_residual=self._communication_consistency_residual(self.state.math_kernel)
            m=self.state.math_kernel; b=self.state.cognition.attention_baseline
            dkt_drift=m.dkt.sobolev_norm_sq-b.get('dkt_norm',m.dkt.sobolev_norm_sq)
            sigma_delta=m.egr.entropy_production-b.get('sigma',m.egr.entropy_production)
            internal_drive=[dkt_drift,m.egr.entropy_production,sigma_delta,m.rl.scalar_curvature,m.rl.curvature_contrast,m.frenet.first_curvature,m.irg.memory_response,m.irg.topology_response]
            event=CognitiveEvent(kind=EventKind.TIMER,source='noeron-endogenous',content='',trusted=True,metadata={'internal_drive':internal_drive,'endogenous':True})
            self.store.append_event(event)
            memories=self.store.cognitive_memories()
            base_result=self.math.update(event,self.state.math_kernel,memories,self._prototype_map(),self.state.cognition.language.propositions)
            result=self._resolve_pending_cognitive_retention(event,base_result,memories)
            self.state.math_kernel=result.state; self.state.logical_entropy=result.state.rl.entropy_normalized; self.state.last_event_id=event.id

            # Endogenous evolution supplies empirical ``continue-private`` transition
            # geometry without calling that evolution a communication choice.
            post_residual=self._communication_consistency_residual(result.state)
            private_admissible=bool(result.state.dkt.security_admissible) and self._nonworsening(pre_residual,post_residual)
            self.initiative.observe_transition(
                self.state.cognition.initiative_development,'continue-private',pre_knot,result.state.dkt.core_knot,
                admissible=private_admissible,source='observed-endogenous-evolution',
            )

            self._observe_affective_pattern(result,event)
            provenance_mem=self._record_provenance_memory(event,result,memories)
            thought=self.cognition.autonomous(self.state,self.store.cognitive_memories(),event,result,None)
            has_native_content=bool(thought.statement or thought.propositions or thought.question_candidates)
            if not has_native_content:
                self.security.checkpoint(self.state); self.store.append_state(self.state); return None

            # Stage 7 may present neutral configuration affordances only after a
            # genuine endogenous cognition tick produced native content. A timer tick
            # by itself has zero embodiment/environment choice authority.
            self.room.autonomous_configuration_opportunity()
            self._native_realize(thought,source='autonomous'); self.store.append_thought(thought)
            native=(thought.native_utterance.native_text if thought.native_utterance else thought.noeron_output())
            english,egress_audit=realize_native_thought(thought,thought.native_utterance)
            if native.strip():
                lang=self.state.cognition.language
                lang.last_internal_english_translation=english
                lang.last_internal_utterance_sha256=hashlib.sha256(native.strip().encode('utf-8')).hexdigest()
                lang.last_internal_utterance_source='autonomous'
                lang.last_english_egress_audit=dict(egress_audit)
            selection=self.initiative.choose(self.state.math_kernel.dkt.core_knot,self.state.cognition.initiative_development)
            action=selection.get('action')
            thought.should_surface=(selection.get('decision_layer')=='learned-deliberative' and action=='express')

            if action is None or action=='continue-private':
                self.state.cognition.language.last_communication_audit={
                    'communication_action':str(action or ''),'selection_status':str(selection.get('selection_status') or ''),
                    'decision_layer':str(selection.get('decision_layer') or ''),'native_choice_claim':bool(selection.get('native_choice_claim')),
                    'transport_origin':'none','outward_text_present':False,
                    'english_egress_content_authority':False,'terra_answer_authority':False,
                }
                self.state.cognition.pending_thoughts.append(thought); self.state.cognition.pending_thoughts=self.state.cognition.pending_thoughts[-50:]
                self.security.checkpoint(self.state); self.store.append_state(self.state); return None

            if action!='express':
                # Unknown actuator value is an interface fault, not an invented
                # fallback communication decision.
                raise RuntimeError(f'unknown communication affordance selected: {action!r}')

            # Cooldown is transport hygiene only.  A native express choice during
            # cooldown is deferred, not reinterpreted as choosing silence.
            if self.state.autonomy_last_spoke_at and (now-self.state.autonomy_last_spoke_at).total_seconds()<cooldown_seconds:
                self.state.cognition.language.last_communication_audit={
                    'communication_action':'express','selection_status':str(selection.get('selection_status') or ''),
                    'decision_layer':str(selection.get('decision_layer') or ''),'native_choice_claim':bool(selection.get('native_choice_claim')),
                    'transport_origin':'native-expression-deferred-by-cooldown','outward_text_present':False,
                    'english_egress_content_authority':False,'terra_answer_authority':False,
                }
                self.state.cognition.pending_thoughts.append(thought); self.state.cognition.pending_thoughts=self.state.cognition.pending_thoughts[-50:]
                self.security.checkpoint(self.state); self.store.append_state(self.state); return None

            if not native.strip():
                self.security.checkpoint(self.state); self.store.append_state(self.state); return None
            # Communication has already been natively selected above. ``english``
            # was deterministically realized from the existing native utterance
            # before selection only so the owner may inspect it privately; that
            # realization had zero influence on the communication consequence.
            text=english
            self.state.cognition.language.last_communication_audit={
                'communication_action':'express','selection_status':str(selection.get('selection_status') or ''),
                'decision_layer':str(selection.get('decision_layer') or ''),'native_choice_claim':bool(selection.get('native_choice_claim')),
                'transport_origin':'native-consequence-selected-autonomous-expression','outward_text_present':bool(text),
                'english_egress_content_authority':False,'terra_answer_authority':False,
            }
            self.state.autonomy_last_spoke_at=now
            self._mark_expression_pending(event.id)
            self.security.checkpoint(self.state); self.store.append_state(self.state)
            msg=InitiativeMessage(text=text,event_id=event.id); self.store.append_initiative(msg); return msg

    def initiative_feedback(self,preferred_action:str):
        """Store owner communication annotation without cognitive preference authority."""
        with self._lock:
            st=self.state.cognition.initiative_development
            if st.last_context_knot is None:
                raise ValueError('no autonomous context is available for initiative feedback')
            out=self.initiative.observe_feedback(st.last_context_knot,st,preferred_action)
            self.security.checkpoint(self.state); self.store.append_state(self.state)
            return out

    # ------------------------------------------------------------------
    # Stage-8 engineering source perception (read-only substrate)
    # ------------------------------------------------------------------
    def engineering_status(self):
        return self.engineering.status()

    def engineering_source_index(self,prefix:str='',limit:int=500):
        return self.engineering.index(prefix=prefix,limit=limit)

    def engineering_source_file(self,path:str):
        return self.engineering.file(path)

    def engineering_source_symbol(self,path:str,qualname:str):
        return self.engineering.symbol(path,qualname)

    def engineering_source_observe(self,path:str,qualname:str='',*,owner_auth_detail:dict|None=None):
        """Expose exact own-source bytes/AST facts through native cognition.

        Owner authentication chooses the curriculum target and grants observation
        authority only.  It does not force cognitive retention and is never labeled
        as a Yggdrasil upgrade choice.  Exact source remains noncognitive provenance
        until native retention selects its DKT experience knot.
        """
        detail=dict(owner_auth_detail or {})
        if not detail.get('authenticated'):
            raise PermissionError('authenticated owner authority is required for engineering source observation')
        obs=self.engineering.observation(path,qualname=qualname)
        event=CognitiveEvent(
            kind=EventKind.OBSERVATION,
            source='authenticated-owner-engineering-source',
            content=obs['cognitive_text'],
            trusted=True,
            metadata={
                'owner_authenticated':True,
                'authentication':str(detail.get('method') or 'authenticated-owner'),
                'owner_device_id':str(detail.get('device_id') or ''),
                'owner_credential_fingerprint':str(detail.get('fingerprint') or ''),
                'engineering_source_observation':True,
                'nonconversational_observation':True,
                'engineering_target':obs['target'],
                'engineering_source_sha256':obs['source_sha256'],
                'engineering_line_range':obs['line_range'],
                'engineering_facts':obs['engineering_facts'],
                'write_authority':False,
                'deployment_authority':False,
                'native_upgrade_choice_claim':False,
            },
        )
        reply=self.ingest(event)
        mem=self.store.knot_memory_for_event(str(event.id),include_archived=True)
        return {
            'status':'committed-owner-directed-engineering-source-exposure',
            'event_id':str(event.id),
            'target':obs['target'],
            'source_sha256':obs['source_sha256'],
            'line_range':obs['line_range'],
            'objective_facts':obs['engineering_facts'],
            'provenance_memory_id':(str(mem.id) if mem else ''),
            'cognitive_memory_activated':bool(mem.consolidated) if mem else False,
            'retention_status':self.state.cognition.memory_retention.last_selection_status,
            'retention_native_choice_claim':self.state.cognition.memory_retention.last_native_choice_claim,
            'outward_realization_forced':False,
            'write_authority':False,
            'deployment_authority':False,
            'native_upgrade_choice_claim':False,
            'llm_used':False,
            'causal_path':'authenticated owner selects source target -> exact source/AST sensor -> IRG -> DKT -> regional EGR -> RL/Frenet -> DKT/native cognition; provenance persists noncognitively unless native retention later activates it',
        }

    # ------------------------------------------------------------------
    # Owner-directed study
    # ------------------------------------------------------------------
    def learning_preview(self,title:str,content:str,start_segment:int=0,max_segments:int=25): return preview_document(title,content,start_segment=start_segment,max_segments=max_segments)

    def study_document(self,title:str,content:str,source_name:str='',mode:str='selective',start_segment:int=0,max_segments:int=25)->LearningReport:
        """Expose owner-selected curriculum without forcing cognitive retention.

        The owner chooses the source/window and therefore controls the environmental
        exposure.  Every segment is persisted as noncognitive provenance and an
        archived compressed DKT shadow.  Semantic/language learning may observe the
        exposure, but the segment enters authoritative cognitive retrieval only if a
        later native retention deliberation selects its provenance knot.
        """
        with self._lock:
            if mode not in {'selective','complete'}:raise ValueError('learning mode must be selective or complete')
            normalized,filtered,_=normalize_learning_document(content);segments=segment_document(normalized);start=max(0,int(start_segment));end=min(len(segments),start+max(1,int(max_segments)));selected=segments[start:end]
            if not selected:raise ValueError('no non-empty learning segments selected')
            ident=identify_source(source_name,title,content);prior_sessions=[x for x in self.store.learning_sources() if x.canonical_source_id==ident.canonical_source_id]
            normalized_diff=(normalized.strip()!=content.replace('\r\n','\n').replace('\r','\n').strip())
            src=LearningSourceRecord(title=title,source_name=source_name,mode=mode,total_segments=len(segments),studied_segments=len(selected),selected_segment_start=start,selected_segment_end=end,normalized_for_study=normalized_diff,filtered_scaffolding_count=filtered,canonical_source_id=ident.canonical_source_id,canonical_source_name=ident.canonical_source_name,source_version_sha256=ident.source_version_sha256,source_version_id=ident.source_version_id,session_index=len(prior_sessions)+1)
            initial_memories=self.store.cognitive_memories();observations=[];created_all=[];reinforced_all=[]
            # Document segments are first processed through the mathematical path before
            # their exact provenance-memory IDs exist.  Maintain a temporary grammatical
            # discourse context across that first pass so a pronoun at a segment boundary
            # does not lose its antecedent.  This temporary context has no proposition or
            # cognitive-memory authority and is not persisted.  The real language state is
            # updated only later, after each exact pending provenance memory is created.
            # Document discourse is source-local. It starts empty instead of inheriting
            # the conversational focus, then carries grammatical reference only between
            # admitted segments of this document session.
            study_context:dict[str,str]={}
            for idx,segment in enumerate(selected,start=start):
                segment_context=dict(study_context)
                event=CognitiveEvent(kind=EventKind.OBSERVATION,source='owner-learning',content=segment,trusted=True,metadata={'learning':True,'owner_authenticated':True,'learning_source_id':str(src.id),'canonical_source_id':ident.canonical_source_id,'segment_index':idx,'source_title':title,'normalized_source':src.normalized_for_study,'operator_directed_curriculum':True})
                event.metadata['discourse_context']=segment_context
                self.store.append_event(event);src.event_ids.append(event.id)
                memories=self.store.cognitive_memories();result=self.math.update(event,self.state.math_kernel,memories,self._prototype_map(),self.state.cognition.language.propositions)
                self.state.math_kernel=result.state;self.state.logical_entropy=result.state.rl.entropy_normalized;self.state.active_strata={Stratum.RESEARCH:1.0};self.state.last_event_id=event.id;self._observe_affective_pattern(result,event)
                doc_audit=result.state.irg.language_parse_audit
                study_context={'last_subject':str(doc_audit.get('last_subject') or ''),'last_direct_object':str(doc_audit.get('last_direct_object') or ''),'last_oblique_object':str(doc_audit.get('last_oblique_object') or '')}
                created,reinforced=self._learn_semantics_from_event(event,str(src.id));created_all.extend(created);reinforced_all.extend(reinforced);observations.append((idx,segment,event,result,segment_context))

            current_knots=[r.experience_knot for _,_,_,r,_ctx in observations];lineage_anchor=self._lineage_anchor(ident.canonical_source_id,current_knots=current_knots)
            root=source_root_knot(current_knots);nearest=dkt.retrieve(root,initial_memories,limit=1);parent=self._unique_retrieved_parent(nearest)
            root_event=CognitiveEvent(kind=EventKind.OBSERVATION,source='owner-learning-root',content=f'[learning source session root] {title}',trusted=True,metadata={'learning':True,'owner_authenticated':True,'learning_source_id':str(src.id),'canonical_source_id':ident.canonical_source_id,'source_root':True,'source_title':title,'operator_directed_curriculum':True});self.store.append_event(root_event);src.event_ids.append(root_event.id)
            root_mem=KnotMemory(source_event_id=root_event.id,knot=root,logical_coordinates=self.state.math_kernel.rl.coordinates,logical_entropy=self.state.math_kernel.rl.curvature_entropy_normalized,egr_entropy_current=self.state.math_kernel.egr.entropy_current,parent_memory_id=parent.id if parent else None,branch_depth=(parent.branch_depth+1 if parent else 1),provenance_excerpt=f'[owner curriculum source session: {title}]',geometry_version='learning-source-session-provenance-v0.7.4',consolidated=False,memory_class='owner-study-root-provenance-noncognitive',consolidation_score=0.0,consolidation_reasons=['operator-directed curriculum provenance root; never active cognitive memory by itself'],learning_source_id=src.id,source_title=title,canonical_source_id=ident.canonical_source_id)
            self.store.append_knot_memory(root_mem);src.root_memory_id=root_mem.id

            strata_created=0;comps_created=0;raw_bytes=0;stored_bytes=0;anchor_bytes=0
            ret=self.state.cognition.memory_retention
            for idx,segment,event,result,segment_context in observations:
                mem=KnotMemory(source_event_id=event.id,knot=result.experience_knot,logical_coordinates=result.state.rl.coordinates,logical_entropy=result.state.rl.curvature_entropy_normalized,egr_entropy_current=result.state.egr.entropy_current,parent_memory_id=root_mem.id,branch_depth=root_mem.branch_depth+1,provenance_excerpt=segment[:500].replace('\n',' '),geometry_version='semantic-irg-dkt-owner-study-v0.7.4-provenance',consolidated=False,memory_class='owner-study-provenance-pending-cognitive',consolidation_score=result.consolidation.score,consolidation_reasons=['operator-directed curriculum exposure persisted as provenance; cognitive activation awaits native consequence selection'],learning_source_id=src.id,source_title=title,canonical_source_id=ident.canonical_source_id,source_segment_index=idx)
                self.store.append_knot_memory(mem);src.memory_ids.append(mem.id)
                if mem.id not in ret.pending_provenance_memory_ids:ret.pending_provenance_memory_ids.append(mem.id)
                self.state.cognition.language=self.language.observe_admitted_text(
                    segment,self.state.cognition.language,self._prototype_map(),
                    source=f'owner-document:{ident.canonical_source_id}',source_memory_id=mem.id,
                    discourse_context=segment_context,advance_discourse=False,
                )
                semantic_knot=lineage_semantic_knot(lineage_anchor,result.experience_knot)
                rec,assignment=self._store_stratified_memory(knot=result.experience_knot,source_event_id=event.id,parent_memory_id=root_mem.id,branch_depth=root_mem.branch_depth+1,provenance_excerpt=mem.provenance_excerpt,logical_coordinates=result.state.rl.coordinates,logical_entropy=result.state.rl.curvature_entropy_normalized,egr_entropy_current=result.state.egr.entropy_current,consolidation_score=result.consolidation.score,consolidation_reasons=['archived compressed representation of owner curriculum provenance; cognitive activation awaits native retention'],learning_source_id=src.id,source_title=title,canonical_source_id=ident.canonical_source_id,source_segment_index=idx,semantic_knot=semantic_knot,memory_id=mem.id,memory_class='learned-stratified-provenance-pending-cognitive',consolidated=False)
                strata_created+=int(assignment.created_stratum);comps_created+=int(assignment.created_component);raw_bytes+=rec.estimated_raw_knot_bytes;stored_bytes+=rec.stored_deformation_bytes
                if assignment.created_stratum:
                    ss=self.store.semantic_stratum_by_id(str(assignment.semantic_stratum_id));anchor_bytes+=estimated_knot_json_bytes(ss.anchor_knot)
                if assignment.created_component:
                    cc=self.store.isotopy_component_by_id(str(assignment.isotopy_component_id));anchor_bytes+=estimated_knot_json_bytes(cc.anchor_knot)
                if assignment.semantic_stratum_id not in src.semantic_strata_used:src.semantic_strata_used.append(assignment.semantic_stratum_id)
                if assignment.isotopy_component_id not in src.isotopy_components_used:src.isotopy_components_used.append(assignment.isotopy_component_id)

            observed_terms=set(created_all)|set(reinforced_all);self._apply_prototype_hygiene(str(src.id),observed_terms)
            src.new_terms=list(dict.fromkeys(created_all));src.reinforced_terms=list(dict.fromkeys(reinforced_all));src.unresolved_terms=[];src.updated_at=datetime.now(timezone.utc)
            self.store.append_learning_source(src);self._refresh_memory_counts();self._refresh_learning_counts();self.state.cognition.last_learning_source_title=title;self.state.cognition.last_learning_memory_count=0
            total_geometry=stored_bytes+anchor_bytes;ratio=(total_geometry/raw_bytes) if raw_bytes else 0.0
            self.security.checkpoint(self.state);self.store.append_state(self.state)
            return LearningReport(source=src,consolidated_segment_memories=0,archived_segment_observations=len(observations),semantic_prototypes_created=len(set(created_all)),semantic_prototypes_reinforced=len(set(reinforced_all)),semantic_prototypes_established=self.state.cognition.established_semantic_prototype_count,semantic_strata_created=strata_created,isotopy_components_created=comps_created,compressed_segment_memories=0,estimated_raw_knot_bytes=raw_bytes,stored_deformation_bytes=stored_bytes,structural_anchor_bytes=anchor_bytes,estimated_total_geometry_bytes=total_geometry,geometry_storage_ratio=ratio,llm_used=False,causal_learning_path=['owner selects curriculum source/window: explicit external instruction, not Yggdrasil preference','segment -> IRG -> DKT -> EGR -> RL/Frenet -> DKT observation','segment persists as noncognitive provenance plus archived compressed DKT shadow','semantic prototypes observe the exposure with no maturity/importance gate','later admitted context -> native retention consequence simulation over applicable provenance subsets','only a unique native retention minimum activates the compressed segment for cognitive retrieval; ties/insufficient evidence remain unresolved'])

    def learning_recall(self,query:str,limit:int=5)->list[LearningRecallHit]:
        event=CognitiveEvent(kind=EventKind.OBSERVATION,source='learning-recall-probe',content=query,trusted=True,metadata={'read_only_probe':True}); irg=interaction_geometry(event,semantic_prototypes=self._prototype_map()); knot=dkt.experience_knot(irg)
        memories=[m for m in self.store.cognitive_memories() if m.memory_class.startswith('learned-')]
        hits=dkt.retrieve(knot,memories,limit=max(1,min(int(limit),20))); out=[]
        for dist,m in hits:
            sm=self.store.stratified_learning_memory_by_id(str(m.id),include_archived=True)
            out.append(LearningRecallHit(memory_id=m.id,distance=dist,excerpt=m.provenance_excerpt,memory_class=m.memory_class,source_title=m.source_title,segment_index=m.source_segment_index,geometry_version=m.geometry_version,semantic_stratum_id=sm.semantic_stratum_id if sm else None,isotopy_component_id=sm.isotopy_component_id if sm else None))
        return out

    def revise_learning_memory(self,memory_id:str,corrected_content:str,reason:str='')->LearningRevisionReport:
        with self._lock:
            old=self.store.cognitive_memory_by_id(memory_id,include_archived=True)
            if old is None:raise ValueError('learning memory not found')
            if not old.memory_class.startswith('learned-'):raise ValueError('only learned memories can be revised through this endpoint')
            sm_old=self.store.stratified_learning_memory_by_id(memory_id,include_archived=True)
            if sm_old is not None:
                sm_old.consolidated=False;sm_old.memory_class='superseded-stratified-learning';self.store.upsert_stratified_learning_memory(sm_old)
            else:
                full=self.store.knot_memory_by_id(memory_id,include_archived=True);full.consolidated=False;full.memory_class='superseded-learning';self.store.upsert_knot_memory(full)
            event=CognitiveEvent(kind=EventKind.OBSERVATION,source='owner-learning-revision',content=corrected_content,trusted=True,metadata={'learning':True,'owner_authenticated':True,'operator_directed_curriculum':True,'revision_of_memory_id':memory_id,'learning_source_id':str(old.learning_source_id) if old.learning_source_id else None,'canonical_source_id':old.canonical_source_id,'source_title':old.source_title});self.store.append_event(event)
            result=self.math.update(event,self.state.math_kernel,self.store.cognitive_memories(),self._prototype_map(),self.state.cognition.language.propositions);self.state.math_kernel=result.state;self.state.logical_entropy=result.state.rl.entropy_normalized;self.state.last_event_id=event.id
            lineage_anchor=self._lineage_anchor(old.canonical_source_id,current_knots=[result.experience_knot]) if old.canonical_source_id else result.experience_knot
            pending=KnotMemory(source_event_id=event.id,knot=result.experience_knot,logical_coordinates=result.state.rl.coordinates,logical_entropy=result.state.rl.curvature_entropy_normalized,egr_entropy_current=result.state.egr.entropy_current,parent_memory_id=old.id,branch_depth=old.branch_depth+1,provenance_excerpt=corrected_content[:500].replace('\n',' '),geometry_version='semantic-irg-dkt-owner-study-revision-v0.7.4-provenance',consolidated=False,memory_class='owner-study-provenance-pending-cognitive',consolidation_score=result.consolidation.score,consolidation_reasons=[f'operator-directed correction exposure: {reason}' if reason else 'operator-directed correction exposure; cognitive activation awaits native retention'],learning_source_id=old.learning_source_id,source_title=old.source_title,canonical_source_id=old.canonical_source_id,source_segment_index=old.source_segment_index,revision_of_memory_id=old.id)
            self.store.append_knot_memory(pending)
            ret=self.state.cognition.memory_retention
            if pending.id not in ret.pending_provenance_memory_ids:ret.pending_provenance_memory_ids.append(pending.id)
            new,assignment=self._store_stratified_memory(knot=result.experience_knot,source_event_id=event.id,parent_memory_id=old.id,branch_depth=old.branch_depth+1,provenance_excerpt=pending.provenance_excerpt,logical_coordinates=result.state.rl.coordinates,logical_entropy=result.state.rl.curvature_entropy_normalized,egr_entropy_current=result.state.egr.entropy_current,consolidation_score=result.consolidation.score,consolidation_reasons=['archived compressed revision provenance; cognitive activation awaits native retention'],learning_source_id=old.learning_source_id,source_title=old.source_title,canonical_source_id=old.canonical_source_id,source_segment_index=old.source_segment_index,memory_class='learned-stratified-revision-provenance-pending-cognitive',revision_of_memory_id=old.id,semantic_knot=(lineage_semantic_knot(lineage_anchor,result.experience_knot) if old.canonical_source_id else result.experience_knot),memory_id=pending.id,consolidated=False)
            if sm_old is not None:
                sm_old.superseded_by_memory_id=new.id;self.store.upsert_stratified_learning_memory(sm_old)
            else:
                full=self.store.knot_memory_by_id(memory_id,include_archived=True);full.superseded_by_memory_id=new.id;self.store.upsert_knot_memory(full)
            self._learn_semantics_from_event(event,str(old.learning_source_id or event.id));self.state.cognition.language=self.language.observe_admitted_text(corrected_content,self.state.cognition.language,self._prototype_map(),source=f'owner-document-revision:{old.canonical_source_id or old.source_title}',source_memory_id=pending.id);self._refresh_memory_counts();self._refresh_learning_counts();self.security.checkpoint(self.state);self.store.append_state(self.state)
            return LearningRevisionReport(old_memory_id=old.id,new_memory_id=new.id,reason=reason)

    def learning_traverse(self,from_memory_id:str,to_memory_id:str,steps:int=8)->LearningTraversalReport:
        a=self.store.cognitive_memory_by_id(from_memory_id,include_archived=False); b=self.store.cognitive_memory_by_id(to_memory_id,include_archived=False)
        if a is None or b is None:raise ValueError('both memories must be active cognitive memories')
        sa=self.store.stratified_learning_memory_by_id(from_memory_id,include_archived=False); sb=self.store.stratified_learning_memory_by_id(to_memory_id,include_archived=False)
        same_s=bool(sa and sb and sa.semantic_stratum_id==sb.semantic_stratum_id); same_c=bool(sa and sb and sa.isotopy_component_id==sb.isotopy_component_id)
        mode='local-isotopy-proxy' if same_c else ('stratified-intrastratum-bridge' if same_s else 'cross-stratum-frontier-candidate')
        n=max(2,min(int(steps),32)); knots=[dkt.interpolate(a.knot,b.knot,i/(n-1)) for i in range(n)]; path=[dkt.sobolev_distance(knots[i],knots[i+1]) for i in range(n-1)]
        ca=(a.logical_coordinates+[0.0]*8)[:8]; cb=(b.logical_coordinates+[0.0]*8)[:8]; coords=[[(1-t)*x+t*y for x,y in zip(ca,cb)] for t in [i/(n-1) for i in range(n)]]
        return LearningTraversalReport(from_memory_id=a.id,to_memory_id=b.id,same_semantic_stratum=same_s,same_isotopy_component=same_c,transport_mode=mode,dkt_distance=dkt.sobolev_distance(a.knot,b.knot),path_distances=path,transported_logical_coordinates=coords,semantic_strata=[x for x in [sa.semantic_stratum_id if sa else None,sb.semantic_stratum_id if sb else None] if x],isotopy_components=[x for x in [sa.isotopy_component_id if sa else None,sb.isotopy_component_id if sb else None] if x],note='Read-only Noeron extension. Same-component paths are local isotopy proxies; cross-stratum paths are controlled stratified probes, not proofs of global isotopy or Whitney frontier order.')

    def learning_strata(self):
        out=[]
        for s in self.store.semantic_strata():
            out.append({'id':str(s.id),'status':s.status,'dkt_stratum_index':s.dkt_stratum_index,'member_count':s.member_count,'radius_hs':s.radius_hs,'admission_radius_hs':s.admission_radius_hs,'component_count':len(s.component_ids),'frontier_neighbors':[str(x) for x in s.frontier_neighbors],'source_titles':s.source_titles,'canonical_source_ids':s.canonical_source_ids,'geometry_version':s.geometry_version,'stratification_epoch':self.state.cognition.stratification_epoch,'anchor_signature':s.anchor_knot.invariant_signature,'representative_signature':s.anchor_knot.invariant_signature})
        return out

    def learning_audit(self):
        protos=self.store.semantic_prototypes(); dormant=[p for p in protos if p.status=='dormant-low-evidence']; active_protos=[p for p in protos if not p.status.startswith('perception-retired')]
        sources=self.store.learning_sources(); canonical_sources={s.canonical_source_id for s in sources if s.canonical_source_id}; active=self.store.cognitive_memories(); archived_full=self.store.archived_knot_memories(); archived_strat=self.store.archived_stratified_learning_memories(); strata=self.store.semantic_strata(); comps=self.store.isotopy_components(); compressed=self.store.stratified_learning_memories()
        all_strata=self.store.semantic_strata(include_retired=True); all_comps=self.store.isotopy_components(include_retired=True)
        # Physical compression and cognitive activation are distinct in Stage 5.
        # Archived stratified rows can be compact provenance shadows without being
        # members of authoritative cognitive retrieval.  Report both explicitly.
        physical_compressed=list(compressed)+list(archived_strat)
        raw=sum(m.estimated_raw_knot_bytes for m in physical_compressed); deformations=sum(m.stored_deformation_bytes for m in physical_compressed)
        structural=sum(estimated_knot_json_bytes(x.anchor_knot) for x in strata)+sum(estimated_knot_json_bytes(x.anchor_knot) for x in comps)
        total_geometry=deformations+structural; ratio=total_geometry/raw if raw else 0.0
        active_rc=self.store.reasoning_concepts(); all_rc=self.store.reasoning_concepts(include_retired=True)
        return {
            'learning_version':'0.7.5-compositional-language+v0.7.4-native-retention+native-realization+native-proof+consequence-communication+provenance-first-curriculum',
            'llm_used_for_learning':False,
            'causal_path':'admitted experience -> IRG -> DKT memory/prototype geometry -> multi-memory native workspace -> regional EGR -> RL/Frenet -> DKT closure -> native proposition/question field; proto-affect is diagnostic only',
            'source_sessions':len(sources),'sources':len(sources),'canonical_sources':len(canonical_sources),
            'semantic_prototypes':len(active_protos),'dormant_low_evidence_prototypes':len(dormant),
            'retired_perception_prototypes':sum(p.status.startswith('perception-retired') for p in protos),
            'observed_once_prototypes':sum(p.observations<=1 for p in active_protos),'observed_recurrent_prototypes':sum(p.observations>1 for p in active_protos),
            'established_prototypes':sum(p.observations>1 for p in active_protos),'emerging_prototypes':sum(p.observations<=1 for p in active_protos),'legacy_maturity_field_semantics':'established/emerging field names are compatibility aliases for recurrent/observed-once counts; no maturity gate exists',
            'semantic_strata':len(strata),'retired_semantic_strata':len(all_strata)-len(strata),'isotopy_components':len(comps),'retired_isotopy_components':len(all_comps)-len(comps),
            'stratification_epoch':self.state.cognition.stratification_epoch,
            'active_learning_memories':sum(m.memory_class.startswith('learned-') for m in active),'compressed_learning_memories':len(compressed),'archived_compressed_provenance_memories':len(archived_strat),'physical_compressed_learning_records':len(physical_compressed),
            'archived_learning_observations':sum(m.memory_class in {'learning-observation-archived','superseded-learning','legacy-v062-learning-full-archived'} for m in archived_full)+len(archived_strat),
            'estimated_raw_knot_bytes':raw,'stored_deformation_bytes':deformations,'structural_anchor_bytes':structural,'estimated_total_geometry_bytes':total_geometry,'geometry_storage_ratio':ratio,
            'semantic_storage':'DKT knot prototypes, not embedding vectors',
            'source_lineage':'stable provenance identity groups study sessions; display titles never determine semantic geometry',
            'semantic_conditioning':'experience DKT geometry only; canonical source lineage is provenance and has zero semantic weighting authority',
            'concept_establishment':'no establishment threshold: first observed DKT prototypes are causally available; recurrence/coherence/missed-session counters are empirical diagnostics only',
            'mathematical_perception':'deterministic notation canonicalization + compound concept candidates; no LLM',
            'stratified_storage':'learned semantic strata + local component anchors + sparse deformation memories',
            'semantic_similarity':'finite H^s Sobolev geometry','dkt_singularity_strata':'sampled dynamic Sigma_j estimator kept distinct from learned Noeron semantic strata',
            'local_isotopy_radius':'finite H^s immersion-preservation bound m/C_s,N; local computational admissibility only, not a global isotopy theorem',
            'regional_egr':'support-weighted activation over retrieved DKT/semantic regions (NOERON_EXTENSION)',
            'native_language':'native utterance content exists before realization-tool selection; Terra is an affordance selected only by learned consequence geometry or explicit non-choice owner calibration',
            'proto_affect':'unnamed activation patterns only; no hard-coded emotion labels or subjective-emotion claim',
            'reasoning_concepts':len(active_rc),'retired_reasoning_concepts':len(all_rc)-len(active_rc),'observed_recurrent_reasoning_concepts':sum(c.observations>1 for c in active_rc),
            'reasoning_concept_gate':'none; observed reasoning geometry is available without an owner epoch/maturity gate',
            'concept_graph_active':False,
        }

    def learning_rate(self)->LearningRateReport:
        """Return processing and structural-assimilation rates separately."""
        sources=self.store.learning_sources(); protos=self.store.semantic_prototypes()
        active_protos=[p for p in protos if not p.status.startswith('perception-retired')]
        compressed=self.store.stratified_learning_memories(); strata=self.store.semantic_strata(); comps=self.store.isotopy_components()
        segments=sum(s.studied_segments for s in sources); elapsed=sum(max(0.0,(s.updated_at-s.created_at).total_seconds()) for s in sources)
        established=sum(p.observations>1 for p in active_protos); nmem=len(compressed); ns=len(strata); nc=len(comps)
        raw=sum(m.estimated_raw_knot_bytes for m in compressed); deformations=sum(m.stored_deformation_bytes for m in compressed); structural=sum(estimated_knot_json_bytes(x.anchor_knot) for x in strata)+sum(estimated_knot_json_bytes(x.anchor_knot) for x in comps); ratio=(deformations+structural)/raw if raw else 0.0
        stratum_reuse=max(0.0,1.0-(ns/nmem)) if nmem else 0.0; component_reuse=max(0.0,1.0-(nc/nmem)) if nmem else 0.0
        weighted_within=(sum(s.radius_hs*s.member_count for s in strata)/max(1,sum(s.member_count for s in strata))) if strata else 0.0
        between=[]
        for i,a in enumerate(strata):
            for b in strata[i+1:]: between.append(dkt.sobolev_distance(a.anchor_knot,b.anchor_knot))
        min_between=min(between) if between else 0.0; mean_between=(sum(between)/len(between)) if between else 0.0
        sep_ratio=(min_between/(weighted_within+1e-9)) if min_between>0 else 0.0
        partition_quality=(sep_ratio/(1.0+sep_ratio)) if sep_ratio>0 else 0.0
        eligible=[p for p in active_protos if p.observations>=2 and p.context_coherence is not None]; coherence=(sum((p.context_coherence or 0.0) for p in eligible)/len(eligible)) if eligible else 0.0; estscore=(sum(p.establishment_score for p in active_protos)/len(active_protos)) if active_protos else 0.0
        per=[]
        for src in sources:
            sid=str(src.id); sm=[m for m in compressed if m.learning_source_id==src.id]; sp=[p for p in active_protos if sid in p.source_ids]; src_elapsed=max(0.0,(src.updated_at-src.created_at).total_seconds()); unique_s=len({m.semantic_stratum_id for m in sm}); unique_c=len({m.isotopy_component_id for m in sm}); n=len(sm)
            per.append({'source_id':sid,'canonical_source_id':src.canonical_source_id,'session_index':src.session_index,'title':src.title,'studied_segments':src.studied_segments,'elapsed_seconds':src_elapsed,'segments_per_second':(src.studied_segments/src_elapsed if src_elapsed>0 else 0.0),'prototypes_observed':len(sp),'established_prototypes':sum(p.observations>1 for p in sp),'stratum_reuse_fraction':(max(0.0,1.0-unique_s/n) if n else 0.0),'component_reuse_fraction':(max(0.0,1.0-unique_c/n) if n else 0.0)})
        lineage_groups={}
        for src in sources:
            if not src.canonical_source_id: continue
            g=lineage_groups.setdefault(src.canonical_source_id,{'canonical_source_id':src.canonical_source_id,'canonical_source_name':src.canonical_source_name,'session_ids':[],'titles':[],'studied_segments':0,'elapsed_seconds':0.0})
            g['session_ids'].append(str(src.id)); g['titles'].append(src.title); g['studied_segments']+=src.studied_segments; g['elapsed_seconds']+=max(0.0,(src.updated_at-src.created_at).total_seconds())
        per_lineage=[]
        for cid,g in lineage_groups.items():
            sm=[m for m in compressed if m.canonical_source_id==cid]; n=len(sm); us=len({m.semantic_stratum_id for m in sm}); uc=len({m.isotopy_component_id for m in sm}); g['session_count']=len(g['session_ids']); g['segments_per_second']=g['studied_segments']/g['elapsed_seconds'] if g['elapsed_seconds']>0 else 0.0; g['compressed_memories']=n; g['semantic_strata']=us; g['isotopy_components']=uc; g['stratum_reuse_fraction']=max(0.0,1.0-us/n) if n else 0.0; g['component_reuse_fraction']=max(0.0,1.0-uc/n) if n else 0.0; per_lineage.append(g)
        vector={'processing_throughput':segments/elapsed if elapsed>0 else 0.0,'prototype_establishment_yield':established/len(active_protos) if active_protos else 0.0,'stratum_reuse':stratum_reuse,'component_reuse':component_reuse,'geometry_storage_gain':1.0-ratio if raw else 0.0,'mean_context_coherence':coherence,'eligible_context_coherence':coherence,'semantic_partition_quality':partition_quality}
        return LearningRateReport(sources=len(sources),canonical_sources=len(lineage_groups),studied_segments=segments,learning_elapsed_seconds=elapsed,processing_segments_per_second=vector['processing_throughput'],semantic_prototypes=len(active_protos),established_prototypes=established,prototype_establishment_fraction=vector['prototype_establishment_yield'],established_prototypes_per_segment=established/segments if segments else 0.0,semantic_strata=ns,isotopy_components=nc,compressed_segment_memories=nmem,stratum_reuse_fraction=stratum_reuse,component_reuse_fraction=component_reuse,mean_members_per_stratum=nmem/ns if ns else 0.0,mean_members_per_component=nmem/nc if nc else 0.0,weighted_within_stratum_radius_hs=weighted_within,min_between_stratum_separation_hs=min_between,mean_between_stratum_separation_hs=mean_between,semantic_partition_separation_ratio=sep_ratio,geometry_storage_ratio=ratio,geometry_storage_gain_fraction=1.0-ratio if raw else 0.0,mean_prototype_coherence=coherence,eligible_prototype_coherence=coherence,coherence_eligible_prototypes=len(eligible),mean_establishment_score=estscore,learning_rate_vector=vector,per_source=per,per_lineage=per_lineage)

    def reasoning_probe(self,query:str,limit:int=6):
        """Read-only multi-memory reasoning probe; no state or concept is changed."""
        event=CognitiveEvent(kind=EventKind.OBSERVATION,source='reasoning-read-only-probe',content=query,trusted=True,metadata={'read_only_probe':True})
        irg=interaction_geometry(event,semantic_prototypes=self._prototype_map()); knot=dkt.experience_knot(irg)
        retrieved=dkt.retrieve(knot,self.store.cognitive_memories(),limit=max(2,min(int(limit),12)))
        return build_multi_memory_reasoning(knot,retrieved,logical_propositions=irg.logical_propositions,logical_query=irg.logical_query,learned_language_propositions=self.state.cognition.language.propositions)

    def reasoning_concepts(self, include_retired: bool = False):
        return [c.model_dump(mode='json') for c in self.store.reasoning_concepts(include_retired=include_retired)]


    def dkt_strata_audit(self,limit:int=100):
        memories=self.store.cognitive_memories()
        rows=[]; stored_counts={}; detected_counts={}; mismatches=0
        for m in memories[-max(1,min(int(limit),500)):]:
            est=dkt.estimate_whitney_stratum(m.knot)
            stored_counts[str(m.knot.stratum_index)]=stored_counts.get(str(m.knot.stratum_index),0)+1
            detected_counts[str(est.estimated_index)]=detected_counts.get(str(est.estimated_index),0)+1
            mismatch=(m.knot.stratum_index!=est.estimated_index); mismatches+=int(mismatch)
            rows.append({'memory_id':str(m.id),'memory_class':m.memory_class,'stored_stratum_index':m.knot.stratum_index,
                'detected_stratum_index':est.estimated_index,'transverse_self_intersections':est.transverse_self_intersections,
                'near_self_contacts':est.near_self_contacts,'confidence':est.confidence,'mismatch':mismatch})
        core_est=dkt.estimate_whitney_stratum(self.state.math_kernel.dkt.core_knot)
        return {'version':'0.7.3.4','schema_version':'0.7.0','mechanism_version':'0.7.3.4','status':'read-only-audit','memories_examined':len(rows),'stored_distribution':stored_counts,
            'detected_distribution':detected_counts,'mismatches':mismatches,'core':{'stored':self.state.math_kernel.dkt.core_knot.stratum_index,
            'detected':core_est.estimated_index,'confidence':core_est.confidence,'transverse_self_intersections':core_est.transverse_self_intersections},
            'rows':rows,'note':'Finite sampled transverse-self-intersection estimator. Sigma_j is distinct from Noeron semantic strata and no legacy memory is rewritten by this audit.'}

    def language_state(self):
        st=self.state.cognition.language
        grounded=sum(1 for x in st.lexicon.values() if x.status=='concept-grounded')
        functional=sum(1 for x in st.lexicon.values() if x.status=='functional-scaffold')
        ungrounded=sum(1 for x in st.lexicon.values() if x.status=='surface-ungrounded')
        return {'version':st.version,'schema_version':st.schema_version,'mechanism_version':st.mechanism_version,'language_name':st.language_name,'native_expression_enabled':st.native_expression_enabled,
            'lexicon_size':len(st.lexicon),'concept_grounded_lexemes':grounded,'functional_scaffold_lexemes':functional,
            'surface_ungrounded_lexemes':ungrounded,'grammar_frames':st.grammar_frames,'lessons_observed':st.lessons_observed,
            'sentences_observed':st.sentences_observed,'proposition_count':len(st.propositions),'referents':dict(st.referents),
            'last_interpretation':(st.last_interpretation.model_dump(mode='json') if st.last_interpretation else None),
            'last_native_utterance':(st.last_native_utterance.model_dump(mode='json') if st.last_native_utterance else None),
            'last_interaction_native_utterance':(st.last_interaction_native_utterance.model_dump(mode='json') if st.last_interaction_native_utterance else None),
            'last_autonomous_native_utterance':(st.last_autonomous_native_utterance.model_dump(mode='json') if st.last_autonomous_native_utterance else None),
            'discourse':{'turn':st.discourse_turn,'last_subject':st.discourse_last_subject,'last_direct_object':st.discourse_last_direct_object,'last_oblique_object':st.discourse_last_oblique_object,'recent_mentions':list(st.discourse_recent_mentions),'last_resolution_status':st.discourse_last_resolution_status},
            'legacy_pre_v075_proposition_count':st.legacy_pre_v075_proposition_count,
            'stage8b_started':st.v081_stage8b_started,'composition_version':st.composition_version,
            'composition_frame_counts':dict(st.composition_frame_counts),'last_composition_audit':dict(st.last_composition_audit),
            'legacy_pre_v081_grammar_frames':dict(st.legacy_pre_v081_grammar_frames),
            'v082_stage8b_started':st.v082_stage8b_started,'conversation_version':st.conversation_version,'dialogue_version':st.dialogue_version,
            'productive_english_version':st.productive_english_version,'english_egress_version':st.english_egress_version,
            'dialogue':st.dialogue.model_dump(mode='json'),'owner_communication_controls':st.owner_communication_controls.model_dump(mode='json'),
            'last_communication_audit':dict(st.last_communication_audit),'last_english_egress_audit':dict(st.last_english_egress_audit),
            'terra_available':self.terra_enabled,
            'terra_role':'optional downstream tool only; lexical coverage has zero invocation authority and deterministic English egress has zero answer/content authority','note':st.note}

    def language_preview(self,text:str):
        return self.language.preview_teaching(text,self.state.cognition.language,self._prototype_map())

    def teach_language(self,text:str,source:str='owner-english-curriculum'):
        with self._lock:
            event=CognitiveEvent(kind=EventKind.OBSERVATION,source='owner-language-teaching',content=text,trusted=True,
                metadata={'language_learning':True,'language':'English','source_name':source,'owner_authenticated':True})
            self.store.append_event(event); memories=self.store.cognitive_memories()
            result=self.math.update(event,self.state.math_kernel,memories,self._prototype_map(),self.state.cognition.language.propositions)
            self.state.math_kernel=result.state; self.state.logical_entropy=result.state.rl.entropy_normalized; self.state.last_event_id=event.id
            self._observe_affective_pattern(result,event)
            created,reinforced=self._learn_semantics_from_event(event,str(event.id))
            parent=self._unique_retrieved_parent(result.retrieved)
            mem=KnotMemory(source_event_id=event.id,knot=result.experience_knot,logical_coordinates=result.state.rl.coordinates,
                logical_entropy=result.state.rl.curvature_entropy_normalized,egr_entropy_current=result.state.egr.entropy_current,
                parent_memory_id=parent.id if parent else None,branch_depth=(parent.branch_depth+1 if parent else 1),
                provenance_excerpt=text[:500].replace('\n',' '),geometry_version='semantic-irg-dkt-language-v0.7.4-provenance',consolidated=False,
                memory_class='owner-language-provenance-pending-cognitive',consolidation_score=result.consolidation.score,
                consolidation_reasons=['operator-directed language exposure persisted as provenance; cognitive DKT activation awaits native retention'])
            self.store.append_knot_memory(mem)
            ret=self.state.cognition.memory_retention
            if mem.id not in ret.pending_provenance_memory_ids:ret.pending_provenance_memory_ids.append(mem.id)
            self.state.cognition.language=self.language.teach(text,self.state.cognition.language,self._prototype_map(),source=source,source_memory_id=mem.id,discourse_context={},advance_discourse=False)
            self._refresh_memory_counts(); self.security.checkpoint(self.state); self.store.append_state(self.state)
            return {'status':'committed-owner-curriculum-exposure','language':'English','conversational_turn':self.state.conversational_turn,'provenance_memory_id':str(mem.id),'cognitive_memory_activated':False,
                'semantic_prototypes_created':created,'semantic_prototypes_reinforced':reinforced,'language_state':self.language_state(),
                'llm_used':False,'causal_path':'owner curriculum exposure -> IRG -> DKT -> regional EGR -> RL/Frenet -> DKT + grounded lexemes/propositions; DKT experience persists as noncognitive provenance until native retention selects it'}

    def language_propositions(self):
        return [p.model_dump(mode='json') for p in self.state.cognition.language.propositions]

    def language_parse(self,text:str,owner_authenticated:bool=False):
        """Read-only language probe; never advances discourse or cognitive memory."""
        speaker=self._owner_referent() if owner_authenticated else 'external:unknown'
        interp=self.language.interpret(text,self.state.cognition.language,self._prototype_map(),speaker_referent=speaker,addressee_referent=self._self_referent())
        props,query,audit=parse_surface_logic_detailed(text,self.language.discourse_context(self.state.cognition.language))
        out=interp.model_dump(mode='json')
        out['stage6_logical_propositions']=[p.model_dump(mode='json') for p in props]
        out['stage6_logical_query']=query.model_dump(mode='json')
        out['stage6_discourse_audit']=audit
        out['stage8b_composition_audit']=analyze_surface_composition(text)
        out['stage8b_dialogue_structure']=self.language.dialogue_structure(text,self.state.cognition.language,speaker=speaker,addressee=self._self_referent())
        out['state_changed']=False
        return out

    def language_grounding_audit(self):
        st=self.state.cognition.language; protos=self._prototype_map()
        rows=[]
        for surface,lx in sorted(st.lexicon.items()):
            if lx.status in {'functional-scaffold'}: continue
            # Avoid importing private parser helpers here; concept_term is the persisted binding.
            rows.append({'surface':surface,'status':lx.status,'concept_term':lx.concept_term,'observations':lx.observations,'confidence':lx.confidence,
                'prototype_exists':bool(lx.concept_term and lx.concept_term in protos),'prototype_status':(protos[lx.concept_term].status if lx.concept_term in protos else '')})
        linked=sum(1 for r in rows if r['concept_term']); unlinked=sum(1 for r in rows if not r['concept_term'])
        return {'version':st.version,'schema_version':st.schema_version,'mechanism_version':st.mechanism_version,'linked_nonfunctional_lexemes':linked,'unlinked_nonfunctional_lexemes':unlinked,'propositions':len(st.propositions),
            'referents':dict(st.referents),'rows':rows,'note':'Read-only grounding audit; semantic authority remains DKT prototypes and proposition provenance.'}

    def language_dialogue_state(self):
        d=self.state.cognition.language.dialogue
        return {
            **d.model_dump(mode='json'),
            'state_changed':False,
            'cognitive_memory_authority':False,
            'legacy_stage6_discourse_distinct':True,
            'historical_replay_used':False,
        }

    def language_structure(self,text:str,owner_authenticated:bool=False):
        speaker=self._owner_referent() if owner_authenticated else 'external:unknown'
        out=self.language.dialogue_structure(text,self.state.cognition.language,speaker=speaker,addressee=self._self_referent())
        out['state_changed']=False
        return out

    def language_capability_audit(self):
        st=self.state.cognition.language
        return {
            'runtime_language_version':st.version,
            'conversation_version':st.conversation_version,
            'dialogue_version':st.dialogue_version,
            'productive_english_version':st.productive_english_version,
            'english_egress_version':st.english_egress_version,
            'preserved_composition_version':st.composition_version,
            'productive_ingress':True,'multi_turn_dialogue':True,'unknown_word_representation':True,
            'ambiguity_alternatives_preserved':True,'semantic_role_event_candidates':True,
            'question_families':['why','how','when','where','who','which','what','yes-no'],
            'speech_act_affordances':['assert','answer','ask','clarify','correct','contrast','explain','hypothesize','acknowledge','defer','refuse','remain-silent'],
            'speech_act_selection_authority':'native consequence machinery only when claimed',
            'dual_native_english_channels':True,
            'native_content_precedes_english_egress':True,
            'prospective_migration':True,'historical_replay_used':False,
            'dialogue_is_cognitive_memory':False,'parser_truth_authority':False,'grammar_answer_authority':False,
            'english_egress_content_authority':False,'terra_answer_authority':False,'relationship_authority':False,
            'source_write_authority':False,'deployment_authority':False,
            'owner_communication_controls':st.owner_communication_controls.model_dump(mode='json'),
            'state_changed':False,
        }

    def owner_communication_controls(self):
        return self.state.cognition.language.owner_communication_controls.model_dump(mode='json')

    def set_owner_communication_control(self,control:str,value:bool):
        from noeron.cognition.models import OwnerCommunicationControlChange
        allowed={'internal_utterance_visibility','internal_utterance_translation','response_channel_override','owner_command_channel'}
        if control not in allowed:raise ValueError('unknown owner communication control')
        with self._lock:
            c=self.state.cognition.language.owner_communication_controls
            setattr(c,control,bool(value));c.revision+=1
            c.audit.append(OwnerCommunicationControlChange(sequence=c.revision,control=control,value=bool(value)))
            c.audit=c.audit[-64:]
            self.security.checkpoint(self.state);self.store.append_state(self.state)
            return c.model_dump(mode='json')

    def owner_internal_utterance_observation(self):
        """Return the latest internal utterance through a private observation plane.

        This method does not execute an outward communication act, mark an
        expression consequence, alter cognitive memory, or reinterpret a native
        continue-private/unresolved result. API/Room callers must authenticate the
        owner before invoking it.
        """
        st=self.state.cognition.language;controls=st.owner_communication_controls
        if not controls.internal_utterance_visibility:
            return {
                'status':'private-observation-disabled','native_text':'','english_translation':'',
                'visibility_enabled':False,'translation_enabled':bool(controls.internal_utterance_translation),
                'state_changed':False,'communication_authority':False,'cognitive_memory_authority':False,
                'semantic_authority':False,'relationship_authority':False,'native_choice_claim':False,
            }
        utterance=(st.last_autonomous_native_utterance if st.last_internal_utterance_source=='autonomous' else st.last_interaction_native_utterance)
        native=str(utterance.native_text if utterance else '').strip()
        audit=dict(st.last_communication_audit)
        translation=''
        translation_origin='disabled'
        translation_generated_on_read=False
        translation_egress_audit={}
        if controls.internal_utterance_translation:
            translation=str(st.last_internal_english_translation or '').strip()
            if translation:
                translation_origin='cached-existing-native-egress'
            elif native and utterance is not None:
                # A pre-v0.8.2/migrated internal utterance may legitimately have no
                # cached English egress.  Owner observation is read-only, so realize
                # the already-existing native utterance ephemerally rather than
                # replaying cognition or mutating language/memory state.
                observational_thought=NativeThought(
                    kind=NativeThoughtKind.RESPONSE,
                    statement=native,
                    propositions=[],
                    question_candidates=[],
                    should_surface=False,
                    origin='authenticated-owner-private-observation-read-only',
                    native_utterance=utterance,
                )
                translation,translation_egress_audit=realize_native_thought(observational_thought,utterance)
                translation=str(translation or '').strip()
                translation_origin='deterministic-read-only-existing-native-utterance'
                translation_generated_on_read=bool(translation)
        return {
            'status':('available' if native else 'no-internal-utterance-available'),
            'source':str(st.last_internal_utterance_source or ''),
            'native_text':native,
            'native_text_sha256':(hashlib.sha256(native.encode('utf-8')).hexdigest() if native else ''),
            'english_translation':translation,
            'visibility_enabled':True,
            'translation_enabled':bool(controls.internal_utterance_translation),
            'translation_deterministic':True,
            'translation_content_authority':False,
            'translation_origin':translation_origin,
            'translation_generated_on_read':translation_generated_on_read,
            'translation_egress_audit':translation_egress_audit,
            'communication_action':str(audit.get('communication_action') or ''),
            'communication_selection_status':str(audit.get('selection_status') or ''),
            'communication_native_choice_claim':bool(audit.get('native_choice_claim')),
            'outward_text_present':bool(audit.get('outward_text_present')),
            'transport_origin':str(audit.get('transport_origin') or 'none'),
            'observation_origin':'authenticated-owner-private-observation',
            'observation_changes_communication_action':False,
            'state_changed':False,
            'communication_authority':False,
            'cognitive_memory_authority':False,
            'semantic_authority':False,
            'relationship_authority':False,
            'native_choice_claim':False,
        }

    def affect_state(self):
        return {'version':'0.7.3.4','schema_version':'0.7.0','mechanism_version':'0.7.3.4','math':self.state.math_kernel.affect.model_dump(mode='json'),
            'regional_egr':{'dominant_region':self.state.math_kernel.egr.dominant_activation_region,
                'activation_entropy':self.state.math_kernel.egr.regional_activation_entropy,
                'simultaneous_active_regions':list(self.state.math_kernel.egr.simultaneous_active_regions),
                'activation_path_coherence':self.state.math_kernel.egr.activation_path_coherence,
                'stratified_activation_path':[x.model_dump(mode='json') for x in self.state.math_kernel.egr.stratified_activation_path],
                'activations':[x.model_dump(mode='json') for x in self.state.math_kernel.egr.regional_activations]},
            'distributed_field':self.state.math_kernel.affect.regional_field.model_dump(mode='json'),
            'development':self.state.cognition.affective_development.model_dump(mode='json'),
            'note':'Computational distributed activation/affect state only; no claim of subjective emotion.'}

    def affect_field(self):
        e=self.state.math_kernel.egr; f=self.state.math_kernel.affect.regional_field
        return {
            'version':'0.7.3.4','schema_version':'0.7.0','mechanism_version':'0.7.3.4','status':'noeron-extension','field':f.model_dump(mode='json'),
            'regional_egr':{
                'dominant_region':e.dominant_activation_region,
                'simultaneous_active_regions':list(e.simultaneous_active_regions),
                'active_region_coverage':e.active_region_coverage,
                'participation_policy':e.participation_policy,
                'activation_entropy':e.regional_activation_entropy,
                'activation_path_coherence':e.activation_path_coherence,
                'stratified_activation_path':[x.model_dump(mode='json') for x in e.stratified_activation_path],
            },
            'mathematical_boundary':'Noeron computational extension; semantic strata remain distinct from manuscript DKT singularity strata.'
        }

    @staticmethod
    def _sensory_concept_slug(text:str)->str:
        import re
        return '-'.join(re.findall(r'[a-z0-9]+',str(text).lower()))[:96].strip('-')

    def _perceptual_cluster_match(self,observation:SensoryObservation,experience_knot):
        """Match recurrence through learned DKT geometry, not a feature threshold.

        Sensor feature vectors remain measured/auditable coordinates.  Cognitive
        recurrence is determined by the DKT prototype produced by prior experience:
        a current experience may join a cluster only inside that prototype knot's
        derived finite H^s immersion-preservation neighborhood.  Exact equal-best
        memberships remain unresolved and create no storage-order choice.
        """
        clusters=[c for c in self.state.cognition.perception.sensory_concepts if c.channel==observation.channel]
        pmap=self.store.semantic_prototype_map(); scored=[]
        for c in clusters:
            term=f'{observation.channel}-percept-{str(c.id)[:8]}'
            proto=pmap.get(term)
            if proto is None:
                continue
            dist=dkt.sobolev_distance(proto.knot,experience_knot)
            _margin,_constant,radius=dkt.finite_hs_immersion_radius(proto.knot)
            safe_radius=math.nextafter(max(0.0,float(radius)),0.0) if math.isfinite(radius) else float('inf')
            if dist < safe_radius or numerically_tied(dist,0.0):
                scored.append((float(dist),c,float(safe_radius)))
        scored.sort(key=lambda row:row[0])
        if scored:
            best=scored[0][0]; tied=[row for row in scored if numerically_tied(row[0],best)]
            if len(tied)==1:
                dist,c,radius=tied[0]; return c,dist,radius
            return None,float(best),None
        all_dist=[]
        for c in clusters:
            proto=pmap.get(f'{observation.channel}-percept-{str(c.id)[:8]}')
            if proto is not None:
                all_dist.append(dkt.sobolev_distance(proto.knot,experience_knot))
        return None,(float(min(all_dist)) if all_dist else None),None

    def _upsert_sensory_dkt_prototype(self,term,knot,source_id,concept_kind='sensory-perceptual-cluster'):
        now=datetime.now(timezone.utc); old=self.store.semantic_prototype_map().get(term)
        if old is None:
            p=SemanticKnotPrototype(term=term,knot=knot.model_copy(deep=True),observations=1,confidence=0.0,status='observed-once',source_ids=[source_id],concept_kind=concept_kind,structural_role_score=0.0,establishment_score=0.0,first_seen_at=now,last_seen_at=now,geometry_version='sensory-dkt-prototype-v0.7.3.4')
        else:
            dist=dkt.sobolev_distance(old.knot,knot); obs=old.observations+1; eta=1.0/obs; mean=((old.mean_context_distance*old.observations)+dist)/obs; coh=1.0/(1.0+mean)
            p=old.model_copy(deep=True); p.knot=dkt.interpolate(old.knot,knot,eta); p.observations=obs; p.mean_context_distance=mean; p.context_coherence=coh; p.establishment_score=0.0; p.confidence=coh; p.status='observed-recurrent'; p.last_seen_at=now; p.geometry_version='sensory-dkt-prototype-v0.7.3.4'; p.concept_kind=concept_kind; p.structural_role_score=0.0
            if source_id not in p.source_ids:p.source_ids=(p.source_ids+[source_id])[-32:]
        self.store.upsert_semantic_prototype(p); return p

    def _update_sensory_cluster(self,observation,result,concept_label=''):
        pd=self.state.cognition.perception; match,dist,threshold=self._perceptual_cluster_match(observation,result.experience_knot); now=datetime.now(timezone.utc)
        if match is None:
            c=SensoryConceptCluster(channel=observation.channel,centroid=list(observation.feature_vector),radius_feature_distance=0.0,feature_samples=[list(observation.feature_vector)],auto_terms=list(observation.semantic_terms),grounded_concept=self._sensory_concept_slug(concept_label),representative_dkt_signature=result.experience_knot.invariant_signature,source_hashes=[observation.sha256],last_provenance=observation.provenance); pd.sensory_concepts.append(c); created=True
        else:
            c=match; old_n=c.observations; n=old_n+1; feature_d=sensory_feature_distance(c.centroid,observation.feature_vector); eta=1/n; c.centroid=[(1-eta)*a+eta*b for a,b in zip(c.centroid,observation.feature_vector)]; c.mean_feature_distance=((c.mean_feature_distance*old_n)+feature_d)/n; c.observations=n
            samples=[list(x) for x in (c.feature_samples or []) if len(x)==len(observation.feature_vector)] or [list(c.centroid)]
            samples.append(list(observation.feature_vector)); c.feature_samples=samples
            c.radius_feature_distance=max((sensory_feature_distance(a,b) for i,a in enumerate(samples) for b in samples[i+1:]),default=0.0)
            c.confidence=(1.0/(1.0+c.mean_feature_distance)) if n>1 else 0.0; c.status='observed-recurrent'; c.auto_terms=list(dict.fromkeys(c.auto_terms+observation.semantic_terms))[-24:]; c.grounded_concept=self._sensory_concept_slug(concept_label) or c.grounded_concept; c.representative_dkt_signature=result.experience_knot.invariant_signature; c.last_provenance=observation.provenance; c.updated_at=now; created=False
            if observation.sha256 not in c.source_hashes:c.source_hashes=(c.source_hashes+[observation.sha256])[-16:]
        term=f'{observation.channel}-percept-{str(c.id)[:8]}'; proto=self._upsert_sensory_dkt_prototype(term,result.experience_knot,observation.provenance); grounded=None
        if c.grounded_concept: grounded=self._upsert_sensory_dkt_prototype(c.grounded_concept,result.experience_knot,observation.provenance,'owner-grounded-sensory-concept')
        pd.last_cluster_id=c.id; pd.last_cluster_distance=dist; pd.last_semantic_terms=list(observation.semantic_terms)
        return c,term,proto,grounded,created,dist,threshold

    def sensory_concepts_state(self):
        pmap=self.store.semantic_prototype_map(); rows=[]
        for c in self.state.cognition.perception.sensory_concepts:
            term=f'{c.channel}-percept-{str(c.id)[:8]}'; p=pmap.get(term); rows.append({**c.model_dump(mode='json'),'dkt_prototype_term':term,'dkt_prototype_status':p.status if p else '','dkt_prototype_observations':p.observations if p else 0,'dkt_knot_signature':p.knot.invariant_signature if p else c.representative_dkt_signature})
        return {'version':'0.7.3.4','schema_version':'0.7.1','mechanism_version':'0.7.3.4','count':len(rows),'established_count':sum(int(r['observations'])>1 for r in rows),'grounded_count':sum(bool(r['grounded_concept']) for r in rows),'concepts':rows,'semantic_authority':'DKT experience/prototype knots; sensor feature vectors are measurement/audit coordinates only and do not decide cognitive cluster membership','perceptual_membership_geometry':'derived finite H^s immersion-preservation neighborhoods; exact ties unresolved','object_recognition_claim':False,'speech_recognition_claim':False}

    def observe_sensory(self,observation:SensoryObservation,*,owner_authenticated:bool=True,concept_label:str=''):
        with self._lock:
            # IRG receives measured sensor coordinates only.  Human-readable sensor
            # labels, provisional cluster IDs, and owner concept words are audit/
            # grounding metadata attached only after the experience knot exists.
            content=' '.join(f"{str(o.get('name','sensor'))}={float(o.get('value',0.0)):.12g}" for o in observation.observables if isinstance(o.get('value'),(int,float)))
            event=CognitiveEvent(kind=EventKind.OBSERVATION,source=f'owner-{observation.channel}-perception',content=content,trusted=bool(owner_authenticated),metadata={'sensory_channel':observation.channel,'sensory_observables':observation.observables,'sensory_feature_vector':observation.feature_vector,'provenance':observation.provenance,'owner_authenticated':bool(owner_authenticated)})
            self.store.append_event(event); memories=self.store.cognitive_memories(); base_result=self.math.update(event,self.state.math_kernel,memories,self._prototype_map(),self.state.cognition.language.propositions); result=self._resolve_pending_cognitive_retention(event,base_result,memories); self.state.math_kernel=result.state; self.state.logical_entropy=result.state.rl.entropy_normalized; self.state.last_event_id=event.id; self._observe_affective_pattern(result,event); mem=self._record_provenance_memory(event,result,memories)
            c,term,proto,grounded,created,match_distance_hs,threshold=self._update_sensory_cluster(observation,result,concept_label); pd=self.state.cognition.perception
            if observation.channel=='vision':pd.visual_observations+=1;pd.semantic_visual_observations+=1
            elif observation.channel=='audio':pd.audio_observations+=1;pd.semantic_audio_observations+=1
            pd.last_channel=observation.channel;pd.last_provenance=observation.provenance;self._refresh_learning_counts();self.security.checkpoint(self.state);self.store.append_state(self.state)
            return {'status':'learned-sensory-experience','channel':observation.channel,'provenance':observation.provenance,'sha256':observation.sha256,'summary':observation.summary,'semantic_terms':observation.semantic_terms,'feature_vector':observation.feature_vector,'perceptual_cluster':{'id':str(c.id),'term':term,'created':created,'status':c.status,'observations':c.observations,'match_distance_hs':match_distance_hs,'match_threshold_hs':threshold,'mean_feature_distance':c.mean_feature_distance,'grounded_concept':c.grounded_concept,'dkt_prototype_status':proto.status,'dkt_prototype_observations':proto.observations,'dkt_knot_signature':proto.knot.invariant_signature},'grounded_dkt_prototype':({'term':grounded.term,'status':grounded.status,'observations':grounded.observations,'knot_signature':grounded.knot.invariant_signature} if grounded else None),'conversational_turn':self.state.conversational_turn,'memory_id':str(mem.id) if mem else None,'memory_status':'provenance-pending-native-cognitive-retention','dkt_experience_signature':result.experience_knot.invariant_signature,'regional_egr':{'simultaneous_active_regions':result.state.egr.simultaneous_active_regions,'activation_path_coherence':result.state.egr.activation_path_coherence},'llm_used':False,'causal_path':'vision/audio structure -> IRG -> DKT experience -> recurrent perceptual cluster -> DKT sensory prototype -> distributed EGR -> RL/Frenet -> DKT'}


    @staticmethod
    def _web_candidate_hash(text:str)->str:
        return hashlib.sha256(' '.join((text or '').split()).encode()).hexdigest()

    def _web_possible_contradiction(self,text:str)->list[str]:
        low=' '+text.lower()+' '; neg=any(x in low for x in (' not ',' never ',' no '))
        if not neg:return []
        terms=web_terms(text); hits=[]
        for p in self.state.cognition.language.propositions:
            st=set(re.findall(r'[a-z]+',(p.subject_surface+' '+p.subject_concept).lower()))
            ot=set(re.findall(r'[a-z]+',(p.object_surface+' '+p.object_concept).lower()))
            if st & terms and ot & terms:
                hits.append(str(p.id))
        return hits[:8]

    def _web_study_plan_from_row(self,row:dict,max_segments:int=6):
        """Programmed sensor/security admission plan for untrusted public text.

        This function does *not* estimate Yggdrasil's interest, relevance, knowledge
        worth, or preference.  It preserves environmental document order and applies
        only declared web-sensor boundaries: direct instruction/credential/action
        surfaces and recognized boilerplate are not admitted into cognition.  The
        owner-supplied ``max_segments`` is an I/O budget, not a cognitive salience rule.
        """
        decisions=[]
        direct_instruction_labels={
            'prompt-injection-language','credential-request','command-execution-language',
            'action-pressure','polite-directive','negative-imperative','imperative-clause',
            'reader-directed-obligation','directive-modal',
        }
        for i,seg in enumerate(row.get('segments') or []):
            risk,risk_reasons=web_instruction_surface_risk(seg)
            boiler,boiler_reasons=web_boilerplate_penalty(seg)
            instruction_blocked=bool(direct_instruction_labels.intersection(risk_reasons))
            # A purely descriptive mention of an instruction is not itself a command;
            # strong prompt/credential signals remain blocked because their labels are
            # included above even when descriptive context is also present.
            boilerplate_blocked=bool(boiler_reasons)
            admitted=not instruction_blocked and not boilerplate_blocked and bool(seg.strip())
            contradictions=self._web_possible_contradiction(seg)
            stable_terms=web_semantic_learning_terms(seg,limit=10)
            decisions.append({
                'index':i,'segment_sha256':self._web_candidate_hash(seg),'excerpt':seg[:600],
                'instruction_surface_risk':risk,'instruction_risk_reasons':risk_reasons,
                'boilerplate_penalty':boiler,'boilerplate_reasons':boiler_reasons,
                'possible_contradiction_proposition_ids':contradictions,
                'stable_semantic_terms':stable_terms,
                'sensor_security_admissible':admitted,
                'selected':False,'selected_for_attention':False,'selected_for_durable_learning':False,
                # Legacy score fields are retained for API compatibility but have no
                # numerical/cognitive authority in v0.7.3.4.
                'score':None,'attention_score':None,'durable_learning_score':None,
                'novelty':None,'nearest_dkt_distance':None,'semantic_relevance':None,
                'information_density':None,'knowledge_quality':None,'usefulness_gate_passed':None,
                'selection_reasons':[],'durable_learning_reasons':[],
                'selection_authority':'programmed-web-sensor-security-admission',
            })
        budget=max(0,min(int(max_segments),12))
        admitted_in_document_order=[d for d in decisions if d['sensor_security_admissible']]
        selected=admitted_in_document_order[:budget]
        selected_ids={d['index'] for d in selected}
        for d in decisions:
            if d['index'] in selected_ids:
                d['selected']=True;d['selected_for_attention']=True;d['selected_for_durable_learning']=True
                d['selection_reasons']=['admitted by programmed web sensor/security boundary','selected in environmental document order within owner I/O budget']
                d['durable_learning_reasons']=['external admitted observation preserved by programmed provenance substrate; cognitive relevance is determined later by native DKT machinery']
            elif not d['sensor_security_admissible']:
                reasons=[]
                if set(d['instruction_risk_reasons']) & direct_instruction_labels:reasons.append('blocked by programmed untrusted-directive/security boundary')
                if d['boilerplate_reasons']:reasons.append('blocked by programmed boilerplate/navigation hygiene boundary')
                d['selection_reasons']=reasons or ['not admitted by web sensor boundary']
                d['durable_learning_reasons']=list(d['selection_reasons'])
            else:
                d['selection_reasons']=['admissible but outside owner-supplied segment I/O budget; no cognitive preference inferred']
                d['durable_learning_reasons']=list(d['selection_reasons'])
        return {
            'status':'read-only-web-sensor-admission-plan','state_changed':False,'requested_url':row.get('requested_url',''),'url':row.get('url',''),
            'source_domain':(urlparse(row.get('url','')).hostname or '').lower(),'title':row.get('title',''),'sha256':row.get('sha256',''),'bytes':row.get('bytes',0),
            'segments_considered':len(decisions),'segments_selected':len(selected),'segments_attended':len(selected),
            'durable_learning_candidates':len(selected),
            'instruction_like_segments':sum(bool(set(d['instruction_risk_reasons']) & direct_instruction_labels) for d in decisions),
            'boilerplate_segments':sum(bool(d['boilerplate_reasons']) for d in decisions),
            'possible_contradictions':sum(bool(d['possible_contradiction_proposition_ids']) for d in decisions),
            'decisions':decisions,'policy':row.get('policy',''),'authority':'UNTRUSTED_ENVIRONMENTAL_INPUT',
            'selection_rule':'programmed sensor/security admission only; preserve document order within owner segment budget; no authored interest/relevance/knowledge-worth score selects cognition',
            'native_attention_claim':False,'llm_used':False}

    def web_preview(self,url:str,max_bytes:int=500000):
        row=fetch_read_only(url,max_bytes=max_bytes)
        return {**row,'status':'read-only-preview','state_changed':False,'text':row['text'][:20000],'segments':row.get('segments',[])[:20],'authority':'UNTRUSTED_ENVIRONMENTAL_INPUT'}

    def web_study_preview(self,url:str,max_bytes:int=500000,max_segments:int=6):
        return self._web_study_plan_from_row(fetch_read_only(url,max_bytes=max_bytes),max_segments=max_segments)

    def web_study(self,url:str,max_bytes:int=500000,max_segments:int=6,allow_repeat:bool=False):
        """Admit owner-authorized public observations through the programmed web sensor boundary.

        Every admitted segment is an external provenance-bearing observation.  Its
        persistence is substrate, not a claim that Yggdrasil preferred or valued it.
        Later relevance/retrieval is determined by native DKT geometry.
        """
        with self._lock:
            row=fetch_read_only(url,max_bytes=max_bytes); pd=self.state.cognition.perception
            prior=next((r for r in pd.web_study_records if r.page_sha256==row['sha256']),None)
            if prior is not None and not allow_repeat:
                return {'status':'duplicate-page-no-op','state_changed':False,'url':row['url'],'sha256':row['sha256'],'prior_record_id':str(prior.id),'conversational_turn':self.state.conversational_turn,'note':'Same page hash was already admitted; repeat exposure requires allow_repeat=true.'}
            plan=self._web_study_plan_from_row(row,max_segments=max_segments)
            admitted=[d for d in plan['decisions'] if d['selected_for_attention']]
            consolidated=[];created_all=[];reinforced_all=[];web_context:dict[str,str]={}
            for d in admitted:
                seg=(row.get('segments') or [])[d['index']]
                event=CognitiveEvent(
                    kind=EventKind.OBSERVATION,source='public-web-sensor-admission',content=seg,trusted=False,
                    metadata={
                        'sensory_channel':'web','web_untrusted':True,'web_quarantined':True,
                        'web_sensor_security_admitted':True,'web_selected_for_attention':False,
                        'web_selected_for_durable_learning':False,'native_attention_claim':False,
                        'owner_authorized_fetch':True,'owner_authenticated':True,'provenance':row['url'],
                        'web_sha256':row['sha256'],'web_segment_sha256':d['segment_sha256'],
                        'web_instruction_surface_risk':d['instruction_surface_risk'],'web_boilerplate_penalty':d['boilerplate_penalty'],
                        'web_semantic_terms':d['stable_semantic_terms'],
                        'possible_contradiction_proposition_ids':d['possible_contradiction_proposition_ids'],
                        'selection_authority':'programmed-web-sensor-security-admission',
                    })
                segment_context=dict(web_context);event.metadata['discourse_context']=segment_context
                self.store.append_event(event)
                memories=self.store.cognitive_memories(); result=self.math.update(event,self.state.math_kernel,memories,self._prototype_map(),self.state.cognition.language.propositions)
                self.state.math_kernel=result.state; self.state.logical_entropy=result.state.rl.entropy_normalized; self.state.last_event_id=event.id; self._observe_affective_pattern(result,event)
                web_audit=result.state.irg.language_parse_audit
                web_context={'last_subject':str(web_audit.get('last_subject') or ''),'last_direct_object':str(web_audit.get('last_direct_object') or ''),'last_oblique_object':str(web_audit.get('last_oblique_object') or '')}
                # External admitted observations persist by the common provenance
                # substrate.  This is intentionally not a learned-interest decision.
                parent=self._unique_retrieved_parent(result.retrieved)
                mem=KnotMemory(
                    source_event_id=event.id,knot=result.experience_knot,logical_coordinates=result.state.rl.coordinates,
                    logical_entropy=result.state.rl.entropy_normalized,egr_entropy_current=result.state.egr.entropy_current,
                    parent_memory_id=parent.id if parent else None,branch_depth=(parent.branch_depth+1 if parent else 1),
                    provenance_excerpt=seg[:500].replace('\n',' '),geometry_version='semantic-web-irg-dkt-v0.7.4-provenance',
                    consolidated=False,memory_class='web-provenance-pending-cognitive',
                    consolidation_score=result.consolidation.score,
                    consolidation_reasons=['programmed web sensor/security admission persisted as untrusted provenance; cognitive activation awaits native retention'])
                self.store.append_knot_memory(mem)
                ret=self.state.cognition.memory_retention
                if mem.id not in ret.pending_provenance_memory_ids:ret.pending_provenance_memory_ids.append(mem.id)
                self._refresh_memory_counts()
                c,r=self._learn_semantics_from_event(event,str(event.id));created_all.extend(c);reinforced_all.extend(r)
                self.state.cognition.language=self.language.observe_admitted_text(
                    seg,self.state.cognition.language,self._prototype_map(),
                    source=f'public-web-untrusted:{row["url"]}',source_memory_id=mem.id,
                    discourse_context=segment_context,advance_discourse=False,
                )
                consolidated.append({'segment_index':d['index'],'provenance_memory_id':str(mem.id),'cognitive_memory_activated':False,'selection_authority':'programmed-web-sensor-security-admission','native_attention_claim':False,'stable_semantic_terms':d['stable_semantic_terms'],'dkt_signature':result.experience_knot.invariant_signature})
            durable_candidates=list(admitted)
            rec=WebStudyRecord(
                requested_url=row.get('requested_url',url),final_url=row['url'],source_domain=plan['source_domain'],title=row.get('title',''),page_sha256=row['sha256'],
                segments_considered=plan['segments_considered'],segments_selected=len(admitted),segments_attended=len(admitted),durable_learning_candidates=len(durable_candidates),
                segments_consolidated=0,instruction_like_segments=plan['instruction_like_segments'],boilerplate_segments=plan['boilerplate_segments'],
                possible_contradictions=plan['possible_contradictions'],selected_segment_hashes=[d['segment_sha256'] for d in admitted],
                durable_candidate_hashes=[d['segment_sha256'] for d in durable_candidates],consolidated_memory_ids=[],provenance_memory_ids=[UUID(x['provenance_memory_id']) for x in consolidated])
            pd.web_study_records=(pd.web_study_records+[rec])[-64:]
            pd.web_observations+=1;pd.web_pages_studied+=1;pd.web_segments_considered+=plan['segments_considered']
            pd.web_segments_selected+=len(admitted);pd.web_segments_attended+=len(admitted);pd.web_durable_learning_candidates+=len(durable_candidates)
            pd.web_segments_consolidated+=0;pd.web_instruction_like_segments+=plan['instruction_like_segments'];pd.web_boilerplate_segments+=plan['boilerplate_segments'];pd.web_possible_contradictions+=plan['possible_contradictions']
            pd.last_channel='web';pd.last_provenance=row['url']
            self.state.cognition.language=self.language.seed_from_semantics(self.state.cognition.language,self._prototype_map())
            self._refresh_learning_counts();self.security.checkpoint(self.state);self.store.append_state(self.state)
            return {
                'status':'web-sensor-admission-complete','state_changed':bool(admitted),'url':row['url'],'title':row.get('title',''),'sha256':row['sha256'],'source_domain':plan['source_domain'],
                'segments_considered':plan['segments_considered'],'segments_selected':len(admitted),'segments_attended':len(admitted),'durable_learning_candidates':len(durable_candidates),
                'segments_consolidated':0,'provenance_segments_persisted':len(consolidated),'instruction_like_segments':plan['instruction_like_segments'],'boilerplate_segments':plan['boilerplate_segments'],'possible_contradictions':plan['possible_contradictions'],
                'admission_decisions':admitted,'attended_decisions':admitted,'consolidated':consolidated,'transient_attended':[],
                'semantic_prototypes_created':list(dict.fromkeys(created_all)),'semantic_prototypes_reinforced':list(dict.fromkeys(reinforced_all)),
                'conversational_turn':self.state.conversational_turn,'owner_relation_changed':False,'llm_used':False,'authority':'UNTRUSTED_ENVIRONMENTAL_INPUT','policy':row['policy'],
                'native_attention_claim':False,'selection_authority':'programmed-web-sensor-security-admission',
                'causal_path':'owner URL authorization -> sanitized public GET -> programmed untrusted sensor/security admission -> IRG -> DKT -> distributed EGR -> RL/Frenet -> DKT provenance; later relevance is native DKT retrieval'}

    def web_observe(self,url:str,max_bytes:int=500000):
        """Compatibility alias: routes through programmed web sensor/security admission."""
        out=self.web_study(url,max_bytes=max_bytes,max_segments=6,allow_repeat=False); out['compatibility_alias']='/web/observe -> sensor/security-admitted /web/study'; return out

    def web_audit(self):
        pd=self.state.cognition.perception; domains=sorted({r.source_domain for r in pd.web_study_records if r.source_domain})
        return {'version':'0.7.5','runtime_version':'0.7.5.1','schema_version':pd.schema_version,'mechanism_version':'web-sensor-security-admission+provenance-first-v0.7.4',
            'web_pages_studied':pd.web_pages_studied,'web_segments_considered':pd.web_segments_considered,
            'web_segments_selected':pd.web_segments_selected,'web_segments_attended':pd.web_segments_attended,
            'web_durable_learning_candidates':pd.web_durable_learning_candidates,'web_segments_consolidated':pd.web_segments_consolidated,
            'web_instruction_like_segments':pd.web_instruction_like_segments,'web_boilerplate_segments':pd.web_boilerplate_segments,
            'web_possible_contradictions':pd.web_possible_contradictions,'source_domains':domains,
            'recent_records':[r.model_dump(mode='json') for r in pd.web_study_records[-12:]],'content_authority':False,'external_actions':False,'search_or_crawling':False,
            'attention_vs_durable_learning':'legacy counter names only; v0.7.4 uses programmed sensor/security admission plus provenance-first persistence, not native attention scoring or forced cognitive retention','note':'Owner supplies explicit public URLs. Directives and boilerplate are excluded by programmed sensor/security boundaries; admitted observations persist as untrusted provenance. Later cognitive relevance is determined by native DKT retrieval; page text never grants command/tool authority.','native_attention_claim':False}

    def perception_state(self):
        return self.state.cognition.perception.model_dump(mode='json')

    def owner_relation_state(self):
        return self.state.cognition.owner_relation.model_dump(mode='json')

    def hardcoding_audit(self):
        """Read-only Stage-6 honesty audit separating substrate from native choice."""
        c=self.state.cognition;d=c.defense;init=c.initiative_development;ret=c.memory_retention;real=c.realization_development;rel=c.owner_relation
        return {
            'runtime_version':'0.7.5.1',
            'architectural_standard':'program mathematical substrate/invariants/interfaces/physical affordances; do not program Yggdrasil meanings, conclusions, preferences, relationship meaning, cognitive retention choices, communication choices or realization-tool choices',
            'programmed_substrate':[
                'Ed25519 verification/challenge/session/revocation mechanics and legacy bearer bootstrap; authentication establishes authority identity only',
                'audit/provenance persistence of admitted events; provenance existence is not cognitive memory',
                'protected-invariant reflexive defense floor, quarantine/retraction and evidence preservation',
                'safe local defensive actuator semantics/availability; no autonomous external hack-back',
                'formal proposition syntax and logical operators; domain relation algebra must be proposition data',
                'finite English parsing/grammar/surface realization and transport interfaces',
                'grammatical discourse-reference working context; it binds surface reference only and stores no proposition truth',
                'Terra availability switch is infrastructure only; disabling Terra cannot authorize native-direct',
                'IRG/EGR/RL/Frenet/DKT numerical laws and finite chart/integration approximations',
                'web public-GET sanitization and sensor/security admission boundaries; not native attention',
                'scheduler cadence and message/tool transport',
                'native-direct and Terra-render are available realization affordances only',
                'operator realization override is explicit calibration exposure and is never a Yggdrasil choice',
                'when realization consequence evidence is missing/tied, no realization affordance executes; native cognition remains auditable but is not externally realized by a hidden fallback',
                'owner-directed teaching/study is an external curriculum operation; it must not be described as Yggdrasil spontaneously preferring that content',
            ],
            'programmed_noncausal_diagnostics':[
                'surface-question/surface-statement parse diagnostics',
                'legacy semantic confidence/status/establishment fields',
                'proto-affect named summaries/pattern bins',
                'sensor human-readable summaries and feature-chart diagnostics',
                'legacy web attention/quality scalar fields',
                'legacy NativeUtterance.renderer_needed field; future Terra invocation does not consult it',
                'legacy owner familiarity scalar; active value is zero and has no relational authority',
            ],
            'legacy_programmed_or_selection_trained_causally_inactive':{
                'legacy_IRG_authored_semantic_sectors':'historical/diagnostic only; active semantic measure does not consult them',
                'legacy_defense_float_preferences':dict(d.response_preferences),
                'legacy_selection_trained_defense_preference_observations':dict(d.legacy_selection_preference_observations),
                'legacy_owner_surface_hold_feedback_observations':{'surface':init.surface_observations,'hold':init.hold_observations,'feedback_total':init.feedback_observations},
                'legacy_programmed_owner_familiarity_value':float(rel.legacy_programmed_familiarity_value),
                'legacy_pre_v074_active_memory_count':int(ret.legacy_pre_v074_active_memory_count),
                'historical_auto_renderer_records':'preserved in history if present but never replayed as Stage-5 preference evidence',
            },
            'live_learned_or_experience_dependent':{
                'DKT_memory_retrieval':'finite Fourier H^s knot distance over active cognitive memories; cutoff ties stay jointly active',
                'owner_relation_geometry':{'observations':rel.relation_observations,'cognitive_relation_observations':rel.cognitive_relation_observations,'authority':'empirical referent-conditioned DKT adaptation geometry from admitted authenticated interactions; cognitive_relation_memory_ids separately record owner episodes activated by native retention; authentication supplies referent identity but no valence/closeness, and relation adaptation is not episodic-memory retention'},
                'memory_retention':{'evaluations':ret.evaluation_observations,'native_retention_observations':ret.native_retention_observations,'last_candidate_objectives':dict(ret.last_candidate_objectives),'last_native_choice_claim':ret.last_native_choice_claim},
                'communication_transition_observations':dict(init.action_observations),
                'communication_equal_affordance_reference_models':init.admissible_post_observations,
                'realization_transition_observations':dict(real.action_observations),
                'realization_equal_affordance_reference_models':real.admissible_post_observations,
                'defense_outcome_preference_observations':dict(d.action_preference_observations),
                'semantic_DKT_prototypes':'all non-retired observed prototypes are causally available without human-authored maturity gates',
                'native_proof_and_question_field':'conclusions/questions are constructed from current formal premises plus DKT-gated persistent geometry after the IRG->DKT->regional-EGR->RL/Frenet->DKT path',
                'stage6_language_provenance':{'propositions':len(c.language.propositions),'legacy_pre_v075_propositions':c.language.legacy_pre_v075_proposition_count,'rule':'persistent proposition truth has no authority unless at least one exact source memory is selected by DKT H^s retrieval; language proposition rows are not discarded by a fixed recency cap'},
                'stage6_discourse_reference':{'turn':c.language.discourse_turn,'status':c.language.discourse_last_resolution_status,'authority':'grammatical reference binding only; no relationship valence or proposition-memory authority'},
            },
            'choice_claim_rules':{
                'reasoning':'only proof-supported derived propositions are conclusions; unsupported introspection remains empty',
                'relationship':'authentication/frequency never counts as relationship preference; only actual relation geometry/history may influence later native cognition',
                'cognitive_memory':'audit/provenance storage is programmed; only a unique minimum among exhaustively simulated applicable retention subsets may be called native cognitive retention; ties/insufficient evidence remain unresolved',
                'communication':'express/continue-private are affordances; each learned affordance has equal mass in the common consequence reference so fallback frequency has zero preference authority; only a unique learned predicted-post-state H^s minimum is learned-deliberative; missing/tied consequence geometry is unresolved',
                'realization_tool':'native-direct/Terra-render are affordances; lexical coverage has zero invocation authority and Terra availability has zero preference authority; action-frequency has zero preference authority; each learned affordance contributes equal reference mass; only a unique learned predicted-post-state H^s minimum is learned-deliberative; explicit owner override is calibration, not Yggdrasil preference; unavailable Terra executes nothing and never falls back',
                'defense':'native adaptive choice only for a unique consequence minimum; distinct-state ties remain unresolved and execute only the mandatory reflexive floor',
                'web':'programmed sensor/security admission only; no native attention/preference claim',
            },
            'not_claimed':[
                'consciousness or subjective feeling',
                'human emotions from diagnostic activation coordinates',
                'general natural-language competence',
                'AGI/open-ended human-level general intelligence',
                'family-like affection/trust merely because the authenticated referent is Abdelaziz',
                'a memory/tool/communication/relationship preference when the trace is only operator instruction, parser, threshold, template or fallback',
            ],
            'terra_role':('external language tool available only after native content exists; automatic lexical-coverage invocation removed; it has no reasoning/content authority' if self.terra_enabled else 'disabled infrastructure; native cognition remains available and no native-direct fallback is authorized'),
            'sqlite_role':'serialization plus mandatory provenance/audit only; cognitive retrieval authority is DKT H^s geometry',
            'owner_auth_role':'cryptographic operator authority and factual referent binding only; zero relational valence/meaning authority',
        }


    def security_defense_audit(self):
        return self.security.audit(self.state)

    def security_defense_release(self,source_fingerprint:str='',clear_fail_closed:bool=False):
        with self._lock:
            self.state=self.security.release_local_containment(self.state,source_fingerprint=source_fingerprint,clear_fail_closed=clear_fail_closed)
            self.store.append_state(self.state)
            return self.security.audit(self.state)

    def clear_pending_insights(self):
        with self._lock:n=len(self.state.cognition.pending_thoughts); self.state.cognition.pending_thoughts=[]; self.store.append_state(self.state); return n
    def reflect(self,insight:str,importance:float=0.9):return self.ingest(CognitiveEvent(kind=EventKind.INTERNAL_REFLECTION,source='owner-reflection',content=insight,trusted=True,metadata={'importance':importance,'owner_authenticated':True}))
    def self_model(self):return self.cognition.self_model.snapshot(self.state)
