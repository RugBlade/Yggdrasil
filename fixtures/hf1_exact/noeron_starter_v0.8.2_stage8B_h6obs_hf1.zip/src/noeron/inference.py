from __future__ import annotations

"""Transparent non-LLM native proposition/inference substrate.

Stage 6 broadens the finite grammar without making the parser a hidden semantic
oracle.  The code supplies generic grammatical/logical operators only.  Domain
facts, relations and conclusions still come from current admitted input or from
persistent proposition records whose provenance is selected by DKT H^s retrieval.

Discourse context is deliberately narrow: it can bind grammatical references such
as ``she`` or ``it`` to recently mentioned surface referents.  It does not store or
assert proposition truth and therefore cannot substitute for cognitive memory.
"""

import re
from typing import Iterable, Mapping, Sequence

from noeron.math.models import LogicalProposition, LogicalQuery, InferenceStep
from noeron.language_dialogue import lemma as _morph_lemma

_SENTENCE_SPLIT = re.compile(r"(?<=[.!?])\s+|\n+")
_DET = re.compile(r"^(?:a|an|the)\s+", re.I)
_SPACE = re.compile(r"\s+")
_PRONOUNS = {'he','she','they','him','her','them','it','this','that','these','those'}
_PERSON_PRONOUNS = {'he','she','they','him','her','them'}
_OBJECT_PRONOUNS = {'it','this','that','these','those'}
_MODAL = {'may','might','must','should','could','would','will','can'}
_SPATIAL = {'inside','beside','near','under','above','behind','before','after','on'}


def _clean(text: str) -> str:
    text = text.strip().strip('"\'').strip().rstrip('.!?').strip()
    return _SPACE.sub(' ', text)


def _entity(text: str) -> str:
    return _DET.sub('', _clean(text)).strip().lower()


def _relation(text: str) -> str:
    return _SPACE.sub('-', _clean(text).lower())


def _display(entity: str) -> str:
    if not entity:
        return entity
    if len(entity) == 1 and entity.isalpha():
        return entity.upper()
    return entity


def proposition_key(p: LogicalProposition) -> tuple[str, str, str, bool, bool, str]:
    return (p.subject, p.relation, p.object, bool(p.polarity), bool(p.universal), p.modality)


def _initial_discourse(context: Mapping[str, object] | None) -> dict[str, str]:
    c = context or {}
    return {
        'last_subject': str(c.get('last_subject') or c.get('discourse_last_subject') or '').strip().lower(),
        'last_direct_object': str(c.get('last_direct_object') or c.get('discourse_last_direct_object') or '').strip().lower(),
        'last_oblique_object': str(c.get('last_oblique_object') or c.get('discourse_last_oblique_object') or '').strip().lower(),
    }


def _resolve_surface(text: str, ctx: dict[str, str], audit: dict, *, role: str) -> str:
    raw = _entity(text)
    if raw not in _PRONOUNS:
        return raw
    target = ''
    if raw in _PERSON_PRONOUNS:
        target = ctx.get('last_subject', '')
    elif raw in _OBJECT_PRONOUNS:
        target = ctx.get('last_direct_object', '') or ctx.get('last_subject', '')
    if target:
        audit['resolutions'].append({'surface': raw, 'resolved_to': target, 'role': role})
        return target
    audit['unresolved_references'].append({'surface': raw, 'role': role})
    return ''


def _resolved_or_literal(text: str, ctx: dict[str, str], audit: dict, *, role: str) -> str:
    """Resolve a pronoun or return a literal non-pronominal entity.

    An unresolved pronoun returns the empty string.  It must never be converted into
    a proposition entity such as ``she`` or ``it`` merely because a grammar frame
    matched; doing that would turn missing discourse context into invented truth.
    """
    raw = _entity(text)
    if raw in _PRONOUNS:
        return _resolve_surface(text, ctx, audit, role=role)
    return raw


def _mention(ctx: dict[str, str], audit: dict, *, subject: str = '', direct: str = '', oblique: str = '') -> None:
    if subject:
        ctx['last_subject'] = subject
        audit['mentions'].append({'entity': subject, 'role': 'subject'})
    if direct:
        ctx['last_direct_object'] = direct
        audit['mentions'].append({'entity': direct, 'role': 'direct-object'})
    if oblique:
        ctx['last_oblique_object'] = oblique
        audit['mentions'].append({'entity': oblique, 'role': 'oblique-object'})


def parse_surface_logic_detailed(
    text: str,
    discourse_context: Mapping[str, object] | None = None,
) -> tuple[list[LogicalProposition], LogicalQuery, dict]:
    """Parse a finite transparent grammar and return an audit of reference binding.

    The audit describes only grammatical resolution and mentions.  It contains no
    inferred relationship valence, semantic salience score or answer selection.
    """
    propositions: list[LogicalProposition] = []
    query = LogicalQuery()
    ctx = _initial_discourse(discourse_context)
    audit = {
        'version': '0.7.5',
        'resolutions': [],
        'unresolved_references': [],
        'mentions': [],
        'last_subject': ctx['last_subject'],
        'last_direct_object': ctx['last_direct_object'],
        'last_oblique_object': ctx['last_oblique_object'],
    }
    sentences = [s.strip() for s in _SENTENCE_SPLIT.split(text.strip()) if s.strip()]

    for raw in sentences:
        s = _clean(raw)
        low = s.lower()

        # ----------------------------- queries -----------------------------
        if '?' in raw or low.startswith(('what ', 'where ', 'who ', 'which ', 'why ', 'how ', 'when ', 'does ', 'do ', 'did ', 'is ', 'are ', 'was ', 'were ', 'can ', 'could ', 'may ', 'might ', 'will ', 'would ', 'should ', 'must ')):
            if re.search(r'\bwhat\s+(?:necessarily\s+)?follows\b', low) or low in {'what follows', 'what can you infer', 'what can be inferred'}:
                query = LogicalQuery(kind='derive-all', raw=raw)
                continue
            if low in {'who am i','who am i really'}:
                query = LogicalQuery(kind='relation-from-subject', subject='speaker:self', relation='identity', raw=raw)
                continue
            if low in {'who are you','who are you really'}:
                query = LogicalQuery(kind='relation-from-subject', subject='interlocutor:self', relation='identity', raw=raw)
                continue
            m = re.match(r'^where\s+is\s+(.+?)\s+relative\s+to\s+(.+)$', low)
            if m:
                a = _resolve_surface(m.group(1), ctx, audit, role='query-subject')
                b = _resolve_surface(m.group(2), ctx, audit, role='query-object')
                query = LogicalQuery(kind=('relation-between' if a and b else 'unresolved-reference'), subject=a, object=b, raw=raw)
                continue
            m = re.match(r'^where\s+is\s+(.+)$', low)
            if m:
                a = _resolve_surface(m.group(1), ctx, audit, role='query-subject')
                query = LogicalQuery(kind=('relation-from-subject' if a else 'unresolved-reference'), subject=a, relation='', raw=raw)
                continue
            m = re.match(r'^what\s+is\s+(.+)$', low)
            if m:
                a = _resolve_surface(m.group(1), ctx, audit, role='query-subject')
                # Non-pronominal target is already a usable entity.
                if not a and _entity(m.group(1)) not in _PRONOUNS:
                    a = _entity(m.group(1))
                query = LogicalQuery(kind=('relation-from-subject' if a else 'unresolved-reference'), subject=a, relation='', raw=raw)
                continue
            m = re.match(r'^what\s+can\s+(.+?)\s+([a-z][a-z-]*)$', low)
            if m:
                a = _resolve_surface(m.group(1), ctx, audit, role='query-subject')
                if not a and _entity(m.group(1)) not in _PRONOUNS:
                    a = _entity(m.group(1))
                query = LogicalQuery(kind=('relation-from-subject' if a else 'unresolved-reference'), subject=a, relation=f'can-{_relation(m.group(2))}', raw=raw)
                continue
            # Productive Stage-8B proof queries. These rows request native
            # proof-field matching only; parser recognition never supplies truth.
            m = re.match(r'^why\s+(?:is|are)\s+(.+?)\s+(?:a\s+|an\s+|the\s+)?(.+)$', low)
            if m:
                a=_resolved_or_literal(m.group(1),ctx,audit,role='query-subject')
                b=_resolved_or_literal(m.group(2),ctx,audit,role='query-object') or _entity(m.group(2))
                query=LogicalQuery(kind=('why-proposition' if a and b else 'unresolved-reference'),subject=a,relation='is',object=b,raw=raw)
                continue
            m = re.match(r'^why\s+(?:did|does|do)\s+(.+?)\s+([a-z][a-z-]*)\s+(.+)$', low)
            if m:
                a=_resolved_or_literal(m.group(1),ctx,audit,role='query-subject')
                b=_resolved_or_literal(m.group(3),ctx,audit,role='query-object') or _entity(m.group(3))
                query=LogicalQuery(kind=('why-proposition' if a and b else 'unresolved-reference'),subject=a,relation=_morph_lemma(m.group(2)),object=b,raw=raw)
                continue
            m = re.match(r'^who\s+([a-z][a-z-]*)\s+(.+)$', low)
            if m:
                b=_resolved_or_literal(m.group(2),ctx,audit,role='query-object') or _entity(m.group(2))
                query=LogicalQuery(kind=('relation-to-object' if b else 'unresolved-reference'),relation=_morph_lemma(m.group(1)),object=b,raw=raw)
                continue
            m = re.match(r'^what\s+(?:did|does|do)\s+(.+?)\s+([a-z][a-z-]*)$', low)
            if m:
                a=_resolved_or_literal(m.group(1),ctx,audit,role='query-subject')
                query=LogicalQuery(kind=('relation-from-subject' if a else 'unresolved-reference'),subject=a,relation=_morph_lemma(m.group(2)),raw=raw)
                continue
            m = re.match(r'^(where|when|how)\s+(?:did|does|do|is|are|was|were)\s+(.+?)(?:\s+([a-z][a-z-]*))?$', low)
            if m:
                family,target,verb=m.groups();a=_resolved_or_literal(target,ctx,audit,role='query-subject')
                query=LogicalQuery(kind=(f'{family}-from-subject' if a else 'unresolved-reference'),subject=a,relation=(_morph_lemma(verb) if verb else ''),raw=raw)
                continue
            # Exact yes/no proposition requests. A supported proposition is the
            # answer; absent proof remains absent rather than becoming a canned yes/no.
            m = re.match(r'^(?:is|are|was|were)\s+(.+?)\s+(?:a\s+|an\s+|the\s+)?(.+)$', low)
            if m:
                a=_resolved_or_literal(m.group(1),ctx,audit,role='query-subject')
                b=_resolved_or_literal(m.group(2),ctx,audit,role='query-object') or _entity(m.group(2))
                query=LogicalQuery(kind=('exact-proposition' if a and b else 'unresolved-reference'),subject=a,relation='is',object=b,raw=raw)
                continue
            m = re.match(r'^(?:does|do|did)\s+(.+?)\s+([a-z][a-z-]*)\s+(.+)$', low)
            if m:
                a=_resolved_or_literal(m.group(1),ctx,audit,role='query-subject')
                b=_resolved_or_literal(m.group(3),ctx,audit,role='query-object') or _entity(m.group(3))
                query=LogicalQuery(kind=('exact-proposition' if a and b else 'unresolved-reference'),subject=a,relation=_morph_lemma(m.group(2)),object=b,raw=raw)
                continue
            m = re.match(r'^(can|could|may|might|will|would|should|must)\s+(.+?)\s+([a-z][a-z-]*)\s+(.+)$', low)
            if m:
                modal,a0,verb,b0=m.groups();a=_resolved_or_literal(a0,ctx,audit,role='query-subject')
                b=_resolved_or_literal(b0,ctx,audit,role='query-object') or _entity(b0)
                # Historical can-X propositions encode can in the relation; other
                # modals use proposition.modality. Keep the query transparent.
                rel=(f'can-{_morph_lemma(verb)}' if modal=='can' else _morph_lemma(verb))
                query=LogicalQuery(kind=('exact-proposition' if a and b else 'unresolved-reference'),subject=a,relation=rel,object=b,raw=raw)
                audit['query_modal']=modal
                continue
            if query.kind == 'none':
                query = LogicalQuery(kind='unresolved-surface-question', raw=raw)
            continue

        # -------------------------- formal relations -----------------------
        m = re.match(r'^if\s+(.+?)\s+then\s+(.+)$', low)
        if m:
            propositions.append(LogicalProposition(subject=_entity(m.group(1)), relation='implies', object=_entity(m.group(2)), source='current-irg', confidence=1.0))
            continue
        m = re.match(r'^(.+?)\s+implies\s+(.+)$', low)
        if m:
            propositions.append(LogicalProposition(subject=_entity(m.group(1)), relation='implies', object=_entity(m.group(2)), source='current-irg', confidence=1.0))
            continue

        m = re.match(r'^(?:the\s+relation\s+)?([a-z][a-z-]*)\s+(?:has\s+property|is)\s+transitive$', low)
        if m:
            propositions.append(LogicalProposition(subject=f'relation:{_relation(m.group(1))}',relation='has-property',object='transitive',source='current-irg',confidence=1.0))
            continue

        # ------------------------- quantification --------------------------
        m = re.match(r'^no\s+(.+?)\s+(?:is|are)\s+(?:a\s+|an\s+|the\s+)?(.+)$', low)
        if m:
            propositions.append(LogicalProposition(subject=_entity(m.group(1)), relation='is', object=_entity(m.group(2)), polarity=False, universal=True, source='current-irg', confidence=1.0))
            continue
        m = re.match(r'^every\s+(.+?)\s+(?:is|are)\s+(?:a\s+|an\s+|the\s+)?(.+)$', low)
        if m:
            propositions.append(LogicalProposition(subject=_entity(m.group(1)), relation='is', object=_entity(m.group(2)), source='current-irg', confidence=1.0, universal=True))
            continue

        # Atomic truth used by implication chains.
        m = re.match(r'^(.+?)\s+is\s+true$', low)
        if m:
            propositions.append(LogicalProposition(subject=_entity(m.group(1)), relation='true', object='true', source='current-irg', confidence=1.0))
            continue

        # Explicit atomic negation.
        m = re.match(r'^(.+?)\s+(?:is|are)\s+not\s+(?:a\s+|an\s+|the\s+)?(.+)$', low)
        if m:
            subj = _resolved_or_literal(m.group(1), ctx, audit, role='subject')
            obj = _entity(m.group(2))
            if subj:
                propositions.append(LogicalProposition(subject=subj, relation='is', object=obj, polarity=False, source='current-irg', confidence=1.0))
            _mention(ctx, audit, subject=subj, direct=(obj if subj else ''))
            continue

        # ----------------------- relative modification ---------------------
        # "The book that Mira placed is blue" -> Mira placed book; book is blue.
        m = re.match(r'^(?:the\s+)?(.+?)\s+that\s+(.+?)\s+([a-z][a-z-]*)\s+(?:is|are)\s+(.+)$', low)
        if m:
            head, actor, verb, pred = m.groups()
            head_e = _entity(head); actor_e = _resolved_or_literal(actor,ctx,audit,role='relative-subject')
            pred_e = _entity(pred)
            if actor_e:
                propositions.append(LogicalProposition(subject=actor_e, relation=_relation(verb), object=head_e, source='current-irg', confidence=1.0, modifiers=[f'relative:{head_e}']))
            propositions.append(LogicalProposition(subject=head_e, relation='is', object=pred_e, source='current-irg', confidence=1.0, modifiers=([f'relative-source:{actor_e}:{_relation(verb)}'] if actor_e else ['relative-subject-unresolved'])))
            _mention(ctx,audit,subject=head_e,direct=pred_e)
            continue

        # -------------------------- conjunction ----------------------------
        # Generic copular conjunction: "Mira is a scholar and a pilot".
        m = re.match(r'^(.+?)\s+(?:is|are)\s+(?:a\s+|an\s+|the\s+)?(.+?)\s+and\s+(?:a\s+|an\s+|the\s+)?(.+)$', low)
        if m:
            subj = _resolved_or_literal(m.group(1),ctx,audit,role='subject')
            o1,o2=_entity(m.group(2)),_entity(m.group(3))
            if subj:
                propositions.extend([
                    LogicalProposition(subject=subj,relation='is',object=o1,source='current-irg',confidence=1.0,modifiers=['conjunct:1']),
                    LogicalProposition(subject=subj,relation='is',object=o2,source='current-irg',confidence=1.0,modifiers=['conjunct:2']),
                ])
            _mention(ctx,audit,subject=subj,direct=(o2 if subj else ''))
            continue

        # -------------------------- action frames --------------------------
        # Direct object plus an explicit spatial oblique. Grammatical role is kept
        # separate so later "it" refers to the direct object rather than whichever
        # proposition happened to be appended last.
        m = re.match(r'^(.+?)\s+placed\s+(.+?)\s+(beside|inside|near|under|above|behind|on)\s+(.+)$', low)
        if m:
            subj0,direct0,spatial,obl0=m.groups()
            subj=_resolve_surface(subj0,ctx,audit,role='subject')
            if not subj and _entity(subj0) not in _PRONOUNS: subj=_entity(subj0)
            direct=_resolve_surface(direct0,ctx,audit,role='direct-object')
            if not direct and _entity(direct0) not in _PRONOUNS: direct=_entity(direct0)
            obl=_resolve_surface(obl0,ctx,audit,role='oblique-object')
            if not obl and _entity(obl0) not in _PRONOUNS: obl=_entity(obl0)
            if subj and direct:
                propositions.append(LogicalProposition(subject=subj,relation='placed',object=direct,source='current-irg',confidence=1.0,modifiers=[f'{spatial}:{obl}' if obl else spatial]))
            if direct and obl:
                propositions.append(LogicalProposition(subject=direct,relation=_relation(spatial),object=obl,source='current-irg',confidence=1.0,modifiers=['spatial-oblique']))
            _mention(ctx,audit,subject=subj,direct=direct,oblique=obl)
            continue

        # Modal SVO. ``can`` retains the historical can-verb relation for backwards
        # compatibility; other modals are explicit proposition modality.
        m = re.match(r'^(.+?)\s+(may|might|must|should|could|would|will|can)\s+([a-z][a-z-]*)\s+(.+)$', low)
        if m:
            subj0,modal,verb,obj0=m.groups()
            subj=_resolve_surface(subj0,ctx,audit,role='subject') or (_entity(subj0) if _entity(subj0) not in _PRONOUNS else '')
            obj=_resolve_surface(obj0,ctx,audit,role='direct-object') or (_entity(obj0) if _entity(obj0) not in _PRONOUNS else '')
            if subj and obj:
                rel=f'can-{_relation(verb)}' if modal=='can' else _relation(verb)
                propositions.append(LogicalProposition(subject=subj,relation=rel,object=obj,modality=('' if modal=='can' else modal),source='current-irg',confidence=1.0))
            _mention(ctx,audit,subject=subj,direct=obj)
            continue

        # Verb + "for" complement keeps the old developmental asks-for frame.
        m = re.match(r'^(?:a\s+|an\s+|the\s+)?(.+?)\s+([a-z][a-z-]*)\s+for\s+(?:a\s+|an\s+|the\s+)?(.+)$', low)
        if m:
            subj0,verb,obj0=m.groups();subj=_resolved_or_literal(subj0,ctx,audit,role='subject');obj=_entity(obj0)
            if subj:
                propositions.append(LogicalProposition(subject=subj,relation=f'{_relation(verb)}-for',object=obj,source='current-irg',confidence=1.0))
            _mention(ctx,audit,subject=subj,direct=(obj if subj else ''))
            continue

        # Historical/generic binary relations.
        relation_patterns = [
            (r'^(.+?)\s+is\s+inside\s+(.+)$', 'inside'),
            (r'^(.+?)\s+is\s+contained\s+in\s+(.+)$', 'inside'),
            (r'^(.+?)\s+contains\s+(.+)$', 'contains'),
            (r'^(.+?)\s+is\s+part\s+of\s+(.+)$', 'part-of'),
            (r'^(.+?)\s+is\s+(?:a\s+|an\s+|the\s+)?(.+)$', 'is'),
            (r'^(.+?)\s+can\s+([a-z][a-z-]*)\s+(.+)$', None),
        ]
        matched = False
        for pattern, rel in relation_patterns:
            m = re.match(pattern, low)
            if not m:
                continue
            if rel is None:
                subj0, verb, obj0 = m.groups(); rel = f'can-{_relation(verb)}'
            else:
                subj0, obj0 = m.groups()
            subj=_resolve_surface(subj0,ctx,audit,role='subject') or (_entity(subj0) if _entity(subj0) not in _PRONOUNS else '')
            obj=_resolve_surface(obj0,ctx,audit,role='direct-object') or (_entity(obj0) if _entity(obj0) not in _PRONOUNS else '')
            if subj and obj:
                propositions.append(LogicalProposition(subject=subj, relation=rel, object=obj, source='current-irg', confidence=1.0))
            _mention(ctx,audit,subject=subj,direct=obj)
            matched = True
            break
        if matched:
            continue

        # Conservative generic SVO action for ordinary finite clauses such as
        # "Mira entered the room". We do not guess semantic roles beyond the visible
        # grammatical subject / predicate / complement structure.
        m = re.match(r'^(?:the\s+)?(.+?)\s+([a-z][a-z-]*)\s+(?:a\s+|an\s+|the\s+)?(.+)$', low)
        if m:
            subj0,verb,obj0=m.groups()
            if verb not in {'and','or','but','because','since'}:
                subj=_resolve_surface(subj0,ctx,audit,role='subject') or (_entity(subj0) if _entity(subj0) not in _PRONOUNS else '')
                obj=_resolve_surface(obj0,ctx,audit,role='direct-object') or (_entity(obj0) if _entity(obj0) not in _PRONOUNS else '')
                if subj and obj:
                    propositions.append(LogicalProposition(subject=subj,relation=_relation(verb),object=obj,source='current-irg',confidence=1.0))
                _mention(ctx,audit,subject=subj,direct=obj)

    audit['last_subject']=ctx['last_subject']
    audit['last_direct_object']=ctx['last_direct_object']
    audit['last_oblique_object']=ctx['last_oblique_object']
    if audit['unresolved_references']:
        audit['resolution_status']='unresolved-reference-present'
    elif audit['resolutions']:
        audit['resolution_status']='resolved-from-grammatical-discourse-context'
    else:
        audit['resolution_status']='no-reference-resolution-needed'
    return propositions, query, audit


def parse_surface_logic(text: str, discourse_context: Mapping[str, object] | None = None) -> tuple[list[LogicalProposition], LogicalQuery]:
    props, query, _audit = parse_surface_logic_detailed(text, discourse_context)
    return props, query


def learned_to_logic(rows: Iterable[object]) -> list[LogicalProposition]:
    out: list[LogicalProposition] = []
    for row in rows or []:
        subj = str(getattr(row, 'subject_concept', '') or getattr(row, 'subject_surface', '')).strip().lower()
        obj = str(getattr(row, 'object_concept', '') or getattr(row, 'object_surface', '')).strip().lower()
        rel = str(getattr(row, 'relation', '')).strip().lower()
        if not subj or not rel or not obj:
            continue
        plural=[str(x) for x in (getattr(row,'source_memory_ids',[]) or []) if x]
        singular=(str(getattr(row, 'source_memory_id')) if getattr(row, 'source_memory_id', None) else '')
        if singular and singular not in plural: plural.append(singular)
        out.append(LogicalProposition(
            subject=subj, relation=rel, object=obj,
            polarity=bool(getattr(row,'polarity',True)),
            universal=bool(getattr(row,'universal',False)),
            modality=str(getattr(row,'modality','') or ''),
            modifiers=list(getattr(row,'modifiers',[]) or []),
            source='persistent-language-proposition',
            confidence=float(getattr(row, 'confidence', 0.5)),
            source_memory_id=singular,
            source_memory_ids=plural,
            source_record_id=(str(getattr(row, 'id')) if getattr(row, 'id', None) else ''),
        ))
    return out


def _relation_matches(observed: str, requested: str) -> bool:
    if not requested:
        return True
    a=str(observed or '').lower();b=str(requested or '').lower()
    if a==b:return True
    if '-' not in a and '-' not in b:
        if _morph_lemma(a)==_morph_lemma(b):return True
        # Transparent past/base comparison without committing a lexical lemma.
        # Both mechanically possible -ed removals are candidates; no truth is
        # asserted by this morphology normalization.
        if a.endswith('ed') and b in {a[:-2],a[:-1]}:return True
        if b.endswith('ed') and a in {b[:-2],b[:-1]}:return True
        return False
    if a.startswith('can-') and b.startswith('can-'):
        return _morph_lemma(a[4:])==_morph_lemma(b[4:])
    return False


def _spatial_relation(relation: str) -> bool:
    return str(relation or '').lower() in {'inside','beside','near','under','above','behind','before','after','on','in','at','from','to'}


def infer(
    premises: Sequence[LogicalProposition],
    query: LogicalQuery,
    *,
    max_steps: int = 128,
) -> tuple[list[LogicalProposition], list[InferenceStep], list[LogicalProposition], str]:
    """Compute finite deductive closure with no domain answer table or forced tie break."""
    known: dict[tuple[str, str, str, bool, bool, str], LogicalProposition] = {}
    premise_keys: set[tuple[str, str, str, bool, bool, str]] = set()
    for p in premises:
        k = proposition_key(p)
        old = known.get(k)
        if old is None or p.confidence > old.confidence:
            known[k] = p.model_copy(deep=True)
        premise_keys.add(k)

    steps: list[InferenceStep] = []
    changed = True
    rounds = 0
    while changed and len(steps) < max_steps:
        changed = False; rounds += 1
        rows = list(known.values())

        # Transitive composition applies only to positive, non-modal relation facts.
        by_relation: dict[str, list[LogicalProposition]] = {}
        for p in rows:
            if p.polarity and not p.modality:
                by_relation.setdefault(p.relation, []).append(p)
        transitive_relations={'implies'}
        transitive_relations.update(
            p.subject.split(':',1)[1]
            for p in rows
            if p.polarity and p.relation=='has-property' and p.object=='transitive' and p.subject.startswith('relation:')
        )
        for rel, rrows in by_relation.items():
            if rel not in transitive_relations:
                continue
            for a in rrows:
                for b in rrows:
                    if a.object != b.subject or a.subject == b.object:
                        continue
                    c = LogicalProposition(subject=a.subject, relation=rel, object=b.object, source='native-inference', confidence=min(a.confidence, b.confidence), derived=True)
                    ck = proposition_key(c)
                    if ck in known:
                        continue
                    known[ck] = c; changed = True
                    steps.append(InferenceStep(rule='transitive-composition',premises=[a.canonical(), b.canonical()],conclusion=c.canonical(),confidence=c.confidence))
                    if len(steps) >= max_steps: break
                if len(steps) >= max_steps: break

        # Positive universal membership: every A is B; x is A -> x is B.
        rows=list(known.values())
        universals=[p for p in rows if p.universal and p.polarity and p.relation=='is' and not p.modality]
        negative_universals=[p for p in rows if p.universal and (not p.polarity) and p.relation=='is' and not p.modality]
        memberships=[p for p in rows if (not p.universal) and p.polarity and p.relation=='is' and not p.modality]
        for u in universals:
            for a in memberships:
                if a.object!=u.subject: continue
                c=LogicalProposition(subject=a.subject,relation='is',object=u.object,source='native-inference',confidence=min(a.confidence,u.confidence),derived=True)
                ck=proposition_key(c)
                if ck in known: continue
                known[ck]=c;changed=True
                steps.append(InferenceStep(rule='universal-membership',premises=[a.canonical(),u.canonical()],conclusion=c.canonical(),confidence=c.confidence))
                if len(steps)>=max_steps: break
            if len(steps)>=max_steps: break

        # Negative universal membership: no A is B; x is A -> not(x is B).
        rows=list(known.values())
        memberships=[p for p in rows if (not p.universal) and p.polarity and p.relation=='is' and not p.modality]
        for u in negative_universals:
            for a in memberships:
                if a.object!=u.subject: continue
                c=LogicalProposition(subject=a.subject,relation='is',object=u.object,polarity=False,source='native-inference',confidence=min(a.confidence,u.confidence),derived=True)
                ck=proposition_key(c)
                if ck in known: continue
                known[ck]=c;changed=True
                steps.append(InferenceStep(rule='universal-negative-membership',premises=[a.canonical(),u.canonical()],conclusion=c.canonical(),confidence=c.confidence))
                if len(steps)>=max_steps: break
            if len(steps)>=max_steps: break
        if len(steps) >= max_steps: break

        # Modus ponens.
        rows = list(known.values())
        implications = [p for p in rows if p.polarity and p.relation == 'implies']
        truths = {p.subject: p for p in rows if p.polarity and p.relation == 'true' and p.object == 'true'}
        for imp in implications:
            tp = truths.get(imp.subject)
            if tp is None: continue
            c = LogicalProposition(subject=imp.object, relation='true', object='true', source='native-inference', confidence=min(imp.confidence, tp.confidence), derived=True)
            ck = proposition_key(c)
            if ck in known: continue
            known[ck] = c; changed = True
            steps.append(InferenceStep(rule='modus-ponens', premises=[imp.canonical(), tp.canonical()], conclusion=c.canonical(), confidence=c.confidence))
            if len(steps) >= max_steps: break
        if rounds > max_steps: break

    derived = [p for k, p in known.items() if k not in premise_keys]
    candidates: list[LogicalProposition] = []
    if query.kind == 'derive-all':
        candidates = list(derived)
    elif query.kind == 'relation-between':
        candidates = [p for p in known.values() if p.subject == query.subject and p.object == query.object]
    elif query.kind == 'relation-from-subject':
        candidates = [p for p in known.values() if p.subject == query.subject and _relation_matches(p.relation,query.relation)]
    elif query.kind == 'relation-to-object':
        candidates = [p for p in known.values() if p.object == query.object and _relation_matches(p.relation,query.relation)]
    elif query.kind in {'exact-proposition','why-proposition'}:
        candidates = [p for p in known.values() if p.subject==query.subject and p.object==query.object and _relation_matches(p.relation,query.relation)]
    elif query.kind == 'where-from-subject':
        candidates = [p for p in known.values() if p.subject==query.subject and _spatial_relation(p.relation) and _relation_matches(p.relation,query.relation)]
    elif query.kind in {'when-from-subject','how-from-subject'}:
        # Time/manner answers require explicit native propositions; the grammar
        # does not invent a temporal or manner relation from surface shape.
        prefix='time-' if query.kind.startswith('when-') else 'manner-'
        candidates = [p for p in known.values() if p.subject==query.subject and str(p.relation).startswith(prefix) and _relation_matches(p.relation,query.relation)]

    if query.kind == 'derive-all' and derived:
        candidates = [p for p in candidates if p.derived]
    dedup = {proposition_key(p): p for p in candidates}
    candidates = sorted(dedup.values(), key=lambda p: p.canonical())
    if len(candidates) == 1:
        status = 'unique-proof-supported-answer'
    elif len(candidates) > 1:
        status = 'multiple-proof-supported-answers-no-forced-choice'
    elif query.kind in {'none', 'unresolved-surface-question', 'unresolved-reference'}:
        status = 'no-logical-selection-requested'
    else:
        status = 'no-proof-supported-answer'
    return derived, steps, candidates, status


def render_logical_proposition(p: LogicalProposition) -> tuple[str, str, str]:
    """Surface one proof proposition; semantic content is already fixed upstream."""
    subj = _display(p.subject); obj = _display(p.object)
    if p.relation == 'true' and p.object == 'true':
        return subj, ('is' if p.polarity else 'is not'), 'true'
    if p.relation == 'identity' and p.subject in {'speaker:self','interlocutor:self'}:
        value=p.object.split(':',1)[1] if ':' in p.object else p.object; value=_display(value)
        return ('You','are',value) if p.subject=='speaker:self' else ('I','am',value)
    modal=(p.modality+' ') if p.modality else ''
    if not p.polarity:
        if p.relation=='is': return subj, 'is not', obj
        return subj, f'{modal}does not {p.relation.replace("-", " ")}'.strip(), obj
    return subj, f'{modal}{p.relation.replace("-", " ")}'.strip(), obj
