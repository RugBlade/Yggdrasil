from __future__ import annotations

import os
import subprocess
from pathlib import Path


def _validated_executable(path: str) -> str:
    p = Path(path or '')
    if not path:
        raise ValueError('local decoder is not configured')
    if not p.is_absolute():
        raise ValueError('local decoder path must be absolute')
    if not p.is_file() or not os.access(p, os.X_OK):
        raise ValueError('local decoder executable is unavailable')
    return str(p)


def run_local_decoder(executable: str, payload: bytes, *, timeout: float = 20.0) -> str:
    """Run an explicitly configured local decoder, with no shell/network fallback."""
    exe = _validated_executable(executable)
    proc = subprocess.run(
        [exe], input=payload, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        shell=False, timeout=max(1.0, min(float(timeout), 120.0)), check=False,
    )
    if proc.returncode != 0:
        raise ValueError(f'local decoder failed with exit code {proc.returncode}')
    return proc.stdout.decode('utf-8', errors='strict').strip()
