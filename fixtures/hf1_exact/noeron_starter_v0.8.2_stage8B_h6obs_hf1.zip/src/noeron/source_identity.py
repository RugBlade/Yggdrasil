from __future__ import annotations

"""Stable source-lineage identity for Noeron learning provenance.

Hashes in this module are provenance identifiers only. They are never used as
semantic coordinates, retrieval features, or IRG/DKT embeddings.
"""

import hashlib
import os
import re
from dataclasses import dataclass


@dataclass(frozen=True)
class SourceIdentity:
    canonical_source_id: str
    canonical_source_name: str
    source_version_sha256: str
    source_version_id: str


def _fallback_title(title: str) -> str:
    t=(title or '').strip()
    t=re.sub(r'\s*[—–-]\s*batch\s*\d+\s*$', '', t, flags=re.I)
    t=re.sub(r'\s*\(\s*batch\s*\d+\s*\)\s*$', '', t, flags=re.I)
    return t or 'unnamed-source'


def canonical_source_name(source_name: str, title: str='') -> str:
    raw=(source_name or '').strip()
    if raw:
        # Pure normalization only: do not resolve symlinks or require the file to exist.
        raw=raw.replace('\\','/')
        return os.path.normpath(raw).replace('\\','/')
    return 'title:'+_fallback_title(title).lower()


def identify_source(source_name: str, title: str, content: str | None=None) -> SourceIdentity:
    name=canonical_source_name(source_name,title)
    lineage_digest=hashlib.sha256(('noeron-source-lineage-v1|'+name).encode('utf-8')).hexdigest()
    canonical_id='src-'+lineage_digest[:24]
    version_hash=hashlib.sha256((content or '').encode('utf-8')).hexdigest() if content is not None else ''
    version_digest=hashlib.sha256((canonical_id+'|'+version_hash).encode('utf-8')).hexdigest() if version_hash else ''
    version_id=('srcv-'+version_digest[:24]) if version_digest else ''
    return SourceIdentity(canonical_id,name,version_hash,version_id)


def provenance_digest(text: str, length: int=24) -> str:
    """Non-semantic audit digest used only for reproducibility/provenance."""
    return hashlib.sha256(text.encode('utf-8')).hexdigest()[:max(8,int(length))]
