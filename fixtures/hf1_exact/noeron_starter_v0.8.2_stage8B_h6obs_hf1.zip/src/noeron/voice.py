from __future__ import annotations

import io
import math
import wave

from noeron.room_models import NativeVoiceProfile


def _bounded(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, float(x)))


def render_native_voice_wav(native_text: str, profile: NativeVoiceProfile, *, sample_rate: int = 16_000) -> bytes:
    """Low-level deterministic acoustic actuator with no speaker/TTS identity.

    It turns already-existing native text into a waveform using only continuous
    profile coordinates.  It does not select content, decide whether voice is used,
    or call a pretrained speech model.
    """
    text = native_text or ''
    if not text:
        raise ValueError('native utterance is empty')
    sr = int(max(8000, min(48000, sample_rate)))
    base = 85.0 + 260.0 * _bounded(profile.base_frequency, 0.0, 1.0)
    overtone = 1.25 + 2.75 * _bounded(profile.overtone_ratio, 0.0, 1.0)
    modulation = 0.5 + 8.0 * _bounded(profile.modulation, 0.0, 1.0)
    articulation = 0.025 + 0.075 * _bounded(profile.articulation, 0.0, 1.0)
    pulse = 0.15 + 0.70 * _bounded(profile.pulse_shape, 0.0, 1.0)
    tempo = 0.55 + 1.45 * _bounded(profile.tempo, 0.0, 1.0)
    out = bytearray()
    phase = 0.0
    for i, ch in enumerate(text):
        code = ord(ch)
        duration = articulation / tempo * (0.45 if ch.isspace() else 1.0)
        n = max(24, int(sr * duration))
        symbol = ((code % 37) / 36.0) if not ch.isspace() else 0.0
        freq = base * (0.72 + 0.56 * symbol)
        for j in range(n):
            t = j / sr
            env = math.sin(math.pi * (j + 0.5) / n) ** (0.7 + pulse)
            fm = 1.0 + 0.018 * math.sin(2.0 * math.pi * modulation * t + i * 0.31)
            phase += 2.0 * math.pi * freq * fm / sr
            s = math.sin(phase) + 0.33 * math.sin(overtone * phase) + 0.11 * math.sin((overtone + 1.0) * phase)
            sample = int(max(-1.0, min(1.0, 0.34 * env * s)) * 32767.0)
            out.extend(int(sample).to_bytes(2, byteorder='little', signed=True))
    bio = io.BytesIO()
    with wave.open(bio, 'wb') as wf:
        wf.setnchannels(1); wf.setsampwidth(2); wf.setframerate(sr); wf.writeframes(bytes(out))
    return bio.getvalue()
