from __future__ import annotations

"""v0.7.3.4 native communication consequence selector.

The runtime programs communication *affordances*, not a hold/speak preference.
Observed pre->post DKT transitions are learned for ``express`` and
``continue-private``.  At decision time each transition is transported to the
current DKT context, producing a predicted post-action knot.  All candidates are
compared by the same H^s distance to one empirically learned admissible/trusted
post-state manifold.  Missing evidence or an exact tie remains unresolved.
"""

from noeron.math import dkt
from noeron.math.models import KnotState
from noeron.math.linalg import numerically_tied
from noeron.consequence import equal_affordance_post_manifold


class InitiativePolicy:
    AFFORDANCES=('express','continue-private')

    def __init__(self, threshold: float = 0.55):
        # Constructor compatibility only; never participates in communication choice.
        self.legacy_threshold=float(threshold)

    @staticmethod
    def _mean(old: KnotState | None, new: KnotState, n_old: int) -> KnotState:
        if old is None or n_old<=0:
            return new.model_copy(deep=True)
        candidate=dkt.interpolate(old,new,1.0/float(n_old+1))
        safe,_audit=dkt.retract_to_admissible(old,candidate)
        return safe

    @staticmethod
    def _transport_transition(model_pre: KnotState, model_post: KnotState, current_pre: KnotState) -> KnotState:
        """Apply the learned finite-chart displacement to the current pre-state."""
        modes=max(model_pre.mode_radius,model_post.mode_radius,current_pre.mode_radius)
        pc,ps=dkt._pad(model_pre,modes)
        qc,qs=dkt._pad(model_post,modes)
        cc,cs=dkt._pad(current_pre,modes)
        out=current_pre.model_copy(deep=True)
        out.mode_radius=modes
        out.cosine=[list(v) for v in cc]
        out.sine=[list(v) for v in cs]
        out.c0=[current_pre.c0[i]+(model_post.c0[i]-model_pre.c0[i]) for i in range(3)]
        for n in range(modes+1):
            for axis in range(3):
                out.cosine[n][axis]+=qc[n][axis]-pc[n][axis]
                out.sine[n][axis]+=qs[n][axis]-ps[n][axis]
        est=dkt.estimate_whitney_stratum(out)
        out.stratum_index=est.estimated_index
        out.invariant_signature=dkt.invariant_signature(out)
        safe,_audit=dkt.retract_to_admissible(current_pre,out)
        return safe

    def observe_transition(self, state, action: str, pre_knot: KnotState, post_knot: KnotState, *, admissible: bool = True, source: str = '') -> dict:
        if action not in self.AFFORDANCES:
            raise ValueError(f'action must be one of {self.AFFORDANCES}')
        if not admissible:
            return {'learned':False,'action':action,'reason':'observed transition was not admitted to trusted/admissible geometry','source':source}
        n=int(state.action_observations.get(action,0))
        state.action_pre_knots[action]=self._mean(state.action_pre_knots.get(action),pre_knot,n)
        state.action_post_knots[action]=self._mean(state.action_post_knots.get(action),post_knot,n)
        state.action_observations[action]=n+1
        state.admissible_post_knot, represented=equal_affordance_post_manifold(state.action_post_knots,state.action_observations,self.AFFORDANCES)
        state.admissible_post_observations=len(represented)
        state.transition_observations+=1
        return {
            'learned':True,'action':action,'observations':n+1,
            'admissible_post_observations':state.admissible_post_observations,
            'source':source,'learning_rule':'observed pre->post DKT transition + frequency-neutral equal-affordance admissible post-state manifold',
            'authority':'empirical consequence geometry; each learned affordance contributes equal reference mass; not owner-labeled preference',
        }

    def choose(self, context_knot: KnotState, state) -> dict:
        state.last_context_knot=context_knot.model_copy(deep=True)
        state.last_context_signature=context_knot.invariant_signature
        state.last_selected_action=''
        state.last_native_choice_claim=False
        state.last_predicted_post_knots={}
        if state.admissible_post_knot is None or any(
            state.action_pre_knots.get(a) is None or state.action_post_knots.get(a) is None or int(state.action_observations.get(a,0))<1
            for a in self.AFFORDANCES
        ):
            state.last_candidate_distances={}
            state.last_selection_status='unresolved-insufficient-consequence-geometry'
            state.last_decision_layer='unresolved'
            return {'action':None,'selection_status':state.last_selection_status,'decision_layer':'unresolved','native_choice_claim':False,'candidate_distances':{},'predicted_post_states':{}}
        predicted={}
        distances={}
        for action in self.AFFORDANCES:
            post=self._transport_transition(state.action_pre_knots[action],state.action_post_knots[action],context_knot)
            predicted[action]=post
            distances[action]=float(dkt.sobolev_distance(post,state.admissible_post_knot))
        state.last_predicted_post_knots={k:v.model_copy(deep=True) for k,v in predicted.items()}
        state.last_candidate_distances=dict(distances)
        best=min(distances.values())
        winners=[a for a,v in distances.items() if numerically_tied(v,best)]
        if len(winners)!=1:
            state.last_selection_status='unresolved-exact-consequence-geometry-tie'
            state.last_decision_layer='unresolved'
            return {'action':None,'selection_status':state.last_selection_status,'decision_layer':'unresolved','native_choice_claim':False,'candidate_distances':distances,'predicted_post_states':predicted}
        action=winners[0]
        state.last_selected_action=action
        state.last_selection_status='native-unique-predicted-post-state-hs-minimum'
        state.last_decision_layer='learned-deliberative'
        state.last_native_choice_claim=True
        return {'action':action,'selection_status':state.last_selection_status,'decision_layer':'learned-deliberative','native_choice_claim':True,'candidate_distances':distances,'predicted_post_states':predicted}

    def observe_feedback(self, context_knot: KnotState, state, preferred_action: str) -> dict:
        """Legacy endpoint compatibility: owner labels never train native preference."""
        if preferred_action not in {'surface','hold','express','continue-private'}:
            raise ValueError('preferred_action is an operator annotation only')
        state.feedback_observations+=1
        return {
            'preferred_action':preferred_action,'learned':False,
            'authority':'operator-feedback-provenance-only',
            'reason':'owner surface/hold labels have zero cognitive authority in consequence-based communication',
            'context_signature':context_knot.invariant_signature,
        }
