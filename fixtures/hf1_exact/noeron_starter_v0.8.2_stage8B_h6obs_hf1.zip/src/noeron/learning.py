from __future__ import annotations

import json
import math
import re
from collections import Counter
from datetime import datetime, timezone
from typing import Mapping

from noeron.learning_models import (
    SemanticKnotPrototype, LearningPreview, SparseKnotDeformation,
)
from noeron.math import dkt
from noeron.math.linalg import numerically_tied
from noeron.math.irg import candidate_residual_terms, interaction_geometry, lexical_root
from noeron.math.models import KnotState
from noeron.models import CognitiveEvent, EventKind


_HEADING = re.compile(r'^\s*(?:#{1,6}\s+.+|\\(?:chapter|section|subsection|subsubsection)\*?\{.+\})\s*$')
_STRUCTURAL = re.compile(r'\b(definition|theorem|lemma|proposition|corollary|proof|equation|axiom|remark)\b', re.I)
_LATEX_HINT = re.compile(r'\\(?:documentclass|usepackage|begin\{|section\{|newtheorem|newcommand|setcounter|graphicspath)')
_LATEX_SCAFFOLD_LINE = re.compile(
    r'^\s*\\(?:documentclass|usepackage|setcounter|graphicspath|newtheorem|newenvironment|newcommand|renewcommand|providecommand|DeclareMathOperator|bibliographystyle|pagestyle|thispagestyle|makeatletter|makeatother|TCIDATA|TCIDHTH|input|include|title|author|date)\b',
    re.I,
)
_ENV_DROP = {'document','center','flushleft','flushright','titlepage'}
_ENV_SEMANTIC = {'abstract','definition','theorem','lemma','proposition','corollary','proof','remark','equation','equation*','align','align*','gather','gather*','multline','multline*'}




# ---------------------------------------------------------------------------
# v0.6.6 mathematical perception / concept formation
# ---------------------------------------------------------------------------

_LEARNING_BACKGROUND = {
    # Syntax/markup only.  No domain/content word is excluded because an engineer
    # judged it unimportant.  These forms are grammatical or presentation substrate.
    'the','a','an','of','to','for','in','on','at','as','or','if','it','its','is','are','was','were','be','been','being',
    'with','from','into','onto','over','under','and','but','this','that','these','those','i','me','my','we','us','our','you','your','they','them','their',
    'begin','end','itemize','enumerate','description','item','mathbb','mathcal','mathrm','mathbf','operatorname','textbf','textit','emph','label','ref','cite','left','right',
}


# Canonical mathematical objects/relations are deterministic sensor symbols.  The
# mapping is deliberately small and explicit: it interprets notation structure, not
# mathematical truth, and uses no LLM.
_MATHBB_NAMES = {
    'R':'real-number-space','C':'complex-number-space','Z':'integer-space',
    'Q':'rational-number-space','N':'natural-number-space',
}
_RELATION_COMMANDS = {
    r'\sim':'equivalence-relation', r'\simeq':'isomorphism-relation',
    r'\cong':'congruence-relation', r'\subset':'subset-relation',
    r'\subseteq':'subset-or-equal-relation', r'\in':'membership-relation',
    r'\notin':'nonmembership-relation', r'\iff':'biconditional-relation',
    r'\to':'mapping-arrow', r'\rightarrow':'mapping-arrow', r'\longrightarrow':'mapping-arrow', r'\mapsto':'mapsto-arrow',
    r'\infty':'infinity-symbol', r'\leq':'less-or-equal-relation', r'\geq':'greater-or-equal-relation',
    r'\neq':'not-equal-relation', r'\ne':'not-equal-relation', r'\hookrightarrow':'embedding-arrow',
    r'\bigcup':'union-operator', r'\bigcap':'intersection-operator', r'\inf':'infimum-operator', r'\sup':'supremum-operator',
    r'\forall':'universal-quantifier', r'\exists':'existential-quantifier',
}


def canonicalize_mathematical_language(text: str) -> tuple[str,list[str]]:
    """Canonicalize common mathematical notation for the IRG text sensor.

    This is a NOERON_EXTENSION perception layer.  It does not solve or interpret an
    equation.  It prevents TeX command names from being learned as concepts and
    exposes a few stable mathematical objects/relations to later DKT learning.
    """
    out=text
    notes=[]

    # Canonical named mathematical objects before generic TeX cleanup.
    # Fr{\'e}chet is the exact form used throughout the current manuscript.
    new,n=re.subn(r"Fr\{\\'e\}chet|Fr\{\\'\{e\}\}chet|Fréchet",'Frechet',out,flags=re.I)
    if n: notes.append(f'canonicalized {n} Frechet-name occurrence(s)')
    out=new
    new,n=re.subn(r'\\(?:text|operatorname)\{Emb\}|\bEmb(?=\s*\()',' embedding-space ',out)
    if n: notes.append(f'canonicalized {n} embedding-space occurrence(s)')
    out=new
    new,n=re.subn(r'\\(?:text|operatorname)\{Imm\}|\bImm(?=\s*\()',' immersion-space ',out)
    if n: notes.append(f'canonicalized {n} immersion-space occurrence(s)')
    out=new
    new,n=re.subn(r'\\(?:text|operatorname)\{Diff\}|\bDiff(?=\s*\()',' diffeomorphism-space ',out)
    if n: notes.append(f'canonicalized {n} diffeomorphism-space occurrence(s)')
    out=new

    def mathbb_repl(m):
        symbol=m.group(1)
        return ' '+_MATHBB_NAMES.get(symbol,f'blackboard-symbol-{symbol.lower()}')+' '
    new,n=re.subn(r'\\mathbb\s*\{\s*([A-Za-z])\s*\}',mathbb_repl,out)
    if n: notes.append(f'canonicalized {n} blackboard-bold mathematical object(s)')
    out=new

    # Frequently used knot notation in the DKT manuscript: preserve that a symbol is
    # a knot variable without pretending its index carries semantic content.
    new,n=re.subn(r'\\mathcal\s*\{\s*K\s*\}(?:_\{?\d+\}?)?', ' knot-symbol ', out)
    if n: notes.append(f'canonicalized {n} DKT knot symbol occurrence(s)')
    out=new

    # Preserve semantic relation roles instead of leaving command names such as sim.
    for cmd,label in sorted(_RELATION_COMMANDS.items(),key=lambda kv:len(kv[0]),reverse=True):
        out,n=re.subn(re.escape(cmd)+r'(?![A-Za-z])',f' {label} ',out)
        if n: notes.append(f'canonicalized {n} {cmd} -> {label} occurrence(s)')

    # Remove style/accent commands while preserving their braced mathematical symbol.
    for _ in range(2):
        out=re.sub(r'\\(?:widetilde|tilde|widehat|hat|overline|underline)\s*\{([^{}]*)\}',r'\1',out)

    # Canonicalize equation wrappers without turning their lines into blank segment
    # boundaries. This preserves mathematical-unit continuity while removing TeX
    # environment names from learnable vocabulary.
    out=re.sub(r'\\begin\{(?:equation\*?|align\*?|gather\*?|multline\*?)\}',' [EQUATION] ',out)
    out=re.sub(r'\\end\{(?:equation\*?|align\*?|gather\*?|multline\*?)\}',' [/EQUATION] ',out)
    # Remaining named TeX commands are represented as syntax, not candidate words.
    # Keep their braced arguments; drop the command name itself.
    out=re.sub(r'\\(?:begin|end)\{(?:itemize|enumerate|description)\}',' ',out)
    out=re.sub(r'\\item(?:\[[^]]*\])?',' ',out)
    out=re.sub(r'\\(?:left|right|big|Big|bigg|Bigg|vert|lvert|rvert)\b',' ',out)
    out=re.sub(r'\\[,;:! ]',' ',out)
    out=re.sub(r'[ \t]+',' ',out)
    out=re.sub(r'\n{3,}','\n\n',out).strip()
    return out,notes


def _normalized_learning_term(term: str) -> str:
    term=lexical_root(term)
    aliases={
        'mechanic':'mechanics','spher':'sphere','sphere':'sphere','embedd':'embedding',
        'sobolev-riemannian':'sobolev-riemannian','navier-stoke':'navier-stokes','yang-mill':'yang-mills',
        # Stable spelling repairs useful for uncontrolled prose.  Prefer explicit
        # repair over accepting malformed e-dropping stems as semantic concepts.
        'provid':'provide','configur':'configure','manag':'manage','reserv':'reserve','revis':'revise',
    }
    return aliases.get(term,term)


def _compound_concepts(text: str) -> list[str]:
    """Uniform lexical composition candidates, with no privileged semantic heads.

    Programmed grammar only defines token boundaries.  Every contiguous run of
    non-function content roots contributes adjacent 2- and 3-grams.  No mathematical
    noun list decides which phrases deserve conceptual standing.
    """
    text=text.replace('[EQUATION]',' ').replace('[/EQUATION]',' ')
    words=[_normalized_learning_term(w) for w in re.findall(r'[A-Za-z][A-Za-z0-9_-]*',text)]
    runs=[]; current=[]
    for w in words:
        if not w or w in _LEARNING_BACKGROUND or len(w)<3 or re.search(r'[_0-9]',w):
            if current:runs.append(current);current=[]
        else:
            current.append(w)
    if current:runs.append(current)
    out=[]
    for run in runs:
        for width in (2,3):
            for i in range(0,max(0,len(run)-width+1)):
                phrase='-'.join(run[i:i+width])
                if len(phrase)<=80 and phrase not in out:out.append(phrase)
    return out


def candidate_learning_concepts(text: str, limit: int | None = None) -> list[str]:
    """All observed lexical/compositional candidates; no authored salience ranking.

    ``limit`` remains accepted for API compatibility but is deliberately ignored in
    causal learning so list position cannot decide which observed concepts exist.
    """
    concepts=[]
    for raw in candidate_residual_terms(text,limit=None):
        term=_normalized_learning_term(raw)
        if not term or term in _LEARNING_BACKGROUND or len(term)<3 or re.search(r'[_0-9]',term):
            continue
        if term not in concepts:concepts.append(term)
    for term in _compound_concepts(text):
        if term not in concepts:concepts.append(term)
    return concepts


def concept_structural_role(term: str, context: str) -> tuple[str,float]:
    """Compatibility metadata only; no hand-authored concept-worth prior.

    v0.7.3.4 removes the table that declared particular mathematical words more
    concept-worthy than ordinary vocabulary. Semantic authority comes from observed
    recurrence and DKT context geometry. The returned score is neutral and has no
    establishment/choice authority.
    """
    return 'experience-grounded-lexical',0.0


def normalize_learning_document(text: str) -> tuple[str,int,list[str]]:
    """Remove LaTeX presentation scaffolding while preserving mathematical content.

    This is deliberately a deterministic structural reader, not a semantic parser and
    not an LLM.  Equations, theorem/proof text, headings and ordinary prose remain.
    Preamble/package/macro declarations and presentation commands are discarded.
    """
    raw=text.replace('\r\n','\n').replace('\r','\n')
    if not _LATEX_HINT.search(raw):
        clean,math_notes=canonicalize_mathematical_language(raw.strip())
        return clean,0,['plain/markdown source: no LaTeX scaffolding normalization required','v0.6.6 deterministic mathematical notation canonicalization applied']+math_notes

    filtered=0
    lines=[]
    in_document=False
    saw_begin_document='\\begin{document}' in raw
    for line in raw.split('\n'):
        # Strip non-escaped comments conservatively.
        line=re.sub(r'(?<!\\)%.*$','',line)
        s=line.strip()
        if saw_begin_document and not in_document:
            if '\\begin{document}' in s:
                in_document=True; filtered+=1
            else:
                filtered+=1
            continue
        if '\\end{document}' in s:
            filtered+=1; break
        if _LATEX_SCAFFOLD_LINE.match(s):
            filtered+=1; continue
        if not s:
            lines.append(''); continue
        if '#1' in s and ('\\small' in s or '\\rule' in s):
            filtered+=1; continue
        km=re.match(r'^\\keywords\{(.+)\}\s*$',s)
        if km:
            s='Keywords: '+km.group(1)
        # Preserve semantic section titles as Markdown-like headings.
        m=re.match(r'^\\(chapter|section|subsection|subsubsection)\*?\{(.+)\}\s*$',s)
        if m:
            level={'chapter':1,'section':2,'subsection':3,'subsubsection':4}[m.group(1)]
            lines.append('#'*level+' '+m.group(2)); continue
        # Semantic environments become explicit textual markers; presentation-only
        # wrappers disappear.
        m=re.match(r'^\\(begin|end)\{([^}]+)\}\s*$',s)
        if m:
            kind,env=m.groups()
            if env in _ENV_DROP or env in {'itemize','enumerate','description'}:
                filtered+=1; continue
            if env in _ENV_SEMANTIC:
                if kind=='begin' and env not in {'equation','equation*','align','align*','gather','gather*','multline','multline*'}:
                    lines.append(f'[{env.upper()}]')
                elif kind=='end' and env not in {'equation','equation*','align','align*','gather','gather*','multline','multline*'}:
                    # Closing delimiters are structural metadata, not experiences.
                    filtered+=1
                else:
                    lines.append(s)
                continue
        # Remove labels/citations/spacing commands without inventing content.
        s=re.sub(r'\\label\{[^}]*\}','',s)
        s=re.sub(r'\\(?:vspace|hspace)\*?\{[^}]*\}',' ',s)
        s=re.sub(r'\\(?:noindent|medskip|smallskip|bigskip|quad|qquad)\b',' ',s)
        # Unwrap common formatting commands while keeping their text argument.
        for _ in range(3):
            s=re.sub(r'\\(?:textbf|textit|emph|mathrm|mathbf|mathit|operatorname|textrm|text)\{([^{}]*)\}',r'\1',s)
        # Remove residual purely presentational commands with no arguments.
        s=re.sub(r'\\(?:maketitle|tableofcontents|newpage|clearpage)\b',' ',s)
        s=re.sub(r'[ \t]+',' ',s).strip()
        if s: lines.append(s)

    # Some legacy TeX generators emit multi-line newenvironment bodies after
    # \begin{document}; remove only the characteristic parameter/scaffolding tokens
    # left at the very beginning, never theorem/equation content.
    while lines and (lines[0].strip() in {'{','}','\\small'} or '#1' in lines[0]):
        lines.pop(0); filtered+=1
    out='\n'.join(lines)
    out=re.sub(r'^\\\s+','',out)
    out=re.sub(r'\n{3,}','\n\n',out).strip()
    out,math_notes=canonicalize_mathematical_language(out)
    notes=[
        'LaTeX structural normalization applied',
        'package/macro/preamble scaffolding removed',
        'headings, theorem/proof text, equations, and prose preserved without LLM interpretation',
        'v0.6.6 deterministic mathematical notation canonicalization applied',
    ]+math_notes
    return out,filtered,notes


def segment_document(text: str, *, max_chars: int = 1400) -> list[str]:
    """Split normalized plain text/Markdown/LaTeX into structural study units."""
    text,_,_=normalize_learning_document(text)
    text=text.strip()
    if not text:
        return []
    raw=[]; current=[]; size=0
    for line in text.split('\n'):
        s=line.strip()
        if _HEADING.match(s):
            if current:
                raw.append('\n'.join(current).strip()); current=[]; size=0
            current=[s]; size=len(s)
            continue
        if not s:
            if current:
                raw.append('\n'.join(current).strip()); current=[]; size=0
            continue
        # Theorem/proof markers create boundaries so a mathematical unit is not
        # merged into unrelated prose merely because it is short.
        if re.match(r'^\[/(?:DEFINITION|THEOREM|LEMMA|PROPOSITION|COROLLARY|PROOF|REMARK)\]$',s):
            if current:
                raw.append('\n'.join(current).strip()); current=[]; size=0
            # v0.6.5: closing-only structural markers never become study units.
            continue
        if re.match(r'^\[(?:DEFINITION|THEOREM|LEMMA|PROPOSITION|COROLLARY|PROOF|REMARK)\]$',s):
            if current:
                raw.append('\n'.join(current).strip()); current=[]; size=0
            current=[s]; size=len(s); continue
        if size+len(s)+1>max_chars and current:
            raw.append('\n'.join(current).strip()); current=[s]; size=len(s)
        else:
            current.append(s); size+=len(s)+1
    if current: raw.append('\n'.join(current).strip())

    out=[]
    for block in raw:
        prev_head=_HEADING.match(out[-1].split('\n',1)[0]) if out else None
        cur_head=_HEADING.match(block.split('\n',1)[0])
        if out and len(block)<180 and len(out[-1])<180 and len(out[-1])+len(block)+2<=max_chars and not prev_head and not cur_head and not block.startswith('['):
            out[-1]=out[-1]+'\n\n'+block
        else:
            out.append(block)
    cleaned=[]
    for x in out:
        z=re.sub(r'\\(?:begin|end)\{(?:itemize|enumerate|description)\}|\\item(?:\[[^]]*\])?',' ',x)
        z=re.sub(r'\s+',' ',z).strip()
        if not z: continue
        if re.fullmatch(r'\[/?(?:DEFINITION|THEOREM|LEMMA|PROPOSITION|COROLLARY|PROOF|REMARK)\]',z): continue
        cleaned.append(z)
    return cleaned


def preview_document(title: str, text: str, *, start_segment: int=0, max_segments: int=25) -> LearningPreview:
    normalized,filtered,notes=normalize_learning_document(text)
    segments=segment_document(normalized); start=max(0,int(start_segment)); end=min(len(segments),start+max(1,int(max_segments)))
    selected=segments[start:end]
    counts=Counter()
    for seg in selected:
        counts.update(candidate_learning_concepts(seg,limit=24))
    # Extra markup roots should not become candidate meanings even if malformed
    # source text leaves one behind.
    markup={'documentclass','usepackage','newtheorem','newenvironment','newcommand','setcounter','graphicspath','textbf','textit','emph','label','cite','ref','begin','end','abstract','definition','theorem','lemma','proposition','corollary','proof','remark','title','author','date','keyword','small'}
    residual=[term for term,_ in counts.most_common(48) if term not in markup][:24]
    return LearningPreview(
        title=title,total_segments=len(segments),selected_segments=len(selected),start_segment=start,end_segment=end,
        segment_previews=[s[:260].replace('\n',' ') for s in selected[:8]],candidate_residual_terms=residual,
        normalized_for_study=(normalized.strip()!=text.replace('\r\n','\n').replace('\r','\n').strip()),
        filtered_scaffolding_count=filtered,normalization_notes=notes,
    )


def _context_without_term(text: str, term: str) -> str:
    cleaned=text
    if '-' in term:
        # Compound concepts are represented canonically with hyphens but may appear
        # in source text with spaces or hyphens. Remove the complete phrase first so
        # the prototype is learned from surrounding context rather than from itself.
        parts=[re.escape(x) for x in term.split('-') if x]
        if parts:
            cleaned=re.sub(r'\b'+r'[\s-]+'.join(parts)+r'\b',' ',cleaned,flags=re.I)
    def repl(match):
        token=match.group(0)
        return '' if _normalized_learning_term(token.lower())==term else token
    cleaned=re.sub(r'[A-Za-z][A-Za-z0-9_-]{1,}',repl,cleaned)
    cleaned=re.sub(r'\s+',' ',cleaned).strip()
    return cleaned or text


def update_semantic_prototypes(
    text: str,
    prototypes: Mapping[str,SemanticKnotPrototype],
    *,
    source_id: str,
    trusted: bool=True,
    limit_terms: int | None=None,
    candidate_terms: list[str] | None = None,
) -> tuple[list[SemanticKnotPrototype],list[str],list[str]]:
    """Learn residual vocabulary by DKT context geometry.

    ``candidate_terms`` is an optional channel-specific hygiene gate.  It changes
    only which surface terms are allowed to become semantic prototypes; DKT context
    geometry remains the semantic authority.
    """
    if candidate_terms is None:
        terms=candidate_learning_concepts(text,limit=None)
    else:
        # Channel-specific term lists are audit metadata only; admitted text is
        # learned by the same neutral lexical/compositional mechanism.
        terms=candidate_learning_concepts(text,limit=None)
    updated=[]; created=[]; reinforced=[]
    working=dict(prototypes)
    for term in terms:
        context=_context_without_term(text,term)
        context_map={k:v for k,v in working.items() if k!=term and not v.status.startswith('perception-retired')}
        evt=CognitiveEvent(kind=EventKind.OBSERVATION,source='noeron-semantic-context',content=context,trusted=trusted,metadata={'semantic_learning_probe':True})
        ctx_irg=interaction_geometry(evt,semantic_prototypes=context_map)
        ctx_knot=dkt.experience_knot(ctx_irg)
        old=working.get(term)
        now=datetime.now(timezone.utc)
        role,role_score=concept_structural_role(term,text)
        if old is None:
            # A first observation is already a causally available empirical DKT
            # prototype.  No human-chosen maturity threshold grants it meaning.
            coherence=None
            p=SemanticKnotPrototype(term=term,knot=ctx_knot,observations=1,confidence=0.0,status='observed-once',source_ids=[source_id],first_seen_at=now,last_seen_at=now,concept_kind=role,structural_role_score=0.0,context_coherence=coherence,establishment_score=0.0,geometry_version='learned-semantic-knot-v0.7.3.4')
            created.append(term)
        else:
            dist=dkt.sobolev_distance(old.knot,ctx_knot)
            obs=old.observations+1
            eta=1.0/obs
            mean=((old.mean_context_distance*old.observations)+dist)/obs
            knot=dkt.interpolate(old.knot,ctx_knot,eta)
            coherence=1.0/(1.0+mean)
            # Coherence is an empirical diagnostic only.  Status records recurrence;
            # neither field gates causal access or semantic standing.
            confidence=coherence
            status='observed-recurrent'
            p=old.model_copy(deep=True); p.knot=knot; p.observations=obs; p.mean_context_distance=mean; p.confidence=confidence; p.status=status; p.last_seen_at=now; p.geometry_version='learned-semantic-knot-v0.7.3.4'; p.concept_kind=role; p.structural_role_score=0.0; p.context_coherence=coherence; p.establishment_score=0.0
            if source_id not in p.source_ids: p.source_ids=(p.source_ids+[source_id])[-32:]
            reinforced.append(term)
        working[term]=p; updated.append(p)
    return updated,created,reinforced


def source_root_knot(knots: list[KnotState], *, s: float=2.0, modes: int=8):
    """Finite H^s-chart Fréchet mean used as a document/source root knot."""
    if not knots:
        return dkt.reference_knot(s=s,modes=modes)
    return dkt.chart_mean(knots)


def lineage_semantic_knot(lineage_anchor: KnotState, experience_knot: KnotState) -> KnotState:
    """Return the observed experience geometry; lineage is provenance only.

    Earlier releases bent semantic geometry toward a canonical source anchor by a
    fixed 20% weight.  That authored source prior is causally disabled in v0.7.3.4.
    The argument is retained for migration/API compatibility only.
    """
    _ = lineage_anchor
    return experience_knot.model_copy(deep=True)


def segment_is_structural(text: str) -> bool:
    first=text.split('\n',1)[0]
    return bool(_HEADING.match(first) or _STRUCTURAL.search(text) or first.startswith('['))


# ---------------------------------------------------------------------------
# v0.6.3 stratified knot learning
# ---------------------------------------------------------------------------

def _all_coefficients(k: KnotState):
    for axis,v in enumerate(k.c0):
        yield 0,0,axis,float(v)
    for n in range(1,k.mode_radius+1):
        c=k.cosine[n] if n < len(k.cosine) else [0.0,0.0,0.0]
        s=k.sine[n] if n < len(k.sine) else [0.0,0.0,0.0]
        for axis,v in enumerate(c): yield 1,n,axis,float(v)
        for axis,v in enumerate(s): yield 2,n,axis,float(v)


def encode_sparse_deformation(anchor: KnotState, target: KnotState, *, tolerance_hs: float=0.004, quantization: float=1e-6) -> SparseKnotDeformation:
    """Compress a nearby knot as a sparse deformation from ``anchor``.

    Coefficients are ranked by their H^s contribution and retained until the omitted
    tail has H^s norm at most ``tolerance_hs``.  Quantization is then audited by
    reconstructing the knot and recording its actual H^s error.
    """
    modes=max(anchor.mode_radius,target.mode_radius)
    ac,ass=dkt._pad(anchor,modes); tc,tss=dkt._pad(target,modes)
    candidates=[]
    for axis in range(3):
        delta=target.c0[axis]-anchor.c0[axis]
        candidates.append((delta*delta,0,0,axis,delta))
    sorder=max(anchor.sobolev_order,target.sobolev_order)
    for n in range(1,modes+1):
        w=(1+n*n)**sorder
        for axis in range(3):
            dc=tc[n][axis]-ac[n][axis]; ds=tss[n][axis]-ass[n][axis]
            candidates.append((w*dc*dc,1,n,axis,dc)); candidates.append((w*ds*ds,2,n,axis,ds))
    # Omit smallest contributions while omitted H^s norm stays under tolerance.
    candidates.sort(key=lambda x:x[0])
    omitted_sq=0.0; retained=[]
    tol_sq=max(0.0,tolerance_hs)**2
    for contrib,kind,n,axis,delta in candidates:
        if omitted_sq+contrib<=tol_sq:
            omitted_sq+=contrib; continue
        q=round(delta/quantization)*quantization if quantization>0 else delta
        if abs(q)>0.0: retained.append((kind,n,axis,float(q)))
    deformation=SparseKnotDeformation(deltas=retained,retained_coefficients=len(retained),original_coefficients=len(candidates),quantization=quantization)
    reconstructed=decode_sparse_deformation(anchor,deformation)
    deformation.reconstruction_error_hs=dkt.sobolev_distance(reconstructed,target)
    return deformation


def decode_sparse_deformation(anchor: KnotState, deformation: SparseKnotDeformation) -> KnotState:
    out=anchor.model_copy(deep=True)
    modes=out.mode_radius
    out.cosine,out.sine=dkt._pad(out,modes)
    for kind,n,axis,value in deformation.deltas:
        if kind==0: out.c0[axis]+=value
        elif kind==1 and n<=modes: out.cosine[n][axis]+=value
        elif kind==2 and n<=modes: out.sine[n][axis]+=value
    out.invariant_signature=dkt.invariant_signature(out)
    return out


def estimated_knot_json_bytes(k: KnotState) -> int:
    return len(json.dumps(k.model_dump(mode='json'),separators=(',',':')).encode())


def estimated_deformation_json_bytes(d: SparseKnotDeformation) -> int:
    return len(json.dumps(d.model_dump(mode='json'),separators=(',',':')).encode())


def isotopy_radius_proxy(anchor: KnotState) -> tuple[float,float]:
    """Return sampled regularity margin and the derived finite H^s radius.

    The radius is ``m/C_{s,N}`` from the truncated Fourier derivative bound.  It is
    still a finite sampled computational sufficient bound, not a global isotopy
    theorem, but it no longer contains an authored semantic admission formula.
    """
    margin,_constant,radius=dkt.finite_hs_immersion_radius(anchor)
    return max(0.0,float(margin)),max(0.0,float(radius))


