from __future__ import annotations

"""Native DKT workspace + auditable finite inference for Noeron v0.7.3.4.

Two roles are deliberately separated:
1. DKT H^s geometry chooses/weights the persistent memory support actually available
   to cognition.
2. A small transparent proposition calculus constructs conclusions from premises.

The calculus programs logical operators, not answer content.  It never contains a
branch such as ``if reasoning_mode == X: emit sentence Y``.
"""

import math
from collections import defaultdict
from statistics import median
from typing import Iterable, Sequence

from noeron.cognition.models import KnotMemory
from noeron.inference import infer, learned_to_logic
from noeron.math import dkt
from noeron.math.linalg import numerically_tied
from noeron.math.models import (
    KnotState, MultiMemoryReasoningMathState, LogicalProposition, LogicalQuery,
)


def _soft_weights(distances: list[float]) -> list[float]:
    """Distance-only Gibbs weights with a scale estimated from this support set.

    No fixed learned/episodic split or content-class preference participates.
    """
    if not distances:
        return []
    if len(distances) == 1:
        return [1.0]
    d0 = min(distances)
    offsets = sorted(d - d0 for d in distances if d - d0 > 1e-12)
    if not offsets:
        return [1.0 / len(distances)] * len(distances)
    scale = median(offsets)
    if scale <= 1e-12:
        scale = max(offsets)
    raw = [math.exp(-(d - d0) / max(scale, 1e-12)) for d in distances]
    z = sum(raw) or 1.0
    return [x / z for x in raw]


def _weighted_coordinates(items: list[tuple[float, KnotMemory]], weights: list[float], n: int = 8) -> list[float]:
    if not items:
        return [0.0] * n
    out = [0.0] * n
    for w, (_d, m) in zip(weights, items):
        c = (m.logical_coordinates + [0.0] * n)[:n]
        for i, x in enumerate(c):
            out[i] += w * x
    return out


def _weighted_knot(items: list[tuple[float, KnotMemory]], weights: list[float]) -> KnotState | None:
    """Order-independent weighted mean in the finite DKT coefficient chart."""
    return dkt.chart_mean([m.knot for _d,m in items],weights) if items else None


def _pairwise_dispersion(items: list[tuple[float, KnotMemory]], weights: list[float]) -> float:
    if len(items) < 2:
        return 0.0
    total = 0.0; z = 0.0
    for i in range(len(items)):
        for j in range(i + 1, len(items)):
            wij = weights[i] * weights[j]
            total += wij * dkt.sobolev_distance(items[i][1].knot, items[j][1].knot)
            z += wij
    return total / max(z, 1e-12)


def _cluster_key(m: KnotMemory) -> str:
    if m.semantic_stratum_id:
        return f'stratum:{m.semantic_stratum_id}'
    return f'episodic:{m.memory_class}'


def _equal_mean_knot(knots: list[KnotState]) -> KnotState | None:
    """Order-independent equal-mass mean in the finite DKT coefficient chart."""
    return dkt.chart_mean(knots)


def _native_open_questions(
    propositions: list[LogicalProposition],
    retrieved: list[tuple[float,KnotMemory]],
    *,
    post_closure_knot: KnotState | None,
    active_region_ids: set[str] | None,
) -> tuple[list[LogicalQuery],dict[str,float],str]:
    """Generate unresolved relation questions from persistent proposition paths.

    Candidate *content* comes from existing proposition endpoints.  The substrate
    supplies only the generic operation "a path exists but its endpoint relation is
    unresolved".  Persistent supports are compared with the post-RL/Frenet DKT core;
    exact minima remain jointly active rather than being broken by lexical order.
    """
    if post_closure_knot is None:
        return [],{},'no-post-closure-dkt-state'
    memories={str(m.id):m for _,m in retrieved}
    known={(p.subject,p.object) for p in propositions if p.polarity}
    candidates: dict[tuple[str,str],set[str]]={}
    for a in propositions:
        if not a.polarity:
            continue
        for b in propositions:
            if not b.polarity or a.object!=b.subject or a.subject==b.object:
                continue
            if (a.subject,b.object) in known:
                continue
            mids={x for x in (a.source_memory_id,b.source_memory_id) if x}
            if not mids or any(mid not in memories for mid in mids):
                continue
            if active_region_ids is not None:
                regions={_cluster_key(memories[mid]) for mid in mids}
                if not regions.issubset(active_region_ids):
                    continue
            candidates.setdefault((a.subject,b.object),set()).update(mids)
    if not candidates:
        return [],{},'no-unresolved-persistent-proposition-path'
    distances={}
    queries={}
    for (subject,obj),mids in candidates.items():
        support=_equal_mean_knot([memories[mid].knot for mid in mids])
        if support is None:
            continue
        key=f'{subject}::{obj}'
        distances[key]=float(dkt.sobolev_distance(post_closure_knot,support))
        queries[key]=LogicalQuery(kind='relation-between',subject=subject,object=obj,raw='')
    if not distances:
        return [],{},'no-geometric-support-for-open-question'
    best=min(distances.values())
    winners=[key for key,value in distances.items() if numerically_tied(value,best)]
    selected=[queries[key] for key in winners]
    status=('unique-post-closure-hs-minimum' if len(selected)==1 else 'distributed-exact-post-closure-hs-tie')
    return selected,distances,status


def _learned_premises_for_retrieved(rows: Sequence[object], retrieved: list[tuple[float, KnotMemory]]) -> list[LogicalProposition]:
    """Expose persistent language propositions only through DKT-selected provenance.

    Stage 6 preserves every distinct source-memory ID for a repeated proposition.
    Retrieval authority therefore intersects the complete provenance set instead of
    consulting only the newest serialized pointer.  A pending newer observation
    cannot shadow an older source that is genuinely active in DKT geometry.
    """
    retrieved_ids = {str(m.id) for _, m in retrieved}
    out: list[LogicalProposition] = []
    for row in rows or []:
        ids={str(x) for x in (getattr(row,'source_memory_ids',[]) or []) if x}
        mid=getattr(row,'source_memory_id',None)
        if mid is not None: ids.add(str(mid))
        matched=sorted(ids.intersection(retrieved_ids))
        if not matched:
            continue
        converted=learned_to_logic([row])
        if not converted:
            continue
        p=converted[0]
        p.source_memory_ids=matched
        p.source_memory_id=matched[0]
        # A merged language row may have observations from both active and pending
        # provenance. Only parser support attached to the actually DKT-retrieved
        # source IDs may affect this cognitive premise. Pending repetitions cannot
        # boost or suppress an authorized source merely by sharing the serialized row.
        by_source=getattr(row,'source_confidences',{}) or {}
        authorized=[float(by_source[mid]) for mid in matched if mid in by_source]
        if authorized:
            p.confidence=max(authorized)
        out.append(p)
    return out


def build_multi_memory_reasoning(
    query_knot: KnotState,
    retrieved: Iterable[tuple[float, KnotMemory]],
    *,
    logical_propositions: Sequence[LogicalProposition] | None = None,
    logical_query: LogicalQuery | None = None,
    learned_language_propositions: Sequence[object] | None = None,
    post_closure_knot: KnotState | None = None,
    active_region_ids: Sequence[str] | None = None,
) -> MultiMemoryReasoningMathState:
    """Construct the geometric workspace and runtime proof closure.

    A conclusion is a derived proposition with an explicit proof path.  If several
    answers are supported, all are retained; the substrate does not invent a hidden
    ranking just to produce one sentence.
    """
    items = list(retrieved)
    distances = [float(d) for d, _ in items]
    global_weights = _soft_weights(distances)

    grouped: dict[str, list[int]] = defaultdict(list)
    for i, (_d, m) in enumerate(items):
        grouped[_cluster_key(m)].append(i)
    mass = {k: sum(global_weights[i] for i in idxs) for k, idxs in grouped.items()}
    max_mass=max(mass.values()) if mass else 0.0
    dominant_keys=[k for k,v in mass.items() if numerically_tied(v,max_mass)]
    lower=sorted({v for v in mass.values() if v < max_mass and not numerically_tied(v,max_mass)},reverse=True)
    alternative_keys=[k for k,v in mass.items() if lower and numerically_tied(v,lower[0])]
    dominant_key=(dominant_keys[0] if len(dominant_keys)==1 else ('distributed-tie:'+'|'.join(sorted(dominant_keys)) if dominant_keys else ''))
    alternative_key=(alternative_keys[0] if len(alternative_keys)==1 else ('distributed-tie:'+'|'.join(sorted(alternative_keys)) if alternative_keys else ''))

    def bundle(keys):
        if isinstance(keys,str):
            keys=[keys]
        idxs=[]
        for key in keys:
            idxs.extend(grouped.get(key,[]))
        subset = [items[i] for i in idxs]
        raw = [global_weights[i] for i in idxs]
        z = sum(raw) or 1.0
        return subset, [x / z for x in raw]

    dominant, dw = bundle(dominant_keys) if dominant_keys else ([], [])
    alternative, aw = bundle(alternative_keys) if alternative_keys else ([], [])
    dominant_knot = _weighted_knot(dominant, dw)
    alternative_knot = _weighted_knot(alternative, aw)
    logical_target = _weighted_coordinates(dominant, dw) if dominant else [0.0] * 8
    dispersion = _pairwise_dispersion(dominant, dw) if dominant else 0.0
    agreement = 1.0 / (1.0 + dispersion)

    learned = [m for _, m in items if m.semantic_stratum_id is not None]
    stratum_ids: list[str] = []; component_ids: list[str] = []; frontier_hits = 0
    for _, m in items:
        if m.semantic_stratum_id and str(m.semantic_stratum_id) not in stratum_ids:
            stratum_ids.append(str(m.semantic_stratum_id))
        if m.isotopy_component_id and str(m.isotopy_component_id) not in component_ids:
            component_ids.append(str(m.isotopy_component_id))
    stratum_set = set(stratum_ids)
    for _, m in items:
        if m.semantic_frontier_neighbor_ids:
            frontier_hits += sum(1 for x in m.semantic_frontier_neighbor_ids if str(x) in stratum_set)
    frontier_hits //= 2 if frontier_hits else 1

    same_component = len(component_ids) == 1 and len(learned) >= 2
    same_semantic = len(stratum_ids) == 1 and len(learned) >= 2
    if not items:
        mode = 'no-memory'
    elif len(items) == 1:
        mode = 'single-memory'
    elif same_component:
        mode = 'local-component-synthesis'
    elif same_semantic:
        mode = 'intrastratum-multi-component'
    elif len(stratum_ids) >= 2:
        mode = 'cross-stratum-contrast'
    else:
        mode = 'mixed-episodic-synthesis'

    bridge_distance = 0.0
    if dominant_knot is not None and alternative_knot is not None:
        bridge_distance = dkt.sobolev_distance(dominant_knot, alternative_knot)

    # Structural support confidence is derived from geometry only: nearest-support
    # proximity and within-dominant-bundle agreement.  No manually weighted feature
    # sum or learned-vs-episodic quota exists.
    proximity = 0.0 if not distances else 1.0 / (1.0 + min(distances))
    confidence = math.sqrt(max(0.0, min(1.0, proximity * agreement))) if items else 0.0

    current_premises = [p.model_copy(deep=True) for p in (logical_propositions or [])]
    learned_premises = _learned_premises_for_retrieved(learned_language_propositions or [], items)
    premise_map = {p.canonical(): p for p in (current_premises + learned_premises)}
    premises = list(premise_map.values())
    query = (logical_query or LogicalQuery()).model_copy(deep=True)
    derived, inference_steps, answers, selection_status = infer(premises, query)
    open_questions,question_distances,question_status=_native_open_questions(
        premises+derived,items,post_closure_knot=post_closure_knot,
        active_region_ids=(set(active_region_ids) if active_region_ids is not None else None),
    )

    # Proof confidence is constrained by its weakest premise; geometric confidence
    # remains a separate audit quantity rather than being mixed with arbitrary weights.
    if answers:
        proof_conf = min(p.confidence for p in answers)
        confidence = proof_conf if not items else math.sqrt(max(0.0, min(1.0, proof_conf * confidence)))

    return MultiMemoryReasoningMathState(
        active=(len(items) >= 2 or bool(inference_steps) or bool(answers)),
        memory_ids=[str(m.id) for _, m in items], distances=distances, weights=global_weights,
        learned_memory_count=len(learned), semantic_stratum_ids=stratum_ids,
        isotopy_component_ids=component_ids, dominant_bundle_key=dominant_key,
        alternative_bundle_key=alternative_key,
        dominant_support_concentration=(sum(mass.get(k,0.0) for k in dominant_keys) if dominant_keys else 0.0),
        within_bundle_hs_dispersion=dispersion, structural_agreement=agreement,
        reasoning_mode=mode, logical_target=logical_target, workspace_knot=dominant_knot,
        contrast_knot=alternative_knot, bridge_distance_hs=bridge_distance,
        frontier_candidate_links=frontier_hits, confidence=confidence,
        premise_propositions=premises, derived_propositions=derived,
        inference_steps=inference_steps, logical_query=query, answer_candidates=answers,
        answer_selection_status=selection_status,
        native_question_candidates=open_questions,native_question_distances=question_distances,
        native_question_selection_status=question_status,
        native_inference_active=bool(inference_steps or answers),
        note='v0.7.5 language interface over preserved DKT H^s cognition: persistent proposition support is provenance-intersected with DKT retrieval; finite grammar/logical operators are programmed substrate; derived content is constructed live from auditable premises and proof steps.',
    )
