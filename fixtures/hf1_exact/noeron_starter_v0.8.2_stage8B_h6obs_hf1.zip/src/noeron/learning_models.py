from __future__ import annotations

from datetime import datetime, timezone
from uuid import UUID, uuid4
from pydantic import BaseModel, Field

from noeron.math.models import KnotState


class SemanticKnotPrototype(BaseModel):
    """A learned lexical meaning represented by a DKT knot, not an embedding vector."""
    term: str
    knot: KnotState
    observations: int = 1
    mean_context_distance: float = 0.0
    confidence: float = 0.0
    status: str = 'observed-once'
    source_ids: list[str] = Field(default_factory=list)
    concept_kind: str = 'lexical-content'
    structural_role_score: float = 0.0
    context_coherence: float | None = None
    establishment_score: float = 0.0
    first_seen_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    last_seen_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    geometry_version: str = 'learned-semantic-knot-v0.6.9'
    missed_learning_sessions: int = 0
    last_observed_session_id: str = ''


class LearningSourceRecord(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    title: str
    source_name: str = ''
    source_type: str = 'document'
    mode: str = 'selective'
    total_segments: int = 0
    studied_segments: int = 0
    selected_segment_start: int = 0
    selected_segment_end: int = 0
    event_ids: list[UUID] = Field(default_factory=list)
    memory_ids: list[UUID] = Field(default_factory=list)
    root_memory_id: UUID | None = None
    new_terms: list[str] = Field(default_factory=list)
    reinforced_terms: list[str] = Field(default_factory=list)
    unresolved_terms: list[str] = Field(default_factory=list)
    status: str = 'studied'
    canonical_source_id: str = ''
    canonical_source_name: str = ''
    source_version_sha256: str = ''
    source_version_id: str = ''
    session_index: int = 1
    normalized_for_study: bool = False
    filtered_scaffolding_count: int = 0
    semantic_strata_used: list[UUID] = Field(default_factory=list)
    isotopy_components_used: list[UUID] = Field(default_factory=list)


class LearningPreview(BaseModel):
    title: str
    total_segments: int
    selected_segments: int
    start_segment: int
    end_segment: int
    segment_previews: list[str] = Field(default_factory=list)
    candidate_residual_terms: list[str] = Field(default_factory=list)
    normalized_for_study: bool = False
    filtered_scaffolding_count: int = 0
    normalization_notes: list[str] = Field(default_factory=list)
    note: str = 'Preview is read-only; no DKT state, memory, semantic stratum, or semantic prototype is changed.'


class LearningReport(BaseModel):
    source: LearningSourceRecord
    consolidated_segment_memories: int = 0
    archived_segment_observations: int = 0
    semantic_prototypes_created: int = 0
    semantic_prototypes_reinforced: int = 0
    semantic_prototypes_established: int = 0
    semantic_strata_created: int = 0
    isotopy_components_created: int = 0
    compressed_segment_memories: int = 0
    estimated_raw_knot_bytes: int = 0
    stored_deformation_bytes: int = 0
    structural_anchor_bytes: int = 0
    estimated_total_geometry_bytes: int = 0
    geometry_storage_ratio: float = 0.0
    llm_used: bool = False
    causal_learning_path: list[str] = Field(default_factory=list)


class LearningRecallHit(BaseModel):
    memory_id: UUID
    distance: float
    excerpt: str
    memory_class: str
    source_title: str = ''
    segment_index: int | None = None
    geometry_version: str = ''
    semantic_stratum_id: UUID | None = None
    isotopy_component_id: UUID | None = None


class LearningRevisionReport(BaseModel):
    old_memory_id: UUID
    new_memory_id: UUID
    reason: str = ''
    history_preserved: bool = True
    old_memory_archived: bool = True
    llm_used: bool = False


class SparseKnotDeformation(BaseModel):
    """Sparse finite-H^s deformation relative to a component anchor.

    Each entry is (kind, mode, axis, value), with kind 0=c0, 1=cosine, 2=sine.
    This is a computational Noeron compression, not a theorem identifying nearby
    knots globally.  ``reconstruction_error_hs`` audits approximation quality.
    """
    deltas: list[tuple[int,int,int,float]] = Field(default_factory=list)
    reconstruction_error_hs: float = 0.0
    retained_coefficients: int = 0
    original_coefficients: int = 0
    quantization: float = 1e-6


class NoeronSemanticStratumRecord(BaseModel):
    """Learned semantic stratum, distinct from manuscript DKT singularity strata."""
    id: UUID = Field(default_factory=uuid4)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    anchor_knot: KnotState
    dkt_stratum_index: int = 0
    member_count: int = 0
    radius_hs: float = 0.0
    # Non-authoritative default. Live/migrated records receive a derived finite-H^s radius.
    admission_radius_hs: float = 0.0
    component_ids: list[UUID] = Field(default_factory=list)
    frontier_neighbors: list[UUID] = Field(default_factory=list)
    source_titles: list[str] = Field(default_factory=list)
    canonical_source_ids: list[str] = Field(default_factory=list)
    status: str = 'active'
    superseded_by_id: UUID | None = None
    retirement_reason: str = ''
    geometry_version: str = 'derived-finite-hs-semantic-neighborhood-v0.7.3.4'


class IsotopyComponentRecord(BaseModel):
    """Tight local component inside a learned semantic stratum.

    ``isotopy_safe_radius_hs`` is the finite H^s immersion-preservation radius
    derived from the anchor knot's sampled regularity margin and Fourier chart.
    It is explicitly not a proof of global isotopy.
    """
    id: UUID = Field(default_factory=uuid4)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    semantic_stratum_id: UUID
    anchor_knot: KnotState
    dkt_stratum_index: int = 0
    member_count: int = 0
    radius_hs: float = 0.0
    # Non-authoritative default. Live/migrated records receive the derived radius.
    isotopy_safe_radius_hs: float = 0.0
    sampled_regularity_margin: float = 0.0
    member_memory_ids: list[UUID] = Field(default_factory=list)
    status: str = 'active'
    superseded_by_id: UUID | None = None
    retirement_reason: str = ''
    geometry_version: str = 'derived-finite-hs-local-component-v0.7.3.4'


class StratifiedLearningMemory(BaseModel):
    """Durable learned memory stored as deformation from an isotopy-component anchor."""
    id: UUID = Field(default_factory=uuid4)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    source_event_id: UUID
    semantic_stratum_id: UUID
    isotopy_component_id: UUID
    deformation: SparseKnotDeformation
    logical_coordinates: list[float] = Field(default_factory=list)
    logical_entropy: float = 0.0
    egr_entropy_current: float = 0.0
    parent_memory_id: UUID | None = None
    branch_depth: int = 0
    provenance_excerpt: str = ''
    geometry_version: str = 'stratified-deformation-memory-v0.6.9'
    consolidated: bool = True
    memory_class: str = 'learned-stratified-segment'
    consolidation_score: float = 1.0
    consolidation_reasons: list[str] = Field(default_factory=list)
    learning_source_id: UUID | None = None
    source_title: str = ''
    canonical_source_id: str = ''
    source_segment_index: int | None = None
    revision_of_memory_id: UUID | None = None
    superseded_by_memory_id: UUID | None = None
    estimated_raw_knot_bytes: int = 0
    stored_deformation_bytes: int = 0
    stratification_history: list[dict] = Field(default_factory=list)


class SemanticStratumAssignment(BaseModel):
    semantic_stratum_id: UUID
    isotopy_component_id: UUID
    created_stratum: bool = False
    created_component: bool = False
    distance_to_stratum_anchor: float = 0.0
    distance_to_component_anchor: float = 0.0
    transition_kind: str = 'local-component'


class LearningTraversalReport(BaseModel):
    from_memory_id: UUID
    to_memory_id: UUID
    same_semantic_stratum: bool
    same_isotopy_component: bool
    transport_mode: str
    dkt_distance: float
    path_distances: list[float] = Field(default_factory=list)
    transported_logical_coordinates: list[list[float]] = Field(default_factory=list)
    semantic_strata: list[UUID] = Field(default_factory=list)
    isotopy_components: list[UUID] = Field(default_factory=list)
    note: str = 'Read-only Noeron transport probe; no memory or state is changed.'


class ReasoningConceptRecord(BaseModel):
    """Persistent higher-order concept formed from recurring multi-memory workspaces.

    Identity is geometric/stratified.  ``descriptor_terms`` are audit labels selected
    from observed semantic prototypes and do not determine the geometry.
    """
    id: UUID = Field(default_factory=uuid4)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    anchor_knot: KnotState
    contrast_knot: KnotState | None = None
    observations: int = 1
    confidence: float = 0.0
    status: str = 'observed-once'
    reasoning_mode: str = ''
    semantic_stratum_ids: list[UUID] = Field(default_factory=list)
    isotopy_component_ids: list[UUID] = Field(default_factory=list)
    support_memory_ids: list[UUID] = Field(default_factory=list)
    descriptor_terms: list[str] = Field(default_factory=list)
    bridge_distance_hs: float = 0.0
    mean_workspace_distance: float = 0.0
    source_titles: list[str] = Field(default_factory=list)
    geometry_version: str = 'multi-memory-reasoning-concept-v0.6.9'
    stratification_epoch: int = 0


class LearningRateReport(BaseModel):
    """Transparent multi-axis Noeron learning-rate measurement.

    This is an engineering/research diagnostic, not a biological learning rate or
    intelligence score.  Rates distinguish processing throughput from structural
    assimilation so faster CPU execution cannot masquerade as better learning.
    """
    sources: int = 0
    canonical_sources: int = 0
    studied_segments: int = 0
    learning_elapsed_seconds: float = 0.0
    processing_segments_per_second: float = 0.0
    semantic_prototypes: int = 0
    established_prototypes: int = 0
    prototype_establishment_fraction: float = 0.0
    established_prototypes_per_segment: float = 0.0
    semantic_strata: int = 0
    isotopy_components: int = 0
    compressed_segment_memories: int = 0
    stratum_reuse_fraction: float = 0.0
    component_reuse_fraction: float = 0.0
    mean_members_per_stratum: float = 0.0
    mean_members_per_component: float = 0.0
    weighted_within_stratum_radius_hs: float = 0.0
    min_between_stratum_separation_hs: float = 0.0
    mean_between_stratum_separation_hs: float = 0.0
    semantic_partition_separation_ratio: float = 0.0
    geometry_storage_ratio: float = 0.0
    geometry_storage_gain_fraction: float = 0.0
    mean_prototype_coherence: float = 0.0
    eligible_prototype_coherence: float = 0.0
    coherence_eligible_prototypes: int = 0
    mean_establishment_score: float = 0.0
    learning_rate_vector: dict[str,float] = Field(default_factory=dict)
    per_source: list[dict] = Field(default_factory=list)
    per_lineage: list[dict] = Field(default_factory=list)
    note: str = 'Multi-axis Noeron diagnostic: throughput is not semantic competence; compare the vector across controlled study batches.'
