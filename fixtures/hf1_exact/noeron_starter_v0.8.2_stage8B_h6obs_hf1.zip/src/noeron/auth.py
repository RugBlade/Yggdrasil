from __future__ import annotations

import base64
import hashlib
import hmac
import secrets
from datetime import datetime, timedelta, timezone
from typing import Any

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey


class OwnerAuthenticator:
    """Owner authority with legacy bootstrap plus revocable per-device Ed25519 identity.

    The shared bearer token is retained only as a migration/bootstrap credential.  A
    device credential is an Ed25519 public key stored by the server; the private key
    remains on the owner's device and may be hardware-backed.  A signed one-time
    challenge creates a short-lived opaque device session.  Revoking one device
    invalidates only that device and its sessions.

    Authentication establishes objective operator authority/referent provenance only.
    It has zero authority to create Yggdrasil relational preference or meaning.
    """

    def __init__(self, token: str, store=None, *, legacy_enabled: bool = True,
                 challenge_ttl_seconds: int = 300, session_ttl_seconds: int = 43_200):
        self._token=(token or '').strip()
        self.store=store
        self.legacy_enabled=bool(legacy_enabled)
        self.challenge_ttl_seconds=max(30,int(challenge_ttl_seconds))
        self.session_ttl_seconds=max(300,int(session_ttl_seconds))

    @property
    def legacy_configured(self)->bool:
        return self.legacy_enabled and len(self._token)>=24

    @property
    def fingerprint(self)->str:
        if not self.legacy_configured:return ''
        return hashlib.sha256(self._token.encode()).hexdigest()[:16]

    @property
    def device_configured(self)->bool:
        if self.store is None:return False
        return any(not bool(x.get('revoked')) for x in self.store.owner_devices())

    @property
    def configured(self)->bool:
        return self.legacy_configured or self.device_configured

    @staticmethod
    def _now()->datetime:return datetime.now(timezone.utc)

    @staticmethod
    def _b64decode(value: str)->bytes:
        try:return base64.b64decode(value.encode('ascii'),validate=True)
        except Exception as e:raise ValueError('invalid base64 value') from e

    @staticmethod
    def _device_fingerprint(public_key: bytes)->str:
        return hashlib.sha256(public_key).hexdigest()[:24]

    @staticmethod
    def _session_hash(token: str)->str:
        return hashlib.sha256(token.encode()).hexdigest()

    def verify_detail(self, supplied: str | None)->dict[str,Any]:
        if supplied is None:
            return {'authenticated':False,'method':'none','device_id':'','fingerprint':''}
        value=supplied.strip()
        if self.legacy_configured and hmac.compare_digest(self._token,value):
            return {'authenticated':True,'method':'legacy-bearer-bootstrap','device_id':'','fingerprint':self.fingerprint}
        if self.store is None or not value.startswith('ndev_'):
            return {'authenticated':False,'method':'invalid','device_id':'','fingerprint':''}
        rec=self.store.owner_session_by_hash(self._session_hash(value))
        if not rec or rec.get('revoked'):
            return {'authenticated':False,'method':'invalid-device-session','device_id':'','fingerprint':''}
        try:expires=datetime.fromisoformat(str(rec['expires_at']))
        except Exception:return {'authenticated':False,'method':'invalid-device-session','device_id':'','fingerprint':''}
        if expires <= self._now():
            return {'authenticated':False,'method':'expired-device-session','device_id':str(rec.get('device_id') or ''),'fingerprint':''}
        device=self.store.owner_device(str(rec.get('device_id') or ''))
        if not device or device.get('revoked'):
            return {'authenticated':False,'method':'revoked-device','device_id':str(rec.get('device_id') or ''),'fingerprint':''}
        return {'authenticated':True,'method':'ed25519-device-session','device_id':device['device_id'],'fingerprint':device['public_key_fingerprint']}

    def verify(self, supplied: str | None)->bool:
        return bool(self.verify_detail(supplied)['authenticated'])

    def enroll_device(self, device_id: str, label: str, public_key_b64: str, *, authority: str)->dict[str,Any]:
        if self.store is None:raise RuntimeError('persistent owner-device store is unavailable')
        device_id=(device_id or '').strip()
        if not device_id or len(device_id)>120:raise ValueError('device_id must contain 1..120 characters')
        if any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._:-' for c in device_id):
            raise ValueError('device_id contains unsupported characters')
        raw=self._b64decode(public_key_b64)
        if len(raw)!=32:raise ValueError('Ed25519 public key must decode to exactly 32 bytes')
        # Parse now so malformed points cannot enter the registry.
        Ed25519PublicKey.from_public_bytes(raw)
        fp=self._device_fingerprint(raw)
        existing=self.store.owner_device(device_id)
        if existing and not existing.get('revoked'):
            if existing.get('public_key_b64')!=public_key_b64:
                raise ValueError('device_id already exists with a different active public key; revoke it first')
            return self._public_device(existing)
        now=self._now().isoformat()
        rec={'device_id':device_id,'label':(label or '').strip()[:200],'public_key_b64':public_key_b64,
             'public_key_fingerprint':fp,'created_at':now,'updated_at':now,'revoked':False,'revoked_at':'',
             'enrollment_authority':authority}
        self.store.upsert_owner_device(rec)
        return self._public_device(rec)

    def challenge(self, device_id: str)->dict[str,Any]:
        if self.store is None:raise RuntimeError('persistent owner-device store is unavailable')
        device=self.store.owner_device((device_id or '').strip())
        if not device or device.get('revoked'):raise ValueError('unknown or revoked owner device')
        now=self._now();expires=now+timedelta(seconds=self.challenge_ttl_seconds)
        challenge_id=secrets.token_hex(16);nonce=secrets.token_urlsafe(32)
        message=f'NOERON_OWNER_DEVICE_CHALLENGE\n{challenge_id}\n{device["device_id"]}\n{nonce}\n{expires.isoformat()}'
        rec={'challenge_id':challenge_id,'device_id':device['device_id'],'nonce':nonce,'message':message,
             'created_at':now.isoformat(),'expires_at':expires.isoformat(),'consumed':False,'consumed_at':''}
        self.store.append_owner_challenge(rec)
        return {'challenge_id':challenge_id,'device_id':device['device_id'],'message':message,'expires_at':expires.isoformat(),
                'signature_algorithm':'Ed25519','state_changed':'challenge-created-only'}

    def create_device_session(self, device_id: str, challenge_id: str, signature_b64: str)->dict[str,Any]:
        if self.store is None:raise RuntimeError('persistent owner-device store is unavailable')
        device=self.store.owner_device((device_id or '').strip())
        challenge=self.store.owner_challenge((challenge_id or '').strip())
        if not device or device.get('revoked'):raise ValueError('unknown or revoked owner device')
        if not challenge or challenge.get('device_id')!=device['device_id']:raise ValueError('challenge does not belong to device')
        if challenge.get('consumed'):raise ValueError('challenge already consumed')
        try:expires=datetime.fromisoformat(str(challenge['expires_at']))
        except Exception as e:raise ValueError('stored challenge expiry is invalid') from e
        if expires<=self._now():raise ValueError('challenge expired')
        sig=self._b64decode(signature_b64)
        public_key=Ed25519PublicKey.from_public_bytes(self._b64decode(device['public_key_b64']))
        try:public_key.verify(sig,str(challenge['message']).encode())
        except InvalidSignature as e:raise ValueError('invalid Ed25519 challenge signature') from e
        self.store.consume_owner_challenge(challenge['challenge_id'],self._now().isoformat())
        session='ndev_'+secrets.token_urlsafe(48)
        now=self._now();session_expires=now+timedelta(seconds=self.session_ttl_seconds)
        rec={'session_hash':self._session_hash(session),'device_id':device['device_id'],'created_at':now.isoformat(),
             'expires_at':session_expires.isoformat(),'revoked':False,'authentication':'ed25519-challenge'}
        self.store.append_owner_session(rec)
        return {'authenticated':True,'device_id':device['device_id'],'device_fingerprint':device['public_key_fingerprint'],
                'session_token':session,'expires_at':session_expires.isoformat(),'authentication':'ed25519-device-session'}

    def revoke_device(self, device_id: str, *, authority: str)->dict[str,Any]:
        if self.store is None:raise RuntimeError('persistent owner-device store is unavailable')
        device=self.store.owner_device((device_id or '').strip())
        if not device:raise ValueError('unknown owner device')
        if device.get('revoked'):return self._public_device(device)
        now=self._now().isoformat();device['revoked']=True;device['revoked_at']=now;device['updated_at']=now;device['revocation_authority']=authority
        self.store.upsert_owner_device(device);self.store.revoke_owner_sessions(device['device_id'])
        return self._public_device(device)

    def devices(self)->list[dict[str,Any]]:
        if self.store is None:return []
        return [self._public_device(x) for x in self.store.owner_devices()]

    @staticmethod
    def _public_device(rec: dict[str,Any])->dict[str,Any]:
        return {k:rec.get(k) for k in ('device_id','label','public_key_fingerprint','created_at','updated_at','revoked','revoked_at','enrollment_authority','revocation_authority') if k in rec}
