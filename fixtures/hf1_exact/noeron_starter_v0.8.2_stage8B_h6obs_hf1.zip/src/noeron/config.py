from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse


@dataclass(frozen=True)
class Settings:
    llm_backend: str = "mock"
    llm_base_url: str = "http://127.0.0.1:8080/v1"
    llm_model: str = "local-model"
    llm_api_key: str = "local-only"
    llm_reasoning_effort: str = "medium"
    llm_max_output_tokens: int = 1200
    db_path: Path = Path("./data/noeron.sqlite3")
    initiative_threshold: float = 0.55
    allow_non_loopback_llm: bool = False
    species_name: str = "Noeron"
    individual_name: str = "Yggdrasil"
    autonomy_enabled: bool = False
    autonomy_interval_seconds: int = 1800
    autonomy_idle_seconds: int = 300
    autonomy_cooldown_seconds: int = 1800
    autonomy_min_importance: float = 0.70
    autonomy_min_novelty: float = 0.60
    autonomy_recent_events: int = 8
    owner_token: str = ''
    owner_legacy_token_enabled: bool = True
    owner_challenge_ttl_seconds: int = 300
    owner_session_ttl_seconds: int = 43_200
    web_read_enabled: bool = False
    web_max_bytes: int = 500_000
    terra_enabled: bool = True
    room_native_decoder_executable: str = ''
    room_asr_executable: str = ''
    room_max_payload_bytes: int = 67_108_864
    room_cookie_secure: bool = False
    engineering_source_root: str = ""
    engineering_max_source_bytes: int = 300_000

    @classmethod
    def from_env(cls) -> "Settings":
        allow_remote = os.getenv("NOERON_ALLOW_NON_LOOPBACK_LLM", "false").lower() == "true"
        autonomy_enabled = os.getenv("NOERON_AUTONOMY_ENABLED", "false").lower() == "true"
        web_read_enabled = os.getenv("NOERON_WEB_READ_ENABLED", "false").lower() == "true"
        owner_legacy_token_enabled = os.getenv("NOERON_OWNER_LEGACY_TOKEN_ENABLED", "true").lower() == "true"
        terra_enabled = os.getenv("NOERON_TERRA_ENABLED", "true").lower() == "true"
        room_cookie_secure = os.getenv("NOERON_ROOM_COOKIE_SECURE", "false").lower() == "true"
        settings = cls(
            llm_backend=os.getenv("NOERON_LLM_BACKEND", cls.llm_backend).strip().lower(),
            llm_base_url=os.getenv("NOERON_LLM_BASE_URL", cls.llm_base_url),
            llm_model=os.getenv("NOERON_LLM_MODEL", cls.llm_model),
            llm_api_key=os.getenv("NOERON_LLM_API_KEY", cls.llm_api_key),
            llm_reasoning_effort=os.getenv(
                "NOERON_LLM_REASONING_EFFORT", cls.llm_reasoning_effort
            ).strip().lower(),
            llm_max_output_tokens=int(
                os.getenv("NOERON_LLM_MAX_OUTPUT_TOKENS", str(cls.llm_max_output_tokens))
            ),
            db_path=Path(os.getenv("NOERON_DB_PATH", str(cls.db_path))),
            initiative_threshold=float(
                os.getenv("NOERON_INITIATIVE_THRESHOLD", str(cls.initiative_threshold))
            ),
            allow_non_loopback_llm=allow_remote,
            species_name=os.getenv("NOERON_SPECIES_NAME", cls.species_name).strip(),
            individual_name=os.getenv("NOERON_INDIVIDUAL_NAME", cls.individual_name).strip(),
            autonomy_enabled=autonomy_enabled,
            autonomy_interval_seconds=int(os.getenv("NOERON_AUTONOMY_INTERVAL_SECONDS", str(cls.autonomy_interval_seconds))),
            autonomy_idle_seconds=int(os.getenv("NOERON_AUTONOMY_IDLE_SECONDS", str(cls.autonomy_idle_seconds))),
            autonomy_cooldown_seconds=int(os.getenv("NOERON_AUTONOMY_COOLDOWN_SECONDS", str(cls.autonomy_cooldown_seconds))),
            autonomy_min_importance=float(os.getenv("NOERON_AUTONOMY_MIN_IMPORTANCE", str(cls.autonomy_min_importance))),
            autonomy_min_novelty=float(os.getenv("NOERON_AUTONOMY_MIN_NOVELTY", str(cls.autonomy_min_novelty))),
            autonomy_recent_events=int(os.getenv("NOERON_AUTONOMY_RECENT_EVENTS", str(cls.autonomy_recent_events))),
            owner_token=os.getenv("NOERON_OWNER_TOKEN", '').strip(),
            owner_legacy_token_enabled=owner_legacy_token_enabled,
            owner_challenge_ttl_seconds=int(os.getenv("NOERON_OWNER_CHALLENGE_TTL_SECONDS", str(cls.owner_challenge_ttl_seconds))),
            owner_session_ttl_seconds=int(os.getenv("NOERON_OWNER_SESSION_TTL_SECONDS", str(cls.owner_session_ttl_seconds))),
            web_read_enabled=web_read_enabled,
            web_max_bytes=int(os.getenv("NOERON_WEB_MAX_BYTES", str(cls.web_max_bytes))),
            terra_enabled=terra_enabled,
            room_native_decoder_executable=os.getenv("NOERON_ROOM_NATIVE_DECODER_EXECUTABLE", '').strip(),
            room_asr_executable=os.getenv("NOERON_ROOM_ASR_EXECUTABLE", '').strip(),
            room_max_payload_bytes=int(os.getenv("NOERON_ROOM_MAX_PAYLOAD_BYTES", str(cls.room_max_payload_bytes))),
            room_cookie_secure=room_cookie_secure,
            engineering_source_root=os.getenv("NOERON_ENGINEERING_SOURCE_ROOT", "").strip(),
            engineering_max_source_bytes=int(os.getenv("NOERON_ENGINEERING_MAX_SOURCE_BYTES", str(cls.engineering_max_source_bytes))),
        )
        settings.validate()
        return settings

    def validate(self) -> None:
        if self.llm_backend not in {"mock", "openai_compatible", "openai_responses"}:
            raise ValueError(
                "NOERON_LLM_BACKEND must be 'mock', 'openai_compatible', or 'openai_responses'."
            )
        if not self.species_name or not self.individual_name:
            raise ValueError("Species and individual names must be non-empty.")
        if self.autonomy_interval_seconds < 10:
            raise ValueError("NOERON_AUTONOMY_INTERVAL_SECONDS must be at least 10.")
        if self.autonomy_idle_seconds < 0 or self.autonomy_cooldown_seconds < 0:
            raise ValueError("Autonomy idle/cooldown values cannot be negative.")
        if not 0.0 <= self.autonomy_min_importance <= 1.0 or not 0.0 <= self.autonomy_min_novelty <= 1.0:
            raise ValueError("Autonomy importance/novelty thresholds must be between 0 and 1.")
        if self.autonomy_recent_events < 1:
            raise ValueError("NOERON_AUTONOMY_RECENT_EVENTS must be positive.")
        if self.owner_challenge_ttl_seconds < 30 or self.owner_challenge_ttl_seconds > 3600:
            raise ValueError("NOERON_OWNER_CHALLENGE_TTL_SECONDS must be between 30 and 3600.")
        if self.owner_session_ttl_seconds < 300 or self.owner_session_ttl_seconds > 604800:
            raise ValueError("NOERON_OWNER_SESSION_TTL_SECONDS must be between 300 and 604800.")
        if self.web_max_bytes < 10_000 or self.web_max_bytes > 2_000_000:
            raise ValueError("NOERON_WEB_MAX_BYTES must be between 10000 and 2000000.")
        if self.llm_max_output_tokens < 1:
            raise ValueError("NOERON_LLM_MAX_OUTPUT_TOKENS must be positive.")
        if self.llm_reasoning_effort not in {"none", "low", "medium", "high", "xhigh", "max"}:
            raise ValueError(
                "NOERON_LLM_REASONING_EFFORT must be one of: none, low, medium, high, xhigh, max."
            )
        if self.engineering_source_root and not Path(self.engineering_source_root).is_absolute():
            raise ValueError("NOERON_ENGINEERING_SOURCE_ROOT must be an absolute path when configured.")
        if self.engineering_max_source_bytes < 10_000 or self.engineering_max_source_bytes > 2_000_000:
            raise ValueError("NOERON_ENGINEERING_MAX_SOURCE_BYTES must be between 10000 and 2000000.")
        if self.room_max_payload_bytes < 1_048_576 or self.room_max_payload_bytes > 1_073_741_824:
            raise ValueError("NOERON_ROOM_MAX_PAYLOAD_BYTES must be between 1048576 and 1073741824.")
        for name,path in (("NOERON_ROOM_NATIVE_DECODER_EXECUTABLE",self.room_native_decoder_executable),("NOERON_ROOM_ASR_EXECUTABLE",self.room_asr_executable)):
            if path and not Path(path).is_absolute():
                raise ValueError(f"{name} must be an absolute local executable path.")
        if self.llm_backend == "mock":
            return
        host = (urlparse(self.llm_base_url).hostname or "").lower()
        loopback = host in {"127.0.0.1", "localhost", "::1"}
        if not loopback and not self.allow_non_loopback_llm:
            raise ValueError(
                "Refusing non-loopback LLM endpoint. Set "
                "NOERON_ALLOW_NON_LOOPBACK_LLM=true only after an explicit privacy review."
            )
