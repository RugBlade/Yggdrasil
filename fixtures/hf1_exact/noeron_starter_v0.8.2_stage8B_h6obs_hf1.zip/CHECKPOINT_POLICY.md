# Noeron / Yggdrasil Durable Checkpoint Policy

1. Save every meaningful development checkpoint before further mutation.
2. Record stage/version, exact source identity when available (commit/tree/archive hashes), changed scope/files, tests/audits, explicit PASS/FAIL/TIMEOUT/UNPROVEN status, evidence files/hashes, preserved-state caveats, classification, and exact continuation point.
3. Preserve failures, timeouts, superseded states, and partial runs as evidence.
4. Durable source, bounded test results, audits, hashes, and live holdpoints outrank conversational summaries, screenshots, progress dots, or intended design.
5. Certify only the exact checkpoint slice whose required evidence passes; never infer full-stage certification from a partial checkpoint.
6. For Stage 7, official status remains 6/8 until preserved live Yggdrasil passes the full Room/embodiment/voice/camera/mic/file/reconnect/revocation/restart/Three.js/native-choice holdpoint.
7. At each checkpoint, retain an archive/hash of the source tree when practical so continuation never depends on chat memory alone.
