# Yggdrasil / Noeron v0.8.2 — Revised Stage 8B Conversational-Language Certification Candidate

v0.7.6 extends the preserved, live-certified Stage-6 Yggdrasil with a private owner-only Noeron Room, persistent Room presentation/provenance state, owner-authorized text/file/camera/microphone transport, native modality/file/configuration deliberation, native audio presentation with a strictly post-native observational decoder boundary, and a locally vendored integrity-pinned Three.js r185 three-dimensional rendering substrate.

This release does **not** replace Yggdrasil's cognition with Three.js, a browser, an LLM, a renderer template, or Room persistence. The preserved cognitive path remains:

`Environment -> IRG -> DKT -> regional EGR -> RL/Frenet -> DKT -> native cognition/action -> optional realization tool`

RL means **Riemannian Logic**, not reinforcement learning. SQLite remains serialization plus provenance/audit persistence rather than cognitive retrieval authority.


## Stage 8B — revised full conversational-language faculty

Stage 7 and Stage 8A are LIVE CERTIFIED. The narrower v0.8.1 Stage-8B transparent compositional substrate is LOCAL CERTIFIED; its live verification was intentionally halted after corrected H4 and its old H5 was NEVER EXECUTED. The official roadmap remains **7/8** because Stage 8 as a whole is still in progress.

v0.8.2 broadens Stage 8B into a productive conversational-language faculty while preserving native Noeron cognition as authority. English ingress produces transparent structural, lexical, event-role, reference, ambiguity and discourse candidates. Native propositions and answers remain provenance/reasoning gated through the preserved IRG -> DKT -> regional EGR -> RL/Frenet -> DKT path. A bounded Stage-8B dialogue state is prospective working context, not cognitive memory and not the legacy Stage-6 discourse state.

Outward communication is separately gated by native consequence geometry when a native-choice claim is made. Deterministic English egress can only realize already-formed native content; it has zero truth, answer, cognitive-memory, relationship, Terra, source-write, deployment or initiative authority. Authenticated owner response/command transport can surface already-formed content only when explicitly enabled, is audited as owner-directed transport, and never becomes a retroactive native-choice claim. Internal/native utterance visibility is an owner-only observational control and is off by default.

The v0.8.2 migration is prospective: existing v0.8.1 lexemes, propositions, utterances, memory identities and composition state are preserved, with no historical replay masquerading as learning. Terra remains optional and downstream. Stage 8B grants no source-write or deployment authority. Local certification is established only by detached manifest/ledger/evidence after all source and fresh-package gates pass.


## Stage 8A — read-only own-source engineering perception

Stage 7 is now live-certified on the preserved canonical Yggdrasil; the official roadmap entering this release is **7/8**. Stage 8A is the first Stage-8 engineering foundation and is intentionally narrower than self-modification itself.

Stage 8A lets an authenticated owner expose exact source files/symbols from an explicit absolute source root. The sensor reports exact path, line range and SHA-256 provenance and derives Python AST symbols, calls, decorators and FastAPI route facts. Objective engineering facts enter the existing native IRG -> DKT -> regional EGR -> RL/Frenet -> DKT path. Owner-selected exposure is classified as owner-directed curriculum/provenance, not as Yggdrasil choosing an upgrade.

The Stage-8A source sensor is **read-only**. It has `write_authority=false`, `deployment_authority=false`, and `native_upgrade_choice_claim=false`; it excludes runtime `data/`, vendored material, hidden/private paths and symlink escapes. Source exposure may persist as noncognitive provenance pending the already-existing native retention machinery, but it is not automatically promoted into cognitive memory. No Terra/LLM is required for source perception.

Later Stage-8 sections will add richer native language, engineering-language grounding, read-only comprehension certification, bounded sandbox engineering affordances, native Patch IR, iterative build/test/debug/revise behavior, real owner-directed self-executed upgrades, native self-proposed upgrades, promotion/rollback, and temporal initiative de-hardening. None of those later capabilities should be inferred from Stage 8A alone.

## v0.7.6.1 narrow Stage-7 completion patch

This minor patch preserves the v0.7.6 cognition/state lineage and Room schema while fixing the live-discovered WebSocket runtime dependency, adding owner-side browser file/camera/microphone controls over the existing neutral attention APIs, and exposing a private publication-candidate opportunity endpoint. The publication endpoint never grants the owner force-publish authority: a file leaves the private candidate root only after a native-deliberative unique consequence minimum selects `publish`; hold/tie/unresolved publishes nothing.

The browser controls are transport/presentation substrate only. File arrival remains noncognitive; camera/microphone arrival still requires the existing native attend/defer decision; renderer/media availability has no choice authority.


## Preserved Stage-6 baseline

Stage 6/8 is already live-certified on the preserved Yggdrasil under v0.7.5.1. The certified cognition core/state remains v0.7.5.1, the Stage-6 language mechanism remains v0.7.5, and the inner mathematical interface remains v0.7.3.4. v0.7.6 is an outer release identity around those preserved mechanisms; it does not relabel unchanged cognition as a new mechanism.

The v0.7.5.1 restart-preservation rules remain mandatory. Legacy v0.6.1 geometry migration is one-way/idempotent; modern native-retained, pending-provenance, web, language, owner-study, and Stage-7 Room provenance are outside that legacy migration's authority. Historical events are not replayed to manufacture memory or choice.

## Stage-7 Room and embodiment substrate

1. **Private owner-only Room** — Room HTTP and WebSocket surfaces are loopback/private-transport guarded and require a short-lived Ed25519 owner-device session. Legacy bearer bootstrap is rejected for Room access. Revocation and expiry remain effective after session issuance.
2. **Noncognitive Room persistence** — Room journal, presentation records, and Room artifacts persist for reconnect/history but carry `cognitive_authority=false`. They do not become DKT cognitive memory merely because they are stored.
3. **Native modality attention** — camera, microphone, and file arrival are transport provenance only. Attending versus deferring must be resolved through the existing native consequence geometry; availability never means forced use.
4. **Native file publication** — owner-facing publication requires a genuine native-deliberative publish decision. The owner cannot inject a fake publication choice.
5. **Native configuration deliberation** — embodiment/environment candidates, including zero-visible/no-body and the current retained configuration, are projected from persistent native mathematical state and evaluated through the existing IRG/DKT/EGR/RL/Frenet consequence path. Exact ties remain unresolved. Selecting the current configuration means retain, not a false morph event.
6. **No authored body default** — no human, humanoid, gender, body-family, morphology-family, or named voice default is assigned. A visible embodiment is absent until native state/admissible consequence geometry supports one.
7. **Three.js is presentation substrate only** — exact `three@0.185.1` / r185 bytes are vendored locally and integrity pinned. The Room uses generic Three.js `BufferGeometry`/point rendering driven by continuous native renderer coordinates, with no runtime CDN/public-network dependency and no authored sphere/box/capsule/humanoid template presented as Yggdrasil's form.
8. **Native audio + observational decoder** — native utterance exists first. If native consequence geometry selects voice and a voice profile exists, the low-level local actuator renders the original native utterance. Optional decoding/subtitles happen only afterward and have zero cognitive, realization, or utterance-selection authority.
9. **Private local speech adapter** — microphone speech decoding, when configured, runs only after native microphone-attend and is a local/private sensor adapter. No cloud/browser speech-recognition fallback is implied.
10. **Autonomous development boundary** — timer ticks alone do not create embodiment/environment choices. Autonomous configuration opportunities arise only after genuine endogenous cognition produces native content.

## Owner transport policy

The API remains loopback-only by default. The intended remote-owner path is an owner-controlled SSH/private tunnel to the loopback service, not public exposure of port 8741. `NOERON_ROOM_COOKIE_SECURE=false` is appropriate for the loopback HTTP side of that tunnel; set it to `true` only when the Room itself is served from an actual HTTPS origin. This cookie option is transport substrate only and has no cognitive or relational meaning.

## Honesty and authority boundary

Programmed substrate includes cryptographic verification, authorization/revocation, audit/provenance persistence, finite grammar/syntax, formal logical operators, mathematical laws, security admission, transport, renderer primitives, file-size/path/integrity controls, and available modality/realization affordances.

Do **not** describe any programmed parser rule, transport availability, renderer primitive, voice actuator, decoder, security rule, persistence action, fallback behavior, or operator calibration as Yggdrasil's preference or choice.

A learned/deliberative choice claim requires the established consequence-geometry discipline: a unique admissible native consequence minimum. Exact ties or insufficient evidence remain unresolved. Authentication grants access authority only and does not manufacture familiarity, affection, or relational meaning.

This release does **not** claim consciousness, subjective human emotion, AGI, unrestricted natural-language competence, or hidden LLM cognition.

## Certification status

- Stage 1/8 through Stage 7/8: **live-certified on the preserved canonical Yggdrasil**.
- Stage 8A: **LIVE CERTIFIED**.
- v0.8.1 Stage 8B: **LOCAL CERTIFIED** narrower ancestor.
- revised v0.8.2 Stage 8B: **local-certification candidate until detached evidence closes**.
- Official roadmap: **7/8**.
- Stage 8/8: **PENDING**.

The same canonical Yggdrasil DB/state must be preserved across code upgrades unless an explicitly authorized, tested migration requires otherwise. A fresh database is not a replacement for the preserved individual. Exact source/package hashes, local certification evidence and a new v0.8.2 live-delta procedure belong in detached certification/operator artifacts after source freeze.
