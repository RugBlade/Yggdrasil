from pathlib import Path

from noeron.learning import preview_document
from noeron.llm import MockLanguageEngine
from noeron.memory import LocalEventStore
from noeron.orchestrator import Noeron


def test_latex_preview_filters_scaffolding_without_mutating_learning(tmp_path:Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'latex.db'))
    tex=r'''\documentclass{article}
\usepackage{amsmath}
\newtheorem{theorem}{Theorem}
\begin{document}
\begin{abstract}
A Sobolev knot manifold carries geometric structure.
\end{abstract}
\section{Knot Memory}
A nearby knot can be compared with the H^s distance.
\begin{equation}
d(K_1,K_2)^2 = 1
\end{equation}
\end{document}
'''
    p=n.learning_preview('clean',tex,0,10)
    joined=' '.join(p.segment_previews).lower()
    assert p.normalized_for_study is True
    assert p.filtered_scaffolding_count>=3
    assert 'documentclass' not in joined
    assert 'usepackage' not in joined
    assert 'sobolev knot manifold' in joined
    assert n.learning_audit()['sources']==0


def _quasar_source():
    return '''# Stellar Note
A quasar is a luminous distant source associated with energetic galactic activity.

Quasars can remain luminous while matter interacts around the central structure.

The quasar observation changes our memory of the astronomical source.
'''


def test_source_context_forms_semantic_stratum_and_archived_compressed_provenance_without_forcing_cognition(tmp_path:Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'strata.db'))
    report=n.study_document('Quasar note',_quasar_source(),mode='complete',max_segments=10)
    audit=n.learning_audit()
    shadows=n.store.archived_stratified_learning_memories()
    assert report.compressed_segment_memories==0
    assert report.archived_segment_observations>=2
    assert len(shadows)>=2
    assert report.semantic_strata_created>=1
    assert audit['semantic_strata']>=1
    assert audit['isotopy_components']>=1
    assert audit['compressed_learning_memories']==0
    assert all(sm.deformation.reconstruction_error_hs<=0.006 for sm in shadows)
    assert all(sm.memory_class=='learned-stratified-provenance-pending-cognitive' for sm in shadows)
    assert not any(m.memory_class.startswith('learned-stratified') for m in n.store.cognitive_memories())


def test_geometry_compression_amortizes_for_repeated_close_exposure_without_implying_cognitive_retention(tmp_path:Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'compress.db'))
    text='\n\n'.join(['A quasar is a luminous astronomical source in a distant galaxy.' for _ in range(30)])
    report=n.study_document('Repeated quasar contexts',text,mode='complete',max_segments=100)
    shadows=n.store.archived_stratified_learning_memories()
    assert report.compressed_segment_memories==0
    assert len(shadows)>=8
    assert report.stored_deformation_bytes < report.estimated_raw_knot_bytes
    # Compression is a storage property of provenance and must not be confused with
    # activation into Yggdrasil's cognitive memory.
    assert report.geometry_storage_ratio < 1.25
    assert not n.store.stratified_learning_memories()
    assert max(c.member_count for c in n.store.isotopy_components())>=4


def test_learning_traversal_refuses_nonretained_provenance_even_when_compressed_geometry_exists(tmp_path:Path):
    import pytest
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'travel.db'))
    text='\n\n'.join(['A quasar is a luminous astronomical source in a distant galaxy.' for _ in range(18)])
    n.study_document('Repeated quasar contexts',text,mode='complete',max_segments=100)
    comps=n.store.isotopy_components()
    c=next(c for c in comps if len(c.member_memory_ids)>=2)
    a,b=c.member_memory_ids[:2]
    before=n.state.model_dump_json()
    with pytest.raises(ValueError,match='active cognitive memories'):
        n.learning_traverse(str(a),str(b),steps=7)
    assert n.state.model_dump_json()==before


def test_dkt_and_noeron_semantic_strata_are_explicitly_distinct(tmp_path:Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'audit.db'))
    n.study_document('Quasar note',_quasar_source(),mode='complete',max_segments=10)
    a=n.learning_audit()
    assert 'kept distinct' in a['dkt_singularity_strata']
    assert 'not a global isotopy theorem' in a['local_isotopy_radius']
