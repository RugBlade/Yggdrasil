from noeron.math.rl import manuscript_metric,scalar_curvature,geodesic_step
from noeron.math.models import RLMathState
from noeron.math.irg import interaction_geometry
from noeron.math.egr import entropy_direction
from noeron.models import CognitiveEvent,EventKind

def test_rl_metric_positive_and_curvature_finite():
    x=[0.2,-0.1,0.05,0.3,0.1,0.2,0.15,0.12]; g=manuscript_metric(x)
    assert all(g[i][i]>0 for i in range(8)); assert isinstance(scalar_curvature(x),float)

def test_irg_and_egr_change_rl_trajectory():
    p=RLMathState()
    a=interaction_geometry(CognitiveEvent(kind=EventKind.USER_MESSAGE,source='t',content='DKT research',trusted=True))
    b=interaction_geometry(CognitiveEvent(kind=EventKind.USER_MESSAGE,source='t',content='hello ordinary',trusted=False))
    ea=entropy_direction(0.0,0.0,a.entropy_source,0.2)
    eb=entropy_direction(0.0,0.0,b.entropy_source,0.2)
    xa,*_=geodesic_step(p,a,ea,[],[0]*8,0)
    xb,*_=geodesic_step(p,b,eb,[],[0]*8,0)
    assert xa!=xb
    assert xa[3]>=0 and xb[3]>=0

def test_egr_entropy_target_changes_fourth_rl_coordinate():
    p=RLMathState()
    irg=interaction_geometry(CognitiveEvent(kind=EventKind.USER_MESSAGE,source='t',content='same interaction',trusted=True))
    low=entropy_direction(0.0,0.0,0.01,0.0)
    high=entropy_direction(0.0,0.0,1.0,0.0)
    xl,*_=geodesic_step(p,irg,low,[],[0]*8,0)
    xh,*_=geodesic_step(p,irg,high,[],[0]*8,0)
    assert xh[3]>xl[3]
