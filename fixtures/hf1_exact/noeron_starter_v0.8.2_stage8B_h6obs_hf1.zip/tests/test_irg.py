from noeron.math.irg import interaction_geometry
from noeron.models import CognitiveEvent,EventKind

def test_irg_is_field_not_label_vector():
    e=CognitiveEvent(kind=EventKind.USER_MESSAGE,source='test',content='memory entropy deformation knot',trusted=True)
    x=interaction_geometry(e)
    assert len(x.interaction_field)==x.support_samples
    assert len(x.deformation_velocity)==x.support_samples
    assert x.entropy_source>=0 and x.memory_response>=0
    assert x.semantic_atoms
