from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path


def test_stage6_frozen_authority_audit_has_only_expected_stage8b_version_failure_and_successor_passes():
    root = Path(__file__).resolve().parents[1]
    env = {**os.environ, 'PYTHONPATH': str(root / 'src')}

    # Preserve the frozen Stage-6 audit exactly.  Stage 8B intentionally advances
    # the current language mechanism, so the historical audit's single
    # current-version assertion must fail rather than being rewritten.
    frozen = subprocess.run(
        [sys.executable, str(root / 'scripts' / 'audit_v075_stage6.py')],
        cwd=root, env=env, text=True, capture_output=True, check=False,
    )
    assert frozen.returncode == 1, frozen.stdout + '\n' + frozen.stderr
    assert 'SUMMARY: 45/46 checks passed' in frozen.stdout
    assert 'FAIL: stage6-language-grounding-audit-version-coherent' in frozen.stdout
    assert frozen.stdout.count('FAIL:') == 1

    # The Stage-8B successor audit must independently prove the new current
    # language identity and authority boundaries rather than modifying history.
    successor = subprocess.run(
        [sys.executable, str(root / 'scripts' / 'audit_v081_stage8B_language.py')],
        cwd=root, env=env, text=True, capture_output=True, check=False,
    )
    assert successor.returncode == 0, successor.stdout + '\n' + successor.stderr
    assert 'SUMMARY: 39/39 PASS' in successor.stdout
