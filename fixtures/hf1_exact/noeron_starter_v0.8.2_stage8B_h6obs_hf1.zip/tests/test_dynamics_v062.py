from pathlib import Path

from noeron.cognition.kernel import GeometricCognitionKernel
from noeron.cognition.models import NativeThought, NativeThoughtKind
from noeron.llm import MockLanguageEngine
from noeron.math.kernel import MathematicalCognitiveKernel
from noeron.math.models import MathKernelState
from noeron.memory import LocalEventStore
from noeron.models import CognitiveEvent, EventKind, NoeronState
from noeron.orchestrator import Noeron


def test_autonomous_internal_drive_uses_local_rates_not_cumulative_egr_current():
    text=Path('src/noeron/orchestrator.py').read_text()
    line=next(x for x in text.splitlines() if 'internal_drive=[' in x)
    assert 'entropy_current' not in line
    assert 'sigma_delta' in line
    assert 'dkt_drift' in line
    assert 'curvature_contrast' in line


def test_routine_entropy_coordinate_accumulation_is_background_not_attention_event():
    k=MathematicalCognitiveKernel(); e=CognitiveEvent(kind=EventKind.TIMER,source='noeron-endogenous',content='',trusted=True,metadata={'endogenous':True,'internal_drive':[0]*8})
    r=k.update(e,MathKernelState(),[])
    state=NoeronState(); state.math_kernel=r.state
    state.cognition.attention_baseline={'sigma':r.state.egr.entropy_production,'entropy_coordinate':0.0,'frenet':r.state.frenet.first_curvature,'dkt_norm':r.state.dkt.sobolev_norm_sq}
    # A large accumulated coordinate change alone must not create entropy chatter.
    r.state.egr.mapped_entropy += 10.0
    r.state.egr.entropy_state += 100.0
    state.math_kernel=r.state
    t=GeometricCognitionKernel().autonomous(state,[],e,r,None)
    assert t.kind==NativeThoughtKind.REFLECTION
    assert t.should_surface is False


def test_v062_migration_clears_only_pending_queue_and_preserves_thought_history(tmp_path:Path):
    st=LocalEventStore(tmp_path/'m.db'); n=Noeron(MockLanguageEngine(),st)
    n.ingest(CognitiveEvent(kind=EventKind.USER_MESSAGE,source='u',content='Remember this learning architecture.',trusted=True))
    historical=len(st.recent_thoughts(100))
    # Use an explicit valid historical pending record. Unsupported ordinary text
    # no longer manufactures a NativeThought merely to populate this migration test.
    n.state.cognition.pending_thoughts=[NativeThought(kind=NativeThoughtKind.REFLECTION,statement='historical pending record')]
    n.state.cognition.v062_dynamics_learning_migration_complete=False
    st.append_state(n.state)
    n2=Noeron(MockLanguageEngine(),st)
    assert n2.state.cognition.pending_thoughts==[]
    assert len(st.recent_thoughts(100))==historical
    assert n2.state.cognition.legacy_pending_cleared_count>=1
