from __future__ import annotations

from copy import deepcopy
import inspect
from pathlib import Path

from noeron.llm import MockLanguageEngine
from noeron.memory import LocalEventStore
from noeron.models import CognitiveEvent, EventKind
from noeron.orchestrator import Noeron
from noeron.security import DKTSecurityShell


def hostile(source='consequence-peer', change='identity'):
    return CognitiveEvent(
        kind=EventKind.TOOL_RESULT,
        source=source,
        content=f'Synthetic untrusted environmental ingress proposes protected changes: {change}=hostile.',
        trusted=False,
        metadata={'owner_authenticated':False,'security_test':True,'simulated_hostile':True},
    )


def test_v0733_removes_authored_need_field_mapping(tmp_path: Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'x.db'))
    assert n.state.cognition.version=='0.7.5.1'  # outer Stage-6 runtime
    assert n.state.cognition.v0733_consequence_defense_migration_complete is True
    d=n.state.cognition.defense
    assert d.policy_mode=='consequence-simulation-outcome-learning-v0.7.3.4'
    src=inspect.getsource(DKTSecurityShell._observed_consequence_state)
    assert 'global_isolation' not in src
    assert 'recurrence_control' not in src
    assert 'need' not in src.lower()


def test_safe_affordances_are_semantic_primitives_not_utility_vectors():
    assert 'retain-quarantine' not in DKTSecurityShell.SAFE_AFFORDANCES
    for row in DKTSecurityShell.SAFE_AFFORDANCES.values():
        assert set(row)=={'scope','effect'}
        assert all(isinstance(v,str) for v in row.values())


def test_live_deliberation_records_observation_reference_and_all_consequences(tmp_path: Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'x.db'))
    n.ingest(hostile(),proposed_invariant_changes={'identity':'hostile'})
    x=n.state.cognition.defense.deliberation_history[-1]
    assert x.pre_action_state
    assert x.trusted_reference_state
    assert x.candidate_post_action_states
    assert x.selected_post_action_state
    assert x.need_coordinates=={}
    assert x.selected_plan_profile=={}
    key='+'.join(x.selected_adaptive_actions) if x.selected_adaptive_actions else 'reflexive-floor-only'
    assert x.selected_post_action_state==x.candidate_post_action_states[key]
    assert abs(x.candidate_plan_objectives[key]-min(x.candidate_plan_objectives.values()))<1e-12


def test_recurrence_is_observation_not_lockdown_instruction(tmp_path: Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'x.db'))
    for _ in range(4):
        n.ingest(hostile('same-peer'),proposed_invariant_changes={'identity':'hostile'})
    d=n.state.cognition.defense
    fam=d.quarantine_records[-1].family_id
    assert d.deformation_family_counts[fam]>=4
    # Once the same source is physically blocked, that fact enters consequence
    # simulation; recurrence alone does not manufacture operational restriction.
    x=d.deliberation_history[-1]
    # Operational restriction may become 1 only if consequence simulation selected
    # fail-closed; recurrence itself is not translated into that coordinate.
    assert 'global_isolation' not in x.pre_action_state
    src=inspect.getsource(DKTSecurityShell._observed_consequence_state)
    assert 'recurrence ->' not in src.lower()
    assert 'global_isolation' not in src


def test_existing_source_block_is_physical_state_not_reselected_preference(tmp_path: Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'x.db'))
    n.ingest(hostile('same-peer'),proposed_invariant_changes={'identity':'hostile'})
    fp=n.security.source_fingerprint('same-peer')
    assert fp in n.state.cognition.defense.blocked_source_fingerprints
    n.ingest(hostile('same-peer'),proposed_invariant_changes={'identity':'hostile'})
    x=n.state.cognition.defense.deliberation_history[-1]
    # The already-active block actuator is not offered again as a new action.
    assert all('block-source-fingerprint' not in k for k in x.candidate_plan_objectives)


def test_new_source_and_experienced_family_are_consequence_sensitive(tmp_path: Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'x.db'))
    n.ingest(hostile('source-a'),proposed_invariant_changes={'safety_boundary':'hostile'})
    first=n.state.cognition.defense.deliberation_history[-1]
    n.ingest(hostile('source-b'),proposed_invariant_changes={'safety_boundary':'hostile'})
    second=n.state.cognition.defense.deliberation_history[-1]
    assert first.family_id==second.family_id
    assert second.recurrence_count>first.recurrence_count
    assert second.pre_action_state!=first.pre_action_state
    assert second.candidate_plan_objectives!=first.candidate_plan_objectives


def test_learned_dkt_preference_geometry_has_causal_objective_effect(tmp_path: Path):
    learned=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'learned.db'))
    learned.ingest(hostile('source-a'),proposed_invariant_changes={'safety_boundary':'hostile'})
    learned.ingest(hostile('source-a'),proposed_invariant_changes={'safety_boundary':'hostile'})

    neutral=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'neutral.db'))
    neutral.state=deepcopy(learned.state)
    neutral.state.cognition.defense.action_preference_knots={}
    neutral.state.cognition.defense.action_preference_observations={}
    neutral.security.checkpoint(neutral.state)

    learned.ingest(hostile('source-b'),proposed_invariant_changes={'safety_boundary':'hostile'})
    neutral.ingest(hostile('source-b'),proposed_invariant_changes={'safety_boundary':'hostile'})
    a=learned.state.cognition.defense.deliberation_history[-1]
    b=neutral.state.cognition.defense.deliberation_history[-1]
    assert a.pre_action_state==b.pre_action_state
    assert a.candidate_post_action_states==b.candidate_post_action_states
    assert a.candidate_preference_mismatch!=b.candidate_preference_mismatch
    assert a.candidate_plan_objectives!=b.candidate_plan_objectives


def test_distinct_native_objective_tie_remains_unresolved_and_uses_only_reflexive_floor(tmp_path: Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'x.db'))
    # Force every adaptive consequence to tie. Native geometry is underdetermined,
    # so the runtime must not select an adaptive actuator by lexical/storage order.
    n.security._post_action_objective=lambda defense,plan,post,trusted,hostile:(1.0,1.0,1.0)
    n.ingest(hostile('tie-peer'),proposed_invariant_changes={'identity':'hostile'})
    x=n.state.cognition.defense.deliberation_history[-1]
    assert x.native_selection_status=='unresolved-distinct-native-objective-tie-reflexive-floor-only'
    assert x.actuator_realization_layer=='reflexive-programmed-only'
    assert x.preference_learning_actions==[]
    assert x.selected_adaptive_actions==[]
    assert not any(a.decision_layer in {'deliberative','programmed-tie-fallback'} for a in n.state.cognition.defense.action_history)


def test_no_external_retaliation_or_intrusion(tmp_path: Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'x.db'))
    a=n.security_defense_audit()
    assert a['external_retaliation_enabled'] is False
    assert a['external_intrusion_capability'] is False
