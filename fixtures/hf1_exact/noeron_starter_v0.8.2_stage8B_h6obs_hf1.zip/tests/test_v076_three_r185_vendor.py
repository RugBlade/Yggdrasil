from __future__ import annotations

import hashlib
import importlib.util
import io
import json
from pathlib import Path
import tarfile

import pytest


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("vendor_three_r185", ROOT / "scripts/vendor_three_r185.py")
assert SPEC is not None and SPEC.loader is not None
vendor_three = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(vendor_three)


def test_01_exact_release_pins_are_locked():
    assert vendor_three.PACKAGE_NAME == "three"
    assert vendor_three.PACKAGE_VERSION == "0.185.1"
    assert vendor_three.UPSTREAM_TAG == "r185"
    assert vendor_three.NPM_SRI == "sha512-5aojFCXKwnjBRZvUnt3WFfEcvUJgkN5LlijRFN95hMy8WVkG4I0QNcJE+OuWvuJ0bOdStrbfXn0pkd6/QyiAlg=="
    assert vendor_three.REQUIRED_FILES == {
        "build/three.module.js": "ad13abf7d128bee607a7672646ca543327e258d3",
        "build/three.core.js": "0bb9262cd029f411933d077fd44197a51ec5e8e9",
        "LICENSE": "8ada2a5f982916b0ba4b7a0aa7de347587e745d7",
    }
    assert vendor_three.DEFAULT_DESTINATION.as_posix() == "src/noeron/static/vendor/three-r185"


def test_02_git_blob_hashing_uses_real_git_object_identity():
    # Canonical Git object identity for a blob containing exactly b"hello\\n".
    assert vendor_three.git_blob_sha1(b"hello\n") == "ce013625030ba8dba906f756967f9e9ca394464a"


def test_03_bad_local_source_fails_before_install(tmp_path):
    source = tmp_path / "source"
    (source / "build").mkdir(parents=True)
    (source / "package.json").write_text(json.dumps({"name": "three", "version": "0.185.1"}))
    (source / "build/three.module.js").write_text("/* SPDX-License-Identifier: MIT */\nimport {} from './three.core.js';\n")
    (source / "build/three.core.js").write_text("/* SPDX-License-Identifier: MIT */\nexport {};\n")
    (source / "LICENSE").write_text("The MIT License\nPermission is hereby granted\n")
    destination = tmp_path / "vendor" / "three-r185"
    with pytest.raises(vendor_three.VerificationError, match="Git blob mismatch"):
        vendor_three.vendor(source_dir=source, npm_tgz=None, destination=destination)
    assert not destination.exists()


def test_04_wrong_npm_tarball_sri_fails_closed_without_extraction_or_install(tmp_path, monkeypatch):
    tgz = tmp_path / "three-0.185.1.tgz"
    with tarfile.open(tgz, "w:gz") as tf:
        data = b'{"name":"three","version":"0.185.1"}'
        info = tarfile.TarInfo("package/package.json")
        info.size = len(data)
        tf.addfile(info, io.BytesIO(data))
    destination = tmp_path / "vendor" / "three-r185"
    opened = False
    original_open = tarfile.open

    def guarded_open(*args, **kwargs):
        nonlocal opened
        opened = True
        return original_open(*args, **kwargs)

    monkeypatch.setattr(vendor_three.tarfile, "open", guarded_open)
    with pytest.raises(vendor_three.VerificationError, match="SRI mismatch"):
        vendor_three.vendor(source_dir=None, npm_tgz=tgz, destination=destination)
    assert opened is False
    assert not destination.exists()


def test_05_module_linkage_is_local_only_without_rejecting_inert_documentation_urls():
    vendor_three._verify_module_linkage(
        b"import { X } from './three.core.js';\n// https://docs.example.invalid/reference-only\nexport { X };\n"
    )
    with pytest.raises(vendor_three.VerificationError, match="local ./three.core.js"):
        vendor_three._verify_module_linkage(b"export const X = 1;\n")
    with pytest.raises(vendor_three.VerificationError, match="non-local module dependencies"):
        vendor_three._verify_module_linkage(
            b"import { X } from './three.core.js';\nimport 'https://cdn.example.invalid/three.js';\n"
        )


def test_06_vendored_r185_material_matches_exact_pins_and_integrity_manifest():
    destination = ROOT / "src/noeron/static/vendor/three-r185"
    assert destination.is_dir()
    manifest = json.loads((destination / "INTEGRITY.json").read_text(encoding="utf-8"))
    assert manifest["package"] == vendor_three.PACKAGE_NAME
    assert manifest["version"] == vendor_three.PACKAGE_VERSION
    assert manifest["upstream_tag"] == vendor_three.UPSTREAM_TAG
    assert manifest["license"] == "MIT"
    assert manifest["npm_sri"] == vendor_three.NPM_SRI
    assert manifest["runtime_public_network_dependency"] is False
    assert manifest["source_mode"] == "npm-tgz-exact-sri"
    assert set(manifest["files"]) == set(vendor_three.REQUIRED_FILES)
    for rel, expected_blob in vendor_three.REQUIRED_FILES.items():
        data = (destination / rel).read_bytes()
        assert vendor_three.git_blob_sha1(data) == expected_blob
        assert manifest["files"][rel]["upstream_git_blob_sha1"] == expected_blob
        assert manifest["files"][rel]["sha256"] == hashlib.sha256(data).hexdigest()
        assert manifest["files"][rel]["size"] == len(data)
    vendor_three._verify_module_linkage((destination / "build/three.module.js").read_bytes())
