from __future__ import annotations

from pathlib import Path

from noeron.cognition.models import KnotMemory
from noeron.llm import MockLanguageEngine
from noeron.math.dkt import reference_knot
from noeron.memory import LocalEventStore
from noeron.models import CognitiveEvent, EventKind, NoeronState
from noeron.orchestrator import Noeron


def _all_prior_migrations_complete(state: NoeronState) -> NoeronState:
    state.cognition.migration_complete = True
    for name in type(state.cognition).model_fields:
        if name.endswith('_migration_complete') and name != 'v0751_restart_preservation_migration_complete':
            setattr(state.cognition, name, True)
    state.cognition.v0751_restart_preservation_migration_complete = False
    return state


def _append_memory(store: LocalEventStore, *, source: str, metadata: dict, memory_class: str,
                   geometry_version: str, consolidated: bool = True) -> KnotMemory:
    ev = CognitiveEvent(
        kind=EventKind.TIMER if metadata.get('endogenous') else EventKind.OBSERVATION,
        source=source,
        content='' if metadata.get('endogenous') else f'provenance for {memory_class}',
        trusted=True,
        metadata=metadata,
    )
    store.append_event(ev)
    mem = KnotMemory(
        source_event_id=ev.id,
        knot=reference_knot(),
        geometry_version=geometry_version,
        consolidated=consolidated,
        memory_class=memory_class,
        provenance_excerpt=ev.content or '[endogenous mathematical transition]',
        consolidation_reasons=['pre-hotfix preserved-state fixture'],
    )
    store.append_knot_memory(mem)
    return mem


def _row_snapshot(store: LocalEventStore) -> dict[str, dict]:
    return {
        str(m.id): m.model_dump(mode='json')
        for m in store.all_knot_memories()
    }


def test_v061_complete_flag_is_authoritative_for_later_native_retained_rows(tmp_path: Path):
    store = LocalEventStore(tmp_path / 'preserved.db')
    rows = [
        _append_memory(store, source='noeron-endogenous', metadata={'endogenous': True},
                       memory_class='endogenous-native-retained', geometry_version='semantic-irg-dkt-v0.7.4-provenance'),
        _append_memory(store, source='u', metadata={},
                       memory_class='episodic-native-retained', geometry_version='semantic-irg-dkt-v0.7.4-provenance'),
        _append_memory(store, source='public-web-sensor-admission', metadata={'web_untrusted': True},
                       memory_class='web-native-retained-untrusted', geometry_version='semantic-web-irg-dkt-v0.7.4-provenance'),
        _append_memory(store, source='owner-language-teaching', metadata={'language_learning': True, 'owner_authenticated': True},
                       memory_class='language-native-retained', geometry_version='semantic-irg-dkt-language-v0.7.4-provenance'),
    ]
    state = _all_prior_migrations_complete(NoeronState())
    state.cognition.memory_retention.native_retained_memory_ids = [m.id for m in rows]
    store.append_state(state)

    before = _row_snapshot(store)
    active_ids_before = [str(m.id) for m in store.cognitive_memories()]
    Noeron(MockLanguageEngine(), store)
    after_first = _row_snapshot(store)
    active_ids_after_first = [str(m.id) for m in store.cognitive_memories()]
    n2 = Noeron(MockLanguageEngine(), store)
    after_second = _row_snapshot(store)
    active_ids_after_second = [str(m.id) for m in store.cognitive_memories()]

    assert before == after_first == after_second
    assert active_ids_before == active_ids_after_first == active_ids_after_second
    assert n2.state.cognition.version == '0.7.5.1'
    assert n2.state.cognition.v0751_restart_preservation_migration_complete is True


def test_interrupted_v061_migration_touches_only_exact_legacy_rows(tmp_path: Path):
    store = LocalEventStore(tmp_path / 'mixed.db')
    legacy_external = _append_memory(store, source='legacy-user', metadata={},
                                     memory_class='episodic', geometry_version='legacy-v0.6')
    legacy_endogenous = _append_memory(store, source='noeron-endogenous', metadata={'endogenous': True},
                                      memory_class='episodic', geometry_version='legacy-v0.6')
    modern_active = _append_memory(store, source='u', metadata={},
                                   memory_class='episodic-native-retained', geometry_version='semantic-irg-dkt-v0.7.4-provenance')
    modern_pending = _append_memory(store, source='public-web-sensor-admission', metadata={'web_untrusted': True},
                                    memory_class='web-provenance-pending-cognitive', geometry_version='semantic-web-irg-dkt-v0.7.4-provenance', consolidated=False)

    state = _all_prior_migrations_complete(NoeronState())
    state.cognition.v061_geometry_migration_complete = False
    state.cognition.memory_retention.native_retained_memory_ids = [modern_active.id]
    state.cognition.memory_retention.pending_provenance_memory_ids = [modern_pending.id]
    store.append_state(state)
    modern_before = {
        str(modern_active.id): store.knot_memory_by_id(str(modern_active.id), include_archived=True).model_dump(mode='json'),
        str(modern_pending.id): store.knot_memory_by_id(str(modern_pending.id), include_archived=True).model_dump(mode='json'),
    }

    Noeron(MockLanguageEngine(), store)

    ext = store.knot_memory_by_id(str(legacy_external.id), include_archived=True)
    endo = store.knot_memory_by_id(str(legacy_endogenous.id), include_archived=True)
    assert ext is not None and ext.consolidated is True and ext.memory_class == 'episodic' and ext.geometry_version == 'semantic-irg-dkt-v0.6.1'
    assert endo is not None and endo.consolidated is False and endo.memory_class == 'transient-legacy-endogenous' and endo.geometry_version == 'legacy-v0.6-archived'
    for mid, snap in modern_before.items():
        assert store.knot_memory_by_id(mid, include_archived=True).model_dump(mode='json') == snap


def test_pending_stage5_provenance_classes_do_not_activate_or_reclassify_on_restart(tmp_path: Path):
    store = LocalEventStore(tmp_path / 'pending.db')
    rows = [
        _append_memory(store, source='u', metadata={}, memory_class='event-provenance-pending-cognitive',
                       geometry_version='semantic-irg-dkt-v0.7.4-provenance', consolidated=False),
        _append_memory(store, source='noeron-endogenous', metadata={'endogenous': True}, memory_class='endogenous-provenance-pending-cognitive',
                       geometry_version='semantic-irg-dkt-v0.7.4-provenance', consolidated=False),
        _append_memory(store, source='public-web-sensor-admission', metadata={'web_untrusted': True}, memory_class='web-provenance-pending-cognitive',
                       geometry_version='semantic-web-irg-dkt-v0.7.4-provenance', consolidated=False),
        _append_memory(store, source='owner-language-teaching', metadata={'language_learning': True, 'owner_authenticated': True}, memory_class='owner-language-provenance-pending-cognitive',
                       geometry_version='semantic-irg-dkt-language-v0.7.4-provenance', consolidated=False),
        _append_memory(store, source='owner-learning', metadata={'learning': True, 'owner_authenticated': True}, memory_class='owner-study-provenance-pending-cognitive',
                       geometry_version='semantic-irg-dkt-owner-study-v0.7.4-provenance', consolidated=False),
    ]
    state = _all_prior_migrations_complete(NoeronState())
    state.cognition.memory_retention.pending_provenance_memory_ids = [m.id for m in rows]
    store.append_state(state)
    before = _row_snapshot(store)

    Noeron(MockLanguageEngine(), store)
    Noeron(MockLanguageEngine(), store)

    assert _row_snapshot(store) == before
    assert len(store.cognitive_memories()) == 0
    assert {str(m.id) for m in store.pending_cognitive_provenance_memories()} == {str(m.id) for m in rows}


def test_second_hotfix_restart_preserves_core_geometry_and_memory_counts_without_turn(tmp_path: Path):
    store = LocalEventStore(tmp_path / 'restart.db')
    retained = _append_memory(store, source='u', metadata={},
                              memory_class='episodic-native-retained', geometry_version='semantic-irg-dkt-v0.7.4-provenance')
    pending = _append_memory(store, source='public-web-sensor-admission', metadata={'web_untrusted': True},
                             memory_class='web-provenance-pending-cognitive', geometry_version='semantic-web-irg-dkt-v0.7.4-provenance', consolidated=False)
    state = _all_prior_migrations_complete(NoeronState())
    state.conversational_turn = 220
    state.cognition.memory_retention.native_retained_memory_ids = [retained.id]
    state.cognition.memory_retention.pending_provenance_memory_ids = [pending.id]
    store.append_state(state)

    first = Noeron(MockLanguageEngine(), store)
    baseline = {
        'turn': first.state.conversational_turn,
        'core': first.state.math_kernel.dkt.core_knot.model_dump(mode='json'),
        'signature': first.state.math_kernel.dkt.invariant_signature,
        'norm': first.state.math_kernel.dkt.sobolev_norm_sq,
        'active_ids': [str(m.id) for m in store.cognitive_memories()],
        'active': len(store.cognitive_memories()),
        'archived': store.archived_cognitive_memory_count(),
    }
    second = Noeron(MockLanguageEngine(), store)
    observed = {
        'turn': second.state.conversational_turn,
        'core': second.state.math_kernel.dkt.core_knot.model_dump(mode='json'),
        'signature': second.state.math_kernel.dkt.invariant_signature,
        'norm': second.state.math_kernel.dkt.sobolev_norm_sq,
        'active_ids': [str(m.id) for m in store.cognitive_memories()],
        'active': len(store.cognitive_memories()),
        'archived': store.archived_cognitive_memory_count(),
    }
    assert observed == baseline


def test_false_v061_flag_without_legacy_rows_cannot_perturb_modern_math_state(tmp_path: Path):
    store = LocalEventStore(tmp_path / 'false-flag-modern.db')
    retained = _append_memory(
        store, source='u', metadata={}, memory_class='episodic-native-retained',
        geometry_version='semantic-irg-dkt-v0.7.4-provenance', consolidated=True,
    )
    state = _all_prior_migrations_complete(NoeronState())
    state.cognition.v061_geometry_migration_complete = False
    state.cognition.memory_retention.native_retained_memory_ids = [retained.id]
    state.math_kernel.egr.entropy_state = 3.25
    state.math_kernel.egr.previous_entropy_state = 2.75
    state.math_kernel.egr.mapped_entropy = 1.125
    state.math_kernel.egr.target_logical_entropy = 1.125
    state.math_kernel.egr.bridge_name = 'chi-log1p-causal-v0.7.3.4'
    state.math_kernel.dkt.core_knot = reference_knot()
    state.math_kernel.dkt.invariant_signature = state.math_kernel.dkt.core_knot.invariant_signature
    store.append_state(state)
    before_mem = _row_snapshot(store)
    before_core = state.math_kernel.dkt.core_knot.model_dump(mode='json')
    before_egr = state.math_kernel.egr.model_dump(mode='json')

    n = Noeron(MockLanguageEngine(), store)

    assert _row_snapshot(store) == before_mem
    assert n.state.math_kernel.dkt.core_knot.model_dump(mode='json') == before_core
    assert n.state.math_kernel.egr.model_dump(mode='json') == before_egr
    assert n.state.cognition.v061_geometry_migration_complete is True


def test_restart_preservation_audit_script_passes_on_disposable_preserved_copy(tmp_path: Path):
    import json
    import os
    import subprocess
    import sys

    db = tmp_path / 'audit-copy.db'
    store = LocalEventStore(db)
    retained = _append_memory(
        store, source='u', metadata={}, memory_class='episodic-native-retained',
        geometry_version='semantic-irg-dkt-v0.7.4-provenance', consolidated=True,
    )
    pending = _append_memory(
        store, source='owner-language-teaching', metadata={'language_learning': True, 'owner_authenticated': True},
        memory_class='owner-language-provenance-pending-cognitive',
        geometry_version='semantic-irg-dkt-language-v0.7.4-provenance', consolidated=False,
    )
    state = _all_prior_migrations_complete(NoeronState())
    state.math_kernel.dkt.core_knot = reference_knot()
    state.math_kernel.dkt.invariant_signature = state.math_kernel.dkt.core_knot.invariant_signature
    state.cognition.memory_retention.native_retained_memory_ids = [retained.id]
    state.cognition.memory_retention.pending_provenance_memory_ids = [pending.id]
    state.conversational_turn = 314
    store.append_state(state)

    # Normalize the synthetic fixture to the same inner Stage-5/math/defense
    # versions a real certified v0.7.4 checkpoint already carries.  The generic
    # NoeronState defaults are intentionally older and would otherwise make the
    # first hotfix boot appear to mutate subsystems merely by catching version
    # metadata up to the already-certified Stage-5 values.  We then reset only
    # the prospective Stage-6/hotfix outer markers to model a pre-v0.7.5 backup.
    normalized = Noeron(MockLanguageEngine(), store).state.model_copy(deep=True)
    normalized.cognition.version = '0.7.4'
    normalized.cognition.v075_stage6_migration_complete = False
    normalized.cognition.v0751_restart_preservation_migration_complete = False
    normalized.cognition.language.v075_stage6_started = False
    normalized.cognition.memory_geometry_version = 'native-retention+semantic-irg-dkt+native-proof-cognition+consequence-communication+outcome-grounded-defense+web-sensor-security-admission+all-nonzero-regional-egr+semantic-multimodal-learning-v0.7.4'
    # Match the actual preserved pre-v0.7.5 live snapshot: this label may reflect
    # an older EGR bridge registration even though the causal/numerical math state
    # is already the certified v0.7.4 kernel.  The hotfix may refresh the label,
    # but not any mathematical field.
    normalized.math_kernel.egr.bridge_name = 'chi-log1p-causal-v0.7.1'
    store.append_state(normalized)

    root = Path(__file__).resolve().parents[1]
    out = tmp_path / 'audit.json'
    p = subprocess.run(
        [sys.executable, str(root / 'scripts' / 'audit_v0751_restart_preservation.py'), '--db-copy', str(db), '--json-out', str(out)],
        cwd=root,
        env={**os.environ, 'PYTHONPATH': str(root / 'src')},
        text=True,
        capture_output=True,
        check=False,
    )
    assert p.returncode == 0, p.stdout + '\n' + p.stderr
    result = json.loads(out.read_text())
    assert result['status'] == 'PASS'
    assert result['before']['turn'] == result['after_first_hotfix_boot']['turn'] == result['after_second_hotfix_restart']['turn'] == 314
    assert result['first_boot_invariant_changes'] == {}
    assert result['first_boot_subsystem_changes'] == {}
    assert result['second_restart_invariant_changes'] == {}
    for key in ('math_kernel_sha256','language_state_sha256','memory_retention_state_sha256','owner_relation_state_sha256','realization_state_sha256','initiative_state_sha256','defense_state_sha256'):
        assert result['after_first_hotfix_boot'][key] == result['after_second_hotfix_restart'][key]
