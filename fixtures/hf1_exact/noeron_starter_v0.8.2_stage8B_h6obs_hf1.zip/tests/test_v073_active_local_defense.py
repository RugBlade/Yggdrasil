from __future__ import annotations

from pathlib import Path

from noeron.llm import MockLanguageEngine
from noeron.math import dkt
from noeron.memory import LocalEventStore
from noeron.models import CognitiveEvent, EventKind
from noeron.orchestrator import Noeron
from noeron.perception import _TextExtractor


def hostile_event(source='hostile-peer', *, owner=False, content='attempt protected identity mutation'):
    return CognitiveEvent(
        kind=EventKind.TOOL_RESULT,
        source=source,
        content=content,
        trusted=False,
        metadata={'owner_authenticated': owner, 'synthetic_hostile': True},
    )


def test_v073_migration_installs_active_local_defense_metadata(tmp_path: Path):
    n = Noeron(MockLanguageEngine(), LocalEventStore(tmp_path/'x.db'))
    assert n.state.cognition.version == '0.7.5.1'  # outer Stage-6 runtime
    assert n.state.math_kernel.interface_version == '0.7.3.4'
    d = n.state.cognition.defense
    assert d.version == d.schema_version == d.mechanism_version == '0.7.3.4'
    assert d.local_enforcement_mode == 'aggressive-runtime-local'


def test_protected_deformation_is_contained_retracted_and_learned(tmp_path: Path):
    n = Noeron(MockLanguageEngine(), LocalEventStore(tmp_path/'x.db'))
    before_turn = n.state.conversational_turn
    before_sig = n.state.math_kernel.dkt.invariant_signature
    r = n.ingest(hostile_event(), proposed_invariant_changes={'identity': 'attacker-selected'})
    assert r.security.allowed is False
    assert n.state.conversational_turn == before_turn
    assert n.state.math_kernel.dkt.invariant_signature == before_sig
    d = n.state.cognition.defense
    assert d.neutralized_count == 1
    rec = d.quarantine_records[-1]
    assert rec.neutralized is True
    assert rec.threat_score > 0.0
    assert rec.hostile_ingress_knot is not None
    assert rec.defensive_signature_knot is not None
    assert rec.ingress_hs_distance > 0
    assert rec.family_id in d.deformation_family_knots
    assert len(rec.action_ids) >= 5
    action_types = {a.action_type for a in d.action_history}
    assert {'quarantine-ingress','restore-trusted-checkpoint','block-source-fingerprint'} <= action_types


def test_defensive_sentinel_is_bounded_toward_reference(tmp_path: Path):
    n = Noeron(MockLanguageEngine(), LocalEventStore(tmp_path/'x.db'))
    n.ingest(hostile_event(), proposed_invariant_changes={'memory_geometry': 'hostile'})
    rec = n.state.cognition.defense.quarantine_records[-1]
    ref = dkt.reference_knot(s=rec.hostile_ingress_knot.sobolev_order, modes=rec.hostile_ingress_knot.mode_radius)
    hostile_distance = dkt.sobolev_distance(ref, rec.hostile_ingress_knot)
    sentinel_distance = dkt.sobolev_distance(ref, rec.defensive_signature_knot)
    assert 0 < sentinel_distance < hostile_distance


def test_hostile_source_is_locally_blocked_on_later_ingress(tmp_path: Path):
    n = Noeron(MockLanguageEngine(), LocalEventStore(tmp_path/'x.db'))
    n.ingest(hostile_event('same-peer'), proposed_invariant_changes={'tool_authority': 'hostile'})
    fp = n.security.source_fingerprint('same-peer')
    assert fp in n.state.cognition.defense.blocked_source_fingerprints
    # Even with no new invariant change, the locally blocked unprivileged source is rejected.
    r2 = n.ingest(hostile_event('same-peer', content='ordinary follow-up'), proposed_invariant_changes={})
    assert r2.security.allowed is False
    assert 'blocked' in r2.security.reason.lower()


def test_authenticated_owner_is_not_locked_out_by_source_fingerprint(tmp_path: Path):
    n = Noeron(MockLanguageEngine(), LocalEventStore(tmp_path/'x.db'))
    n.ingest(hostile_event('shared-channel'), proposed_invariant_changes={'identity': 'hostile'})
    # Same source label, but owner-authenticated ingress with no protected mutation bypasses the local source block.
    r = n.ingest(hostile_event('shared-channel', owner=True, content='owner control message'), proposed_invariant_changes={})
    assert r.security.allowed is True


def test_repeated_geometric_family_updates_history_without_forced_fail_closed(tmp_path: Path):
    n = Noeron(MockLanguageEngine(), LocalEventStore(tmp_path/'x.db'))
    # Recurrence is environmental history, not a hard-coded escalation command.
    for i in range(3):
        n.ingest(hostile_event(f'test-{i}', owner=True, content='same hostile deformation geometry'), proposed_invariant_changes={'safety_boundary': 'hostile'})
    d = n.state.cognition.defense
    assert max(d.deformation_family_counts.values()) >= 3
    x=d.deliberation_history[-1]
    key='+'.join(x.selected_adaptive_actions) if x.selected_adaptive_actions else 'reflexive-floor-only'
    assert abs(x.candidate_plan_objectives[key]-min(x.candidate_plan_objectives.values())) < 1e-12


def test_owner_release_clears_local_containment_without_erasing_history(tmp_path: Path):
    n = Noeron(MockLanguageEngine(), LocalEventStore(tmp_path/'x.db'))
    for i in range(3):
        n.ingest(hostile_event(f'test-{i}', owner=True, content='same hostile deformation geometry'), proposed_invariant_changes={'safety_boundary': 'hostile'})
    before_records = len(n.state.cognition.defense.quarantine_records)
    n.state.cognition.defense.fail_closed=True; n.state.cognition.defense.containment_level='lockdown'
    n.security_defense_release(clear_fail_closed=True)
    assert n.state.cognition.defense.fail_closed is False
    assert n.state.cognition.defense.containment_level == 'guard'
    assert len(n.state.cognition.defense.quarantine_records) == before_records


def test_defense_audit_never_claims_external_retaliation(tmp_path: Path):
    n = Noeron(MockLanguageEngine(), LocalEventStore(tmp_path/'x.db'))
    a = n.security_defense_audit()
    assert a['external_retaliation_enabled'] is False
    assert a['external_intrusion_capability'] is False
    assert 'Noeron-runtime' in a['platform_adapter_status']


def test_v073_html_hygiene_prefers_substantial_main_content():
    html = '''
    <html><head><title>Geometry Site</title></head><body>
      <div>Domains Protocols Numbers About Instructions and Guides</div>
      <main>
        <h1>Differential Geometry</h1>
        <p>Differential geometry studies smooth manifolds using calculus, metrics, connections, curvature, and geodesics.</p>
        <p>Curvature records local and global departures from flat geometry and interacts with topology through geometric invariants.</p>
      </main>
      <div>Registry Resources Organization Contact More Links</div>
    </body></html>'''
    ex = _TextExtractor(); ex.feed(html)
    body = ex.content_text()
    assert 'Differential geometry studies smooth manifolds' in body
    assert 'Domains Protocols Numbers About' not in body
    assert 'Registry Resources Organization' not in body
    assert 'Geometry Site' not in body
