from noeron.math.kernel import MathematicalCognitiveKernel
from noeron.math.models import MathKernelState
from noeron.models import CognitiveEvent,EventKind

def test_full_math_is_on_causal_path_in_original_order():
    k=MathematicalCognitiveKernel(); e=CognitiveEvent(kind=EventKind.USER_MESSAGE,source='t',content='DKT EGR IRG RL memory entropy',trusted=True)
    r=k.update(e,MathKernelState(),[]); s=r.state
    assert s.runtime_mode=='causal-mathematical'
    assert s.dkt.experience_knot is not None
    assert s.irg.interaction_field
    assert s.egr.entropy_production>=0
    assert s.rl.metric
    assert s.rl.coordinates[3] >= 0
    assert s.frenet.samples==1
    assert 'IRG:' in s.causal_trace[0]
    assert 'DKT:' in s.causal_trace[1]
    assert 'EGR:' in s.causal_trace[2]
    assert 'RL:' in s.causal_trace[3]
    assert s.dkt.security_reason != 'uninitialized'
