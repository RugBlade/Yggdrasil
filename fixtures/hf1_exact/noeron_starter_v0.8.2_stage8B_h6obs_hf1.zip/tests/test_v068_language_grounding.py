from pathlib import Path
from types import SimpleNamespace

from noeron.llm import MockLanguageEngine
from noeron.memory import LocalEventStore
from noeron.models import CognitiveEvent, EventKind
from noeron.orchestrator import Noeron

LESSON=(
    'I am Yggdrasil. You are Abdelaziz. A word can name a concept. '
    'A sentence can express a thought. This is a statement. What is a question? '
    'A question asks for information. I do not know. I answer because I remember. '
    'The word and can join ideas.'
)


def test_lesson_binds_surface_to_dkt_prototype_and_stores_proposition(tmp_path:Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'x.db'))
    report=n.teach_language(LESSON,source='owner-english-curriculum-001')
    assert report['llm_used'] is False
    lx=n.state.cognition.language.lexicon['question']
    assert lx.concept_term=='question'
    assert lx.status in {'concept-linked-emerging','concept-grounded'}
    props=n.language_propositions()
    assert any(p['subject_concept']=='question' and p['relation']=='asks-for' and p['object_concept']=='information' for p in props)
    assert n.state.cognition.language.referents['i'].startswith('identity:yggdrasil')
    assert n.state.cognition.language.referents['you'].startswith('owner:abdelaziz')


def test_parse_what_is_question_is_read_only_and_grounded(tmp_path:Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'x.db'))
    n.teach_language(LESSON,source='owner-english-curriculum-001')
    turn=n.state.conversational_turn
    out=n.language_parse('What is a question?')
    assert out['frame']=='definition-question'
    assert out['target_concept']=='question'
    # Stage 6 keeps this endpoint read-only and non-authoritative: stored language
    # rows may be reported as candidates, but without a query-specific DKT retrieval
    # they cannot be called a supported cognitive answer.
    assert out['answer_supported'] is False
    assert out['native_proposition'] is None
    assert out['matched_proposition_ids']
    assert 'no DKT retrieval authority' in out['note']
    assert n.state.conversational_turn==turn


def test_real_interaction_uses_grounded_language_proposition_before_terra(tmp_path:Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'x.db'))
    n.teach_language(LESSON,source='owner-english-curriculum-001')
    # Add an irrelevant old question-shaped episodic memory to reproduce the v0.6.7 failure mode.
    n.ingest(CognitiveEvent(kind=EventKind.USER_MESSAGE,source='u',content='Would you like to get it one day?',trusted=True))
    r=n.ingest(CognitiveEvent(kind=EventKind.USER_MESSAGE,source='u',content='What is a question?',trusted=True))
    assert r.native_text.lower().strip()== 'question asks for information.'
    rr=r.state.math_kernel.reasoning
    assert [p.canonical() for p in rr.answer_candidates]==['question::asks-for::information']
    assert any(p.source=='persistent-language-proposition' for p in rr.premise_propositions)
    assert r.state.cognition.language.last_interpretation is None
    assert r.state.cognition.language.last_interaction_native_utterance.native_text==r.native_text
    # Native cognition is complete before realization.  Stage 5 deliberately
    # executes no native-direct/Terra path while realization consequence geometry
    # is unresolved, so the proof-supported native content remains audit-only.
    assert r.text=='' and r.renderer_used is False
    rz=r.state.cognition.realization_development
    assert rz.last_selection_status=='unresolved-insufficient-realization-consequence-geometry'
    assert rz.last_effective_action=='' and rz.last_native_choice_claim is False


def test_v068_migration_regrounds_existing_v067_language_memory_without_replaying_lesson(tmp_path:Path):
    store=LocalEventStore(tmp_path/'x.db')
    n=Noeron(MockLanguageEngine(),store)
    out=n.teach_language(LESSON,source='owner-english-curriculum-001')
    lessons=n.state.cognition.language.lessons_observed
    # Reconstruct the *legacy v0.6.7* persistence shape explicitly.  Current v0.7.4
    # teaching correctly creates pending provenance, so using its default class here
    # would not actually be a v0.6.7 migration fixture.  Historical active language
    # memory remains legitimate migration input; Stage-5 pending provenance does not.
    legacy=n.store.knot_memory_by_id(out['provenance_memory_id'],include_archived=True)
    legacy.consolidated=True
    legacy.memory_class='language-learning'
    legacy.geometry_version='semantic-irg-dkt-language-v0.6.7'
    n.store.upsert_knot_memory(legacy)
    n.state.cognition.v068_language_grounding_migration_complete=False
    n.state.cognition.language.propositions=[]
    q=n.state.cognition.language.lexicon['question']; q.concept_term=''; q.status='surface-ungrounded'
    n.state.cognition.language.lexicon['question']=q
    store.append_state(n.state)
    n2=Noeron(MockLanguageEngine(),store)
    assert n2.state.cognition.v068_language_grounding_migration_complete is True
    assert n2.state.cognition.language.lessons_observed==lessons
    assert n2.state.cognition.language.lexicon['question'].concept_term=='question'
    assert any(p.subject_concept=='question' and p.relation=='asks-for' for p in n2.state.cognition.language.propositions)


def test_affect_episode_gate_suppresses_correlated_endogenous_ticks(tmp_path:Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'x.db'))
    fake=SimpleNamespace(state=SimpleNamespace(affect=SimpleNamespace(pattern_signature='A3-U1-N7-T2-C4-P+1')))
    e1=CognitiveEvent(kind=EventKind.TIMER,source='noeron-endogenous',content='',trusted=True,metadata={'endogenous':True})
    e2=CognitiveEvent(kind=EventKind.TIMER,source='noeron-endogenous',content='',trusted=True,metadata={'endogenous':True})
    assert n._observe_affective_pattern(fake,e1) is True
    assert n._observe_affective_pattern(fake,e2) is False
    st=n.state.cognition.affective_development
    assert st.pattern_counts['A3-U1-N7-T2-C4-P+1']==1
    assert st.suppressed_correlated_observations==1


def test_language_grounding_module_has_no_llm_import():
    text=(Path(__file__).parents[1]/'src'/'noeron'/'development.py').read_text()
    assert 'from noeron.llm' not in text
    assert 'import noeron.llm' not in text
