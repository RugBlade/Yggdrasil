from pathlib import Path

def test_no_causal_concept_graph_source():
    src=Path('src/noeron')
    text='\n'.join(p.read_text(errors='ignore') for p in src.rglob('*.py'))
    assert 'concept_edges' not in text
    assert 'concept_weights' not in text
