from noeron.math.rl import build_state


def test_rl_keeps_manuscript_entropy_and_adds_non_destructive_curvature_diagnostics():
    x=[0.2,-0.1,0.05,0.3,0.1,0.2,0.15,0.12]
    s=build_state(x,[0]*8,[0]*8,[[v*0.9 for v in x],[v*1.05 for v in x]],[0]*8,[0]*8,0.0,0.0,0.0)
    assert 0.0<=s.curvature_entropy_normalized<=1.0
    assert s.curvature_variance>=0.0
    assert s.curvature_contrast>=0.0
    assert s.curvature_contrast==max(s.curvatures)-min(s.curvatures)
