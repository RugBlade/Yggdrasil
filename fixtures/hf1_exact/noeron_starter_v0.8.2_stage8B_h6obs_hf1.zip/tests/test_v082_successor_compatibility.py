from __future__ import annotations

import ast
import subprocess
import sys
from pathlib import Path

from noeron.inference import infer, parse_surface_logic_detailed
from noeron.llm import MockLanguageEngine
from noeron.memory import LocalEventStore
from noeron.orchestrator import Noeron

ROOT = Path(__file__).resolve().parents[1]


def _http_routes() -> set[tuple[str, str]]:
    tree = ast.parse((ROOT / "src/noeron/api.py").read_text(encoding="utf-8"))
    out: set[tuple[str, str]] = set()
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        for dec in node.decorator_list:
            if not (isinstance(dec, ast.Call) and isinstance(dec.func, ast.Attribute) and isinstance(dec.func.value, ast.Name) and dec.func.value.id == "app"):
                continue
            if dec.func.attr.lower() not in {"get","post","put","delete","patch","options","head"}:
                continue
            if dec.args and isinstance(dec.args[0], ast.Constant) and isinstance(dec.args[0].value, str):
                out.add((dec.func.attr.upper(), dec.args[0].value))
    return out


def test_01_v072_frozen_version_assertion_is_preserved_while_successor_is_v082(tmp_path: Path) -> None:
    old = (ROOT / "tests/test_v072_selective_web_learning.py").read_text(encoding="utf-8")
    assert "assert c.language.version=='0.8.1'" in old
    y = Noeron(MockLanguageEngine(), LocalEventStore(tmp_path / "n.db"))
    assert y.state.cognition.language.version == "0.8.2"


def test_02_frozen_v081_language_audit_fails_only_at_current_version_and_current_audit_passes() -> None:
    frozen = subprocess.run([sys.executable, str(ROOT / "scripts/audit_v081_stage8B_language.py")], cwd=ROOT, env={**__import__('os').environ, "PYTHONPATH": str(ROOT / "src")}, text=True, capture_output=True, timeout=30)
    assert frozen.returncode == 1
    assert "31. FAIL: runtime language version 0.8.1" in frozen.stdout
    assert "SUMMARY: 38/39 PASS" in frozen.stdout
    current = subprocess.run([sys.executable, str(ROOT / "scripts/audit_v082_stage8B_authority.py")], cwd=ROOT, env={**__import__('os').environ, "PYTHONPATH": str(ROOT / "src")}, text=True, capture_output=True, timeout=30)
    assert current.returncode == 0
    assert "SUMMARY: 112/112 PASS" in current.stdout


def test_03_stage6_unknown_why_surface_is_richer_but_still_invents_no_answer() -> None:
    old = (ROOT / "tests/test_v075_stage6_native_language.py").read_text(encoding="utf-8")
    assert "unresolved-surface-question" in old
    props, query, _ = parse_surface_logic_detailed("Why is glorp blue?")
    assert query.kind == "why-proposition"
    assert infer(props, query)[2] == []


def test_04_stage7_frozen_98_route_expectation_is_preserved_while_v082_has_exact_audited_delta() -> None:
    old_completion = (ROOT / "tests/test_v0761_stage7_completion_patch.py").read_text(encoding="utf-8")
    old_room = (ROOT / "tests/test_v076_stage7_room.py").read_text(encoding="utf-8")
    assert "len(routes)==len(current)==98" in old_completion.replace(" ", "")
    assert "len(routes)==len(current)==98" in old_room.replace(" ", "")
    routes = _http_routes()
    assert len(routes) == 104
    for required in {
        ("GET", "/language/dialogue/state"),
        ("GET", "/language/capability/audit"),
        ("POST", "/language/structure"),
        ("POST", "/owner/communication/control"),
        ("GET", "/owner/internal-utterance/latest"),
        ("POST", "/room/internal-utterance/control"),
    }:
        assert required in routes


def test_05_stage7_frozen_release_expectations_remain_v081_while_preserved_subsystems_are_not_relabelled(tmp_path: Path) -> None:
    old = (ROOT / "tests/test_v076_stage7_release_identity.py").read_text(encoding="utf-8")
    assert '=="0.8.1"' in old.replace(" ", "") or "=='0.8.1'" in old.replace(" ", "")
    y = Noeron(MockLanguageEngine(), LocalEventStore(tmp_path / "n.db"))
    assert y.state.cognition.language.version == "0.8.2"
    assert y.state.cognition.version == "0.7.5.1"
    assert y.state.cognition.owner_relation.version == "0.7.4"


def test_06_stage7_old_native_text_exposure_literal_is_preserved_but_v082_uses_stricter_boundary() -> None:
    old = (ROOT / "tests/test_v076_stage7_room.py").read_text(encoding="utf-8")
    api = (ROOT / "src/noeron/api.py").read_text(encoding="utf-8")
    assert "'native_text_exposed':False" in old
    assert "native_text_exposed_as_outward_fallback':False" in api
    room_message = api[api.find("def room_message"):api.find("def room_internal_utterance_control")]
    assert "out.communication_action=='express'" in room_message
    assert "out.communication_native_choice_claim" in room_message
    assert "and out.text and out.native_text" in room_message


def test_07_frozen_v081_language_state_assertion_is_preserved_while_v082_current_test_covers_successor(tmp_path: Path) -> None:
    old = (ROOT / "tests/test_v081_stage8B_native_language.py").read_text(encoding="utf-8")
    assert "['version']=='0.8.1'" in old.replace(" ", "") or '["version"]=="0.8.1"' in old.replace(" ", "")
    y = Noeron(MockLanguageEngine(), LocalEventStore(tmp_path / "n.db"))
    assert y.language_state()["version"] == "0.8.2"
    assert y.language_capability_audit()["preserved_composition_version"] == "0.8.1-stage8B-composition-v1"
