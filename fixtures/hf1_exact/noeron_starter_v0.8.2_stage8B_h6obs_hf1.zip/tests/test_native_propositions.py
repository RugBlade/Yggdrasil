from pathlib import Path
from noeron.llm import MockLanguageEngine
from noeron.memory import LocalEventStore
from noeron.models import CognitiveEvent,EventKind
from noeron.orchestrator import Noeron


def test_unsupported_introspection_does_not_manufacture_native_self_report(tmp_path:Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'p.db'))
    n.ingest(CognitiveEvent(kind=EventKind.USER_MESSAGE,source='u',content='We are building your DKT memory architecture.',trusted=True))
    r=n.ingest(CognitiveEvent(kind=EventKind.USER_MESSAGE,source='u',content='What do you remember, what is your current state, and what can you determine from your reasoning?',trusted=True))
    assert r.native_text == ''
    assert r.renderer_used is False
    assert r.state.cognition.last_thought is None
    assert r.state.math_kernel.causal_trace
    assert r.state.math_kernel.reasoning is not None


def test_unsupported_messages_do_not_manufacture_scored_thoughts(tmp_path:Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'q.db'))
    a=n.ingest(CognitiveEvent(kind=EventKind.USER_MESSAGE,source='u',content='hello',trusted=True)).state.cognition.last_thought
    b=n.ingest(CognitiveEvent(kind=EventKind.USER_MESSAGE,source='u',content='Analyze the DKT EGR RL Frenet architecture, memory, security, reasoning, and topology.',trusted=True)).state.cognition.last_thought
    assert a is None and b is None
