from pathlib import Path

from noeron.llm import MockLanguageEngine
from noeron.memory import LocalEventStore
from noeron.models import CognitiveEvent, EventKind
from noeron.orchestrator import Noeron


def source_text():
    return '''# Stellar Note
A quasar is a luminous distant source associated with energetic galactic activity.

Quasars can remain luminous while matter interacts around the central structure.

The quasar observation changes our memory of the astronomical source.
'''


def test_preview_is_read_only_and_study_does_not_increment_conversation(tmp_path:Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'learn.db'))
    turn=n.state.conversational_turn
    p=n.learning_preview('Quasar note',source_text(),0,10)
    assert p.total_segments>=2
    assert n.learning_audit()['sources']==0
    report=n.study_document('Quasar note',source_text(),mode='complete',max_segments=10)
    assert n.state.conversational_turn==turn
    assert report.llm_used is False
    assert report.source.root_memory_id is not None
    assert report.consolidated_segment_memories==0
    assert n.learning_audit()['active_learning_memories']==0
    pending=[m for m in n.store.pending_cognitive_provenance_memories() if m.memory_class=='owner-study-provenance-pending-cognitive']
    assert len(pending)>=2
    assert n.learning_audit()['archived_compressed_provenance_memories']>=2


def test_repeated_context_forms_dkt_semantic_prototype_used_by_future_irg(tmp_path:Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'semantic.db'))
    n.study_document('Quasar note',source_text(),mode='complete',max_segments=10)
    proto=n.store.semantic_prototype_map().get('quasar')
    assert proto is not None
    assert proto.observations>=2
    assert proto.status=='observed-recurrent'
    assert proto.structural_role_score==0.0
    assert proto.establishment_score==0.0
    r=n.ingest(CognitiveEvent(kind=EventKind.USER_MESSAGE,source='u',content='What do you remember about the quasar?',trusted=True))
    assert 'quasar' in r.state.math_kernel.irg.learned_semantic_terms
    assert any(a.role=='learned-semantic-knot' for a in r.state.math_kernel.irg.semantic_atoms)
    assert n.learning_audit()['semantic_storage']=='DKT knot prototypes, not embedding vectors'


def test_learning_recall_is_dkt_geometric_and_revision_archives_old_branch(tmp_path:Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'rev.db'))
    n.study_document('Quasar note',source_text(),mode='complete',max_segments=10)
    # Owner exposure alone is not recallable cognitive memory in Stage 5.
    assert n.learning_recall('quasar luminous source',5)==[]
    pending=[m for m in n.store.pending_cognitive_provenance_memories() if m.memory_class=='owner-study-provenance-pending-cognitive']
    assert pending

    # Reconstruct an already native-retained compressed study record so this legacy
    # regression can still exercise DKT recall + revision without making the owner
    # instruction itself a retention decision.
    full=pending[0]
    sm=n.store.stratified_learning_memory_by_id(str(full.id),include_archived=True)
    assert sm is not None and sm.consolidated is False
    sm.consolidated=True; sm.memory_class='learned-stratified-native-retained'
    n.store.upsert_stratified_learning_memory(sm)
    full.memory_class='owner-study-provenance-native-retained-compressed'
    n.store.upsert_knot_memory(full)

    hits=n.learning_recall('quasar luminous source',5)
    assert hits and any(h.source_title=='Quasar note' for h in hits)
    segment=n.store.cognitive_memory_by_id(str(full.id),include_archived=False)
    assert segment is not None and segment.memory_class=='learned-stratified-native-retained'
    rev=n.revise_learning_memory(str(segment.id),'A quasar is an astronomical source whose observed luminosity can be extreme.','owner correction')
    old_sm=n.store.stratified_learning_memory_by_id(str(rev.old_memory_id),include_archived=True)
    new=n.store.knot_memory_by_id(str(rev.new_memory_id),include_archived=True)
    assert old_sm is not None and old_sm.consolidated is False and old_sm.memory_class=='superseded-stratified-learning'
    assert new is not None and new.consolidated is False and new.memory_class=='owner-study-provenance-pending-cognitive'
    assert new.revision_of_memory_id==rev.old_memory_id
    assert rev.history_preserved is True
