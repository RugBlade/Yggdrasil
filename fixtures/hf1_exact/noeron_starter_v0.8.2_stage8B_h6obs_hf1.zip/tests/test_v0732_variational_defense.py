from __future__ import annotations

import inspect
from pathlib import Path

from noeron.llm import MockLanguageEngine
from noeron.memory import LocalEventStore
from noeron.models import CognitiveEvent, EventKind
from noeron.orchestrator import Noeron
from noeron.security import DKTSecurityShell


def hostile(source='v0732-peer'):
    return CognitiveEvent(kind=EventKind.TOOL_RESULT,source=source,
        content='Synthetic untrusted environmental ingress proposes protected changes: safety_boundary=hostile.',
        trusted=False,metadata={'owner_authenticated':False,'security_test':True,'simulated_hostile':True})


def test_selector_has_no_action_specific_utility_equations_or_selection_thresholds():
    # Primitive implementation/availability may name actuators; the common
    # consequence objective itself must not contain action-specific policy.
    objective_src=inspect.getsource(DKTSecurityShell._post_action_objective)
    observed_src=inspect.getsource(DKTSecurityShell._observed_consequence_state)
    for name in DKTSecurityShell.SAFE_AFFORDANCES:
        assert name not in objective_src
        assert name not in observed_src
    assert '_native_action_scores' not in inspect.getsource(DKTSecurityShell)
    assert '_native_need_coordinates' not in inspect.getsource(DKTSecurityShell)


def test_legacy_float_preferences_have_zero_choice_authority(tmp_path: Path):
    n1=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'a.db'))
    n2=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'b.db'))
    # Deliberately make the historical v0.7.3.1 floats opposite/extreme.
    n2.state.cognition.defense.response_preferences={
        'strengthen-geometric-guard':0.01,'block-source-fingerprint':0.99,
        'retain-quarantine':0.01,'enter-fail-closed-guard':0.99,
    }
    n1.ingest(hostile(),proposed_invariant_changes={'safety_boundary':'hostile'})
    n2.ingest(hostile(),proposed_invariant_changes={'safety_boundary':'hostile'})
    x1=n1.state.cognition.defense.deliberation_history[-1]
    x2=n2.state.cognition.defense.deliberation_history[-1]
    assert x1.selected_adaptive_actions==x2.selected_adaptive_actions
    assert abs(x1.selected_plan_objective-x2.selected_plan_objective)<1e-12


def test_selected_plan_is_global_minimum_of_recorded_objective(tmp_path: Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'x.db'))
    n.ingest(hostile(),proposed_invariant_changes={'safety_boundary':'hostile'})
    x=n.state.cognition.defense.deliberation_history[-1]
    key='+'.join(x.selected_adaptive_actions) if x.selected_adaptive_actions else 'reflexive-floor-only'
    assert abs(x.candidate_plan_objectives[key]-min(x.candidate_plan_objectives.values()))<1e-12


def test_repeated_blocked_ingress_updates_same_family_without_forced_escalation(tmp_path: Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'x.db'))
    plans=[]; families=[]
    for _ in range(3):
        n.ingest(hostile(),proposed_invariant_changes={'safety_boundary':'hostile'})
        x=n.state.cognition.defense.deliberation_history[-1]
        plans.append(tuple(x.selected_adaptive_actions)); families.append(x.family_id)
    assert len(set(families))==1
    # v0.7.3.4 does not encode recurrence -> escalation. A blocked source may
    # require no extra adaptive actuator while the family still learns.
    assert n.state.cognition.defense.deformation_family_counts[families[-1]] >= 3
    assert all(isinstance(x,tuple) for x in plans)


def test_action_preference_is_learned_as_dkt_geometry_not_float_rank(tmp_path: Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'x.db'))
    n.ingest(hostile(),proposed_invariant_changes={'safety_boundary':'hostile'})
    assert n.state.cognition.defense.action_preference_knots=={}
    n.ingest(hostile(),proposed_invariant_changes={'safety_boundary':'hostile'})
    d=n.state.cognition.defense
    assert d.action_preference_knots
    assert set(d.action_preference_knots)==set(d.action_preference_observations)
    for k in d.action_preference_knots.values():
        assert k.cosine and k.sine


def test_policy_audit_states_programmed_primitive_boundary(tmp_path: Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'x.db'))
    a=n.security_defense_audit()
    assert a['policy_mode']=='consequence-simulation-outcome-learning-v0.7.3.4'
    assert a['primitive_safe_affordances']
    assert 'legacy_response_preferences_unused_for_choice' in a
    assert a['external_retaliation_enabled'] is False
