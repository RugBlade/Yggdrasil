from pathlib import Path
from noeron.llm import MockLanguageEngine
from noeron.memory import LocalEventStore
from noeron.models import CognitiveEvent,EventKind
from noeron.orchestrator import Noeron

def test_first_message_persists_dkt_provenance_without_forcing_cognitive_memory(tmp_path:Path):
    store=LocalEventStore(tmp_path/'x.db'); n=Noeron(MockLanguageEngine(),store)
    r=n.ingest(CognitiveEvent(kind=EventKind.USER_MESSAGE,source='u',content='Hello Yggdrasil, remember DKT and IRG.',trusted=True))
    assert r.state.cognition.knot_memory_count==0
    assert r.state.cognition.concept_graph_active is False
    pending=store.pending_cognitive_provenance_memories()
    assert len(pending)==1
    assert pending[0].knot.cosine
    assert pending[0].consolidated is False
    assert r.state.cognition.memory_retention.last_native_choice_claim is False
