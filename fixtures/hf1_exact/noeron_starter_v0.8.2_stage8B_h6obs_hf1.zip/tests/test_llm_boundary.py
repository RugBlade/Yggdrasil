from pathlib import Path

def test_math_and_native_cognition_cannot_call_llm():
    math_text='\n'.join(p.read_text() for p in Path('src/noeron/math').glob('*.py'))
    cognition=Path('src/noeron/cognition/kernel.py').read_text()
    learning=Path('src/noeron/learning.py').read_text()
    assert 'noeron.llm' not in math_text
    assert 'LanguageEngine' not in math_text
    assert 'noeron.llm' not in cognition
    assert 'noeron.llm' not in learning
    assert 'LanguageEngine' not in cognition
    assert 'LanguageEngine' not in learning
    assert '_intent(' not in cognition
    assert 'event.content.lower()' not in cognition
