from noeron.math.dkt import reference_knot,retract_to_admissible,regularity_margin

def test_dkt_rejects_uncommanded_stratum_transition():
    a=reference_knot(); b=a.model_copy(deep=True); b.stratum_index=1
    out,diag=retract_to_admissible(a,b)
    assert diag['retracted'] is True
    assert out.stratum_index==a.stratum_index

def test_reference_knot_is_regular():
    assert regularity_margin(reference_knot())>0.5
