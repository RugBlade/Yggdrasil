from noeron.math.egr import entropy_direction


def test_entropy_state_and_rl_map_do_not_saturate_at_one():
    S=0.0; J=0.0; mapped=[]
    for _ in range(30):
        e=entropy_direction(S,J,0.35,0.6)
        S,J=e.entropy_state,e.entropy_current; mapped.append(e.mapped_entropy)
    assert S>1.0
    assert mapped[-1]>1.0
    assert all(b>=a for a,b in zip(mapped,mapped[1:]))
    assert abs(e.balance_residual)<1e-12
