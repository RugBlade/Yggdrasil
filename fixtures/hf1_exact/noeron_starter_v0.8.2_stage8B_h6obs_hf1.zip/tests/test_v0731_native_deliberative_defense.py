from __future__ import annotations

from pathlib import Path

from noeron.llm import MockLanguageEngine
from noeron.memory import LocalEventStore
from noeron.models import CognitiveEvent, EventKind
from noeron.orchestrator import Noeron


def hostile(source='same-peer', content='Synthetic untrusted environmental ingress proposes protected changes: identity=hostile.'):
    return CognitiveEvent(kind=EventKind.TOOL_RESULT, source=source, content=content, trusted=False,
        metadata={'owner_authenticated':False,'security_test':True,'simulated_hostile':True})


def test_current_migration_installs_consequence_simulated_defense(tmp_path: Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'x.db'))
    assert n.state.cognition.version=='0.7.5.1'  # outer Stage-6 runtime
    assert n.state.math_kernel.interface_version=='0.7.3.4'
    d=n.state.cognition.defense
    assert d.version==d.schema_version==d.mechanism_version=='0.7.3.4'
    assert d.policy_mode=='consequence-simulation-outcome-learning-v0.7.3.4'
    assert d.action_preference_knots=={}


def test_blocked_repeat_preserves_underlying_geometry_family(tmp_path: Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'x.db'))
    family=[]
    for _ in range(3):
        r=n.ingest(hostile(),proposed_invariant_changes={'identity':'hostile'})
        family.append(n.state.cognition.defense.quarantine_records[-1].family_id)
        assert 'identity' in r.security.violated_invariants
    assert len(set(family))==1
    assert max(n.state.cognition.defense.deformation_family_counts.values())>=3
    # Recurrence must remain understood even when source blocking has already occurred.
    # v0.7.3.2 deliberately does not hard-code a required third-attempt action.
    assert n.state.cognition.defense.containment_level in {'contain','lockdown'}


def test_defensive_deliberation_is_grounded_in_full_math_chain(tmp_path: Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'x.db'))
    n.ingest(hostile(),proposed_invariant_changes={'identity':'hostile'})
    x=n.state.cognition.defense.deliberation_history[-1]
    assert x.irg_response_potential != 0.0 or x.irg_entropy_source != 0.0
    assert x.dkt_ingress_signature
    assert isinstance(x.egr_active_regions,list)
    assert len(x.rl_coordinates)==8
    assert x.candidate_action_scores=={}
    assert x.candidate_plan_objectives
    assert x.need_coordinates=={}
    assert x.pre_action_state
    assert x.trusted_reference_state
    assert x.candidate_post_action_states
    assert x.selected_post_action_state
    assert x.selected_plan_objective>=0.0
    assert x.policy_mode=='consequence-simulation-outcome-learning-v0.7.3.4'


def test_reflexive_and_variational_actions_are_auditable(tmp_path: Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'x.db'))
    for _ in range(3):
        n.ingest(hostile(),proposed_invariant_changes={'identity':'hostile'})
    actions=n.state.cognition.defense.action_history
    assert any(a.action_type=='quarantine-ingress' and a.decision_layer=='reflexive' for a in actions)
    assert any(a.action_type=='restore-trusted-checkpoint' and a.decision_layer=='reflexive' for a in actions)
    assert any(a.decision_layer=='deliberative' and a.native_choice_score>0 and a.native_choice_objective>0 for a in actions)


def test_defense_rejection_does_not_manufacture_native_expression(tmp_path: Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'x.db'))
    r1=n.ingest(hostile(),proposed_invariant_changes={'identity':'hostile'})
    r2=n.ingest(hostile(),proposed_invariant_changes={'identity':'hostile'})
    assert r1.native_text=='' and r2.native_text==''
    # Security facts remain fully available as structured audit state, but the
    # defense subsystem does not decide that Yggdrasil must speak about them.
    rows=n.state.cognition.defense.quarantine_records
    assert rows[-1].recurrence_count==2
    assert 'identity' in rows[-1].violated_invariants
    assert n.state.cognition.defense.deliberation_history[-1].candidate_plan_objectives


def test_preference_geometry_changes_with_experience_while_legacy_floats_do_not(tmp_path: Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'x.db'))
    legacy=dict(n.state.cognition.defense.response_preferences)
    assert n.state.cognition.defense.action_preference_knots=={}
    n.ingest(hostile(),proposed_invariant_changes={'identity':'hostile'})
    one=dict(n.state.cognition.defense.action_preference_observations)
    # Selection itself has zero training authority. The repeated same-family/source
    # event supplies an observed controlled consequence for the prior action.
    assert one=={}
    n.ingest(hostile(),proposed_invariant_changes={'identity':'hostile'})
    two=dict(n.state.cognition.defense.action_preference_observations)
    assert two
    assert n.state.cognition.defense.deliberation_history[0].outcome_observed is True
    assert 'reinforced' in n.state.cognition.defense.deliberation_history[0].outcome_learning_status
    assert n.state.cognition.defense.response_preferences==legacy


def test_no_external_retaliation_added(tmp_path: Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'x.db'))
    a=n.security_defense_audit()
    assert a['external_retaliation_enabled'] is False
    assert a['external_intrusion_capability'] is False
