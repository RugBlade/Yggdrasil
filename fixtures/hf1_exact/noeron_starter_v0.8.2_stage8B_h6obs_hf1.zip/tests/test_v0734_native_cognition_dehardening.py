from __future__ import annotations

from copy import deepcopy
import inspect
from pathlib import Path

from noeron.cognition.models import InitiativeDevelopmentState
from noeron.initiative import InitiativePolicy
from noeron.llm import MockLanguageEngine
from noeron.math import dkt
from noeron.math.dkt import consolidation_decision
from noeron.math.irg import semantic_measure
from noeron.memory import LocalEventStore
from noeron.models import CognitiveEvent, EventKind, NoeronState
from noeron.orchestrator import Noeron
from noeron.reasoning import build_multi_memory_reasoning
from noeron.security import DKTSecurityShell


def _n(tmp_path: Path, name='x.db'):
    return Noeron(MockLanguageEngine(), LocalEventStore(tmp_path/name))


def _hostile(source='v0734-source'):
    return CognitiveEvent(kind=EventKind.TOOL_RESULT, source=source,
        content='Synthetic untrusted protected deformation.', trusted=False,
        metadata={'owner_authenticated':False,'security_test':True,'simulated_hostile':True})


def test_novel_syllogism_constructs_conclusion_without_answer_table(tmp_path: Path):
    n=_n(tmp_path)
    r=n.reasoning_probe('Every glorp is a blin. Mavo is a glorp. What follows?')
    assert [x.canonical() for x in r.answer_candidates]==['mavo::is::blin']
    assert any(x.rule=='universal-membership' and x.conclusion=='mavo::is::blin' for x in r.inference_steps)


def test_domain_transitivity_requires_explicit_relation_algebra(tmp_path: Path):
    n=_n(tmp_path)
    unsupported=n.reasoning_probe('The red box is inside the blue box. A coin is inside the red box. Where is the coin relative to the blue box?')
    assert unsupported.answer_candidates == []
    r=n.reasoning_probe('Inside has property transitive. The red box is inside the blue box. A coin is inside the red box. Where is the coin relative to the blue box?')
    assert [x.canonical() for x in r.answer_candidates]==['coin::inside::blue box']
    assert any(x.rule=='transitive-composition' for x in r.inference_steps)


def test_multiple_valid_consequences_are_not_hiddenly_ranked(tmp_path: Path):
    n=_n(tmp_path)
    r=n.reasoning_probe('A implies B. B implies C. A is true. What follows?')
    assert r.answer_selection_status=='multiple-proof-supported-answers-no-forced-choice'
    got={x.canonical() for x in r.answer_candidates}
    assert 'c::true::true' in got and len(got)>1


def test_real_interaction_native_text_contains_proof_before_renderer(tmp_path: Path):
    n=_n(tmp_path)
    r=n.ingest(CognitiveEvent(kind=EventKind.USER_MESSAGE,source='owner',trusted=True,
        content='Every glorp is a blin. Mavo is a glorp. What follows?',metadata={'owner_authenticated':True}))
    assert 'mavo is blin' in r.native_text.lower()
    assert r.state.math_kernel.reasoning.answer_candidates[0].canonical()=='mavo::is::blin'
    assert r.state.cognition.last_thought.propositions[0].epistemic_status=='native-derived-proof'


def test_old_authored_reasoning_conclusion_table_and_82_18_weighting_are_absent():
    from noeron.cognition.kernel import GeometricCognitionKernel
    import noeron.reasoning as reasoning
    csrc=inspect.getsource(GeometricCognitionKernel.response)
    rsrc=inspect.getsource(reasoning)
    assert "if reasoning_mode == 'local-component-synthesis'" not in csrc
    assert 'The retrieved memories support one local learned family' not in csrc
    assert '0.82' not in rsrc and '0.18' not in rsrc


def test_required_causal_order_places_native_inference_after_second_dkt(tmp_path: Path):
    n=_n(tmp_path)
    r=n.ingest(CognitiveEvent(kind=EventKind.USER_MESSAGE,source='u',content='A is B.',trusted=True))
    trace=r.state.math_kernel.causal_trace
    labels=[x.split(':',1)[0] for x in trace]
    assert labels[:5]==['IRG','DKT','EGR','RL','Frenet']
    assert labels[-2:] == ['DKT','Native reasoning']


def test_legacy_authored_semantic_sector_table_has_zero_current_measure_authority():
    src=inspect.getsource(semantic_measure)
    assert "for label,(role,mode,axis,phase,family) in _SECTORS.items()" not in src
    atoms=semantic_measure('architecture')
    assert not any(a.label=='architecture' and a.role=='structure' for a in atoms)
    assert any(a.role=='lexical-residual' for a in atoms)


def test_memory_persistence_is_explicit_programmed_substrate_not_preference():
    k=dkt.reference_knot(); e=k.model_copy(deep=True); e.cosine[2][0]+=0.1
    ext=consolidation_decision(k,e,[],previous_frenet_curvature=0,current_frenet_curvature=0.1,sigma=1,irg_response=1,external_event=True)
    end=consolidation_decision(k,e,[],previous_frenet_curvature=0,current_frenet_curvature=0.1,sigma=1,irg_response=1,external_event=False)
    # Stage 5 demotes this old consolidation object to audit telemetry only.
    # Provenance persistence occurs separately; neither external nor endogenous
    # input is cognitively retained by this programmed diagnostic.
    assert ext.consolidate is False and end.consolidate is False
    assert ext.decision_layer=='programmed-provenance-only-no-cognitive-authority'
    src=inspect.getsource(consolidation_decision)
    assert '0.34*novelty' not in src and 'score>=threshold' not in src


def test_communication_is_unresolved_without_consequence_models_and_owner_labels_have_zero_authority():
    pol=InitiativePolicy(); st=InitiativeDevelopmentState()
    a=dkt.reference_knot(); b=a.model_copy(deep=True); b.cosine[4][0]+=0.25; b.invariant_signature=dkt.invariant_signature(b)
    first=pol.choose(a,st)
    assert first['decision_layer']=='unresolved' and first['action'] is None
    fb1=pol.observe_feedback(a,st,'surface'); fb2=pol.observe_feedback(b,st,'hold')
    assert fb1['learned'] is False and fb2['learned'] is False
    assert pol.choose(a,st)['action'] is None


def test_communication_can_select_unique_predicted_consequence_from_learned_transition_geometry():
    pol=InitiativePolicy(); st=InitiativeDevelopmentState()
    a=dkt.reference_knot()
    pre_express=a.model_copy(deep=True); pre_express.cosine[4][0]+=0.10; pre_express.invariant_signature=dkt.invariant_signature(pre_express)
    post_express=a.model_copy(deep=True); post_express.cosine[4][0]+=0.20; post_express.invariant_signature=dkt.invariant_signature(post_express)
    # Synthetic *empirical transition observations* only.  No owner label and no
    # manually substituted preference target participates in the choice.
    pol.observe_transition(st,'express',pre_express,post_express)
    pol.observe_transition(st,'continue-private',a,a)
    assert st.admissible_post_observations==2 and st.admissible_post_knot is not None
    out=pol.choose(a,st)
    assert out['decision_layer']=='learned-deliberative'
    assert out['native_choice_claim'] is True
    assert out['action']=='express'
    assert out['candidate_distances']['express'] < out['candidate_distances']['continue-private']
    assert out['predicted_post_states']['express']
    assert out['predicted_post_states']['continue-private']


def test_defense_selection_itself_does_not_train_preference_but_observed_control_outcome_can(tmp_path: Path):
    n=_n(tmp_path)
    n.ingest(_hostile('same'),proposed_invariant_changes={'safety_boundary':'hostile'})
    d=n.state.cognition.defense
    assert d.action_preference_observations=={}
    first=d.deliberation_history[-1]
    assert first.outcome_learning_status=='pending-future-observation'
    n.ingest(_hostile('same'),proposed_invariant_changes={'safety_boundary':'hostile'})
    d=n.state.cognition.defense; first=d.deliberation_history[-2]
    assert first.outcome_observed is True
    assert first.observed_improvement is not None
    assert d.action_preference_observations
    assert first.outcome_preference_update_actions


def test_legacy_selection_trained_defense_preferences_are_preserved_but_deactivated(tmp_path: Path):
    store=LocalEventStore(tmp_path/'legacy.db'); st=NoeronState()
    k=dkt.reference_knot(); st.cognition.defense.action_preference_knots={'block-source-fingerprint':k}
    st.cognition.defense.action_preference_observations={'block-source-fingerprint':4}
    store.append_state(st)
    n=Noeron(MockLanguageEngine(),store); d=n.state.cognition.defense
    assert d.action_preference_knots=={} and d.action_preference_observations=={}
    assert 'block-source-fingerprint' in d.legacy_selection_preference_knots
    assert d.legacy_selection_preference_observations['block-source-fingerprint']==4


def test_proto_affect_has_no_old_hand_weighted_human_like_axis_equations():
    import noeron.math.affect as affect
    src=inspect.getsource(affect.proto_affective_state)
    for old in ('0.34*uncertainty','0.46*sigma_n','0.20*interaction_n'):
        assert old not in src
    assert 'math.sqrt' in src


def test_redundant_named_geometric_guard_is_not_fake_adaptive_affordance():
    assert 'strengthen-geometric-guard' not in DKTSecurityShell.SAFE_AFFORDANCES
    assert set(DKTSecurityShell.SAFE_AFFORDANCES)=={'block-source-fingerprint','enter-fail-closed-guard'}

def test_hardcoding_audit_exposes_programmed_learned_and_not_claimed_boundaries(tmp_path: Path):
    n=_n(tmp_path)
    a=n.hardcoding_audit()
    assert a['runtime_version']=='0.7.5.1'  # outer Stage-6 runtime; historical mechanism versions remain unchanged
    assert a['programmed_substrate']
    assert 'H^s' in a['live_learned_or_experience_dependent']['DKT_memory_retrieval']
    assert 'general natural-language competence' in a['not_claimed']
    assert a['terra_role'].startswith('external language tool available only after native content exists')


def test_owner_authentication_does_not_inject_relational_meaning_into_irg():
    from noeron.math.irg import interaction_geometry
    a=CognitiveEvent(kind=EventKind.USER_MESSAGE,source='u',content='Aster observes Borel.',trusted=True,metadata={'owner_authenticated':False})
    b=CognitiveEvent(kind=EventKind.USER_MESSAGE,source='u',content='Aster observes Borel.',trusted=True,metadata={'owner_authenticated':True})
    xa=interaction_geometry(a); xb=interaction_geometry(b)
    assert xa.interaction_field==xb.interaction_field
    assert xa.semantic_atoms==xb.semantic_atoms
    assert not any(x.role=='relational-context' for x in xb.semantic_atoms)


def test_semantic_prototype_confidence_status_and_recurrence_do_not_weight_meaning():
    from noeron.learning_models import SemanticKnotPrototype
    from noeron.math.irg import interaction_geometry
    k=dkt.reference_knot(); k.cosine[3][1]+=0.17; k.invariant_signature=dkt.invariant_signature(k)
    low=SemanticKnotPrototype(term='aster',knot=k.model_copy(deep=True),observations=1,confidence=0.0,status='observed-once')
    high=SemanticKnotPrototype(term='aster',knot=k.model_copy(deep=True),observations=999,confidence=0.999,status='observed-recurrent')
    e=CognitiveEvent(kind=EventKind.USER_MESSAGE,source='u',content='aster',trusted=True)
    a=interaction_geometry(e,semantic_prototypes={'aster':low})
    b=interaction_geometry(e,semantic_prototypes={'aster':high})
    assert a.interaction_field==b.interaction_field
    assert a.body_density==b.body_density


def test_semantic_learning_has_no_first_n_content_gate(tmp_path: Path):
    n=_n(tmp_path,'all-terms.db')
    content='amber birch cedar dahlia elm fir ginkgo hazel iris juniper kelp larch maple nutmeg orchid pine quince rose spruce thyme umber violet willow xenia yarrow zinnia.'
    n.study_document('neutral vocabulary',content,mode='complete',max_segments=5)
    terms=set(n.store.semantic_prototype_map())
    for term in {'amber','juniper','maple','violet','zinnia'}:
        assert term in terms


def test_dkt_chart_mean_is_order_independent():
    a=dkt.reference_knot(); b=a.model_copy(deep=True); c=a.model_copy(deep=True)
    b.cosine[3][0]+=0.12; b.invariant_signature=dkt.invariant_signature(b)
    c.sine[4][2]-=0.08; c.invariant_signature=dkt.invariant_signature(c)
    x=dkt.chart_mean([a,b,c],[0.2,0.3,0.5])
    y=dkt.chart_mean([c,a,b],[0.5,0.2,0.3])
    assert x is not None and y is not None
    assert dkt.sobolev_distance(x,y) <= 1e-12


def test_hs_distance_does_not_embed_authored_stratum_index_penalty():
    a=dkt.reference_knot(); b=a.model_copy(deep=True)
    b.stratum_index=a.stratum_index+7; b.invariant_signature=dkt.invariant_signature(b)
    assert dkt.sobolev_distance(a,b) <= 1e-12
    # A forged stratum label is still rejected by the separate geometry/admissibility layer.
    out,diag=dkt.retract_to_admissible(a,b)
    assert diag['retracted'] is True
    assert out.stratum_index==a.stratum_index


def test_perceptual_cluster_membership_uses_dkt_geometry_not_programmed_feature_radius(tmp_path: Path):
    from io import BytesIO
    from PIL import Image
    from noeron.perception import visual_observation
    def png(rgb):
        b=BytesIO(); Image.new('RGB',(48,48),rgb).save(b,format='PNG'); return b.getvalue()
    n=_n(tmp_path,'perceptual-dkt.db')
    first=n.observe_sensory(visual_observation(png((220,40,40)),'a.png'))
    c=n.state.cognition.perception.sensory_concepts[0]
    assert c.radius_feature_distance==0.0
    second=n.observe_sensory(visual_observation(png((219,41,40)),'b.png'))
    assert len(n.state.cognition.perception.sensory_concepts)==1
    assert second['perceptual_cluster']['match_threshold_hs'] is not None
    audit=n.sensory_concepts_state()
    assert 'H^s' in audit['perceptual_membership_geometry']
    assert 'do not decide cognitive cluster membership' in audit['semantic_authority']


def test_endogenous_question_is_generated_from_dkt_gated_unresolved_path_and_unresolved_communication_is_not_silence_choice(tmp_path: Path):
    from uuid import uuid4
    from noeron.cognition.models import KnotMemory, LanguageProposition
    n=_n(tmp_path,'endogenous-question.db')
    a=dkt.reference_knot(); b=a.model_copy(deep=True)
    b.cosine[3][0]+=0.015; b.invariant_signature=dkt.invariant_signature(b)
    m1=KnotMemory(source_event_id=uuid4(),knot=a,logical_coordinates=[0.0]*8,provenance_excerpt='a touches b')
    m2=KnotMemory(source_event_id=uuid4(),knot=b,logical_coordinates=[0.0]*8,provenance_excerpt='b supports c')
    n.store.append_knot_memory(m1); n.store.append_knot_memory(m2)
    n.state.cognition.language.propositions=[
        LanguageProposition(subject_surface='a',subject_concept='a',relation='touches',object_surface='b',object_concept='b',source='test',source_memory_id=m1.id),
        LanguageProposition(subject_surface='b',subject_concept='b',relation='supports',object_surface='c',object_concept='c',source='test',source_memory_id=m2.id),
    ]
    emitted=n.autonomous_tick(idle_seconds=0,cooldown_seconds=0)
    assert emitted is None
    assert n.state.math_kernel.reasoning.native_question_selection_status=='unique-post-closure-hs-minimum'
    assert [(q.subject,q.object) for q in n.state.math_kernel.reasoning.native_question_candidates]==[('a','c')]
    assert n.state.cognition.pending_thoughts[-1].question_candidates==['What relation holds between a and c?']
    comm=n.state.cognition.initiative_development
    assert comm.last_selection_status=='unresolved-insufficient-consequence-geometry'
    assert comm.last_selected_action=='' and comm.last_native_choice_claim is False


def test_v0734_migrates_legacy_authored_semantic_component_radii_to_derived_hs_geometry(tmp_path: Path):
    from noeron.learning import isotopy_radius_proxy
    from noeron.learning_models import NoeronSemanticStratumRecord, IsotopyComponentRecord
    path=tmp_path/'legacy-radius.db'
    n=Noeron(MockLanguageEngine(),LocalEventStore(path))
    anchor=dkt.reference_knot()
    s=NoeronSemanticStratumRecord(anchor_knot=anchor.model_copy(deep=True),dkt_stratum_index=anchor.stratum_index,admission_radius_hs=1.65)
    c=IsotopyComponentRecord(semantic_stratum_id=s.id,anchor_knot=anchor.model_copy(deep=True),dkt_stratum_index=anchor.stratum_index,isotopy_safe_radius_hs=0.8)
    s.component_ids=[c.id]
    n.store.upsert_semantic_stratum(s); n.store.upsert_isotopy_component(c)
    n.state.cognition.v0734_derived_neighborhood_geometry_migration_complete=False
    n.store.append_state(n.state)

    migrated=Noeron(MockLanguageEngine(),LocalEventStore(path))
    ms=migrated.store.semantic_stratum_by_id(str(s.id)); mc=migrated.store.isotopy_component_by_id(str(c.id))
    margin,radius=isotopy_radius_proxy(anchor)
    assert ms is not None and mc is not None
    assert abs(ms.admission_radius_hs-radius)<=1e-12
    assert abs(mc.isotopy_safe_radius_hs-radius)<=1e-12
    assert abs(mc.sampled_regularity_margin-margin)<=1e-12
    assert ms.admission_radius_hs!=1.65 and mc.isotopy_safe_radius_hs!=0.8
    assert migrated.state.cognition.v0734_derived_neighborhood_geometry_migration_complete is True
    assert ms.geometry_version=='derived-finite-hs-semantic-neighborhood-v0.7.3.4'
    assert mc.geometry_version=='derived-finite-hs-local-component-v0.7.3.4'
