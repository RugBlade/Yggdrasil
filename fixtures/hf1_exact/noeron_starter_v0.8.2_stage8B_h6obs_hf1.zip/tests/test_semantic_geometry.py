from pathlib import Path
from noeron.math import dkt
from noeron.math.irg import interaction_geometry
from noeron.models import CognitiveEvent,EventKind


def ev(text):return CognitiveEvent(kind=EventKind.USER_MESSAGE,source='u',content=text,trusted=True)


def test_unlearned_synonyms_do_not_receive_authored_semantic_equivalence():
    a=dkt.experience_knot(interaction_geometry(ev('remember memory')))
    b=dkt.experience_knot(interaction_geometry(ev('recall history')))
    # Without learned DKT prototypes there is no hand-authored synonym ontology
    # entitled to force these phrases into one semantic neighborhood.
    assert a.invariant_signature != '' and b.invariant_signature != ''

def test_surface_question_does_not_receive_authored_semantic_request_dimensions():
    x=interaction_geometry(ev('Tell me what you remember from before, what your current state is, and what you can determine from your reasoning.'))
    assert x.request_dimensions==[]
    assert x.query_targets==[]
    assert set(x.dialogue_acts).issubset({'surface-question','surface-statement'})


def test_irg_source_has_no_hash_semantic_mapping():
    text=Path('src/noeron/math/irg.py').read_text()
    assert 'hashlib' not in text
    assert 'sha256' not in text
    assert 'SemanticAtom' in text
