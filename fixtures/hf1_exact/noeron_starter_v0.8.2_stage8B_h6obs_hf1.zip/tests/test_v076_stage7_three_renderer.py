from __future__ import annotations

import ast
import importlib
import os
from pathlib import Path
import shutil
import sys

import pytest
from starlette.requests import Request

from noeron import renderer as renderer_module

ROOT=Path(__file__).resolve().parents[1]


def _request(client_host: str = "127.0.0.1") -> Request:
    return Request({
        "type":"http","http_version":"1.1","method":"GET","scheme":"http",
        "path":"/room/vendor/three-r185/build/three.module.js",
        "raw_path":b"/room/vendor/three-r185/build/three.module.js",
        "query_string":b"","headers":[],"client":(client_host,43210),
        "server":("127.0.0.1",8741),"root_path":"",
    })


def test_01_exact_vendored_three_r185_material_verifies():
    manifest=renderer_module.verify_vendor_material()
    assert manifest["package"]=="three"
    assert manifest["version"]=="0.185.1"
    assert manifest["upstream_tag"]=="r185"
    assert manifest["license"]=="MIT"
    assert manifest["runtime_public_network_dependency"] is False


def test_02_tampered_vendor_byte_fails_closed(tmp_path,monkeypatch):
    copied=tmp_path/"three-r185"
    shutil.copytree(renderer_module.THREE_VENDOR_ROOT,copied)
    target=copied/"build/three.module.js"
    target.write_bytes(target.read_bytes()+b"\n// tampered\n")
    monkeypatch.setattr(renderer_module,"THREE_VENDOR_ROOT",copied)
    with pytest.raises(renderer_module.RendererIntegrityError,match="size mismatch|SHA-256 mismatch|Git blob mismatch"):
        renderer_module.verify_vendor_material()


def test_03_browser_asset_allowlist_rejects_license_and_traversal():
    with pytest.raises(renderer_module.RendererIntegrityError,match="not allowed"):
        renderer_module.read_three_browser_asset("LICENSE")
    with pytest.raises(renderer_module.RendererIntegrityError,match="not allowed"):
        renderer_module.read_three_browser_asset("../../etc/passwd")


def test_04_renderer_descriptor_has_presentation_authority_only():
    d=renderer_module.renderer_substrate_descriptor()
    assert d["backend"]=="three.js" and d["version"]=="0.185.1"
    assert d["local_vendored"] is True and d["runtime_public_network_dependency"] is False
    assert d["asset_integrity_enforced_on_read"] is True
    assert d["cognitive_authority"] is False
    assert d["embodiment_choice_authority"] is False
    assert d["environment_choice_authority"] is False
    assert d["morphology_template_authority"] is False


def test_05_room_html_uses_only_local_three_and_has_no_2d_or_named_shape_fallback():
    src=(ROOT/"src/noeron/api.py").read_text()
    assert "await import('/room/vendor/three-r185/build/three.module.js')" in src
    assert "new THREE.WebGLRenderer" in src
    assert "new THREE.BufferGeometry" in src
    assert "new THREE.Points(" in src
    renderer_slice=src[src.index('function neutralCoordinates'):src.index('async function post')]
    assert "getContext('2d')" not in renderer_slice and 'getContext("2d")' not in renderer_slice
    # v0.7.6.1 may use an owner-side 2-D canvas only to capture a camera frame;
    # that capture substrate is not an embodiment/environment renderer fallback.
    for forbidden in ("THREE.SphereGeometry","THREE.BoxGeometry","THREE.CapsuleGeometry","THREE.ConeGeometry","THREE.CylinderGeometry","GLTFLoader"):
        assert forbidden not in src
    assert "cdn.jsdelivr" not in src and "unpkg.com" not in src


def test_06_zero_or_absent_visible_configuration_creates_no_body_object():
    src=(ROOT/"src/noeron/api.py").read_text()
    assert "if(!THREE||!config||config.visible===false)return null" in src
    assert "no fallback body is fabricated" in src
    assert "presentation_substrate_only:true" in src


def test_07_renderer_asset_route_is_room_scoped_and_auth_precedes_read():
    src=(ROOT/"src/noeron/api.py").read_text();tree=ast.parse(src)
    fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=="room_three_r185_asset")
    assert isinstance(fn.decorator_list[0],ast.Call)
    assert fn.decorator_list[0].args[0].value=="/room/vendor/three-r185/{asset_path:path}"
    first=fn.body[0]
    assert isinstance(first,ast.Expr) and isinstance(first.value,ast.Call)
    assert isinstance(first.value.func,ast.Name) and first.value.func.id=="_room_auth"
    text=ast.get_source_segment(src,fn) or ""
    assert text.index("_room_auth(request)") < text.index("read_three_browser_asset(asset_path)")


@pytest.fixture(scope="module")
def api_module(tmp_path_factory):
    old_db=os.environ.get("NOERON_DB_PATH")
    db=tmp_path_factory.mktemp("room-three-renderer")/"renderer.sqlite3"
    os.environ["NOERON_DB_PATH"]=str(db)
    sys.modules.pop("noeron.api",None)
    module=importlib.import_module("noeron.api")
    try:
        yield module
    finally:
        try:
            module.store._connection.commit();module.store._connection.close()
        except Exception:
            pass
        sys.modules.pop("noeron.api",None)
        if old_db is None: os.environ.pop("NOERON_DB_PATH",None)
        else: os.environ["NOERON_DB_PATH"]=old_db


def test_08_authenticated_asset_route_serves_exact_verified_module(api_module,monkeypatch):
    monkeypatch.setattr(api_module,"_room_auth",lambda request:{"authenticated":True,"method":"ed25519-device-session"})
    response=api_module.room_three_r185_asset("build/three.module.js",_request())
    expected=(renderer_module.THREE_VENDOR_ROOT/"build/three.module.js").read_bytes()
    assert response.status_code==200 and response.body==expected
    assert response.headers["content-type"].startswith("text/javascript")
    assert "default-src 'none'" in response.headers["content-security-policy"]


def test_09_asset_integrity_error_returns_503_not_unverified_bytes(api_module,monkeypatch):
    monkeypatch.setattr(api_module,"_room_auth",lambda request:{"authenticated":True,"method":"ed25519-device-session"})
    def fail(_): raise renderer_module.RendererIntegrityError("tampered")
    monkeypatch.setattr(api_module,"read_three_browser_asset",fail)
    from fastapi import HTTPException
    with pytest.raises(HTTPException) as exc:
        api_module.room_three_r185_asset("build/three.module.js",_request())
    assert exc.value.status_code==503


def test_10_csp_allows_same_origin_module_but_remains_default_deny():
    src=(ROOT/"src/noeron/api.py").read_text()
    assert "default-src 'none'" in src
    assert "script-src 'self' 'unsafe-inline'" in src
    assert "object-src 'none'" in src and "base-uri 'none'" in src
