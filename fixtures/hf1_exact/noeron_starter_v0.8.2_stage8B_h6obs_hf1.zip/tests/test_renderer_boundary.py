from noeron.cognition.renderer import LanguageRenderer,RENDERER_SYSTEM_PROMPT
class E:
    def __init__(self):self.messages=None
    def generate(self,messages):self.messages=messages; return messages[-1]['content'].split('NOERON_OUTPUT:\n',1)[1]
def test_only_final_output_reaches_renderer():
    e=E(); r=LanguageRenderer(e); out=r.render('A native mathematical conclusion.'); assert out=='A native mathematical conclusion.'
    assert len([m for m in e.messages if m['role']=='system'])==1
    assert 'without adding information' in RENDERER_SYSTEM_PROMPT
