from __future__ import annotations

from pathlib import Path
from uuid import uuid4

from noeron.cognition.models import KnotMemory
from noeron.llm import MockLanguageEngine
from noeron.math import dkt
from noeron.memory import LocalEventStore
from noeron.models import NoeronState
from noeron.orchestrator import Noeron


def test_stage5_migration_preserves_legacy_active_memory_but_does_not_claim_native_retention(tmp_path:Path):
    store=LocalEventStore(tmp_path/'migration.sqlite3')
    old=NoeronState()
    old.cognition.version='0.7.3.4'
    old.cognition.v074_stage5_migration_complete=False
    old.cognition.owner_relation.familiarity=0.42
    old.cognition.owner_relation.note='STALE PRE-STAGE5 RELATIONAL NOTE'
    store.append_state(old)
    mem=KnotMemory(source_event_id=uuid4(),knot=dkt.reference_knot(),consolidated=True,
        memory_class='episodic',geometry_version='semantic-irg-dkt-v0.7.3.4',
        provenance_excerpt='pre-v0.7.4 active memory')
    store.append_knot_memory(mem)

    n=Noeron(MockLanguageEngine(),store)
    c=n.state.cognition;ret=c.memory_retention;rel=c.owner_relation
    assert c.version=='0.7.5.1'  # outer runtime migrated prospectively to Stage 6
    assert c.v074_stage5_migration_complete is True
    assert mem.id in ret.legacy_pre_v074_active_memory_ids
    assert ret.legacy_pre_v074_active_memory_count==1
    assert mem.id not in ret.native_retained_memory_ids
    assert store.knot_memory_by_id(str(mem.id)).consolidated is True
    assert rel.familiarity==0.0
    assert rel.legacy_programmed_familiarity_value==0.42
    assert rel.note!='STALE PRE-STAGE5 RELATIONAL NOTE'
    assert 'no familiarity/closeness/emotion formula has causal authority' in rel.note


def test_stage5_hardcoding_audit_exposes_retention_relationship_and_terra_boundaries(tmp_path:Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'audit.sqlite3'))
    a=n.hardcoding_audit()
    assert a['runtime_version']=='0.7.5.1'  # audit reports current outer release
    assert 'cognitive_memory' in a['choice_claim_rules']
    assert 'realization_tool' in a['choice_claim_rules']
    assert 'relationship' in a['choice_claim_rules']
    assert 'lexical coverage has zero invocation authority' in a['choice_claim_rules']['realization_tool']
    assert a['owner_auth_role'].endswith('zero relational valence/meaning authority')
    assert 'automatic lexical-coverage invocation removed' in a['terra_role']
    assert any('provenance persistence' in x for x in a['programmed_substrate'])


def test_stage5_migration_initializes_existing_pending_provenance_without_promoting_it(tmp_path:Path):
    store=LocalEventStore(tmp_path/'pending.sqlite3')
    old=NoeronState();old.cognition.v074_stage5_migration_complete=False;store.append_state(old)
    mem=KnotMemory(source_event_id=uuid4(),knot=dkt.reference_knot(),consolidated=False,
        memory_class='event-provenance-pending-cognitive',geometry_version='semantic-irg-dkt-v0.7.4-provenance')
    store.append_knot_memory(mem)
    n=Noeron(MockLanguageEngine(),store)
    assert mem.id in n.state.cognition.memory_retention.pending_provenance_memory_ids
    assert store.knot_memory_by_id(str(mem.id),include_archived=True).consolidated is False


def test_math_registry_and_hardcoding_audit_describe_stage5_authority_boundaries(tmp_path:Path):
    from noeron.math.kernel import MathematicalCognitiveKernel
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'registry.sqlite3'))
    reg=MathematicalCognitiveKernel.registry();audit=n.hardcoding_audit()
    assert reg['interface_version']=='0.7.3.4'  # unchanged inner mathematical mechanism
    assert 'native retention' in reg['stage5_outer_selection']
    assert 'lexical coverage has zero invocation authority' in reg['llm_role']
    assert 'equal mass' in audit['choice_claim_rules']['communication']
    assert 'action-frequency' in audit['choice_claim_rules']['realization_tool']
