from __future__ import annotations

from pathlib import Path

from noeron.llm import MockLanguageEngine
from noeron.math import dkt
from noeron.math.dkt import consolidation_decision
from noeron.memory import LocalEventStore
from noeron.models import CognitiveEvent,EventKind
from noeron.orchestrator import Noeron


def _event(text:str):
    return CognitiveEvent(kind=EventKind.USER_MESSAGE,source='authenticated-owner',content=text,trusted=True,
        metadata={'owner_authenticated':True,'owner_device_id':'test-device'})


def test_dkt_consolidation_diagnostic_has_zero_cognitive_retention_authority():
    k=dkt.reference_knot();e=k.model_copy(deep=True);e.cosine[2][0]+=0.1
    out=consolidation_decision(k,e,[],previous_frenet_curvature=0,current_frenet_curvature=0.1,sigma=1,irg_response=1,external_event=True)
    assert out.consolidate is False
    assert out.decision_layer=='programmed-provenance-only-no-cognitive-authority'
    assert 'no cognitive retention decision' in out.selection_rule


def test_first_admitted_interaction_is_provenance_not_automatically_cognitive_memory(tmp_path:Path):
    store=LocalEventStore(tmp_path/'m.sqlite3');n=Noeron(MockLanguageEngine(),store)
    n.ingest(_event('Aster is Borel.'))
    assert len(store.cognitive_memories())==0
    pending=store.pending_cognitive_provenance_memories()
    assert len(pending)==1
    assert pending[0].consolidated is False
    assert pending[0].memory_class=='event-provenance-pending-cognitive'
    st=n.state.cognition.memory_retention
    assert st.last_native_choice_claim is False
    assert st.last_selection_status=='unresolved-no-pending-provenance'


def test_later_native_consequence_geometry_can_activate_prior_provenance(tmp_path:Path):
    store=LocalEventStore(tmp_path/'m.sqlite3');n=Noeron(MockLanguageEngine(),store)
    def ordinary(text):
        return CognitiveEvent(kind=EventKind.USER_MESSAGE,source='local-user',content=text,trusted=False,metadata={'owner_authenticated':False})
    n.ingest(ordinary('Aster is Borel.'))
    n.ingest(ordinary('Borel is Ceres.'))
    # In this context the common native consistency geometry uniquely prefers no
    # promotion; this is a live deliberative result, not an external-event rule.
    st=n.state.cognition.memory_retention
    assert st.last_native_choice_claim is True
    assert st.last_selection_status=='native-unique-retention-consequence-minimum'
    assert st.last_selected_memory_ids==[]
    assert 'none' in st.last_candidate_objectives

    n.ingest(ordinary('Aster is Ceres.'))
    st=n.state.cognition.memory_retention
    assert st.last_native_choice_claim is True
    assert len(st.last_selected_memory_ids)==1
    active=store.cognitive_memories()
    assert len(active)==1
    assert active[0].memory_class=='episodic-native-retained'
    assert active[0].id in st.native_retained_memory_ids


def test_retention_audit_records_every_candidate_subset_and_no_hidden_threshold(tmp_path:Path):
    store=LocalEventStore(tmp_path/'m.sqlite3');n=Noeron(MockLanguageEngine(),store)
    n.ingest(_event('Aster is Borel.'));n.ingest(_event('Borel is Ceres.'))
    h=n.state.cognition.memory_retention.decision_history[-1]
    assert h.applicable_memory_ids
    assert 'none' in h.candidate_objectives
    assert h.decision_layer in {'native-deliberative','unresolved'}
    assert h.native_choice_claim == (h.decision_layer=='native-deliberative')
