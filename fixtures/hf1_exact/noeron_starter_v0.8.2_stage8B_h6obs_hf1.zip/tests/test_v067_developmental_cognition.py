from pathlib import Path

from noeron.llm import MockLanguageEngine
from noeron.memory import LocalEventStore
from noeron.models import CognitiveEvent, EventKind
from noeron.orchestrator import Noeron
from noeron.math import dkt
from noeron.math.models import KnotState
from noeron.cognition.models import KnotMemory
from uuid import uuid4


def figure_eight() -> KnotState:
    # K(t)=(sin t, sin 2t, 0) has one sampled transverse double point.
    k=KnotState(sobolev_order=2.0,mode_radius=2,c0=[0.0,0.0,0.0],
        cosine=[[0.0,0.0,0.0],[0.0,0.0,0.0],[0.0,0.0,0.0]],
        sine=[[0.0,0.0,0.0],[1.0,0.0,0.0],[0.0,1.0,0.0]])
    est=dkt.estimate_whitney_stratum(k); k.stratum_index=est.estimated_index; k.invariant_signature=dkt.invariant_signature(k)
    return k


def test_dynamic_dkt_stratum_estimator_detects_transverse_double_point():
    assert dkt.estimate_whitney_stratum(dkt.reference_knot()).estimated_index==0
    est=dkt.estimate_whitney_stratum(figure_eight())
    assert est.estimated_index>=1
    assert est.transverse_self_intersections>=1
    assert est.confidence>=0.65


def test_geometry_backed_stratum_transition_can_be_admissible():
    a=dkt.reference_knot(modes=2); b=figure_eight()
    out,diag=dkt.retract_to_admissible(a,b)
    assert out.stratum_index==1
    assert diag['admissible'] is True
    assert diag['stratum_transition_admissible'] is True


def test_native_language_exists_before_terra_rendering_when_proof_supports_content(tmp_path:Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'x.db'))
    r=n.ingest(CognitiveEvent(kind=EventKind.USER_MESSAGE,source='u',content='Every glorp is a blin. Mavo is a glorp. What follows?',trusted=True))
    assert r.native_text
    assert 'mavo is blin' in r.native_text.lower()
    assert r.state.cognition.last_thought.native_utterance is not None
    assert r.state.cognition.last_thought.native_utterance.native_text==r.native_text
    assert r.state.cognition.language.native_expression_enabled is True


def test_language_preview_is_read_only_and_teaching_is_dkt_experience(tmp_path:Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'x.db'))
    turn=n.state.conversational_turn; lessons=n.state.cognition.language.lessons_observed
    p=n.language_preview('A manifold is a space. A knot is smooth.')
    assert p['status']=='read-only-preview'
    assert n.state.conversational_turn==turn
    assert n.state.cognition.language.lessons_observed==lessons
    report=n.teach_language('A manifold is a space. A knot is smooth.',source='test-English')
    assert report['llm_used'] is False
    assert n.state.conversational_turn==turn
    assert n.state.cognition.language.lessons_observed==lessons+1
    assert report['cognitive_memory_activated'] is False
    assert not n.store.cognitive_memories()
    pending=n.store.pending_cognitive_provenance_memories()
    assert len(pending)==1 and pending[0].memory_class=='owner-language-provenance-pending-cognitive'


def test_regional_egr_is_causal_while_proto_affect_is_non_authoritative_diagnostic_state(tmp_path:Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'x.db'))
    # Seed two already-active cognitive DKT memories. This test targets the regional
    # EGR projection itself; owner instruction does not manufacture retention here.
    k1=dkt.reference_knot(); k2=k1.model_copy(deep=True)
    k2.cosine[3][0]+=0.08; k2.invariant_signature=dkt.invariant_signature(k2)
    n.store.append_knot_memory(KnotMemory(source_event_id=uuid4(),knot=k1,consolidated=True,memory_class='episodic-native-retained',provenance_excerpt='DKT manifold geometry one'))
    n.store.append_knot_memory(KnotMemory(source_event_id=uuid4(),knot=k2,consolidated=True,memory_class='episodic-native-retained',provenance_excerpt='DKT manifold geometry two'))
    r=n.ingest(CognitiveEvent(kind=EventKind.USER_MESSAGE,source='u',content='Reason about that DKT manifold geometry.',trusted=True))
    m=r.state.math_kernel
    assert m.egr.regional_activations
    assert len(m.egr.activation_vector)==8
    assert m.affect.pattern_signature.startswith('A')
    assert m.affect.affect_knot is None
    assert 'subjective' in m.affect.note.lower() and 'choices' in m.affect.note.lower()
    assert m.egr.participation_policy=='all-nonzero-regions-causal-v0.7.3.4'
    assert 'subjective emotion' in m.affect.note


def test_dkt_strata_audit_does_not_rewrite_history(tmp_path:Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'x.db'))
    n.ingest(CognitiveEvent(kind=EventKind.USER_MESSAGE,source='u',content='Store one memory.',trusted=True))
    before=[(str(m.id),m.knot.stratum_index,m.knot.invariant_signature) for m in n.store.cognitive_memories()]
    audit=n.dkt_strata_audit(100)
    after=[(str(m.id),m.knot.stratum_index,m.knot.invariant_signature) for m in n.store.cognitive_memories()]
    assert audit['status']=='read-only-audit'
    assert before==after


def test_developmental_modules_do_not_import_llm():
    root=Path(__file__).parents[1]/'src'/'noeron'
    for name in ['development.py','math/affect.py','math/dkt.py','math/kernel.py']:
        text=(root/name).read_text()
        assert 'from noeron.llm' not in text
        assert 'import noeron.llm' not in text


def test_v067_migration_preserves_existing_epoch_one(tmp_path:Path):
    store=LocalEventStore(tmp_path/'x.db')
    from noeron.models import NoeronState
    st=NoeronState(); st.cognition.stratification_epoch=1; st.conversational_turn=199
    st.cognition.v066_source_lineage_migration_complete=True
    store.append_state(st)
    n=Noeron(MockLanguageEngine(),store)
    assert n.state.cognition.stratification_epoch==1
    assert n.state.conversational_turn==199
    assert n.state.cognition.v067_developmental_cognition_migration_complete is True
    assert n.state.cognition.version=='0.7.5.1'  # outer Stage-6 runtime
