from __future__ import annotations

import ast
import importlib
import os
from pathlib import Path
import sys

import pytest
from fastapi import HTTPException
from starlette.requests import Request


def _request(client_host: str, *, cookie: str = "") -> Request:
    headers=[]
    if cookie:
        headers.append((b"cookie",cookie.encode("ascii")))
    return Request({
        "type":"http",
        "http_version":"1.1",
        "method":"GET",
        "scheme":"http",
        "path":"/room",
        "raw_path":b"/room",
        "query_string":b"",
        "headers":headers,
        "client":(client_host,43210),
        "server":("127.0.0.1",8741),
        "root_path":"",
    })


@pytest.fixture(scope="module")
def api_module(tmp_path_factory):
    old_db=os.environ.get("NOERON_DB_PATH")
    db=tmp_path_factory.mktemp("room-transport")/"transport.sqlite3"
    os.environ["NOERON_DB_PATH"]=str(db)
    sys.modules.pop("noeron.api",None)
    module=importlib.import_module("noeron.api")
    try:
        yield module
    finally:
        try:
            module.store._connection.commit();module.store._connection.close()
        except Exception:
            pass
        sys.modules.pop("noeron.api",None)
        if old_db is None:
            os.environ.pop("NOERON_DB_PATH",None)
        else:
            os.environ["NOERON_DB_PATH"]=old_db


def test_01_remote_room_is_403_and_never_receives_login_shell(api_module):
    with pytest.raises(HTTPException) as exc:
        api_module.room_shell(_request("203.0.113.41"))
    assert exc.value.status_code==403
    assert "loopback/tunnel" in str(exc.value.detail)


def test_02_local_unauthenticated_room_gets_owner_login_only(api_module):
    response=api_module.room_shell(_request("127.0.0.1"))
    assert response.status_code==401
    body=response.body.decode("utf-8")
    assert "Ed25519 owner-device session required" in body
    assert "<canvas id=\"renderer\"" not in body


def test_03_local_authenticated_room_gets_private_room(api_module,monkeypatch):
    seen=[]
    def verified(token):
        seen.append(token)
        return {"authenticated":True,"method":"ed25519-device-session","device_id":"owner-device"}
    monkeypatch.setattr(api_module,"_room_auth_detail_from_token",verified)
    response=api_module.room_shell(_request("::1",cookie="noeron_room_session=owner-session-token"))
    assert response.status_code==200
    assert seen==["owner-session-token"]
    body=response.body.decode("utf-8")
    assert "Private Noeron Room" in body and "<canvas id=\"renderer\"" in body


def test_04_http_and_websocket_transport_checks_precede_auth_origin_session():
    src=Path("src/noeron/api.py").read_text()
    tree=ast.parse(src)
    shell=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=="room_shell")
    assert isinstance(shell.body[0],ast.Expr)
    call=shell.body[0].value
    assert isinstance(call,ast.Call) and isinstance(call.func,ast.Name) and call.func.id=="_room_transport_guard"
    assert isinstance(shell.body[1],ast.Try)
    ws=next(n for n in tree.body if isinstance(n,ast.AsyncFunctionDef) and n.name=="room_ws")
    text=ast.get_source_segment(src,ws) or ""
    transport=text.index("_room_ws_transport_allowed(ws)")
    origin=text.index("origin not in allowed")
    session=text.index("owner_auth.verify_detail(token)")
    assert transport < origin < session
