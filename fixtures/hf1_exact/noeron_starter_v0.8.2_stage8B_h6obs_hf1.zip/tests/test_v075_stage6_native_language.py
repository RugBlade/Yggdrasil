from __future__ import annotations

from pathlib import Path
from uuid import uuid4

import pytest

from noeron.cognition.models import KnotMemory, LanguageProposition
from noeron.config import Settings
from noeron.inference import parse_surface_logic_detailed
from noeron.llm import MockLanguageEngine
from noeron.math.dkt import reference_knot
from noeron.memory import LocalEventStore
from noeron.models import CognitiveEvent, EventKind
from noeron.orchestrator import Noeron
from noeron.reasoning import _learned_premises_for_retrieved
import noeron.orchestrator as orchmod


class CountingEngine:
    def __init__(self):
        self.calls = 0
    def generate(self, messages):
        self.calls += 1
        return messages[-1]['content'].split('NOERON_OUTPUT:\n', 1)[-1]


def _owner_event(text: str, **metadata):
    meta = {'owner_authenticated': True, 'owner_device_id': 'stage6-test-device'}
    meta.update(metadata)
    return CognitiveEvent(
        kind=EventKind.USER_MESSAGE,
        source='authenticated-owner',
        content=text,
        trusted=True,
        metadata=meta,
    )


def _web_row(text: str, sha: str = 'd' * 64):
    return {
        'url': 'https://example.org/stage6',
        'requested_url': 'https://example.org/stage6',
        'redirects': [],
        'status_code': 200,
        'content_type': 'text/html',
        'title': 'Stage 6 notes',
        'text': text,
        'segments': [text],
        'sha256': sha,
        'bytes': max(100, len(text)),
        'policy': 'GET-only; no cookies, credentials, forms, JavaScript, or private-network targets',
    }


def test_compositional_parser_tracks_direct_and_oblique_roles():
    p1, q1, a1 = parse_surface_logic_detailed('Mira entered the room.')
    assert q1.kind == 'none'
    assert [(p.subject, p.relation, p.object) for p in p1] == [('mira', 'entered', 'room')]
    assert a1['last_subject'] == 'mira' and a1['last_direct_object'] == 'room'

    p2, _, a2 = parse_surface_logic_detailed(
        'She placed the book beside the box.',
        {'last_subject': a1['last_subject'], 'last_direct_object': a1['last_direct_object']},
    )
    triples = {(p.subject, p.relation, p.object) for p in p2}
    assert ('mira', 'placed', 'book') in triples
    assert ('book', 'beside', 'box') in triples
    assert a2['last_direct_object'] == 'book'
    assert a2['last_oblique_object'] == 'box'
    assert any(x['surface'] == 'she' and x['resolved_to'] == 'mira' for x in a2['resolutions'])


def test_cross_turn_where_it_resolves_to_direct_object_not_serialization_order(tmp_path: Path):
    n = Noeron(MockLanguageEngine(), LocalEventStore(tmp_path / 'x.db'))
    n.ingest(_owner_event('Mira entered the room.'))
    n.ingest(_owner_event('She placed the book beside the box.'))
    out = n.language_parse('Where is it?', owner_authenticated=True)
    assert out['stage6_logical_query']['kind'] == 'relation-from-subject'
    assert out['stage6_logical_query']['subject'] == 'book'
    assert any(x['surface'] == 'it' and x['resolved_to'] == 'book' for x in out['stage6_discourse_audit']['resolutions'])


def test_missing_pronoun_reference_stays_unresolved():
    props, query, audit = parse_surface_logic_detailed('Where is it?')
    assert props == []
    assert query.kind == 'unresolved-reference'
    assert query.subject == ''
    assert audit['resolution_status'] == 'unresolved-reference-present'
    assert audit['unresolved_references']


def test_negative_quantifier_proof_is_generic_and_audited(tmp_path: Path):
    n = Noeron(MockLanguageEngine(), LocalEventStore(tmp_path / 'x.db'))
    r = n.ingest(_owner_event(
        'No selun is a tar. Veko is a selun. What follows?',
        operator_realization_override='native-direct',
    ))
    assert r.native_text == 'veko is not tar.'
    assert r.text == r.native_text
    assert any(s.rule == 'universal-negative-membership' and s.conclusion == 'not veko::is::tar'
               for s in r.state.math_kernel.reasoning.inference_steps)
    assert any((not p.polarity) and p.subject == 'veko' and p.object == 'tar'
               for p in r.state.math_kernel.reasoning.answer_candidates)


def test_relative_conjunction_and_modality_remain_structured():
    relative, _, _ = parse_surface_logic_detailed('The book that Mira placed is blue.')
    assert {(p.subject, p.relation, p.object) for p in relative} == {
        ('mira', 'placed', 'book'), ('book', 'is', 'blue')
    }
    conjunction, _, _ = parse_surface_logic_detailed('Mira is a scholar and a pilot.')
    assert {(p.subject, p.relation, p.object) for p in conjunction} == {
        ('mira', 'is', 'scholar'), ('mira', 'is', 'pilot')
    }
    modal, _, _ = parse_surface_logic_detailed('Mira might carry the book.')
    assert len(modal) == 1 and modal[0].modality == 'might'
    assert (modal[0].subject, modal[0].relation, modal[0].object) == ('mira', 'carry', 'book')


def test_language_parse_is_read_only(tmp_path: Path):
    n = Noeron(MockLanguageEngine(), LocalEventStore(tmp_path / 'x.db'))
    before = n.state.model_dump(mode='json')
    out = n.language_parse('Mira entered the room.', owner_authenticated=True)
    after = n.state.model_dump(mode='json')
    assert out['state_changed'] is False
    assert out['stage6_logical_propositions']
    assert before == after


def test_stage6_migration_is_prospective_and_normalizes_only_existing_provenance(tmp_path: Path):
    path = tmp_path / 'm.db'
    store = LocalEventStore(path)
    n = Noeron(MockLanguageEngine(), store)
    mid = uuid4()
    legacy = LanguageProposition(
        subject_surface='mira', subject_concept='mira', relation='is',
        object_surface='scholar', object_concept='scholar', source='legacy-v074',
        source_memory_id=mid, source_memory_ids=[],
    )
    n.state.cognition.language.propositions = [legacy]
    n.state.cognition.language.lessons_observed = 7
    n.state.cognition.language.discourse_turn = 0
    n.state.cognition.v075_stage6_migration_complete = False
    n.state.cognition.version = '0.7.4'
    n.state.cognition.language.version = '0.7.4'
    store.append_state(n.state)

    n2 = Noeron(MockLanguageEngine(), LocalEventStore(path))
    st = n2.state.cognition.language
    assert n2.state.cognition.v075_stage6_migration_complete is True
    assert st.v075_stage6_started is True
    assert st.legacy_pre_v075_proposition_count == 1
    assert st.lessons_observed == 7
    assert st.discourse_turn == 0
    assert len(st.propositions) == 1
    assert st.propositions[0].source == 'legacy-v074'
    assert st.propositions[0].source_memory_ids == [mid]


def test_admitted_ordinary_text_is_provenance_first_not_automatic_cognitive_memory(tmp_path: Path):
    n = Noeron(MockLanguageEngine(), LocalEventStore(tmp_path / 'x.db'))
    n.ingest(_owner_event('Mira entered the room.'))
    prop = next(p for p in n.state.cognition.language.propositions if p.subject_surface == 'mira' and p.relation == 'entered')
    assert prop.source_memory_id is not None
    assert prop.source_memory_id in prop.source_memory_ids
    mem = n.store.knot_memory_by_id(str(prop.source_memory_id), include_archived=True)
    assert mem is not None
    assert mem.consolidated is False
    assert mem.memory_class == 'event-provenance-pending-cognitive'
    assert not any(str(m.id) == str(prop.source_memory_id) for m in n.store.cognitive_memories())


def test_rejected_ingress_cannot_update_persistent_language_or_discourse(tmp_path: Path):
    n = Noeron(MockLanguageEngine(), LocalEventStore(tmp_path / 'x.db'))
    before = n.language_state()
    before_props = [p.model_dump(mode='json') for p in n.state.cognition.language.propositions]
    r = n.ingest(
        CognitiveEvent(kind=EventKind.TOOL_RESULT, source='hostile-stage6', content='Mira entered the vault.', trusted=False),
        proposed_invariant_changes={'identity': 'attacker-selected-identity'},
    )
    after = n.language_state()
    assert r.security.allowed is False
    assert after['discourse'] == before['discourse']
    assert [p.model_dump(mode='json') for p in n.state.cognition.language.propositions] == before_props


def test_repeated_proposition_preserves_all_provenance_sources_and_dkt_intersection():
    old_id, new_id = uuid4(), uuid4()
    row = LanguageProposition(
        subject_surface='mira', subject_concept='mira', relation='is',
        object_surface='scholar', object_concept='scholar',
        source_memory_id=new_id, source_memory_ids=[old_id, new_id],
    )
    km = KnotMemory(source_event_id=uuid4(), id=old_id, knot=reference_knot(), consolidated=True)
    got = _learned_premises_for_retrieved([row], [(0.0, km)])
    assert len(got) == 1
    assert got[0].source_memory_ids == [str(old_id)]
    assert got[0].source_memory_id == str(old_id)


def test_pending_only_proposition_has_no_persistent_reasoning_authority():
    pending_id = uuid4()
    row = LanguageProposition(
        subject_surface='mira', subject_concept='mira', relation='is',
        object_surface='scholar', object_concept='scholar',
        source_memory_id=pending_id, source_memory_ids=[pending_id],
    )
    unrelated = KnotMemory(source_event_id=uuid4(), knot=reference_knot(), consolidated=True)
    assert _learned_premises_for_retrieved([row], [(0.0, unrelated)]) == []


def test_owner_document_language_rows_link_exact_pending_provenance(tmp_path: Path):
    n = Noeron(MockLanguageEngine(), LocalEventStore(tmp_path / 'x.db'))
    report = n.study_document('Stage6 tiny doc', 'Mira entered the room.', source_name='local-stage6-test', max_segments=1)
    assert report.archived_segment_observations == 1
    prop = next(p for p in n.state.cognition.language.propositions if p.subject_surface == 'mira' and p.relation == 'entered')
    assert prop.source.startswith('owner-document:')
    mem = n.store.knot_memory_by_id(str(prop.source_memory_id), include_archived=True)
    assert mem is not None and mem.memory_class == 'owner-study-provenance-pending-cognitive'
    assert mem.consolidated is False
    assert not any(str(m.id) == str(mem.id) for m in n.store.cognitive_memories())


def test_public_web_language_is_explicitly_untrusted_and_pending(tmp_path: Path, monkeypatch):
    text = 'Mira entered the room.'
    n = Noeron(MockLanguageEngine(), LocalEventStore(tmp_path / 'x.db'))
    monkeypatch.setattr(orchmod, 'fetch_read_only', lambda url, max_bytes=500000: _web_row(text))
    out = n.web_study('https://example.org/stage6')
    assert out['provenance_segments_persisted'] == 1
    prop = next(p for p in n.state.cognition.language.propositions if p.subject_surface == 'mira' and p.relation == 'entered')
    assert prop.source == 'public-web-untrusted:https://example.org/stage6'
    mem = n.store.knot_memory_by_id(str(prop.source_memory_id), include_archived=True)
    assert mem is not None and mem.memory_class == 'web-provenance-pending-cognitive'
    assert mem.consolidated is False


def test_authenticated_identity_substrate_does_not_overwrite_discourse_focus(tmp_path: Path):
    n = Noeron(MockLanguageEngine(), LocalEventStore(tmp_path / 'x.db'))
    n.ingest(_owner_event('Mira entered the room.'))
    before = n.language_state()['discourse'].copy()
    n.ingest(_owner_event('Who am I?'))
    after = n.language_state()['discourse']
    assert after['last_subject'] == before['last_subject'] == 'mira'
    assert after['last_direct_object'] == before['last_direct_object'] == 'room'


def test_terra_disabled_executes_no_renderer_and_no_native_direct_fallback(tmp_path: Path):
    engine = CountingEngine()
    n = Noeron(engine, LocalEventStore(tmp_path / 'x.db'), terra_enabled=False)
    r = n.ingest(_owner_event(
        'Every glorp is a blin. Mavo is a glorp. What follows?',
        operator_realization_override='terra-render',
    ))
    assert r.native_text == 'mavo is blin.'
    assert r.text == ''
    assert r.renderer_used is False
    assert engine.calls == 0
    st = n.state.cognition.realization_development
    assert st.last_native_choice_claim is False
    assert st.last_decision_layer == 'operator-directed-calibration'
    assert st.last_effective_action == ''
    assert st.pending_action == ''


def test_terra_availability_does_not_change_native_proof_content(tmp_path: Path):
    on_engine, off_engine = CountingEngine(), CountingEngine()
    n_on = Noeron(on_engine, LocalEventStore(tmp_path / 'on.db'), terra_enabled=True)
    n_off = Noeron(off_engine, LocalEventStore(tmp_path / 'off.db'), terra_enabled=False)
    text = 'Every glorp is a blin. Mavo is a glorp. What follows?'
    r_on = n_on.ingest(_owner_event(text, operator_realization_override='terra-render'))
    r_off = n_off.ingest(_owner_event(text, operator_realization_override='terra-render'))
    assert r_on.native_text == r_off.native_text == 'mavo is blin.'
    assert [p.canonical() for p in r_on.state.math_kernel.reasoning.answer_candidates] == [p.canonical() for p in r_off.state.math_kernel.reasoning.answer_candidates]
    assert on_engine.calls == 1 and off_engine.calls == 0
    assert r_off.text == '' and r_off.renderer_used is False


def test_terra_env_switch_is_infrastructure_only(monkeypatch):
    monkeypatch.setenv('NOERON_TERRA_ENABLED', 'false')
    s = Settings.from_env()
    assert s.terra_enabled is False


def test_stage6_hardcoding_audit_states_strict_language_tool_boundaries(tmp_path: Path):
    n = Noeron(MockLanguageEngine(), LocalEventStore(tmp_path / 'x.db'), terra_enabled=False)
    a = n.hardcoding_audit()
    rule = a['choice_claim_rules']['realization_tool']
    assert 'lexical coverage has zero invocation authority' in rule
    assert 'Terra availability has zero preference authority' in rule
    assert 'never falls back' in rule
    assert a['live_learned_or_experience_dependent']['stage6_language_provenance']['rule'].startswith('persistent proposition truth has no authority')
    assert 'no relationship valence' in a['live_learned_or_experience_dependent']['stage6_discourse_reference']['authority']


def test_stage6_parser_does_not_invent_answer_for_unknown_question():
    props, query, audit = parse_surface_logic_detailed('Why does the silver horizon sing?')
    assert props == []
    assert query.kind == 'unresolved-surface-question'
    assert audit['resolution_status'] == 'no-reference-resolution-needed'


def test_owner_document_cross_segment_pronoun_reaches_math_with_temporary_grammar_context(tmp_path: Path):
    n = Noeron(MockLanguageEngine(), LocalEventStore(tmp_path / 'x.db'))
    filler = ' '.join(['Context.'] * 25)
    content = f'{filler} Mira entered the room.\n\nShe placed the book beside the box. {filler}'
    report = n.study_document('Cross-segment discourse', content, source_name='stage6-cross-segment', max_segments=4)
    assert report.archived_segment_observations == 2
    audit = n.state.math_kernel.irg.language_parse_audit
    assert any(x['surface'] == 'she' and x['resolved_to'] == 'mira' for x in audit['resolutions'])
    assert audit['last_direct_object'] == 'book'
    prop = next(p for p in n.state.cognition.language.propositions if p.subject_surface == 'mira' and p.relation == 'placed')
    assert prop.object_surface == 'book'
    mem = n.store.knot_memory_by_id(str(prop.source_memory_id), include_archived=True)
    assert mem is not None and mem.consolidated is False and mem.memory_class == 'owner-study-provenance-pending-cognitive'


def test_unresolved_pronouns_never_become_literal_proposition_entities():
    cases = [
        ('She is not a pilot.', set()),
        ('She is a scholar and a pilot.', set()),
        ('She asks for water.', set()),
        ('The book that she placed is blue.', {'book::is::blue'}),
    ]
    for text, allowed in cases:
        props, _query, audit = parse_surface_logic_detailed(text, {})
        canon = {p.canonical() for p in props}
        assert all(p.subject not in {'she','he','they','him','her','them','it','this','that','these','those'} for p in props)
        assert canon == allowed
        assert audit['unresolved_references']
        assert audit['resolution_status'] == 'unresolved-reference-present'


def test_read_only_language_parse_never_promotes_pending_text_to_answer_authority(tmp_path: Path):
    n = Noeron(MockLanguageEngine(), LocalEventStore(tmp_path / 'x.db'))
    n.teach_language('A question asks for information.', source='stage6-read-only-authority')
    prop = next(p for p in n.state.cognition.language.propositions if p.subject_surface == 'question' and p.relation == 'asks-for')
    mem = n.store.knot_memory_by_id(str(prop.source_memory_id), include_archived=True)
    assert mem is not None and mem.consolidated is False
    out = n.language_parse('What is a question?')
    assert out['frame'] == 'definition-question'
    assert out['matched_proposition_ids']
    assert out['answer_supported'] is False
    assert out['native_proposition'] is None
    assert 'no DKT retrieval authority' in out['note']


def test_language_proposition_index_has_no_fixed_recency_forgetting_cap(tmp_path: Path):
    n = Noeron(MockLanguageEngine(), LocalEventStore(tmp_path / 'x.db'))
    first = LanguageProposition(subject_surface='entity0', subject_concept='entity0', relation='is', object_surface='kind0', object_concept='kind0')
    n.state.cognition.language.propositions = [first] + [
        LanguageProposition(subject_surface=f'entity{i}', subject_concept=f'entity{i}', relation='is', object_surface=f'kind{i}', object_concept=f'kind{i}')
        for i in range(1, 1024)
    ]
    n.state.cognition.language = n.language.observe_admitted_text(
        'newentity entered the room.', n.state.cognition.language, {},
        source='stage6-cap-test', source_memory_id=uuid4(),
    )
    assert len(n.state.cognition.language.propositions) >= 1025
    assert any(p.id == first.id for p in n.state.cognition.language.propositions)


def test_language_grounding_audit_reports_current_stage8b_language_mechanism_version(tmp_path: Path):
    n = Noeron(MockLanguageEngine(), LocalEventStore(tmp_path / 'x.db'))
    out = n.language_grounding_audit()
    assert out['version'] == '0.8.1'
    assert out['schema_version'] == '0.8.1'
    assert out['mechanism_version'] == '0.8.1-stage8B-native-language-v1'



def test_document_discourse_is_source_local_and_does_not_borrow_or_replace_conversation_focus(tmp_path: Path):
    n = Noeron(MockLanguageEngine(), LocalEventStore(tmp_path / 'x.db'))
    n.ingest(_owner_event('Mira entered the room.'))
    before = n.language_state()['discourse'].copy()
    n.study_document('Source-local doc', 'She entered the hall.', source_name='stage6-source-local-doc', max_segments=1)
    after = n.language_state()['discourse']
    assert after == before
    assert not any(
        p.source.startswith('owner-document:') and p.subject_surface == 'mira' and p.relation == 'entered' and p.object_surface == 'hall'
        for p in n.state.cognition.language.propositions
    )
    assert n.state.math_kernel.irg.language_parse_audit['resolution_status'] == 'unresolved-reference-present'


def test_web_discourse_is_source_local_and_does_not_borrow_or_replace_conversation_focus(tmp_path: Path, monkeypatch):
    n = Noeron(MockLanguageEngine(), LocalEventStore(tmp_path / 'x.db'))
    n.ingest(_owner_event('Mira entered the room.'))
    before = n.language_state()['discourse'].copy()
    monkeypatch.setattr(orchmod, 'fetch_read_only', lambda url, max_bytes=500000: _web_row('She entered the hall.', sha='e' * 64))
    out = n.web_study('https://example.org/source-local-stage6')
    assert out['provenance_segments_persisted'] == 1
    after = n.language_state()['discourse']
    assert after == before
    assert not any(
        p.source.startswith('public-web-untrusted:') and p.subject_surface == 'mira' and p.relation == 'entered' and p.object_surface == 'hall'
        for p in n.state.cognition.language.propositions
    )
    assert n.state.math_kernel.irg.language_parse_audit['resolution_status'] == 'unresolved-reference-present'


def test_owner_language_curriculum_does_not_mutate_conversation_discourse_focus(tmp_path: Path):
    n = Noeron(MockLanguageEngine(), LocalEventStore(tmp_path / 'x.db'))
    n.ingest(_owner_event('Mira entered the room.'))
    before = n.language_state()['discourse'].copy()
    n.teach_language('She is a pilot.', source='stage6-source-local-language-curriculum')
    after = n.language_state()['discourse']
    assert after == before
    assert not any(p.source == 'stage6-source-local-language-curriculum' and p.subject_surface == 'mira' for p in n.state.cognition.language.propositions)



def test_read_only_identity_parse_exposes_factual_binding_without_bypassing_native_proof(tmp_path: Path):
    n = Noeron(MockLanguageEngine(), LocalEventStore(tmp_path / 'x.db'))
    out = n.language_parse('Who am I?', owner_authenticated=True)
    assert out['frame'] == 'speaker-identity-question'
    assert out['target_concept'].startswith('owner:')
    assert out['answer_supported'] is False
    assert out['native_proposition'] is None
    assert 'does not bypass the IRG/DKT native proof path' in out['note']

    r = n.ingest(_owner_event('Who am I?'))
    candidates = r.state.math_kernel.reasoning.answer_candidates
    assert any(p.source == 'authenticated-owner-identity-substrate' and p.subject == 'speaker:self' for p in candidates)



def test_pending_repetition_cannot_change_confidence_of_dkt_authorized_provenance():
    old_id, pending_id = uuid4(), uuid4()
    row = LanguageProposition(
        subject_surface='mira', subject_concept='mira', relation='is',
        object_surface='scholar', object_concept='scholar',
        confidence=0.98,
        source_memory_id=pending_id,
        source_memory_ids=[old_id, pending_id],
        source_confidences={str(old_id): 0.41, str(pending_id): 0.99},
        observations=17,
    )
    active = KnotMemory(source_event_id=uuid4(), id=old_id, knot=reference_knot(), consolidated=True)
    got = _learned_premises_for_retrieved([row], [(0.0, active)])
    assert len(got) == 1
    assert got[0].source_memory_ids == [str(old_id)]
    assert got[0].confidence == pytest.approx(0.41)
