from noeron.math.irg import interaction_geometry
from noeron.models import CognitiveEvent,EventKind

def test_dialogue_act_is_surface_diagnostic_only():
    e=CognitiveEvent(kind=EventKind.USER_MESSAGE,source='u',content='Yggdrasil, how is your architecture built?',trusted=True)
    x=interaction_geometry(e)
    assert x.dialogue_act=='surface-question'
    assert x.query_targets==[]
    assert x.request_dimensions==[]
    assert x.dialogue_acts==['surface-question']
