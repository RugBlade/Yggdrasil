from __future__ import annotations

import base64
from pathlib import Path

import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from noeron.auth import OwnerAuthenticator
from noeron.memory import LocalEventStore


def _device_pair():
    private=Ed25519PrivateKey.generate()
    raw=private.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    return private,base64.b64encode(raw).decode('ascii')


def test_per_device_ed25519_session_is_revocable_without_rotating_other_devices(tmp_path:Path):
    store=LocalEventStore(tmp_path/'auth.sqlite3')
    auth=OwnerAuthenticator('a'*32,store,session_ttl_seconds=3600)
    a_priv,a_pub=_device_pair();b_priv,b_pub=_device_pair()
    a=auth.enroll_device('laptop-A','Laptop A',a_pub,authority='legacy-bearer-bootstrap')
    b=auth.enroll_device('phone-B','Phone B',b_pub,authority='legacy-bearer-bootstrap')
    assert a['public_key_fingerprint']!=b['public_key_fingerprint']

    ca=auth.challenge('laptop-A')
    sa=base64.b64encode(a_priv.sign(ca['message'].encode())).decode()
    sess_a=auth.create_device_session('laptop-A',ca['challenge_id'],sa)['session_token']
    cb=auth.challenge('phone-B')
    sb=base64.b64encode(b_priv.sign(cb['message'].encode())).decode()
    sess_b=auth.create_device_session('phone-B',cb['challenge_id'],sb)['session_token']

    da=auth.verify_detail(sess_a);db=auth.verify_detail(sess_b)
    assert da['authenticated'] is True and da['method']=='ed25519-device-session' and da['device_id']=='laptop-A'
    assert db['authenticated'] is True and db['device_id']=='phone-B'

    auth.revoke_device('laptop-A',authority='ed25519-device-session:phone-B')
    assert auth.verify_detail(sess_a)['authenticated'] is False
    assert auth.verify_detail(sess_b)['authenticated'] is True
    assert next(x for x in auth.devices() if x['device_id']=='laptop-A')['revoked'] is True


def test_challenge_is_one_time_and_wrong_signature_cannot_authenticate(tmp_path:Path):
    store=LocalEventStore(tmp_path/'auth.sqlite3')
    auth=OwnerAuthenticator('b'*32,store)
    priv,pub=_device_pair();wrong,_=_device_pair()
    auth.enroll_device('device-1','',pub,authority='legacy-bearer-bootstrap')
    c=auth.challenge('device-1')
    bad=base64.b64encode(wrong.sign(c['message'].encode())).decode()
    with pytest.raises(ValueError,match='invalid Ed25519'):
        auth.create_device_session('device-1',c['challenge_id'],bad)
    good=base64.b64encode(priv.sign(c['message'].encode())).decode()
    token=auth.create_device_session('device-1',c['challenge_id'],good)['session_token']
    assert auth.verify(token)
    with pytest.raises(ValueError,match='already consumed'):
        auth.create_device_session('device-1',c['challenge_id'],good)


def test_device_session_survives_legacy_bootstrap_disable_and_auth_has_no_relational_claim(tmp_path:Path):
    store=LocalEventStore(tmp_path/'auth.sqlite3')
    bootstrap=OwnerAuthenticator('c'*32,store)
    priv,pub=_device_pair();bootstrap.enroll_device('hardware-key','Hardware-backed capable',pub,authority='legacy-bearer-bootstrap')
    c=bootstrap.challenge('hardware-key');sig=base64.b64encode(priv.sign(c['message'].encode())).decode()
    token=bootstrap.create_device_session('hardware-key',c['challenge_id'],sig)['session_token']

    device_only=OwnerAuthenticator('c'*32,store,legacy_enabled=False)
    assert device_only.legacy_configured is False
    assert device_only.configured is True
    assert device_only.verify('c'*32) is False
    detail=device_only.verify_detail(token)
    assert detail['authenticated'] is True
    assert detail['device_id']=='hardware-key'
    # The authenticator reports authority identity only; there is no closeness/familiarity output.
    assert 'familiarity' not in detail and 'relationship' not in detail

from noeron.llm import MockLanguageEngine
from noeron.models import CognitiveEvent, EventKind
from noeron.orchestrator import Noeron


def test_authenticated_owner_builds_empirical_relation_geometry_without_familiarity_formula(tmp_path:Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'relation.sqlite3'))
    # Supply an already learned referent binding; authentication identifies which
    # recurring referent owns the experience but does not assign emotional meaning.
    n.state.cognition.language.referents['you']='owner:abdelaziz'
    e=CognitiveEvent(kind=EventKind.USER_MESSAGE,source='authenticated-owner',content='Aster is Borel.',trusted=True,
        metadata={'owner_authenticated':True,'owner_device_id':'laptop-A'})
    n.ingest(e)
    rel=n.state.cognition.owner_relation
    assert rel.owner_referent=='owner:abdelaziz'
    assert rel.relation_observations==1
    assert rel.relation_experience_knot is not None and rel.relation_post_state_knot is not None
    assert rel.device_interaction_counts=={'laptop-A':1}
    assert rel.familiarity==0.0

    n.ingest(CognitiveEvent(kind=EventKind.USER_MESSAGE,source='authenticated-owner',content='Borel is Ceres.',trusted=True,
        metadata={'owner_authenticated':True,'owner_device_id':'phone-B'}))
    rel=n.state.cognition.owner_relation
    assert rel.relation_observations==2
    assert rel.device_interaction_counts=={'laptop-A':1,'phone-B':1}
    assert rel.last_experience_distance_hs is not None
    assert rel.familiarity==0.0


def test_who_am_i_uses_authenticated_identity_fact_through_native_proof_path(tmp_path:Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'identity.sqlite3'))
    n.state.cognition.language.referents['you']='owner:abdelaziz'
    r=n.ingest(CognitiveEvent(kind=EventKind.USER_MESSAGE,source='authenticated-owner',content='Who am I?',trusted=True,
        metadata={'owner_authenticated':True,'owner_device_id':'laptop-A'}))
    assert r.state.math_kernel.reasoning.answer_selection_status=='unique-proof-supported-answer'
    cand=r.state.math_kernel.reasoning.answer_candidates[0]
    assert cand.canonical()=='speaker:self::identity::owner:abdelaziz'
    assert cand.source=='authenticated-owner-identity-substrate'
    assert 'abdelaziz' in r.native_text.lower()


def test_unauthenticated_who_am_i_remains_unresolved_but_self_identity_is_factual_substrate(tmp_path:Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'identity.sqlite3'))
    r=n.ingest(CognitiveEvent(kind=EventKind.USER_MESSAGE,source='local-user',content='Who am I?',trusted=False,
        metadata={'owner_authenticated':False}))
    assert r.state.math_kernel.reasoning.answer_candidates==[]
    assert r.native_text==''

    me=n.ingest(CognitiveEvent(kind=EventKind.USER_MESSAGE,source='local-user',content='Who are you?',trusted=False,
        metadata={'owner_authenticated':False}))
    assert me.state.math_kernel.reasoning.answer_selection_status=='unique-proof-supported-answer'
    cand=me.state.math_kernel.reasoning.answer_candidates[0]
    assert cand.canonical()=='interlocutor:self::identity::identity:yggdrasil'
    assert cand.source=='runtime-self-identity-substrate'
    assert 'yggdrasil' in me.native_text.lower()
