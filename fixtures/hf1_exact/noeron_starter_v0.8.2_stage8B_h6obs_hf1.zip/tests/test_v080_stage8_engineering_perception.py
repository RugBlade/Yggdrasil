from __future__ import annotations

from pathlib import Path

import pytest

from noeron.engineering import EngineeringSourceError, SourceWorkspace
from noeron.llm import MockLanguageEngine
from noeron.memory import LocalEventStore
from noeron.orchestrator import Noeron


def _repo(tmp_path: Path) -> Path:
    root = tmp_path / "repo"
    (root / "src" / "noeron").mkdir(parents=True)
    (root / "tests").mkdir()
    (root / "data").mkdir()
    (root / "vendor").mkdir()
    (root / "src" / "noeron" / "sample.py").write_text(
        "from fastapi import FastAPI\n"
        "app=FastAPI()\n\n"
        "def helper(x:int)->int:\n"
        "    return x+1\n\n"
        "@app.get('/sample')\n"
        "def sample_route():\n"
        "    return helper(1)\n",
        encoding="utf-8",
    )
    (root / "tests" / "test_sample.py").write_text("def test_x(): assert True\n", encoding="utf-8")
    (root / "data" / "secret.sqlite3").write_bytes(b"secret")
    (root / "vendor" / "thirdparty.py").write_text("x=1\n", encoding="utf-8")
    return root


def test_source_workspace_is_read_only_allowlisted_and_hashes_exact_bytes(tmp_path: Path):
    root = _repo(tmp_path)
    ws = SourceWorkspace(root)
    st = ws.status()
    assert st["enabled"] is True
    assert st["read_only"] is True
    assert st["write_authority"] is False
    assert st["deployment_authority"] is False

    idx = ws.index()
    paths = {x["path"] for x in idx["files"]}
    assert "src/noeron/sample.py" in paths
    assert "tests/test_sample.py" in paths
    assert all(not p.startswith("data/") for p in paths)
    assert all(not p.startswith("vendor/") for p in paths)

    row = ws.file("src/noeron/sample.py")
    assert row["content"].startswith("from fastapi")
    assert len(row["sha256"]) == 64
    assert row["write_authority"] is False

    with pytest.raises(EngineeringSourceError):
        ws.file("../etc/passwd")
    with pytest.raises(EngineeringSourceError):
        ws.file("data/secret.sqlite3")


def test_source_index_does_not_follow_symlinks_outside_source_root(tmp_path: Path):
    root = _repo(tmp_path)
    outside = tmp_path / "outside.py"
    outside.write_text("SECRET_OUTSIDE_SOURCE_ROOT = True\n", encoding="utf-8")
    leak = root / "src" / "noeron" / "leak.py"
    leak.symlink_to(outside)

    ws = SourceWorkspace(root)
    paths = {x["path"] for x in ws.index()["files"]}
    assert "src/noeron/leak.py" not in paths
    with pytest.raises(EngineeringSourceError):
        ws.file("src/noeron/leak.py")


def test_symbol_sensor_extracts_exact_lines_calls_and_route_fact(tmp_path: Path):
    root = _repo(tmp_path)
    ws = SourceWorkspace(root)
    row = ws.symbol("src/noeron/sample.py", "sample_route")
    assert row["kind"] == "function"
    assert "helper" in row["calls"]
    assert "@app.get('/sample')" in row["source"]
    facts = {(x["relation"], x["object"]) for x in row["facts"]}
    assert ("exposes-route", "GET /sample") in facts
    assert ("calls", "symbol-ref:helper") in facts
    assert row["write_authority"] is False
    assert row["deployment_authority"] is False


def test_owner_directed_source_observation_enters_native_path_as_pending_provenance(tmp_path: Path):
    root = _repo(tmp_path)
    store = LocalEventStore(tmp_path / "noeron.sqlite3")
    y = Noeron(
        MockLanguageEngine(),
        store,
        terra_enabled=False,
        engineering_source_root=str(root),
    )
    out = y.engineering_source_observe(
        "src/noeron/sample.py",
        "sample_route",
        owner_auth_detail={
            "authenticated": True,
            "method": "ed25519-device-session",
            "device_id": "owner-test",
            "fingerprint": "test-fp",
        },
    )
    assert out["status"] == "committed-owner-directed-engineering-source-exposure"
    assert out["provenance_memory_id"]
    assert out["cognitive_memory_activated"] is False
    assert out["outward_realization_forced"] is False
    assert out["write_authority"] is False
    assert out["deployment_authority"] is False
    assert out["native_upgrade_choice_claim"] is False
    assert out["llm_used"] is False

    event = store.event_by_id(out["event_id"])
    assert event is not None
    assert event.metadata["engineering_source_observation"] is True
    assert event.metadata["owner_authenticated"] is True
    assert event.metadata["write_authority"] is False
    assert any(x["relation"] == "exposes-route" for x in event.metadata["engineering_facts"])

    # Objective engineering facts were admitted to IRG logical premises, not merely logged.
    props = y.state.math_kernel.irg.logical_propositions
    assert any(p.relation == "exposes-route" and p.object == "GET /sample" for p in props)
    p = next(p for p in props if p.relation == "exposes-route" and p.object == "GET /sample")
    assert "no-write-authority" in p.modifiers
    assert "no-deployment-authority" in p.modifiers

    mem = store.knot_memory_by_id(out["provenance_memory_id"], include_archived=True)
    assert mem is not None
    assert mem.consolidated is False
    assert mem.memory_class.endswith("provenance-pending-cognitive")


def test_engineering_observation_requires_authenticated_owner(tmp_path: Path):
    root = _repo(tmp_path)
    y = Noeron(
        MockLanguageEngine(),
        LocalEventStore(tmp_path / "noeron.sqlite3"),
        terra_enabled=False,
        engineering_source_root=str(root),
    )
    with pytest.raises(PermissionError):
        y.engineering_source_observe(
            "src/noeron/sample.py",
            "sample_route",
            owner_auth_detail={"authenticated": False},
        )
