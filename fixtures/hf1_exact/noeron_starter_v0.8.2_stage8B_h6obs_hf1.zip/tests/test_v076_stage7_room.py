from __future__ import annotations

import ast
import json
import os
from pathlib import Path
from types import SimpleNamespace

import pytest

from noeron.llm import MockLanguageEngine
from noeron.memory import LocalEventStore
from noeron.orchestrator import Noeron
from noeron.room_models import NativeRoomDecision, NativeVoiceProfile


def make_noeron(tmp_path: Path, name: str='room.sqlite3', **kwargs):
    return Noeron(MockLanguageEngine(), LocalEventStore(tmp_path/name), **kwargs)


def _native_decision(domain: str, action: str) -> NativeRoomDecision:
    return NativeRoomDecision(domain=domain,candidates=[action],candidate_residuals={action:0.0},admissible_candidates=[action],minimum_candidates=[action],selected_action=action,selection_status='unique-native-consequence-minimum',decision_layer='native-deliberative',native_choice_claim=True)


def _fake_result(residual: float=0.0, admissible: bool=True):
    state=SimpleNamespace(
        dkt=SimpleNamespace(security_admissible=admissible),
        egr=SimpleNamespace(bridge_residual=residual,balance_residual=0.0),
        rl=SimpleNamespace(geodesic_acceleration_norm=0.0),
        causal_trace=['IRG','DKT','EGR','RL/Frenet','DKT'],
    )
    return SimpleNamespace(state=state)


def test_01_prospective_migration_assigns_no_body_or_environment(tmp_path):
    n=make_noeron(tmp_path)
    assert n.state.room.migration_complete is True
    assert n.state.room.embodiment_configuration is None
    assert n.state.room.environment_configuration is None
    assert not [e for e in n.store.all_events() if e.source.startswith('noeron-stage7-native-configuration-adoption')]


def test_02_candidate_projection_uses_live_math_state_and_no_second_curvature(tmp_path):
    n=make_noeron(tmp_path)
    a=n.room.configuration_candidates('embodiment')
    n.state.math_kernel.irg.response_potential += 7.0
    b=n.room.configuration_candidates('embodiment')
    assert [x.model_dump() for x in a[1:]] != [x.model_dump() for x in b[1:]]
    src=Path('src/noeron/room.py').read_text()
    assert 'second_curvature' not in src


def test_03_turn_only_change_does_not_change_candidate_ids(tmp_path):
    n=make_noeron(tmp_path);a=[x.id for x in n.room.configuration_candidates('embodiment')]
    n.state.conversational_turn += 19
    b=[x.id for x in n.room.configuration_candidates('embodiment')]
    assert a==b


def test_04_neutral_and_zero_ids_are_stable_under_native_state_change(tmp_path):
    n=make_noeron(tmp_path)
    e0=n.room.configuration_candidates('embodiment')[0].id
    v0=n.room.configuration_candidates('environment')[0].id
    n.state.math_kernel.irg.response_potential += 3.0
    n.state.math_kernel.rl.coordinates[0] += 2.0
    assert n.room.configuration_candidates('embodiment')[0].id==e0
    assert n.room.configuration_candidates('environment')[0].id==v0


def test_05_current_configuration_keeps_adopted_identity_as_candidate(tmp_path):
    n=make_noeron(tmp_path);c=n.room.configuration_candidates('embodiment')[1]
    n.state.room.embodiment_configuration=c.model_copy(deep=True)
    n.state.math_kernel.egr.entropy_state += 5.0
    ids=[x.id for x in n.room.configuration_candidates('embodiment')]
    assert c.id in ids


def test_06_exact_consequence_tie_is_unresolved_and_does_not_adopt(tmp_path,monkeypatch):
    n=make_noeron(tmp_path)
    monkeypatch.setattr(n.room,'_simulate',lambda domain,action,obs:(_fake_result(0.0),0.0,True))
    d=n.room.deliberate_configuration('embodiment')
    assert d.native_choice_claim is False and d.selection_status=='unresolved-exact-tie'
    assert n.state.room.embodiment_configuration is None and n.state.room.embodiment_morph_epoch==0


def test_07_adoption_reenters_math_and_is_not_cognitive_retention_trigger(tmp_path,monkeypatch):
    n=make_noeron(tmp_path);c=n.room.configuration_candidates('embodiment')[1];before_turn=n.state.conversational_turn
    calls=[];orig=n.math.update
    def wrapped(event,*args,**kwargs):calls.append(event);return orig(event,*args,**kwargs)
    monkeypatch.setattr(n.math,'update',wrapped)
    n.room._adopt_configuration(c,_native_decision('embodiment',c.id))
    assert calls and calls[-1].source=='noeron-stage7-native-configuration-adoption'
    assert n.state.conversational_turn==before_turn
    assert n.state.room.embodiment_configuration.id==c.id
    assert not n.store.knot_memory_for_event(str(calls[-1].id),include_archived=True)
    assert all(str(x.source_event_id)!=str(calls[-1].id) for x in n.store.pending_cognitive_provenance_memories())


def test_08_retaining_current_configuration_is_not_false_morph(tmp_path):
    n=make_noeron(tmp_path);c=n.room.configuration_candidates('embodiment')[1];d=_native_decision('embodiment',c.id)
    n.room._adopt_configuration(c,d);epoch=n.state.room.embodiment_morph_epoch;events=len(n.store.all_events())
    n.room._adopt_configuration(c,d)
    assert n.state.room.embodiment_morph_epoch==epoch and len(n.store.all_events())==events


def test_09_room_journal_is_persistent_and_non_cognitive(tmp_path):
    p=tmp_path/'r.db';n=Noeron(MockLanguageEngine(),LocalEventStore(p));e=n.room.append_journal('test',{'x':1})
    assert e.cognitive_authority is False
    n2=Noeron(MockLanguageEngine(),LocalEventStore(p))
    assert any(str(x.id)==str(e.id) and x.cognitive_authority is False for x in n2.store.room_journal())
    assert not any(str(m.source_event_id)==str(e.id) for m in n2.store.cognitive_memories())


def test_10_private_file_offer_permissions_and_no_cognitive_effect(tmp_path):
    n=make_noeron(tmp_path);turn=n.state.conversational_turn;mem=len(n.store.cognitive_memories())
    r=n.room.store_owner_file(b'private bytes','sample.txt','text/plain')
    assert oct(Path(r.storage_path).stat().st_mode & 0o777)=='0o600'
    assert oct(Path(r.storage_path).parent.stat().st_mode & 0o777)=='0o700'
    assert r.cognitive_authority is False and n.state.conversational_turn==turn and len(n.store.cognitive_memories())==mem


def test_11_publication_guard_rejects_non_native_decision(tmp_path):
    n=make_noeron(tmp_path);bad=NativeRoomDecision(domain='file-publication',selected_action='publish',selection_status='operator',decision_layer='operator',native_choice_claim=False)
    with pytest.raises(PermissionError): n.room._publish_bytes(b'x','x.bin','application/octet-stream',bad)


def test_12_hold_publish_exact_tie_publishes_nothing(tmp_path,monkeypatch):
    n=make_noeron(tmp_path);monkeypatch.setattr(n.room,'_simulate',lambda domain,action,obs:(_fake_result(0),0.0,True))
    d,a=n.room.deliberate_publish_existing(b'abc','a.bin')
    assert d.native_choice_claim is False and a is None
    assert not [x for x in n.store.room_artifacts() if x.direction=='noeron-to-owner']


def test_13_unique_native_publish_minimum_is_required(tmp_path,monkeypatch):
    n=make_noeron(tmp_path)
    monkeypatch.setattr(n.room,'_simulate',lambda domain,action,obs:(_fake_result(0 if action=='publish' else 1),0.0 if action=='publish' else 1.0,True))
    d,a=n.room.deliberate_publish_existing(b'abc','a.bin')
    assert d.native_choice_claim is True and d.selected_action=='publish'
    assert a is not None and a.publication_native_choice_claim is True and Path(a.storage_path).read_bytes()==b'abc'


def test_14_no_selected_native_voice_means_no_audio(tmp_path):
    n=make_noeron(tmp_path)
    assert n.room.present_native_utterance('sava is vel.') is None
    assert n.state.room.last_voice_decision.selection_status=='unresolved-no-selected-native-voice'


def test_15_voice_exact_tie_means_no_audio(tmp_path,monkeypatch):
    n=make_noeron(tmp_path);c=n.room.configuration_candidates('embodiment')[1];n.state.room.embodiment_configuration=c
    monkeypatch.setattr(n.room,'_simulate',lambda domain,action,obs:(_fake_result(0),0.0,True))
    assert n.room.present_native_utterance('sava is vel.') is None
    assert n.state.room.last_voice_decision.selection_status=='unresolved-exact-tie'


def test_16_native_audio_exists_before_observational_decoder_runs(tmp_path,monkeypatch):
    n=make_noeron(tmp_path,room_native_decoder_executable='/bin/cat');c=n.room.configuration_candidates('embodiment')[1];n.state.room.embodiment_configuration=c
    monkeypatch.setattr(n.room,'_select',lambda domain,candidates:(_native_decision(domain,'voice'),{}))
    import noeron.room as roommod
    seen={'audio_before_decoder':False}
    orig=roommod.run_local_decoder
    def decoder(exe,payload,**kwargs):
        seen['audio_before_decoder']=bool([a for a in n.store.room_artifacts() if a.direction=='noeron-to-owner' and a.media_type=='audio/wav'])
        return orig(exe,payload,**kwargs)
    monkeypatch.setattr(roommod,'run_local_decoder',decoder)
    p=n.room.present_native_utterance('sava is vel.')
    assert p is not None and seen['audio_before_decoder'] is True
    assert p.decoder_ran_after_native_utterance is True and p.decoded_text=='sava is vel.'
    assert p.decoder_cognitive_authority is False and p.decoder_realization_authority is False
    a=n.store.room_artifact(str(p.audio_artifact_id));assert a and Path(a.storage_path).read_bytes()[:4]==b'RIFF'


def test_17_local_decoder_requires_absolute_executable_and_no_shell(tmp_path):
    from noeron.speech import run_local_decoder
    with pytest.raises(ValueError):run_local_decoder('relative-decoder',b'x')
    src=Path('src/noeron/speech.py').read_text()
    assert 'shell=False' in src and 'subprocess.run' in src
    assert 'http://' not in src and 'https://' not in src


def test_18_modality_exact_tie_does_not_force_attention(tmp_path,monkeypatch):
    n=make_noeron(tmp_path);monkeypatch.setattr(n.room,'_simulate',lambda domain,action,obs:(_fake_result(0),0.0,True))
    d=n.room.deliberate_attention('camera',[{'name':'luminance','role':'vision','value':.5}])
    assert d.native_choice_claim is False and d.selected_action==''


def test_19_modality_attend_requires_unique_native_minimum(tmp_path,monkeypatch):
    n=make_noeron(tmp_path)
    monkeypatch.setattr(n.room,'_simulate',lambda domain,action,obs:(_fake_result(0 if action=='attend' else 1),0.0 if action=='attend' else 1.0,True))
    d=n.room.deliberate_attention('microphone',[{'name':'rms','role':'audio','value':.2}])
    assert d.native_choice_claim is True and d.selected_action=='attend' and d.decision_layer=='native-deliberative'


def test_20_certified_74_routes_preserved_and_new_http_surface_room_scoped():
    api=Path('src/noeron/api.py').read_text();tree=ast.parse(api);routes=[]
    for node in ast.walk(tree):
        if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
            for dec in node.decorator_list:
                if isinstance(dec,ast.Call) and isinstance(dec.func,ast.Attribute) and dec.func.attr in {'get','post','put','patch','delete'} and dec.args and isinstance(dec.args[0],ast.Constant):
                    routes.append((dec.func.attr.upper(),str(dec.args[0].value)))
    certified={tuple(x) for x in json.loads(Path('scripts/v0751_certified_api_routes.json').read_text())}
    current=set(routes);new=current-certified
    assert len(certified)==74 and certified.issubset(current)
    # Stage 8A preserves the exact Stage-7 Room delta while adding exactly five
    # owner-only engineering source-perception routes. No other HTTP surface is allowed.
    room_new={(method,path) for method,path in new if path.startswith('/room')}
    engineering_new={(method,path) for method,path in new if path.startswith('/engineering')}
    expected_engineering={
        ('GET','/engineering/status'),
        ('GET','/engineering/source/index'),
        ('GET','/engineering/source/file'),
        ('GET','/engineering/source/symbol'),
        ('POST','/engineering/source/observe'),
    }
    assert len(routes)==len(current)==98 and len(new)==24
    assert len(room_new)==19 and all(path.startswith('/room') for _,path in room_new)
    assert engineering_new==expected_engineering
    assert new==room_new|engineering_new


def test_21_room_auth_and_presentation_boundary_are_source_explicit():
    src=Path('src/noeron/api.py').read_text()
    assert "d.get('method')!='ed25519-device-session'" in src
    assert 'legacy bootstrap is not accepted' in src
    assert "'native_text_exposed':False" in src
    assert 'native_text_exposed_as_fallback' in src
    assert "await asyncio.sleep(0.75)" in src and 'owner_auth.verify_detail(token)' in src
    assert "origin not in allowed" in src


def test_22_no_hidden_body_family_gender_or_named_voice_schema(tmp_path):
    n=make_noeron(tmp_path);fields=set(type(n.room.configuration_candidates('embodiment')[1]).model_fields)
    assert 'gender' not in fields and 'body_family' not in fields and 'speaker' not in fields and 'accent' not in fields
    vf=set(NativeVoiceProfile.model_fields)
    assert vf=={'base_frequency','overtone_ratio','modulation','articulation','pulse_shape','tempo'}
    assert n.state.room.embodiment_configuration is None


def test_23_room_payload_bound_and_traversal_names_fail_closed(tmp_path):
    n=make_noeron(tmp_path,room_max_payload_bytes=1_048_576)
    with pytest.raises(ValueError):
        n.room.store_owner_file(b'x'*(1_048_576+1),'too-big.bin')
    for bad in ('../escape.bin','sub/path.bin','sub\\path.bin','bad\x00name.bin'):
        with pytest.raises(ValueError):
            n.room.store_owner_file(b'x',bad)


def test_24_private_write_is_exclusive_0600_and_roots_0700(tmp_path):
    n=make_noeron(tmp_path);r=n.room.store_owner_file(b'abc','safe.bin')
    p=Path(r.storage_path)
    assert p.read_bytes()==b'abc'
    assert oct(p.stat().st_mode & 0o777)=='0o600'
    assert oct(p.parent.stat().st_mode & 0o777)=='0o700'
    src=Path('src/noeron/room.py').read_text()
    assert 'os.O_EXCL' in src and 'O_NOFOLLOW' in src and 'os.fsync' in src


def test_25_artifact_tamper_and_path_escape_fail_closed(tmp_path):
    n=make_noeron(tmp_path);r=n.room.store_owner_file(b'abc','safe.bin');p=Path(r.storage_path)
    assert n.room.read_artifact(r)==b'abc'
    p.write_bytes(b'abd')
    with pytest.raises(ValueError):
        n.room.read_artifact(r)
    outside=tmp_path/'outside.bin';outside.write_bytes(b'abc');r.storage_path=str(outside);r.size=3;r.sha256=__import__('hashlib').sha256(b'abc').hexdigest()
    with pytest.raises(ValueError):
        n.room.read_artifact(r)


def test_26_publication_requires_matching_native_domain_and_action(tmp_path):
    n=make_noeron(tmp_path)
    wrong_domain=_native_decision('native-voice','publish')
    with pytest.raises(PermissionError):
        n.room._publish_bytes(b'x','x.bin','application/octet-stream',wrong_domain)
    wrong_action=_native_decision('file-publication','hold')
    with pytest.raises(PermissionError):
        n.room._publish_bytes(b'x','x.bin','application/octet-stream',wrong_action)
    voice=_native_decision('native-voice','voice')
    a=n.room._publish_bytes(b'RIFF','x.wav','audio/wav',voice,expected_domain='native-voice',expected_action='voice')
    assert a.publication_native_choice_claim is True


def test_27_room_loopback_transport_and_hardened_headers_are_explicit():
    src=Path('src/noeron/api.py').read_text()
    assert '_room_transport_guard(request)' in src
    assert '_room_ws_transport_allowed(ws)' in src
    assert "default-src 'none'" in src and "form-action 'self'" in src and "base-uri 'none'" in src
    assert "Referrer-Policy':'no-referrer'" in src and "X-Content-Type-Options':'nosniff'" in src
    assert "Permissions-Policy':'camera=(self), microphone=(self)'" in src
    tree=ast.parse(src); fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='room_shell')
    assert isinstance(fn.body[0],ast.Expr)
    first=fn.body[0].value
    assert isinstance(first,ast.Call) and isinstance(first.func,ast.Name) and first.func.id=='_room_transport_guard'
    assert isinstance(fn.body[1],ast.Try)
