from __future__ import annotations

from pathlib import Path

from noeron.llm import MockLanguageEngine
from noeron.memory import LocalEventStore
from noeron.models import CognitiveEvent,EventKind
from noeron.orchestrator import Noeron


def _owner(text:str):
    return CognitiveEvent(kind=EventKind.USER_MESSAGE,source='authenticated-owner',content=text,trusted=True,
        metadata={'owner_authenticated':True,'owner_device_id':'device-A'})


def test_empirical_owner_relation_geometry_reenters_native_dkt_retrieval_without_valence_weight(tmp_path:Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'relation.sqlite3'))
    n.state.cognition.language.referents['you']='owner:abdelaziz'
    n.ingest(_owner('Aster is Borel.'))
    assert n.state.cognition.owner_relation.relation_observations==1
    r=n.ingest(_owner('Borel is Ceres.'))
    rel=n.state.cognition.owner_relation
    assert rel.causal_context_injections>=1
    assert rel.last_causal_context_memory_id is not None
    assert str(rel.last_causal_context_memory_id) in r.state.math_kernel.dkt.retrieved_memory_ids
    assert rel.familiarity==0.0


def test_owner_study_is_exposure_and_provenance_not_forced_cognitive_memory(tmp_path:Path):
    store=LocalEventStore(tmp_path/'study.sqlite3');n=Noeron(MockLanguageEngine(),store)
    report=n.study_document('Owner curriculum','Aster is Borel.','owner-test',max_segments=1)
    assert report.consolidated_segment_memories==0
    assert len(store.cognitive_memories())==0
    pending=store.pending_cognitive_provenance_memories()
    rows=[m for m in pending if m.memory_class=='owner-study-provenance-pending-cognitive']
    assert len(rows)==1
    sm=store.stratified_learning_memory_by_id(str(rows[0].id),include_archived=True)
    assert sm is not None and sm.consolidated is False
    assert rows[0].id in n.state.cognition.memory_retention.pending_provenance_memory_ids


def test_owner_language_teaching_changes_explicit_curriculum_state_but_not_force_dkt_memory(tmp_path:Path):
    store=LocalEventStore(tmp_path/'language.sqlite3');n=Noeron(MockLanguageEngine(),store)
    out=n.teach_language('A question asks for information.','owner-curriculum')
    assert out['status']=='committed-owner-curriculum-exposure'
    assert out['cognitive_memory_activated'] is False
    assert len(store.cognitive_memories())==0
    pending=store.pending_cognitive_provenance_memories()
    assert len(pending)==1 and pending[0].memory_class=='owner-language-provenance-pending-cognitive'
    # Explicit teaching is allowed to alter the language-learning substrate, but it
    # is not relabeled as Yggdrasil spontaneously choosing the lesson as memory.
    assert n.state.cognition.language.propositions


def test_communication_common_reference_is_frequency_neutral_across_affordance_models():
    from noeron.cognition.models import InitiativeDevelopmentState
    from noeron.initiative import InitiativePolicy
    from noeron.math import dkt
    pol=InitiativePolicy();st=InitiativeDevelopmentState();a=dkt.reference_knot()
    express=a.model_copy(deep=True);express.cosine[4][0]+=0.10;express.invariant_signature=dkt.invariant_signature(express)
    private=a.model_copy(deep=True);private.cosine[4][1]+=0.16;private.invariant_signature=dkt.invariant_signature(private)
    pol.observe_transition(st,'express',a,express)
    pol.observe_transition(st,'continue-private',a,private)
    target=st.admissible_post_knot.model_copy(deep=True)
    for _ in range(8):pol.observe_transition(st,'continue-private',a,private)
    assert st.admissible_post_observations==2
    assert dkt.sobolev_distance(target,st.admissible_post_knot)<=1e-12
