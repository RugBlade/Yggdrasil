from pathlib import Path

from noeron.llm import MockLanguageEngine
from noeron.memory import LocalEventStore
from noeron.models import CognitiveEvent, EventKind
from noeron.orchestrator import Noeron


def _activate_retained_study_segments(n, count:int=2):
    """Build an already-retained cognitive fixture without making owner study authoritative."""
    pending=[m for m in n.store.pending_cognitive_provenance_memories() if m.memory_class=='owner-study-provenance-pending-cognitive']
    assert len(pending)>=count
    for full in pending[:count]:
        sm=n.store.stratified_learning_memory_by_id(str(full.id),include_archived=True)
        assert sm is not None and sm.consolidated is False
        sm.consolidated=True; sm.memory_class='learned-stratified-native-retained'
        n.store.upsert_stratified_learning_memory(sm)
        full.memory_class='owner-study-provenance-native-retained-compressed'; full.consolidated=False
        n.store.upsert_knot_memory(full)
        st=n.state.cognition.memory_retention
        if full.id not in st.native_retained_memory_ids: st.native_retained_memory_ids.append(full.id)
        if full.id in st.pending_provenance_memory_ids: st.pending_provenance_memory_ids.remove(full.id)


def test_v065_preview_removes_closing_boundaries_and_list_scaffolding(tmp_path: Path):
    n = Noeron(MockLanguageEngine(), LocalEventStore(tmp_path / 'p.db'))
    tex = r"""\documentclass{article}
\begin{document}
\begin{lemma}
Let $x\in\mathbb{R}$.
\end{lemma}
\begin{proof}
\begin{itemize}
\item Since $x\in\mathbb{R}$, the claim follows.
\end{itemize}
\end{proof}
\end{document}
"""
    p = n.learning_preview('clean', tex, 0, 20)
    joined = ' '.join(p.segment_previews).lower()
    assert '[/lemma]' not in joined
    assert '[/proof]' not in joined
    assert 'itemize' not in joined
    assert '\\item' not in joined
    assert 'real-number-space' in joined


def test_v065_actual_style_math_names_and_notation_are_cleaned(tmp_path: Path):
    n = Noeron(MockLanguageEngine(), LocalEventStore(tmp_path / 'm.db'))
    tex = r"""\documentclass{article}
\begin{document}
The Fr{\'e}chet space $C^{\infty}$ contains $\text{Emb}(S^1,\mathbb{R}^3)$.
\end{document}
"""
    p = n.learning_preview('math', tex, 0, 20)
    joined = ' '.join(p.segment_previews).lower()
    terms = set(p.candidate_residual_terms)
    assert 'frechet' in joined
    assert 'embedding-space' in joined
    assert 'infinity-symbol' in joined
    assert 'chet-space' not in terms
    assert 'emb' not in terms
    assert 'infty' not in terms


def test_single_observation_coherence_is_unestimated(tmp_path: Path):
    n = Noeron(MockLanguageEngine(), LocalEventStore(tmp_path / 'c.db'))
    n.study_document('one', 'A manifold carries geometric structure.', mode='complete', max_segments=5)
    p = n.store.semantic_prototype_map().get('manifold')
    assert p is not None
    assert p.observations == 1
    assert p.context_coherence is None
    r = n.learning_rate()
    assert r.coherence_eligible_prototypes == 0
    assert r.eligible_prototype_coherence == 0.0


def test_multi_memory_reasoning_uses_multiple_dkt_memories_and_is_read_only_probe(tmp_path: Path):
    n = Noeron(MockLanguageEngine(), LocalEventStore(tmp_path / 'r.db'))
    text = '\n\n'.join([
        'A quasar is a luminous astronomical source in a distant galaxy.',
        'A quasar is an energetic galactic source with luminous emission.',
        'Quasar observations describe luminous distant galactic activity.',
        'A quasar source can be compared with another luminous quasar source.',
        'The quasar remains an astronomical source in this geometric note.',
        'A luminous quasar belongs to the same astronomical discussion.',
    ])
    n.study_document('quasar', text, mode='complete', max_segments=20)
    _activate_retained_study_segments(n,2)
    before = n.state.model_dump_json()
    r = n.reasoning_probe('What can you determine by reasoning across the quasar memories?', limit=6)
    after = n.state.model_dump_json()
    assert before == after
    assert len(r.memory_ids) >= 2
    assert r.active is True
    assert r.learned_memory_count >= 2
    assert r.reasoning_mode in {'local-component-synthesis', 'intrastratum-multi-component', 'cross-stratum-contrast'}
    assert len(r.logical_target) == 8


def test_normal_reasoning_query_has_causal_multi_memory_workspace(tmp_path: Path):
    n = Noeron(MockLanguageEngine(), LocalEventStore(tmp_path / 'q.db'))
    text = '\n\n'.join(['A quasar is a luminous astronomical source in a distant galaxy.' for _ in range(12)])
    n.study_document('quasar', text, mode='complete', max_segments=30)
    _activate_retained_study_segments(n,2)
    reply = n.ingest(CognitiveEvent(kind=EventKind.USER_MESSAGE, source='u', content='What can you determine from reasoning across your quasar memories?', trusted=True))
    rr = reply.state.math_kernel.reasoning
    assert rr.active is True
    assert len(rr.memory_ids) >= 2
    assert rr.learned_memory_count >= 2
    # The multi-memory workspace is causally active mathematics, not a canned self-report.
    assert rr.workspace_knot is not None
    assert reply.native_text == ''
    assert reply.state.cognition.last_thought is None


def test_repeated_reasoning_can_form_higher_order_geometric_concept(tmp_path: Path):
    from types import SimpleNamespace
    from uuid import uuid4
    from noeron.cognition.models import KnotMemory
    from noeron.math import dkt
    from noeron.math.models import MathKernelState, MultiMemoryReasoningMathState

    n = Noeron(MockLanguageEngine(), LocalEventStore(tmp_path / 'f.db'))
    sid = uuid4(); cid1 = uuid4(); cid2 = uuid4(); k = dkt.reference_knot()
    m1 = KnotMemory(source_event_id=uuid4(), knot=k.model_copy(deep=True), semantic_stratum_id=sid, isotopy_component_id=cid1, source_title='synthetic learned source', memory_class='learned-stratified-segment')
    k2 = dkt.interpolate(k, k, 0.5)
    m2 = KnotMemory(source_event_id=uuid4(), knot=k2, semantic_stratum_id=sid, isotopy_component_id=cid2, source_title='synthetic learned source', memory_class='learned-stratified-segment')
    reasoning = MultiMemoryReasoningMathState(active=True, memory_ids=[str(m1.id),str(m2.id)], distances=[0.2,0.3], weights=[0.55,0.45], learned_memory_count=2, semantic_stratum_ids=[str(sid)], isotopy_component_ids=[str(cid1),str(cid2)], dominant_bundle_key=f'stratum:{sid}', dominant_support_concentration=1.0, within_bundle_hs_dispersion=0.1, structural_agreement=0.9, reasoning_mode='intrastratum-multi-component', logical_target=[0.0]*8, workspace_knot=k.model_copy(deep=True), bridge_distance_hs=0.0, confidence=0.9)
    result = SimpleNamespace(state=MathKernelState(reasoning=reasoning), retrieved=[(0.2,m1),(0.3,m2)])
    n.state.cognition.stratification_epoch = 1
    first = n._observe_reasoning_concept(result); second = n._observe_reasoning_concept(result)
    assert first is not None and second is not None
    concepts = n.store.reasoning_concepts()
    assert len(concepts) == 1
    assert concepts[0].observations == 2
    assert n.state.cognition.reasoning_concept_count == 1
    assert concepts[0].geometry_version.endswith('v0.6.9')
