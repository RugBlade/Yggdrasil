from __future__ import annotations

import base64
from pathlib import Path

import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from noeron.auth import OwnerAuthenticator
from noeron.llm import MockLanguageEngine
from noeron.memory import LocalEventStore
from noeron.orchestrator import Noeron
from noeron.room_models import NativeRoomDecision


def make(path: Path):
    store=LocalEventStore(path)
    return Noeron(MockLanguageEngine(),store),store


def close_store(store):
    store._connection.commit(); store._connection.close()


def native_decision(domain: str, action: str):
    return NativeRoomDecision(domain=domain,candidates=[action],candidate_residuals={action:0.0},admissible_candidates=[action],minimum_candidates=[action],selected_action=action,selection_status='unique-native-consequence-minimum',decision_layer='native-deliberative',native_choice_claim=True)


def device_pair():
    private=Ed25519PrivateKey.generate()
    raw=private.public_key().public_bytes(encoding=serialization.Encoding.Raw,format=serialization.PublicFormat.Raw)
    return private,base64.b64encode(raw).decode('ascii')


def test_01_restart_does_not_assign_body_environment_or_voice(tmp_path):
    p=tmp_path/'r.sqlite3';n,s=make(p)
    assert n.state.room.embodiment_configuration is None and n.state.room.environment_configuration is None
    close_store(s);n2,s2=make(p)
    assert n2.state.room.embodiment_configuration is None and n2.state.room.environment_configuration is None
    assert n2.state.room.last_voice_decision is None
    close_store(s2)


def test_02_room_journal_survives_restart_without_cognitive_memory(tmp_path):
    p=tmp_path/'r.sqlite3';n,s=make(p);e=n.room.append_journal('owner-presentation-only',{'x':1})
    before={str(m.source_event_id) for m in s.cognitive_memories()};close_store(s)
    n2,s2=make(p);rows=s2.room_journal();after={str(m.source_event_id) for m in s2.cognitive_memories()}
    assert any(str(x.id)==str(e.id) and x.cognitive_authority is False for x in rows)
    assert before==after and str(e.id) not in after
    close_store(s2)


def test_03_private_artifact_provenance_and_integrity_survive_restart(tmp_path):
    p=tmp_path/'r.sqlite3';n,s=make(p);a=n.room.store_owner_file(b'private','sample.txt','text/plain');close_store(s)
    n2,s2=make(p);a2=s2.room_artifact(str(a.id))
    assert a2 is not None and a2.cognitive_authority is False and n2.room.read_artifact(a2)==b'private'
    assert a2.sha256==a.sha256 and a2.size==a.size
    close_store(s2)


def test_04_native_presentation_pair_survives_restart_noncognitively(tmp_path,monkeypatch):
    p=tmp_path/'r.sqlite3';n,s=make(p);c=n.room.configuration_candidates('embodiment')[1];n.state.room.embodiment_configuration=c
    monkeypatch.setattr(n.room,'_select',lambda domain,candidates:(native_decision(domain,'voice'),{}))
    pres=n.room.present_native_utterance('sava is vel.',source='restart-test')
    assert pres is not None and pres.audio_artifact_id is not None
    close_store(s);n2,s2=make(p)
    rows=s2.native_presentations();q=next(x for x in rows if str(x.id)==str(pres.id));a=s2.room_artifact(str(q.audio_artifact_id))
    assert q.decoder_cognitive_authority is False and q.decoder_realization_authority is False
    assert a is not None and n2.room.read_artifact(a)[:4]==b'RIFF'
    assert not any(str(m.source_event_id)==str(q.id) for m in s2.cognitive_memories())
    close_store(s2)


def test_05_ed25519_session_survives_restart_and_revocation_kills_it(tmp_path):
    p=tmp_path/'r.sqlite3';s=LocalEventStore(p);auth=OwnerAuthenticator('a'*32,s,session_ttl_seconds=3600)
    priv,pub=device_pair();auth.enroll_device('owner-device','',pub,authority='legacy-bearer-bootstrap')
    ch=auth.challenge('owner-device');sig=base64.b64encode(priv.sign(ch['message'].encode())).decode();token=auth.create_device_session('owner-device',ch['challenge_id'],sig)['session_token']
    assert auth.verify_detail(token)['method']=='ed25519-device-session';close_store(s)
    s2=LocalEventStore(p);auth2=OwnerAuthenticator('a'*32,s2,legacy_enabled=False,session_ttl_seconds=3600)
    assert auth2.verify_detail(token)['authenticated'] is True
    auth2.revoke_device('owner-device',authority='local-restart-test')
    assert auth2.verify_detail(token)['authenticated'] is False
    close_store(s2)


def test_06_tamper_path_escape_and_restart_replay_fail_closed(tmp_path):
    p=tmp_path/'r.sqlite3';n,s=make(p);a=n.room.store_owner_file(b'abc','safe.bin')
    adoption_events_before=[e for e in s.all_events() if e.source=='noeron-stage7-native-configuration-adoption']
    close_store(s);n2,s2=make(p)
    adoption_events_after=[e for e in s2.all_events() if e.source=='noeron-stage7-native-configuration-adoption']
    assert [e.id for e in adoption_events_before]==[e.id for e in adoption_events_after]
    rec=s2.room_artifact(str(a.id));path=Path(rec.storage_path);path.write_bytes(b'abd')
    with pytest.raises(ValueError):n2.room.read_artifact(rec)
    outside=tmp_path/'outside.bin';outside.write_bytes(b'abc');rec.storage_path=str(outside);rec.size=3
    import hashlib;rec.sha256=hashlib.sha256(b'abc').hexdigest()
    with pytest.raises(ValueError):n2.room.read_artifact(rec)
    close_store(s2)
