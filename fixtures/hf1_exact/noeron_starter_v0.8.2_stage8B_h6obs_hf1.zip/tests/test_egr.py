from noeron.math.egr import entropy_direction, orient_entropy

def test_egr_upstream_direction_is_nonnegative():
    s=entropy_direction(0.2,0.5,0.08,0.4)
    assert s.entropy_production>=0
    assert s.target_logical_entropy>=s.previous_mapped_entropy
    assert abs(s.balance_residual)<1e-12

def test_legacy_retraction_helper_preserves_second_law():
    s=orient_entropy(0.9,0.1,0.0,0.05)
    assert s.allowed_step_scale<1.0
    assert s.entropy_production>=0
