from pathlib import Path
import pytest

from noeron.llm import MockLanguageEngine
from noeron.memory import LocalEventStore
from noeron.orchestrator import Noeron
from noeron.math import dkt


def _same_source_text():
    return '''# Knot note
A smooth knot embedding belongs to a Sobolev manifold and a topological embedding space.

## Nearby embeddings
A smooth knot embedding can be compared with another nearby embedding in the same manifold.

## Quotient geometry
The quotient space and smooth embedding geometry remain part of the knot manifold.

## Sobolev structure
A Sobolev manifold supports smooth embedding geometry and topological structure.
'''


def test_same_file_different_titles_are_one_canonical_lineage(tmp_path: Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'lineage.db'))
    text=_same_source_text(); source='/opt/noeron/app/docs/research/same.tex'
    n.study_document('Same manuscript',text,source_name=source,mode='complete',start_segment=0,max_segments=2)
    n.study_document('Same manuscript — batch 2',text,source_name=source,mode='complete',start_segment=2,max_segments=2)
    lineages=n.learning_lineages()
    assert len(lineages)==1
    assert lineages[0]['session_count']==2
    assert lineages[0]['studied_segments']==4
    sources=n.store.learning_sources()
    assert sources[0].canonical_source_id==sources[1].canonical_source_id
    assert sources[0].session_index==1 and sources[1].session_index==2
    assert sources[0].source_version_sha256==sources[1].source_version_sha256


def test_recluster_preview_is_read_only_and_commit_is_noop_until_study_is_natively_retained(tmp_path: Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'recluster.db'))
    text=_same_source_text(); source='/tmp/same.tex'
    n.study_document('Same manuscript',text,source_name=source,mode='complete',start_segment=0,max_segments=2)
    n.study_document('Same manuscript — batch 2',text,source_name=source,mode='complete',start_segment=2,max_segments=2)
    before_turn=n.state.conversational_turn
    assert not n.store.stratified_learning_memories()
    assert n.store.archived_stratified_learning_memories()
    state_before=n.state.model_dump_json()
    preview=n.recluster_preview()
    assert n.state.model_dump_json()==state_before
    assert preview['status']=='read-only-preview'
    assert preview['memory_count']==0
    assert preview['plan_digest'].startswith('recluster-')
    with pytest.raises(ValueError): n.recluster_commit('recluster-wrong-plan-digest')
    report=n.recluster_commit(preview['plan_digest'])
    assert report['status']=='no-op'
    assert report['reason']=='no active stratified learning memories'
    assert n.state.conversational_turn==before_turn
    assert n.state.cognition.stratification_epoch==0
    # Owner exposure may form provisional semantic organization, but the cognitive
    # recluster operation has no authority until native retention activates members.
    assert n.store.archived_stratified_learning_memories()


def test_reasoning_concepts_do_not_require_owner_maturity_gate(tmp_path: Path):
    from types import SimpleNamespace
    from uuid import uuid4
    from noeron.cognition.models import KnotMemory
    from noeron.math.models import MathKernelState, MultiMemoryReasoningMathState

    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'concept-gate.db'))
    sid=uuid4(); cid=uuid4(); k=dkt.reference_knot()
    m1=KnotMemory(source_event_id=uuid4(),knot=k,semantic_stratum_id=sid,isotopy_component_id=cid,memory_class='learned-stratified-segment')
    m2=KnotMemory(source_event_id=uuid4(),knot=k,semantic_stratum_id=sid,isotopy_component_id=cid,memory_class='learned-stratified-segment')
    r=MultiMemoryReasoningMathState(active=True,memory_ids=[str(m1.id),str(m2.id)],learned_memory_count=2,semantic_stratum_ids=[str(sid)],isotopy_component_ids=[str(cid)],dominant_support_concentration=1.0,structural_agreement=0.9,reasoning_mode='local-component-synthesis',logical_target=[0.0]*8,workspace_knot=k,confidence=0.9)
    result=SimpleNamespace(state=MathKernelState(reasoning=r),retrieved=[(0.1,m1),(0.2,m2)])
    c=n._observe_reasoning_concept(result)
    assert c is not None
    assert c.status=='observed-once'


def test_one_off_prototype_history_is_retained_without_authored_dormancy_choice(tmp_path: Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'hygiene.db'))
    source='/tmp/curriculum.txt'
    n.study_document('s1','Nebularion appears in this isolated note.',source_name=source,mode='complete')
    assert n.store.semantic_prototype_map()['nebularion'].observations==1
    for i,text in enumerate(['A manifold is smooth.','A tensor field is geometric.','A quotient space is topological.'],start=2):
        n.study_document(f's{i}',text,source_name=source,mode='complete')
    p=n.store.semantic_prototype_map()['nebularion']
    assert p.missed_learning_sessions>=3
    assert p.status=='observed-once'
    # v0.7.3.4 records recurrence gaps but does not convert an authored three-session rule into semantic worth.
    assert 'nebularion' not in {x['term'] for x in n.learning_prototypes()} if hasattr(n,'learning_prototypes') else True


def test_v066_additional_notation_is_structural_not_lexical(tmp_path: Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'notation.db'))
    tex=r'''\documentclass{article}
\begin{document}
Let $A\hookrightarrow B$, $x\leq y$, and $U=\bigcup_i U_i$.
\end{document}
'''
    p=n.learning_preview('notation',tex,0,10)
    joined=' '.join(p.segment_previews)
    terms=set(p.candidate_residual_terms)
    assert 'embedding-arrow' in joined
    assert 'less-or-equal-relation' in joined
    assert 'union-operator' in joined
    assert 'hookrightarrow' not in terms
    assert 'leq' not in terms
    assert 'bigcup' not in terms
