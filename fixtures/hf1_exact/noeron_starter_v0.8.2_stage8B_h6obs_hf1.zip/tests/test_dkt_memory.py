from noeron.math import dkt
from noeron.math.irg import interaction_geometry
from noeron.models import CognitiveEvent,EventKind

def event(text):return CognitiveEvent(kind=EventKind.USER_MESSAGE,source='test',content=text,trusted=True)
def test_events_become_actual_knots_and_distance_is_geometric():
    a=dkt.experience_knot(interaction_geometry(event('DKT memory knot geometry')))
    b=dkt.experience_knot(interaction_geometry(event('DKT memory knot geometry')))
    c=dkt.experience_knot(interaction_geometry(event('completely different cooking weather bicycle')))
    assert dkt.sobolev_distance(a,b)<1e-12
    assert dkt.sobolev_distance(a,c)>0
    assert a.cosine[1][0]==1.0 and a.sine[1][1]==1.0

from noeron.cognition.models import KnotMemory
from uuid import uuid4

def test_dkt_geometry_selects_memory_without_text_search():
    irga=interaction_geometry(event('alpha geometry experience'))
    irgb=interaction_geometry(event('beta unrelated experience'))
    ka=dkt.experience_knot(irga); kb=dkt.experience_knot(irgb)
    ma=KnotMemory(source_event_id=uuid4(),knot=ka,provenance_excerpt='same text is irrelevant')
    mb=KnotMemory(source_event_id=uuid4(),knot=kb,provenance_excerpt='same text is irrelevant')
    assert dkt.retrieve(ka,[mb,ma],limit=1)[0][1].id==ma.id
    assert dkt.retrieve(kb,[ma,mb],limit=1)[0][1].id==mb.id
