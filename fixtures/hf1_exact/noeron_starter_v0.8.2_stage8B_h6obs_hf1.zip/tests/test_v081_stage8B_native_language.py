from __future__ import annotations

from copy import deepcopy

from noeron.cognition.models import LanguageFacultyState
from noeron.language_composition import (
    COMPOSITION_VERSION,
    LANGUAGE_MECHANISM_VERSION,
    analyze_surface_composition,
)
from noeron.llm import MockLanguageEngine
from noeron.memory import LocalEventStore
from noeron.models import NoeronState
from noeron.orchestrator import Noeron


def _noeron(tmp_path, *, terra=False):
    return Noeron(
        MockLanguageEngine(),
        LocalEventStore(tmp_path / "noeron.sqlite3"),
        terra_enabled=terra,
        engineering_source_root=str(tmp_path),
    )


def test_stage8b_composition_recognizes_generic_structure_without_authority():
    audit = analyze_surface_composition(
        "Why might every candidate not pass because the test is uncertain?"
    )
    frames = audit["frame_counts"]
    assert frames["question"] == 1
    assert frames["why-question"] == 1
    assert frames["quantifier:universal"] == 1
    assert frames["negation"] == 1
    assert frames["modality:might"] == 1
    assert frames["uncertainty-marker"] == 1
    assert frames["causal-because"] == 1
    for key in (
        "semantic_authority",
        "cognitive_memory_authority",
        "answer_selection_authority",
        "terra_authority",
        "relationship_authority",
        "source_write_authority",
        "deployment_authority",
    ):
        assert audit[key] is False


def test_stage8b_conditional_clause_roles_are_structural_not_opaque():
    audit = analyze_surface_composition(
        "If the candidate fails, then perhaps it should be revised."
    )
    row = audit["sentences"][0]
    assert "conditional" in row["frames"]
    roles = {x["role"]: x["text"] for x in row["clauses"]}
    assert roles["antecedent"] == "the candidate fails"
    assert "perhaps it should be revised" == roles["consequent"]
    link = next(x for x in row["links"] if x["relation"] == "conditional")
    assert link["authority"] == "surface-composition-only"
    assert audit["semantic_authority"] is False


def test_stage8b_unknown_why_question_gains_question_structure_but_no_answer(tmp_path):
    y = _noeron(tmp_path)
    out = y.language_parse("Why does a flarn orbit a zibble?")
    comp = out["stage8b_composition_audit"]
    assert comp["frame_counts"]["why-question"] == 1
    assert out["answer_supported"] is False
    assert comp["answer_selection_authority"] is False


def test_stage8b_read_only_parse_exposes_rich_composition_without_state_change(tmp_path):
    y = _noeron(tmp_path)
    before = y.state.model_dump(mode="json")
    out = y.language_parse("If all knots change, then perhaps a test should run.")
    after = y.state.model_dump(mode="json")
    assert before == after
    assert out["composition_audit"]["frame_counts"]["conditional"] == 1
    assert out["stage8b_composition_audit"]["semantic_authority"] is False


def test_stage8b_preview_is_nonmutating_and_reports_composition(tmp_path):
    y = _noeron(tmp_path)
    before = y.state.model_dump(mode="json")
    out = y.language_preview("Every test may pass, but perhaps another test will fail.")
    after = y.state.model_dump(mode="json")
    assert before == after
    audit = out["stage8b_composition_audit"]
    assert audit["frame_counts"]["quantifier:universal"] == 1
    assert audit["frame_counts"]["modality:may"] == 1
    assert audit["frame_counts"]["contrast"] >= 1
    assert audit["semantic_authority"] is False


def test_stage8b_owner_curriculum_persists_compact_grammar_growth_but_not_cognitive_authority(tmp_path):
    y = _noeron(tmp_path)
    before = dict(y.state.cognition.language.composition_frame_counts)
    out = y.teach_language(
        "If a patch fails, then it should be revised because a test failed.",
        source="owner-stage8b-curriculum",
    )
    assert out["cognitive_memory_activated"] is False
    st = y.state.cognition.language
    assert st.composition_frame_counts.get("conditional", 0) > before.get("conditional", 0)
    assert st.composition_frame_counts.get("modality:should", 0) > before.get("modality:should", 0)
    assert st.last_composition_audit["semantic_authority"] is False
    assert st.last_composition_audit["cognitive_memory_authority"] is False


def test_stage8b_migration_is_prospective_and_idempotent(tmp_path):
    store = LocalEventStore(tmp_path / "noeron.sqlite3")
    old = NoeronState()
    old.cognition.language = LanguageFacultyState(
        version="0.7.5",
        schema_version="0.7.5",
        mechanism_version="0.7.5",
        grammar_frames={"declarative": 11, "question": 7},
        sentences_observed=41,
        lessons_observed=3,
    )
    store.append_state(old)

    y = Noeron(
        MockLanguageEngine(),
        store,
        terra_enabled=False,
        engineering_source_root=str(tmp_path),
    )
    st = y.state.cognition.language
    assert st.v081_stage8b_started is True
    assert st.legacy_pre_v081_grammar_frames == {"declarative": 11, "question": 7}
    # No historical replay into the new frame counter.
    assert st.composition_frame_counts == {}
    assert st.sentences_observed == 41
    assert st.lessons_observed == 3

    # Re-running the migration must not move/recount historical grammar.
    snapshot = st.model_dump(mode="json")
    y._migrate_v081_stage8b_language()
    assert y.state.cognition.language.model_dump(mode="json") == snapshot


def test_stage8b_language_state_reports_new_mechanism_without_relabelling_other_faculties(tmp_path):
    y = _noeron(tmp_path)
    out = y.language_state()
    assert out["version"] == "0.8.1"
    assert out["schema_version"] == "0.8.1"
    assert out["mechanism_version"] == LANGUAGE_MECHANISM_VERSION
    assert out["composition_version"] == COMPOSITION_VERSION
    assert out["stage8b_started"] is True
    assert y.state.cognition.version == "0.7.5.1"
    assert y.state.cognition.memory_retention.mechanism_version == "0.7.4"
    assert y.state.cognition.initiative_development.mechanism_version == "0.7.4"


def test_stage8b_terra_stays_downstream_and_composition_has_no_tool_authority(tmp_path):
    y = _noeron(tmp_path, terra=False)
    out = y.language_parse("How could a test fail if the source changes?")
    comp = out["stage8b_composition_audit"]
    assert comp["frame_counts"]["how-question"] == 1
    assert comp["terra_authority"] is False
    assert y.terra_enabled is False
    assert y.language_state()["composition_version"] == COMPOSITION_VERSION
