from pathlib import Path

from noeron.learning import normalize_learning_document, preview_document
from noeron.llm import MockLanguageEngine
from noeron.memory import LocalEventStore
from noeron.orchestrator import Noeron


def test_math_notation_is_canonicalized_without_learning_tex_command_names(tmp_path:Path):
    tex=r'''\documentclass{article}
\begin{document}
\section{Objects}
Let $x\in\mathbb{R}$ and let $A\subset\mathbb{R}$. Define $x\sim y$ as an equivalence relation.
\end{document}
'''
    normalized,_,notes=normalize_learning_document(tex)
    low=normalized.lower()
    assert 'real-number-space' in low
    assert 'membership-relation' in low
    assert 'subset-relation' in low
    assert 'equivalence-relation' in low
    assert 'mathbb' not in low
    assert any('mathematical notation canonicalization' in x for x in notes)


def test_preview_forms_compound_math_concepts_and_filters_background(tmp_path:Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'p.db'))
    text='''# Geometry\nA Sobolev-Riemannian manifold supports a tensor field.\n\nThe Sobolev-Riemannian manifold supports another tensor field.\n'''
    p=n.learning_preview('geometry',text,0,10)
    assert 'sobolev-riemannian-manifold' in p.candidate_residual_terms
    assert 'tensor-field' in p.candidate_residual_terms
    assert 'begin' not in p.candidate_residual_terms


def test_structural_role_gating_does_not_establish_background_but_can_establish_content(tmp_path:Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'g.db'))
    text='''# Geometry\nA manifold is a geometric space used in this note.\n\nThe manifold carries local geometric structure.\n\nThis manifold appears again in the geometric construction.\n'''
    n.study_document('geometry',text,mode='complete',max_segments=10)
    p=n.store.semantic_prototype_map().get('manifold')
    assert p is not None and p.status=='observed-recurrent'
    assert p.establishment_score==0.0
    assert n.store.semantic_prototype_map().get('begin') is None


def test_learning_rate_separates_throughput_from_structural_assimilation(tmp_path:Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'r.db'))
    text='\n\n'.join(['A quasar is a luminous astronomical source in a distant galaxy.' for _ in range(12)])
    n.study_document('repeated quasar',text,mode='complete',max_segments=30)
    r=n.learning_rate()
    assert r.studied_segments>=3
    assert r.processing_segments_per_second>=0
    assert 0 <= r.prototype_establishment_fraction <= 1
    assert 0 <= r.component_reuse_fraction <= 1
    assert 0 <= r.stratum_reuse_fraction <= 1
    assert 'processing_throughput' in r.learning_rate_vector
    assert 'component_reuse' in r.learning_rate_vector
    # Owner study creates provenance/topology exposure but does not force any
    # segment into active cognitive memory; cognitive-assimilation occupancy is
    # therefore legitimately zero until native retention selects a segment.
    assert r.compressed_segment_memories==0
    assert r.mean_members_per_component==0.0
