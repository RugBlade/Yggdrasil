from pathlib import Path
from noeron.memory import LocalEventStore
from noeron.cognition.models import KnotMemory
from noeron.math.dkt import reference_knot
from noeron.models import CognitiveEvent,EventKind

def test_sqlite_serializes_knot_memory_without_text_search(tmp_path:Path):
    st=LocalEventStore(tmp_path/'n.db'); e=CognitiveEvent(kind=EventKind.USER_MESSAGE,source='t',content='hello',trusted=True); st.append_event(e)
    m=KnotMemory(source_event_id=e.id,knot=reference_knot(),provenance_excerpt='hello'); st.append_knot_memory(m)
    assert len(st.knot_memories())==1
    assert st.knot_memory_for_event(str(e.id)).knot.cosine[1][0]==1.0
