from __future__ import annotations

import inspect
from pathlib import Path

from noeron.cognition.models import RealizationDevelopmentState
from noeron.math import dkt
from noeron.memory import LocalEventStore
from noeron.models import CognitiveEvent,EventKind
from noeron.orchestrator import Noeron
from noeron.realization import RealizationPolicy


class CountingFaithfulEngine:
    def __init__(self):self.calls=0
    def generate(self,messages):
        self.calls+=1
        last=messages[-1]['content']
        return last.split('NOERON_OUTPUT:\n',1)[-1]


def _event(text:str,**meta):
    m={'owner_authenticated':True,'owner_device_id':'test-device'};m.update(meta)
    return CognitiveEvent(kind=EventKind.USER_MESSAGE,source='authenticated-owner',content=text,trusted=True,metadata=m)


def test_incomplete_native_lexicon_does_not_automatically_invoke_terra(tmp_path:Path):
    engine=CountingFaithfulEngine();n=Noeron(engine,LocalEventStore(tmp_path/'r.sqlite3'))
    r=n.ingest(_event('Every glorp is a blin. Mavo is a glorp. What follows?'))
    assert r.native_text
    assert r.text==''
    assert r.renderer_used is False
    assert engine.calls==0
    st=n.state.cognition.realization_development
    assert st.last_native_choice_claim is False
    assert st.last_selection_status=='unresolved-insufficient-realization-consequence-geometry'
    assert st.last_effective_action==''
    assert st.pending_action=='' and st.pending_decision_layer==''


def test_owner_can_force_terra_only_as_explicit_calibration_not_yggdrasil_preference(tmp_path:Path):
    engine=CountingFaithfulEngine();n=Noeron(engine,LocalEventStore(tmp_path/'r.sqlite3'))
    r=n.ingest(_event('Every glorp is a blin. Mavo is a glorp. What follows?',operator_realization_override='terra-render'))
    assert r.renderer_used is True and engine.calls==1
    st=n.state.cognition.realization_development
    assert st.last_native_choice_claim is False
    assert st.last_decision_layer=='operator-directed-calibration'
    assert st.last_effective_action=='terra-render'
    assert st.operator_calibration_observations==1
    # The next admitted interaction supplies the observed post-state consequence.
    n.ingest(_event('Aster is Borel.'))
    assert n.state.cognition.realization_development.action_observations.get('terra-render',0)==1


def test_unresolved_realization_executes_no_path_and_cannot_train_native_direct_by_fallback(tmp_path:Path):
    engine=CountingFaithfulEngine();n=Noeron(engine,LocalEventStore(tmp_path/'r.sqlite3'))
    first=n.ingest(_event('Every glorp is a blin. Mavo is a glorp. What follows?'))
    assert first.native_text and first.text=='' and engine.calls==0
    n.ingest(_event('Aster is Borel.'))
    st=n.state.cognition.realization_development
    assert st.action_observations.get('native-direct',0)==0
    assert st.transition_observations==0
    assert st.pending_action==''


def test_owner_can_calibrate_native_direct_as_nonchoice_empirical_exposure(tmp_path:Path):
    engine=CountingFaithfulEngine();n=Noeron(engine,LocalEventStore(tmp_path/'r.sqlite3'))
    first=n.ingest(_event('Every glorp is a blin. Mavo is a glorp. What follows?',operator_realization_override='native-direct'))
    assert first.native_text and first.text==first.native_text and first.renderer_used is False and engine.calls==0
    st=n.state.cognition.realization_development
    assert st.last_native_choice_claim is False and st.last_decision_layer=='operator-directed-calibration'
    assert st.pending_action=='native-direct'
    n.ingest(_event('Aster is Borel.'))
    assert n.state.cognition.realization_development.action_observations.get('native-direct',0)==1


def test_realization_policy_selects_only_unique_learned_post_state_minimum():
    pol=RealizationPolicy();st=RealizationDevelopmentState();a=dkt.reference_knot()
    pre_terra=a.model_copy(deep=True);pre_terra.cosine[4][0]+=0.10;pre_terra.invariant_signature=dkt.invariant_signature(pre_terra)
    post_terra=a.model_copy(deep=True);post_terra.cosine[4][0]+=0.20;post_terra.invariant_signature=dkt.invariant_signature(post_terra)
    assert pol.choose(a,st)['action'] is None
    # Empirical consequences only: native-direct observed a -> a, while Terra was
    # observed in a different context as +0.10 -> +0.20.  The equal-affordance
    # admissible post manifold is learned by the implementation itself; the test
    # never substitutes an action-specific target.
    pol.observe_transition(st,'native-direct',a,a)
    pol.observe_transition(st,'terra-render',pre_terra,post_terra)
    assert st.admissible_post_observations==2 and st.admissible_post_knot is not None
    out=pol.choose(a,st)
    assert out['native_choice_claim'] is True
    assert out['decision_layer']=='learned-deliberative'
    assert out['action']=='terra-render'
    assert out['candidate_distances']['terra-render'] < out['candidate_distances']['native-direct']


def test_orchestrator_has_no_renderer_needed_auto_invocation_branch():
    src=inspect.getsource(Noeron)
    assert 'if utterance.renderer_needed' not in src
    assert 'not thought.native_utterance.renderer_needed' not in src


def test_realization_common_reference_is_frequency_neutral_across_affordance_models():
    pol=RealizationPolicy();st=RealizationDevelopmentState();a=dkt.reference_knot()
    native=a.model_copy(deep=True);native.cosine[4][0]+=0.12;native.invariant_signature=dkt.invariant_signature(native)
    terra=a.model_copy(deep=True);terra.cosine[4][1]+=0.20;terra.invariant_signature=dkt.invariant_signature(terra)
    pol.observe_transition(st,'native-direct',a,native)
    pol.observe_transition(st,'terra-render',a,terra)
    target=st.admissible_post_knot.model_copy(deep=True)
    # Repeated empirical native-direct calibration observations may refine its own
    # model but must not give it extra mass in the common reference.
    for _ in range(8):pol.observe_transition(st,'native-direct',a,native)
    assert st.admissible_post_observations==2
    assert dkt.sobolev_distance(target,st.admissible_post_knot)<=1e-12
