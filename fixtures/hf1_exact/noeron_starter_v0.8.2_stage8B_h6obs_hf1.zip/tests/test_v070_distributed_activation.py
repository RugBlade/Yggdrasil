from types import SimpleNamespace
from uuid import uuid4

from noeron.math.affect import project_regional_activation, proto_affective_state
from noeron.math.models import EGRMathState


def mem(cls,coords,stratum=None):
    return SimpleNamespace(memory_class=cls,semantic_stratum_id=stratum,isotopy_component_id=None,logical_coordinates=coords)


def reasoning(weights):
    return SimpleNamespace(weights=weights,active=True,confidence=0.72,structural_agreement=0.61,within_bundle_hs_dispersion=0.4)


def irg():
    return SimpleNamespace(response_potential=0.8)


def frenet():
    return SimpleNamespace(first_curvature=0.25)


def test_all_nonzero_regions_are_causal_without_salience_cutoff():
    s=str(uuid4())
    retrieved=[(0.1,mem('endogenous-consolidated',[2,0,0,3,1,0,1,0])),
               (0.2,mem('episodic',[0,2,0,1,1,1,0,0])),
               (0.3,mem('learning',[1,1,0,2,0,1,1,0],s)),
               (0.4,mem('learned-source-root',[0,0,2,2,1,0,0,1]))]
    e=EGRMathState(entropy_production=0.5)
    out=project_regional_activation(e,irg(),reasoning([0.82,0.065,0.063,0.052]),retrieved)
    assert len(out.simultaneous_active_regions) == 4
    assert out.active_region_coverage == 1.0
    assert out.participation_policy == 'all-nonzero-regions-causal-v0.7.3.4'
    assert out.dominant_activation_region in out.simultaneous_active_regions
    n=len(out.simultaneous_active_regions)
    assert len(out.stratified_activation_path)==n*(n-1)//2
    assert all(r.materially_active for r in out.regional_activations if r.activation>0)
    assert all(r.participation_score==r.normalized_weight for r in out.regional_activations)


def test_distributed_field_has_region_local_axes_and_global_summary_is_only_projection():
    s=str(uuid4())
    retrieved=[(0.1,mem('episodic',[2,0,0,3,1,0,1,0])),
               (0.2,mem('learning',[0,2,0,1,1,1,0,0],s)),
               (0.3,mem('learned-source-root',[1,1,0,2,0,1,1,0]))]
    e=project_regional_activation(EGRMathState(entropy_production=0.6),irg(),reasoning([0.7,0.2,0.1]),retrieved)
    a=proto_affective_state(irg(),e,reasoning([0.7,0.2,0.1]),frenet(),1.2)
    assert a.regional_field.active_region_count >= 2
    assert len(a.regional_field.global_summary)==6
    assert a.regional_field.global_summary_role.startswith('coarse projection')
    assert all(0.0 <= r.activation_intensity <= 1.0 for r in a.regional_field.regional_axes)
    assert all(-1.0 <= r.approach_bias <= 1.0 for r in a.regional_field.regional_axes)
    assert f'-R{a.regional_field.active_region_count}' in a.pattern_signature


def test_distribution_changes_causal_rl_activation_vector():
    retrieved=[(0.1,mem('a',[3,0,0,1,0,0,0,0])),(0.2,mem('b',[0,3,0,1,0,0,0,0]))]
    e1=project_regional_activation(EGRMathState(entropy_production=0.5),irg(),reasoning([0.9,0.1]),retrieved)
    e2=project_regional_activation(EGRMathState(entropy_production=0.5),irg(),reasoning([0.55,0.45]),retrieved)
    assert e1.activation_vector != e2.activation_vector


def test_persisted_v069_snapshot_can_be_reprojected_without_event_replay():
    from noeron.math.affect import upgrade_existing_distributed_field
    from noeron.math.models import EGRRegionalActivation, ProtoAffectiveMathState
    e=EGRMathState(entropy_production=0.4,regional_activations=[
        EGRRegionalActivation(region_id='episodic:a',region_kind='episodic',support_mass=0.82,activation=0.328,logical_center=[2,0,0,3,1,0,1,0]),
        EGRRegionalActivation(region_id='episodic:b',region_kind='episodic',support_mass=0.065,activation=0.026,logical_center=[0,2,0,1,1,1,0,0]),
        EGRRegionalActivation(region_id='stratum:x',region_kind='semantic-stratum',support_mass=0.063,activation=0.0252,logical_center=[1,1,0,2,0,1,1,0]),
        EGRRegionalActivation(region_id='episodic:root',region_kind='episodic',support_mass=0.052,activation=0.0208,logical_center=[0,0,2,2,1,0,0,1]),
    ])
    a=ProtoAffectiveMathState(activation_intensity=.33,uncertainty=.16,novelty=.76,tension=.30,coherence=.47,approach_bias=.35,pattern_signature='A3-U1-N7-T3-C4-P+1')
    e2,a2=upgrade_existing_distributed_field(e,a)
    assert len(e2.simultaneous_active_regions)==4
    assert e2.active_region_coverage==1.0
    assert a2.regional_field.active_region_count==len(e2.simultaneous_active_regions)
    assert a2.pattern_signature.endswith(f'-R{a2.regional_field.active_region_count}')


def test_equal_activation_has_no_order_selected_dominant_region():
    retrieved=[(0.1,mem('a',[2,0,0,1,0,0,0,0])),(0.1,mem('b',[0,2,0,1,0,0,0,0]))]
    out=project_regional_activation(EGRMathState(entropy_production=0.5),irg(),reasoning([0.5,0.5]),retrieved)
    assert len(out.simultaneous_active_regions)==2
    assert out.dominant_activation_region==''
    assert out.active_region_coverage==1.0
    assert len(out.stratified_activation_path)==1


def test_regional_affect_distances_are_from_activation_barycenter_not_first_row():
    retrieved=[(0.1,mem('a',[2,0,0,1,0,0,0,0])),(0.2,mem('b',[0,2,0,1,0,0,0,0]))]
    e=project_regional_activation(EGRMathState(entropy_production=0.5),irg(),reasoning([0.5,0.5]),retrieved)
    a=proto_affective_state(irg(),e,reasoning([0.5,0.5]),frenet(),0.4)
    assert len(a.regional_field.regional_axes)==2
    ds=[r.logical_distance_from_activation_barycenter for r in a.regional_field.regional_axes]
    assert abs(ds[0]-ds[1])<1e-12
    assert a.affect_knot is None  # diagnostic field has no independent authored DKT coupling
