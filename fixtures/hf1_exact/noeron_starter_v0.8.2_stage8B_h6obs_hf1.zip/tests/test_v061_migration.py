from pathlib import Path
from uuid import uuid4
from noeron.cognition.models import KnotMemory
from noeron.llm import MockLanguageEngine
from noeron.math.dkt import reference_knot
from noeron.memory import LocalEventStore
from noeron.models import CognitiveEvent,EventKind,NoeronState
from noeron.orchestrator import Noeron


def test_v060_memory_geometry_is_reencoded_and_endogenous_archived(tmp_path:Path):
    st=LocalEventStore(tmp_path/'m.db')
    ext=CognitiveEvent(kind=EventKind.USER_MESSAGE,source='u',content='Remember our DKT architecture',trusted=True)
    endo=CognitiveEvent(kind=EventKind.TIMER,source='noeron-endogenous',content='',trusted=True,metadata={'endogenous':True})
    st.append_event(ext); st.append_event(endo)
    m1=KnotMemory(source_event_id=ext.id,knot=reference_knot(),geometry_version='legacy-v0.6',consolidated=True,provenance_excerpt=ext.content)
    m2=KnotMemory(source_event_id=endo.id,knot=reference_knot(),geometry_version='legacy-v0.6',consolidated=True,provenance_excerpt='[endogenous mathematical transition]')
    st.append_knot_memory(m1); st.append_knot_memory(m2)
    old=NoeronState(); old.cognition.migration_complete=True; old.cognition.v061_geometry_migration_complete=False; st.append_state(old)
    n=Noeron(MockLanguageEngine(),st)
    active=st.knot_memories(); archived=st.archived_knot_memories()
    assert len(active)==1 and active[0].source_event_id==ext.id
    assert active[0].geometry_version=='semantic-irg-dkt-v0.6.1'
    assert len(archived)==1 and archived[0].source_event_id==endo.id
    assert n.state.cognition.v061_geometry_migration_complete is True
