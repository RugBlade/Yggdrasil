from pathlib import Path
from datetime import datetime,timezone,timedelta
from noeron.llm import MockLanguageEngine
from noeron.memory import LocalEventStore
from noeron.models import CognitiveEvent,EventKind
from noeron.orchestrator import Noeron


def test_idle_tick_advances_math_without_automatic_memory_spam(tmp_path:Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'a.db'),initiative_threshold=0.20)
    e=CognitiveEvent(kind=EventKind.USER_MESSAGE,source='u',content='hello Yggdrasil remember our architecture',trusted=True,created_at=datetime.now(timezone.utc)-timedelta(hours=2))
    n.ingest(e)
    before_current=n.state.math_kernel.egr.entropy_current
    before_norm=n.state.math_kernel.dkt.sobolev_norm_sq
    count=len(n.store.knot_memories())
    for _ in range(5):
        n.autonomous_tick(idle_seconds=0,cooldown_seconds=0,min_importance=0,min_novelty=0)
    assert n.state.math_kernel.egr.entropy_current>before_current
    assert n.state.math_kernel.dkt.sobolev_norm_sq!=before_norm
    # v0.6.1 explicitly separates continuous self-evolution from durable memory.
    assert len(n.store.knot_memories())<=count+1
    assert n.state.math_kernel.causal_trace[2].startswith('EGR:')
