from __future__ import annotations
from io import BytesIO
from pathlib import Path
import math, struct, wave
from PIL import Image
from noeron.llm import MockLanguageEngine
from noeron.memory import LocalEventStore
from noeron.orchestrator import Noeron
from noeron.perception import visual_observation, audio_observation, sensory_feature_distance

def png(color,size=(64,64)):
    b=BytesIO();Image.new('RGB',size,color).save(b,format='PNG');return b.getvalue()
def tone(freq=440.0,amp=0.2,seconds=0.25,rate=8000):
    frames=[struct.pack('<h',int(amp*math.sin(2*math.pi*freq*i/rate)*32767)) for i in range(int(seconds*rate))]
    b=BytesIO()
    with wave.open(b,'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(rate);w.writeframes(b''.join(frames))
    return b.getvalue()
def test_visual_preview_has_structural_semantics_without_object_claims():
    o=visual_observation(png((240,30,30),(96,64)),'red.png');assert 'landscape-frame' in o.semantic_terms;assert 'red-dominant' in o.semantic_terms;assert len(o.feature_vector)==11;assert sensory_feature_distance(o.feature_vector,o.feature_vector)==0.0
def test_repeated_visual_experience_forms_established_perceptual_cluster_and_dkt_prototype(tmp_path:Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'x.db'));turn=n.state.conversational_turn
    for i,c in enumerate([(240,30,30),(238,32,30),(242,28,32)]):r=n.observe_sensory(visual_observation(png(c),'red%d.png'%i),owner_authenticated=True)
    c=n.state.cognition.perception.sensory_concepts[0];a=n.sensory_concepts_state();assert n.state.conversational_turn==turn;assert c.observations==3 and c.status=='observed-recurrent';assert a['established_count']==1;assert a['concepts'][0]['dkt_prototype_status']=='observed-recurrent';assert r['llm_used'] is False
def test_distinct_visual_structure_forms_distinct_cluster(tmp_path:Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'x.db'));n.observe_sensory(visual_observation(png((240,30,30)),'red.png'));n.observe_sensory(visual_observation(png((30,30,240)),'blue.png'));assert len(n.state.cognition.perception.sensory_concepts)==2
def test_owner_label_binds_perceptual_cluster_to_dkt_semantic_prototype(tmp_path:Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'x.db'));r=n.observe_sensory(visual_observation(png((250,250,250)),'bright.png'),concept_label='bright reference');assert n.state.cognition.perception.sensory_concepts[0].grounded_concept=='bright-reference';assert r['grounded_dkt_prototype']['term']=='bright-reference'
def test_audio_experience_forms_recurrent_acoustic_cluster(tmp_path:Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'x.db'))
    for f in (440,445,438):r=n.observe_sensory(audio_observation(tone(f),'tone.wav'))
    cs=[c for c in n.state.cognition.perception.sensory_concepts if c.channel=='audio'];assert len(cs)==1 and cs[0].status=='observed-recurrent';assert n.state.cognition.perception.semantic_audio_observations==3;assert any('audio' in t for t in r['semantic_terms'])
def test_bulk_sensory_learning_does_not_fake_owner_familiarity(tmp_path:Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'x.db'));before=n.owner_relation_state()['authenticated_interactions']
    for _ in range(3):n.observe_sensory(visual_observation(png((120,120,120)),'x.png'),owner_authenticated=True)
    assert n.owner_relation_state()['authenticated_interactions']==before
def test_same_owner_concept_can_bridge_vision_and_audio_through_one_dkt_prototype(tmp_path:Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'x.db'));v=n.observe_sensory(visual_observation(png((200,200,200)),'signal.png'),concept_label='signal');a=n.observe_sensory(audio_observation(tone(440),'signal.wav'),concept_label='signal');p=n.store.semantic_prototype_map()['signal'];assert p.observations==2;assert v['grounded_dkt_prototype']['term']==a['grounded_dkt_prototype']['term']=='signal'
