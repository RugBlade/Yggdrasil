from __future__ import annotations

import ast
import json
import os
from pathlib import Path
from types import SimpleNamespace

import pytest

from noeron.llm import MockLanguageEngine
from noeron.memory import LocalEventStore
from noeron.orchestrator import Noeron

ROOT=Path(__file__).resolve().parents[1]


def make_noeron(tmp_path: Path, name: str='room.sqlite3'):
    return Noeron(MockLanguageEngine(), LocalEventStore(tmp_path/name))


def _fake_result(residual: float=0.0, admissible: bool=True):
    state=SimpleNamespace(
        dkt=SimpleNamespace(security_admissible=admissible),
        egr=SimpleNamespace(bridge_residual=residual,balance_residual=0.0),
        rl=SimpleNamespace(geodesic_acceleration_norm=0.0),
        causal_trace=['IRG','DKT','EGR','RL/Frenet','DKT'],
    )
    return SimpleNamespace(state=state)


def test_01_stage8_outer_identity_preserves_stage7_websocket_dependency():
    import noeron, tomllib
    project=tomllib.loads((ROOT/'pyproject.toml').read_text())['project']
    assert noeron.__version__=='0.8.1'
    assert project['version']=='0.8.1'
    assert 'websockets==17.0.1' in project['dependencies']
    assert project['requires-python']=='>=3.11'
    assert any(x.startswith('uvicorn>=') for x in project['dependencies'])


def test_02_room_patch_migration_updates_only_substrate_metadata(tmp_path):
    p=tmp_path/'preserved.sqlite3'; n=Noeron(MockLanguageEngine(),LocalEventStore(p))
    c=n.room.configuration_candidates('embodiment')[1]
    e=n.room.configuration_candidates('environment')[1]
    n.state.room.embodiment_configuration=c.model_copy(deep=True)
    n.state.room.environment_configuration=e.model_copy(deep=True)
    n.state.room.embodiment_morph_epoch=3;n.state.room.environment_epoch=2
    n.state.room.version='0.7.6';n.state.room.mechanism_version='0.7.6-reconstructed'
    n.store.append_state(n.state)
    turn=n.state.conversational_turn; active=len(n.store.cognitive_memories()); events=len(n.store.all_events())
    n.store._connection.close()
    n2=Noeron(MockLanguageEngine(),LocalEventStore(p))
    assert n2.state.room.version=='0.7.6.1'
    assert n2.state.room.schema_version=='0.7.6'
    assert n2.state.room.mechanism_version=='0.7.6.1-room-completion-patch'
    assert n2.state.room.embodiment_configuration.id==c.id
    assert n2.state.room.environment_configuration.id==e.id
    assert n2.state.room.embodiment_morph_epoch==3 and n2.state.room.environment_epoch==2
    assert n2.state.conversational_turn==turn
    assert len(n2.store.cognitive_memories())==active and len(n2.store.all_events())==events


def test_03_publication_candidate_root_is_private_and_empty_by_default(tmp_path):
    n=make_noeron(tmp_path)
    root=n.room.publication_candidates_root
    assert root.is_dir() and oct(root.stat().st_mode & 0o777)=='0o700'
    assert n.room.publication_candidates()==[]


def test_04_candidate_listing_is_metadata_only_and_deterministic(tmp_path):
    n=make_noeron(tmp_path); p=n.room.publication_candidates_root/'note.txt';p.write_bytes(b'private candidate')
    a=n.room.publication_candidates();b=n.room.publication_candidates()
    assert a==b and len(a)==1
    c=a[0]
    assert c['filename']=='note.txt' and c['size']==len(b'private candidate')
    assert len(c['sha256'])==64 and len(c['id'])==32
    assert c['cognitive_authority'] is False and c['publication_authority'] is False
    assert 'storage_path' not in c and 'content' not in c


def test_05_candidate_listing_rejects_symlink_and_unsafe_basename(tmp_path):
    n=make_noeron(tmp_path); outside=tmp_path/'outside.bin';outside.write_bytes(b'secret')
    try:(n.room.publication_candidates_root/'link.bin').symlink_to(outside)
    except OSError:pytest.skip('symlink unsupported')
    (n.room.publication_candidates_root/'bad\\name.bin').write_bytes(b'x')
    assert n.room.publication_candidates()==[]


def test_06_publication_tie_or_hold_publishes_nothing(tmp_path,monkeypatch):
    n=make_noeron(tmp_path);p=n.room.publication_candidates_root/'x.bin';p.write_bytes(b'abc')
    cid=n.room.publication_candidates()[0]['id']
    monkeypatch.setattr(n.room,'_simulate',lambda domain,action,obs:(_fake_result(0),0.0,True))
    d,a,c=n.room.deliberate_publication_candidate(cid)
    assert d.native_choice_claim is False and a is None
    assert n.state.room.last_file_publication_decision.id==d.id
    assert not [x for x in n.store.room_artifacts() if x.direction=='noeron-to-owner']


def test_07_unique_native_publish_is_required_and_guarded(tmp_path,monkeypatch):
    n=make_noeron(tmp_path);p=n.room.publication_candidates_root/'x.bin';p.write_bytes(b'abc')
    cid=n.room.publication_candidates()[0]['id']
    monkeypatch.setattr(n.room,'_simulate',lambda domain,action,obs:(_fake_result(0 if action=='publish' else 1),0.0 if action=='publish' else 1.0,True))
    d,a,c=n.room.deliberate_publication_candidate(cid)
    assert d.native_choice_claim is True and d.decision_layer=='native-deliberative'
    assert d.selected_action=='publish' and d.selection_status=='unique-native-consequence-minimum'
    assert a is not None and a.direction=='noeron-to-owner' and a.publication_native_choice_claim is True
    assert n.room.read_artifact(a)==b'abc'
    journals=[j for j in n.store.room_journal() if j.kind=='native-file-publication-opportunity']
    assert journals and journals[0].payload['owner_force_publication'] is False


def test_08_file_attention_and_file_publication_decisions_are_separate(tmp_path,monkeypatch):
    n=make_noeron(tmp_path)
    monkeypatch.setattr(n.room,'_simulate',lambda domain,action,obs:(_fake_result(0 if action in {'defer','hold'} else 1),0.0 if action in {'defer','hold'} else 1.0,True))
    att=n.room.deliberate_attention('file',[{'name':'file','role':'presence','value':.5}])
    (n.room.publication_candidates_root/'x.bin').write_bytes(b'abc');cid=n.room.publication_candidates()[0]['id']
    pub,artifact,_=n.room.deliberate_publication_candidate(cid)
    assert n.state.room.last_file_decision.id==att.id
    assert n.state.room.last_file_publication_decision.id==pub.id
    assert artifact is None


def test_09_candidate_bytes_changed_before_open_fail_closed(tmp_path,monkeypatch):
    n=make_noeron(tmp_path);p=n.room.publication_candidates_root/'x.bin';p.write_bytes(b'abc');cid=n.room.publication_candidates()[0]['id']
    original=n.room._publication_candidate_descriptor
    calls={'n':0}
    def changed(path):
        rec=original(path);calls['n']+=1
        if calls['n']==2:p.write_bytes(b'xyz')
        return rec
    monkeypatch.setattr(n.room,'_publication_candidate_descriptor',changed)
    with pytest.raises(ValueError):n.room.deliberate_publication_candidate(cid)


def test_10_browser_has_direct_file_camera_microphone_controls():
    api=(ROOT/'src/noeron/api.py').read_text()
    for token in ('id="fileInput"','id="fileOffer"','id="cameraCapture"','id="micStart"','id="micStop"'):
        assert token in api
    assert "navigator.mediaDevices.getUserMedia({video:true,audio:false})" in api
    assert "navigator.mediaDevices.getUserMedia({audio:true,video:false})" in api
    assert "type:'audio/wav'" in api and "encodeWav" in api


def test_11_browser_file_offer_does_not_automatically_force_attention():
    api=(ROOT/'src/noeron/api.py').read_text()
    assert "uploadBlob('/room/files'" in api
    assert "arrival did not force attention" in api
    assert "Present attention affordance" in api
    # The consider endpoint remains a distinct explicit opportunity action.
    assert "'/room/files/'+a0.id+'/consider'" in api


def test_12_browser_publication_control_only_presents_opportunity():
    api=(ROOT/'src/noeron/api.py').read_text()
    assert 'Private publication candidate:' in api
    assert 'Present publish/hold opportunity' in api
    assert "'/room/publication/candidates/'+c.id+'/deliberate'" in api
    assert 'owner_force_publication' in api
    assert '/room/publication/force' not in api and '/publish-now' not in api


def test_13_publication_api_is_room_scoped_and_authenticated():
    api=(ROOT/'src/noeron/api.py').read_text();tree=ast.parse(api);routes=[]
    for node in ast.walk(tree):
        if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
            for dec in node.decorator_list:
                if isinstance(dec,ast.Call) and isinstance(dec.func,ast.Attribute) and dec.args and isinstance(dec.args[0],ast.Constant):
                    if dec.func.attr in {'get','post','put','patch','delete'}:routes.append((dec.func.attr.upper(),str(dec.args[0].value),node.name))
    assert ('GET','/room/publication/candidates','room_publication_candidates') in routes
    assert ('POST','/room/publication/candidates/{candidate_id}/deliberate','room_publication_candidate_deliberate') in routes
    assert '_room_auth(request)' in api[api.index('def room_publication_candidates'):api.index("@app.post('/room/camera')")]


def test_14_route_delta_is_two_more_room_only_routes():
    api=(ROOT/'src/noeron/api.py').read_text();tree=ast.parse(api);routes=[]
    for node in ast.walk(tree):
        if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
            for dec in node.decorator_list:
                if isinstance(dec,ast.Call) and isinstance(dec.func,ast.Attribute) and dec.func.attr in {'get','post','put','patch','delete'} and dec.args and isinstance(dec.args[0],ast.Constant):
                    routes.append((dec.func.attr.upper(),str(dec.args[0].value)))
    certified={tuple(x) for x in json.loads((ROOT/'scripts/v0751_certified_api_routes.json').read_text())}
    current=set(routes);new=current-certified
    # Stage 8A preserves the exact v0.7.6.1 Room surface and adds only the five
    # owner-authenticated engineering source-perception routes.
    room_new={(method,path) for method,path in new if path.startswith('/room')}
    engineering_new={(method,path) for method,path in new if path.startswith('/engineering')}
    expected_engineering={
        ('GET','/engineering/status'),
        ('GET','/engineering/source/index'),
        ('GET','/engineering/source/file'),
        ('GET','/engineering/source/symbol'),
        ('POST','/engineering/source/observe'),
    }
    assert len(routes)==len(current)==98 and len(new)==24
    assert len(room_new)==19
    assert engineering_new==expected_engineering
    assert new==room_new|engineering_new


def test_15_no_runtime_cdn_or_public_renderer_dependency_added():
    api=(ROOT/'src/noeron/api.py').read_text();project=(ROOT/'pyproject.toml').read_text()
    assert "import('/room/vendor/three-r185/build/three.module.js')" in api
    assert 'cdn.jsdelivr.net' not in api and 'unpkg.com' not in api
    assert 'websockets==17.0.1' in project


def test_16_patch_does_not_relabel_preserved_cognition_language_or_math():
    api=(ROOT/'src/noeron/api.py').read_text();orch=(ROOT/'src/noeron/orchestrator.py').read_text();models=(ROOT/'src/noeron/math/models.py').read_text()
    assert "'runtime_version':'0.7.5.1'" in orch
    assert "interface_version: str = '0.7.3.4'" in models
    assert "'kernel_version':'0.7.5.1'" in api
    assert "native_language':'rich-transparent-compositional-language+DKT-gated-proposition-authority+native-proof-realization-v0.8.1-stage8B'" in api


def test_17_patch_has_no_auth_relational_or_choice_authority_coupling():
    src=(ROOT/'src/noeron/api.py').read_text()+(ROOT/'src/noeron/room.py').read_text()
    for forbidden in ('relational_authority=True','cognitive_authority=True','owner_force_publication=True','native_choice_claim=True # owner'):
        assert forbidden not in src
    assert "decision.native_choice_claim and decision.decision_layer=='native-deliberative'" in src


def test_18_room_state_keeps_schema_v076_while_patch_runtime_is_v0761(tmp_path):
    n=make_noeron(tmp_path)
    assert n.state.room.version=='0.7.6.1'
    assert n.state.room.schema_version=='0.7.6'
    assert n.state.room.mechanism_version=='0.7.6.1-room-completion-patch'


def test_19_vendored_live_server_websocket_wheel_is_integrity_pinned():
    import hashlib, json, zipfile
    m=json.loads((ROOT/'vendor/python/INTEGRITY.json').read_text())
    wheel=ROOT/'vendor/python'/m['live_server_wheel']
    assert wheel.is_file() and hashlib.sha256(wheel.read_bytes()).hexdigest()==m['sha256']
    assert m['sha256']=='f47b0815af3948ec6a440b3afa02f05b18cc0939549e91b5c677b5d9c2c8472a'
    with zipfile.ZipFile(wheel) as z:
        meta=z.read('websockets-17.0.1.dist-info/METADATA').decode()
        wh=z.read('websockets-17.0.1.dist-info/WHEEL').decode()
    assert 'Name: websockets' in meta and 'Version: 17.0.1' in meta and 'Requires-Python: >=3.11' in meta
    assert 'Tag: cp312-cp312-manylinux_2_28_x86_64' in wh

