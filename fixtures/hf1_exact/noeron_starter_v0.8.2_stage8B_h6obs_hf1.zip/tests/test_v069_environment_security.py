from __future__ import annotations

from io import BytesIO
from pathlib import Path
from uuid import uuid4
import wave

import pytest
from PIL import Image

from noeron.auth import OwnerAuthenticator
from noeron.cognition.models import KnotMemory
from noeron.llm import MockLanguageEngine
from noeron.math.affect import project_regional_activation
from noeron.math.dkt import reference_knot
from noeron.math.models import EGRMathState, IRGMathState, MultiMemoryReasoningMathState
from noeron.memory import LocalEventStore
from noeron.models import CognitiveEvent, EventKind
from noeron.orchestrator import Noeron
from noeron.perception import visual_observation, audio_observation, fetch_read_only

LESSON=(
    'I am Yggdrasil. You are Abdelaziz. A word can name a concept. '
    'A sentence can express a thought. This is a statement. What is a question? '
    'A question asks for information. I do not know. I answer because I remember. '
    'The word and can join ideas.'
)


def test_v069_repairs_two_v068_language_failures_without_reteaching(tmp_path:Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'x.db'))
    n.teach_language(LESSON,source='owner-english-curriculum-001')
    lessons=n.state.cognition.language.lessons_observed

    r=n.ingest(CognitiveEvent(kind=EventKind.USER_MESSAGE,source='authenticated-owner',
        content='What can a sentence express?',trusted=True,metadata={'owner_authenticated':True}))
    # Explicit teaching may develop the language substrate, but its pending provenance
    # cannot become a shadow proof-memory authority before native retention selects it.
    assert r.native_text==''
    assert r.state.math_kernel.reasoning.answer_candidates==[]
    assert r.state.cognition.language.last_interpretation is None
    assert r.renderer_used is False

    r2=n.ingest(CognitiveEvent(kind=EventKind.USER_MESSAGE,source='authenticated-owner',
        content='Who am I?',trusted=True,metadata={'owner_authenticated':True}))
    # Cryptographic authentication supplies an objective factual referent premise;
    # this is explicitly substrate identity, not learned closeness/relationship meaning.
    assert 'abdelaziz' in r2.native_text.lower()
    assert r2.state.math_kernel.reasoning.answer_candidates[0].source=='authenticated-owner-identity-substrate'
    assert r2.state.cognition.language.last_interpretation is None
    assert n.state.cognition.language.lessons_observed==lessons


def test_pronouns_are_perspective_sensitive(tmp_path:Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'x.db'))
    n.teach_language(LESSON)
    a=n.language_parse('Who are you?',owner_authenticated=True)
    b=n.language_parse('Who am I?',owner_authenticated=True)
    assert a['grounded_terms']['you']=='identity:yggdrasil'
    assert a['answer_supported'] is False
    assert a['native_proposition'] is None
    assert b['grounded_terms']['i']=='owner:abdelaziz'
    assert b['answer_supported'] is False
    assert b['native_proposition'] is None


def test_simultaneous_regional_activation_builds_piecewise_stratified_path():
    k=reference_knot()
    m1=KnotMemory(source_event_id=uuid4(),knot=k,logical_coordinates=[0.1]*8,semantic_stratum_id=uuid4())
    m2=KnotMemory(source_event_id=uuid4(),knot=k,logical_coordinates=[0.4]*8,semantic_stratum_id=uuid4())
    reasoning=MultiMemoryReasoningMathState(active=True,weights=[0.6,0.4])
    egr=EGRMathState(entropy_production=0.5)
    irg=IRGMathState(response_potential=0.5)
    out=project_regional_activation(egr,irg,reasoning,[(0.1,m1),(0.2,m2)])
    assert len(out.simultaneous_active_regions)==2
    assert len(out.stratified_activation_path)==1
    seg=out.stratified_activation_path[0]
    assert seg.from_region!=seg.to_region
    assert seg.logical_distance>0
    assert 0.0<=out.activation_path_coherence<=1.0


def test_visual_and_audio_are_low_level_irg_observations_and_do_not_increment_turn(tmp_path:Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'x.db'))
    buf=BytesIO(); Image.new('RGB',(16,12),(128,64,32)).save(buf,format='PNG')
    obs=visual_observation(buf.getvalue(),'sample.png')
    before=n.state.conversational_turn
    row=n.observe_sensory(obs,owner_authenticated=True)
    assert row['channel']=='vision'
    assert n.state.conversational_turn==before
    assert n.state.cognition.perception.visual_observations==1
    assert any(a.role.startswith('vision-') for a in n.state.math_kernel.irg.semantic_atoms)

    wav=BytesIO()
    with wave.open(wav,'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(8000); w.writeframes((b'\x00\x00\x10\x00\xf0\xff')*100)
    aobs=audio_observation(wav.getvalue(),'sample.wav')
    n.observe_sensory(aobs,owner_authenticated=True)
    assert n.state.cognition.perception.audio_observations==1
    assert any(a.role.startswith('audio-') for a in n.state.math_kernel.irg.semantic_atoms)


def test_defensive_quarantine_retracts_and_learns_locally(tmp_path:Path):
    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'x.db'))
    before_turn=n.state.conversational_turn
    event=CognitiveEvent(kind=EventKind.TOOL_RESULT,source='security-test',content='hostile mutation',trusted=False)
    r=n.ingest(event,proposed_invariant_changes={'identity':'attacker-selected-identity'})
    assert r.security.allowed is False
    assert r.state.cognition.defense.neutralized_count==1
    assert r.state.cognition.defense.quarantine_records[-1].neutralized is True
    assert r.state.cognition.defense.quarantine_records[-1].violated_invariants==['identity']
    assert n.state.conversational_turn==before_turn
    audit=n.security_defense_audit()
    assert audit['external_retaliation_enabled'] is False
    assert len(audit['deformation_family_counts'])==1


def test_owner_authenticator_and_relation_are_distinct_from_trusted_flag(tmp_path:Path):
    token='A'*32
    auth=OwnerAuthenticator(token)
    assert auth.configured is True
    assert auth.verify(token) is True
    assert auth.verify('wrong') is False

    n=Noeron(MockLanguageEngine(),LocalEventStore(tmp_path/'x.db'))
    n.teach_language(LESSON)
    n.ingest(CognitiveEvent(kind=EventKind.USER_MESSAGE,source='authenticated-owner',content='Hello',trusted=True,metadata={'owner_authenticated':True}))
    rel=n.owner_relation_state()
    assert rel['owner_referent']=='owner:abdelaziz'
    assert rel['authenticated_interactions']==1
    assert rel['familiarity']==0.0  # authentication provenance is not relational meaning


def test_read_only_web_rejects_private_targets_without_network_access():
    with pytest.raises(ValueError,match='private|loopback|reserved'):
        fetch_read_only('http://127.0.0.1:8741/health')

def test_v069_migration_repairs_preserved_v068_lesson_without_replaying(tmp_path:Path):
    path=tmp_path/'m.db'; store=LocalEventStore(path); n=Noeron(MockLanguageEngine(),store)
    out=n.teach_language(LESSON,source='owner-english-curriculum-001')
    before_lessons=n.state.cognition.language.lessons_observed
    before_turn=n.state.conversational_turn
    # Reconstruct an actual legacy v0.6.8 active language memory. Current v0.7.4
    # curriculum exposure is pending provenance and must not be replayed as if active.
    legacy=n.store.knot_memory_by_id(out['provenance_memory_id'],include_archived=True)
    legacy.consolidated=True; legacy.memory_class='language-learning'; legacy.geometry_version='semantic-irg-dkt-language-v0.6.8'
    n.store.upsert_knot_memory(legacy)
    n.state.cognition.language.propositions=[p for p in n.state.cognition.language.propositions if p.relation!='can-express']
    n.state.cognition.v069_environment_security_migration_complete=False
    n.state.cognition.version='0.6.8'; n.state.cognition.language.version='0.6.8'
    store.append_state(n.state)

    store2=LocalEventStore(path); n2=Noeron(MockLanguageEngine(),store2)
    assert any(p.relation=='can-express' and p.subject_surface=='sentence' for p in n2.state.cognition.language.propositions)
    assert n2.state.cognition.language.lessons_observed==before_lessons
    assert n2.state.conversational_turn==before_turn
