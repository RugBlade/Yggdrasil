from __future__ import annotations

from dataclasses import replace
import importlib
import os
from pathlib import Path
import sys
import tomllib

import pytest
from fastapi import Response
from starlette.requests import Request

from noeron.config import Settings

ROOT=Path(__file__).resolve().parents[1]


def _request(client_host: str = "127.0.0.1") -> Request:
    return Request({
        "type":"http","http_version":"1.1","method":"POST","scheme":"http",
        "path":"/room/session","raw_path":b"/room/session","query_string":b"",
        "headers":[],"client":(client_host,43210),"server":("127.0.0.1",8741),"root_path":"",
    })


@pytest.fixture(scope="module")
def api_module(tmp_path_factory):
    old={k:os.environ.get(k) for k in ("NOERON_DB_PATH","NOERON_ROOM_COOKIE_SECURE","NOERON_OWNER_LEGACY_TOKEN_ENABLED")}
    db=tmp_path_factory.mktemp("release-identity")/"release.sqlite3"
    os.environ["NOERON_DB_PATH"]=str(db)
    os.environ["NOERON_ROOM_COOKIE_SECURE"]="false"
    os.environ["NOERON_OWNER_LEGACY_TOKEN_ENABLED"]="false"
    sys.modules.pop("noeron.api",None)
    module=importlib.import_module("noeron.api")
    try:
        yield module
    finally:
        try:
            module.store._connection.commit();module.store._connection.close()
        except Exception:
            pass
        sys.modules.pop("noeron.api",None)
        for k,v in old.items():
            if v is None: os.environ.pop(k,None)
            else: os.environ[k]=v


def test_01_outer_release_advances_to_v081_without_relabelling_preserved_subsystems():
    import noeron
    project=tomllib.loads((ROOT/"pyproject.toml").read_text())
    assert noeron.__version__=="0.8.1"
    assert project["project"]["version"]=="0.8.1"


def test_02_api_outer_release_is_v081_while_cognition_core_remains_v0751(api_module):
    audit=api_module.version_audit()
    assert api_module.OUTER_RUNTIME_VERSION=="0.8.1"
    assert api_module.app.version=="0.8.1"
    assert audit["runtime_version"]=="0.8.1" and audit["api_version"]=="0.8.1"
    assert audit["cognition_version"]=="0.7.5.1"
    assert audit["math_interface"]=="0.7.3.4"
    assert api_module.noeron.hardcoding_audit()["runtime_version"]=="0.7.5.1"
    assert api_module.graph_audit()["kernel_version"]=="0.7.5.1"


def test_03_outer_api_surfaces_report_v081_without_relabelling_preserved_subsystems(api_module):
    assert api_module.health()["runtime_version"]=="0.8.1"
    assert api_module.memory_retention_audit()["runtime_version"]=="0.8.1"
    assert api_module.web_status()["runtime_version"]=="0.8.1"
    assert api_module.security_defense_deliberation()["runtime_version"]=="0.8.1"
    assert api_module.security_defense_policy()["runtime_version"]=="0.8.1"
    v=api_module.version_audit()
    assert v["subsystems"]["language"]["runtime_version"]=="0.8.1"
    assert v["subsystems"]["defense"]["runtime_version"]!="0.8.1"


def test_04_room_cookie_secure_defaults_false_and_can_be_enabled_from_env(monkeypatch):
    monkeypatch.delenv("NOERON_ROOM_COOKIE_SECURE",raising=False)
    assert Settings.from_env().room_cookie_secure is False
    monkeypatch.setenv("NOERON_ROOM_COOKIE_SECURE","true")
    assert Settings.from_env().room_cookie_secure is True
    monkeypatch.setenv("NOERON_ROOM_COOKIE_SECURE","TRUE")
    assert Settings.from_env().room_cookie_secure is True


def _session_cookie(api_module,monkeypatch,secure:bool)->str:
    monkeypatch.setattr(api_module,"settings",replace(api_module.settings,room_cookie_secure=secure))
    monkeypatch.setattr(api_module,"_room_auth_detail_from_token",lambda token:{"authenticated":True,"method":"ed25519-device-session","device_id":"owner-device"})
    out=api_module.room_session(_request(),Response(),session_token="device-session",x_noeron_owner_token=None)
    assert out.status_code==303
    return out.headers["set-cookie"]


def test_05_loopback_http_cookie_default_does_not_set_secure(api_module,monkeypatch):
    cookie=_session_cookie(api_module,monkeypatch,False)
    assert "Secure" not in cookie
    assert "HttpOnly" in cookie and "SameSite=strict" in cookie and "Path=/room" in cookie


def test_06_https_policy_can_enable_secure_cookie_without_changing_auth(api_module,monkeypatch):
    cookie=_session_cookie(api_module,monkeypatch,True)
    assert "Secure" in cookie
    assert "HttpOnly" in cookie and "SameSite=strict" in cookie and "Path=/room" in cookie
    assert "device-session" in cookie


def test_07_room_cookie_flag_is_transport_substrate_only():
    config=(ROOT/"src/noeron/config.py").read_text()
    api=(ROOT/"src/noeron/api.py").read_text()
    assert "room_cookie_secure: bool = False" in config
    assert 'NOERON_ROOM_COOKIE_SECURE' in config
    assert "secure=settings.room_cookie_secure" in api
    for forbidden in ("cognitive_authority=settings.room_cookie_secure","relational_authority=settings.room_cookie_secure","native_choice_claim=settings.room_cookie_secure"):
        assert forbidden not in api+config


def test_08_env_examples_are_stage8b_truthful_and_preserve_stage8a_live_boundary():
    for rel in (".env.example","deploy/noeron.env.example"):
        text=(ROOT/rel).read_text()
        assert "Noeron v0.8.1" in text and "Stage 8B" in text and "Stage 8A live-certified" in text
        assert "NOERON_OWNER_LEGACY_TOKEN_ENABLED=false" in text
        assert "NOERON_ROOM_COOKIE_SECURE=false" in text
        assert "NOERON_ROOM_NATIVE_DECODER_EXECUTABLE=" in text
        assert "NOERON_ROOM_ASR_EXECUTABLE=" in text
        assert "NOERON_ENGINEERING_SOURCE_ROOT=" in text
        assert "NOERON_ENGINEERING_MAX_SOURCE_BYTES=300000" in text
        assert "loopback/SSH tunnel" in text


def test_09_release_identity_does_not_relabel_cognition_state_or_math_interface():
    orch=(ROOT/"src/noeron/orchestrator.py").read_text()
    models=(ROOT/"src/noeron/math/models.py").read_text()
    api=(ROOT/"src/noeron/api.py").read_text()
    assert "'runtime_version':'0.7.5.1'" in orch
    assert "interface_version: str = '0.7.3.4'" in models
    assert "'kernel_version':'0.7.5.1'" in api
    assert "from noeron import __version__ as OUTER_RUNTIME_VERSION" in api


def test_10_root_release_documents_are_v081_stage8b_and_stage8a_live_truthful():
    for rel in ("README.md","RELEASE_COMMIT.txt","BUILD_PROVENANCE.txt","LOCAL_CERTIFICATION.txt"):
        text=(ROOT/rel).read_text()
        assert "v0.8.1" in text and ("Stage 8B" in text or "Stage-8B" in text)
        assert "Stage 8A" in text or "Stage-8A" in text
        assert "7/8" in text
        assert "Stage-7 live certification: PENDING" not in text
        assert "Official roadmap remains **6/8**" not in text
    readme=(ROOT/"README.md").read_text()
    assert "Stage 1/8 through Stage 7/8" in readme
    assert "Official roadmap: **7/8**" in readme
    assert "Stage 8/8: **PENDING**" in readme
