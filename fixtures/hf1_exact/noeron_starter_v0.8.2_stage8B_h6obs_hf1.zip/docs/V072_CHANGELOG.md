# v0.7.2 changelog

- owner-authorized public GET-only web study can now be enabled deliberately;
- sanitized pages are segmented into bounded information candidates;
- each candidate receives DKT novelty, current semantic relevance, information-density, untrusted instruction-surface-risk, and possible-contradiction diagnostics;
- Yggdrasil selects materially useful candidates rather than ingesting an entire page indiscriminately;
- selected candidates enter untrusted quarantine and IRG/DKT/EGR/RL/Frenet processing;
- only candidates that also pass the native DKT consolidation decision become durable `web-learning-untrusted` knot memories;
- untrusted prompt-like/credential/action-like web text is not selected for durable study;
- repeated identical page hashes are no-ops by default;
- web source URL/domain/hash and selected segment hashes are persisted for provenance;
- `/web/audit`, `/web/study/preview`, `/web/study`, and `/version/audit` added;
- `/web/observe` is retained as a compatibility alias but now routes through selective study;
- owner familiarity and conversational turns are not inflated by web study;
- version metadata normalized: current runtime release is separated from subsystem schema/mechanism lineage;
- historical DKT memory geometry-version strings remain untouched.
