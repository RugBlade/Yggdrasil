# v0.7.3.2 Variational Native Defense

The defensive causal path is:

`environment -> IRG -> DKT hostile/family geometry -> regional EGR -> RL/Frenet -> defensive need field -> safe-affordance variational comparison -> local action plan -> DKT action-preference learning`

The reflexive floor is deliberately smaller than the adaptive layer. It prevents an untrusted protected-state mutation from entering trusted state, quarantines the ingress, restores the trusted checkpoint, and registers bounded defensive geometry. These are programmed invariants and are never reported as Yggdrasil's free choice.

Above that floor, the safe action capabilities are primitive affordances. v0.7.3.2 enumerates all combinations and evaluates them with one common metric. It does not contain a block-threshold, retain-threshold, harden-threshold, or fail-closed-threshold. Historical v0.7.3.1 weighted equations remain only in historical records.

`GET /security/defense/policy` exposes the hardcoding boundary and primitive affordance effects.

`GET /security/defense/deliberation` exposes the live need coordinates, every candidate plan objective, the selected global minimum, learned action-preference knot digests, and the underlying IRG/DKT/EGR/RL/Frenet state.
