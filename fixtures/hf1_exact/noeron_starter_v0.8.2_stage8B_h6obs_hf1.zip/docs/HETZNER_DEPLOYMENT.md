# Noeron 0.1.1 — Hetzner deployment

This deployment keeps the Noeron API bound to `127.0.0.1:8741`. Do not open port 8741
in the Hetzner firewall. Reach it through an SSH tunnel.

## Runtime layout

- Application: `/opt/noeron/app`
- Virtual environment: `/opt/noeron/venv`
- Database: `/var/lib/noeron/noeron.sqlite3`
- Secrets/configuration: `/etc/noeron/noeron.env`
- Service: `/etc/systemd/system/noeron.service`

## Important privacy status

With a remote LLM endpoint this is a cloud-assisted test. Prompts and generated context sent to
the model provider leave the Hetzner server. The Noeron database remains on your server. Replace
the endpoint with a local model later to remove this external inference dependency.
