# v0.6.1 changelog

## Why this release exists
Live v0.6.0 testing proved that autonomous mathematical state evolution was real, but exposed four problems: token hashing gave poor semantic knot geometry; every autonomous tick became a durable memory; the EGR->RL entropy coordinate saturated at 1; and autonomous/native thought scoring contained fixed constants and sentence templates.

## Semantic IRG ingress
v0.6.1 models the text channel as a finite environment measure of semantic atoms. Each atom is assigned a role and acts through a declared interaction-kernel sector on S^1. Synonym families share sectors. Unknown vocabulary is permitted only as a low-weight lexical residual; the runtime never pretends this fallback is semantic understanding.

## DKT memory
The DKT knot remains the memory object. v0.6.1 separates continuous core-knot evolution from durable branch consolidation. The consolidation decision is a Noeron extension computed from DKT novelty/displacement, Frenet redirection, EGR production and IRG response. On migration, old external v0.6 memories are re-encoded into the new semantic geometry. Old endogenous tick memories are preserved in SQLite but marked archived/non-authoritative.

## EGR -> RL
The causal order is unchanged: EGR occurs before RL. The finite homogeneous production law advances an unbounded entropy state under Sigma>=0. The declared bridge is chi(S)=log(1+S). The fourth RL coordinate is set from this EGR map and is no longer clipped to 1. RL's own curvature entropy remains separately calculated from rho=e^-R/Z and S_L=<R>+log Z.

## Native cognition
The cognitive object is now structured before prose: NativeProposition + optional NativeJudgment + MathematicalProvenance. Terra receives only the finalized textual serialization of these native objects.

## Autonomous attention
Routine smooth evolution stays internal. A trajectory thought requires substantial Frenet redirection; entropy thoughts require a meaningful change; consolidation thoughts require an actual new durable DKT branch. State signatures are quantized so tiny numerical changes do not defeat duplicate suppression.
