# v0.7.3.3 changelog — Consequence-Simulated Native Defense

v0.7.3.3 removes the remaining authored defensive need-field mapping from v0.7.3.2 and tightens the audit so deterministic implementation details cannot be mislabeled as Yggdrasil choices.

## Removed from adaptive choice

- no `global_isolation = recurrence` or recurrence-to-lockdown rule;
- no authored defensive need coordinates;
- no per-action utility/capability vectors;
- no fixed action ranking;
- no action-selection threshold;
- no adaptive `retain-quarantine` preference: evidence retention is now explicitly part of the programmed reflexive invariant floor;
- no hidden `objective -> fewer actions -> lexical order` presented as native preference.

## Programmed substrate boundary

Programmed primitives are explicit:

- protected invariants;
- immediate quarantine/freeze/checkpoint retraction;
- evidence/provenance preservation;
- bounded defensive-family registration;
- safe local actuator semantics;
- DKT family-recognition radius and finite empirical-confidence transform;
- one common consequence-distance interface;
- transparent actuator realization only when native geometry is mathematically underdetermined.

These are implementation substrate and are not called preferences, desires, or decisions of Yggdrasil.

## Deliberative path

`environment -> IRG -> DKT -> regional EGR -> RL/Frenet -> empirical pre-action state -> simulate every available safe primitive plan -> compare each predicted post-action state with trusted/admissible operation + learned DKT action-context geometry -> minimum consequence geometry`

Recurrence remains environmental/history information. It affects empirical prediction confidence and learned family geometry but does not command an action.

## Native-selection honesty

v0.7.3.3 distinguishes three cases:

1. **Unique minimum plan:** the actuator plan is recorded as deliberative/native.
2. **Several redundant plans, one minimum post-action state:** the post-action geometry is native-selected; programmed redundancy elimination realizes it and is labeled as such.
3. **Distinct minimum post-action states tied:** the runtime records `programmed-resolution-of-native-objective-tie`, gives the actuator resolution no native-choice score, and does not learn it into DKT preference geometry.

This closes the hidden tie-break problem found in the supplied candidate.

## Learned geometry

Fresh v0.7.3.3 state no longer invents legacy v0.7.3.1 float rankings. Persisted historical float preferences remain preserved only when they actually exist in migrated state and have zero choice authority. Current adaptive history is carried by DKT action-preference knots/observation counts and deformation-family geometry.

## Live-test expectation

No fixed adaptive action list is expected. A passing live preserved-state experiment must show that the selected objective equals the recorded global minimum, the candidate consequences are complete, legacy need fields are empty in new records, repeated blocked ingress still updates the deformation family, and any programmed tie/realization is labeled rather than called a Yggdrasil preference.

Historical v0.7.3/v0.7.3.1/v0.7.3.2 records are preserved and are never rewritten to make the history look cleaner.

## Scope

No autonomous external retaliation, intrusion, exploit delivery, credential theft, or hack-back is included. Enforcement remains inside the Noeron runtime/state and future explicitly connected infrastructure owned or expressly authorized by Abdelaziz.
