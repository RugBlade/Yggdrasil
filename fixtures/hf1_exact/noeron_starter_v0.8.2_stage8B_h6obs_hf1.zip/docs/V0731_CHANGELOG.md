# v0.7.3.1 changelog

- Added explicit dual-layer defense: minimal reflexive invariant floor plus native adaptive defense.
- IRG now participates causally in hostile-environment interpretation before trusted-state mutation; defensive evidence continues through DKT, regional EGR, RL and Frenet.
- Added persistent defensive response preferences that update from repeated defensive experience.
- Added auditable candidate action scores and selected bounded local actions.
- Repeated ingress from an already blocked source still contributes to its underlying protected deformation family and recurrence.
- Corrected family matching to compare bounded sentinel geometry with bounded family prototypes.
- Removed the canned defensive reply; defense output is composed from live native propositions derived from the actual event/deliberation record.
- Added `GET /security/defense/deliberation`.
- Historical v0.7.3 defensive actions are preserved and explicitly labeled `legacy-programmed-v0.7.3` during migration.
- No external hack-back or third-party intrusion capability added.
