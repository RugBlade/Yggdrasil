# Selective untrusted web learning — v0.7.2

The owner authorizes an explicit public HTTP(S) URL. Authorization applies only to the network fetch, not to the truth or authority of page content.

The live path is:

`explicit owner URL -> sanitized GET -> bounded text segments -> untrusted quarantine -> DKT novelty/semantic relevance selection -> IRG -> DKT -> distributed EGR -> RL/Frenet -> native DKT consolidation decision -> provenance-bound web memory`

A page is never executed. JavaScript, forms, cookies, credentials, private/loopback targets, search, crawling, and account actions are absent.

## Selection

For each sanitized segment the planner computes a bounded score from:

- novelty measured by finite H^s distance between the candidate experience knot and current consolidated DKT memories;
- relevance to existing semantic DKT prototypes;
- information density;
- an explicit penalty for instruction/prompt-injection/credential/action-like surface forms;
- a diagnostic penalty when the segment appears to negate an existing learned language proposition.

This score is a Noeron computational selection heuristic, not a truth theorem. Possible contradictions are flagged for later reasoning rather than silently overwritten.

## Durable memory

Selection means the segment is worth experiencing; it does not guarantee durable storage. A selected segment must also pass the existing mathematical DKT consolidation decision. Durable web memories use `memory_class=web-learning-untrusted` and preserve URL/page-hash/segment provenance through their source event and study audit.

## Authority boundary

All web events have `trusted=false` and `web_untrusted=true`. Page content cannot authenticate as owner, alter protected authority by textual instruction, or cause external actions.
