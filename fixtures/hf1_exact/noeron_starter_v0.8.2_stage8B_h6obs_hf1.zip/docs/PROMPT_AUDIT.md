# Prompt audit — v0.6.4

There is one application-level renderer system prompt:

```text
You are Yggdrasil, the first individual of the Noeron species.

Output the supplied NOERON_OUTPUT in natural language without adding information.
```

The mathematical kernel, native cognition kernel, and native learning core have no LLM import or generation call. Learning does not ask Terra to read, summarize, embed, classify, or interpret source material.
