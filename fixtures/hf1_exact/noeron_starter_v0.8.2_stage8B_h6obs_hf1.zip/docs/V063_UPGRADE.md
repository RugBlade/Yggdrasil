# Upgrade Yggdrasil v0.6.2 -> v0.6.3

1. Stop the service and preserve the current database/config.
2. Verify the release archive SHA-256.
3. Extract to a temporary directory and run the full test suite before replacing installed code.
4. Verify no LLM imports exist under `src/noeron/math`, `src/noeron/cognition/kernel.py`, or `src/noeron/learning.py`.
5. Verify old concept-graph source identifiers are absent.
6. Install the new application code while the service remains stopped.
7. Run the installed test suite.
8. Start the service.
9. Verify conversational-turn continuity.
10. Inspect `/learning/audit`, `/learning/strata`, `/memory/audit`, and `/math/interface`.
11. Preview the manuscript; do not commit it immediately.

The first v0.6.3 boot creates three persistence tables if missing:

- `semantic_strata`
- `isotopy_components`
- `stratified_learning_memories`

If active v0.6.2 `learned-source-segment` memories exist, v0.6.3 stores an equivalent stratified deformation record and archives the old full segment row. Source-root knots remain full DKT memories. History is preserved.
