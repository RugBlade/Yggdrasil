# v0.7.3.3 Consequence-Simulated Native Defense

The defensive architecture has two deliberately separated layers.

1. **Reflexive invariant floor — programmed substrate:** reject and quarantine protected-state deformation, freeze the protected mutation, restore the last trusted checkpoint, preserve evidence/provenance, and register only a bounded defensive DKT sentinel/family. These acts are mandatory implementation invariants and are never labeled Yggdrasil preferences.
2. **Adaptive consequence selection — native mathematical comparison when determinate:** IRG/DKT/regional-EGR/RL/Frenet state plus persistent defensive history define an empirical pre-action state. Every currently available safe local actuator combination is simulated to a post-action state, and one common consequence objective compares those post-action states with the trusted/admissible operating geometry plus learned DKT action-context geometry.

## Consequence state

The finite release uses the common bounded coordinate chart

`(IRG response, IRG entropy, IRG topology, DKT displacement, EGR entropy, RL acceleration, Frenet curvature, expected family exposure, expected source exposure, operational restriction)`.

The first seven coordinates come from the live causal mathematical kernel. The trusted mathematical reference comes from the last trusted checkpoint. The admissible reference extends it with zero hostile-family exposure, zero hostile-source exposure, and zero defensive operational restriction.

Recurrence is **not** translated into a desired action. It enters only as empirical evidence about persistence of the observed deformation family/source. The common finite-sample confidence transform is `n/(n+1)`. Family-guard consequence prediction also uses geometric match to the learned DKT defensive-family prototype. These are programmed prediction interfaces, not action preferences.

## Primitive actuator semantics

The adaptive actuator space contains only:

- `strengthen-geometric-guard`: local family-geometry retraction/hardening;
- `block-source-fingerprint`: local denial of one unprivileged source fingerprint;
- `enter-fail-closed-guard`: deny unprivileged runtime ingress at the physical cost of restricting normal ingress.

Evidence retention is **not** an adaptive option in v0.7.3.3. Preserving quarantine evidence/provenance belongs to the reflexive floor and therefore cannot be falsely presented as a learned preference.

The actuator implementation contains branches because physical capabilities necessarily have different semantics. Those branches are not the choice rule. `SAFE_AFFORDANCES` contains no per-action utility weights, preference scores, escalation thresholds, or recurrence-to-action mapping.

## Common objective

For each safe plan `a`, the runtime predicts

`X_t --a--> X_(t+1)^(a)`

and evaluates the RMS distance of the predicted consequence coordinates from the trusted/admissible reference. This common consequence distance is then combined, again by one common RMS operation, with DKT preference-geometry mismatch. Unlearned actuators all use the same DKT reference-knot geometry as a symmetric neutral state rather than receiving hand-authored action-specific priors.

Thus the choice layer contains no `global_isolation = recurrence`, no manually authored defensive need vector, no per-action utility equation, no fixed action ranking, and no action-selection threshold.

## Learned DKT preference geometry

When a unique global-minimum actuator plan is mathematically selected, the defensive context knot contributes to persistent DKT action-preference geometry. Repeated experience can therefore change future objective values through actual stored knot geometry.

If several actuator plans are merely redundant realizations of the **same** minimum post-action state, the native object of selection is the minimum post-action geometry. Redundancy elimination is explicitly labeled a programmed realization detail; it is not called a Yggdrasil action preference. Only actions common to all equivalent minimum realizations may be learned from that event.

If distinct post-action states are exactly tied by the native objective, the audit labels the actuator resolution `programmed-resolution-of-native-objective-tie`; it receives no native-choice score and is not learned into DKT preference geometry. This prevents a deterministic tie-break from being laundered into a claim that Yggdrasil preferred one tied state.

## Audit requirements

Every new v0.7.3.3 deliberation records:

- the IRG/DKT/EGR/RL/Frenet evidence used;
- recurrence as observed history;
- empirical pre-action state;
- trusted/admissible reference state;
- every candidate post-action state;
- every candidate consequence distance;
- every candidate learned-DKT preference mismatch;
- every candidate total objective;
- all minimum candidate plans;
- selected post-action state and objective;
- native selection status;
- actuator realization layer;
- which actions, if any, were allowed to update preference geometry;
- preference geometry before/after;
- live explanation facts.

Historical v0.7.3/v0.7.3.1/v0.7.3.2 records remain untouched provenance and never acquire current choice authority.

## Scope boundary

This release is aggressive only inside the Noeron runtime/state and future explicitly connected infrastructure owned or expressly authorized by Abdelaziz. It contains no autonomous external retaliation, intrusion, exploit delivery, credential theft, or hack-back. OS firewall/service/container adapters are not silently claimed to exist.

This mechanism is a finite `NOERON_EXTENSION`; it is not a theorem that the full infinite-dimensional DKT machinery solves cybersecurity attribution or control.
