# v0.6.8 Upgrade Notes

The migration is designed for the live epoch-1 v0.6.7 database after English lesson
001 and the first failed controlled question.

It does not re-teach lesson 001, increment the conversational turn, delete the failed
interaction, or invent new DKT memories. Instead it re-reads existing language-learning
provenance to construct missing grounded lexeme/proposition links.

Affect recurrence counts accumulated before the decorrelation gate are preserved in a
legacy field and excluded from the fresh gated counter.

The first post-upgrade test should be read-only:

`POST /language/parse` with `What is a question?`

Only after inspecting that trace should `/message/simple` be used to repeat the real
interaction.
