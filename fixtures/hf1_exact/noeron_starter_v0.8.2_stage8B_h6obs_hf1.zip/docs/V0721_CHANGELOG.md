# v0.7.2.1 changelog

- Split web segment selection into `selected_for_attention` and `selected_for_durable_learning`.
- Added `knowledge_quality`, `boilerplate_penalty`, `durable_learning_score`, and stable semantic-term diagnostics.
- Made novelty insufficient by itself for durable web learning.
- Added deterministic main-content hygiene for nav/footer/aside/form HTML regions.
- Broadened instruction/directive detection to ordinary imperatives and reader-directed obligations.
- Added descriptive-instruction context distinction.
- Added conservative web-channel semantic vocabulary hygiene to prevent malformed prototype stems.
- Added web audit counters for attended segments, durable candidates, and boilerplate segments.
- New durable web memories use geometry lineage `semantic-web-irg-dkt-v0.7.2.1`; older v0.7.2 memory provenance is preserved.
- Runtime/mechanism metadata normalized to v0.7.2.1; historical schema/provenance versions are not rewritten.
