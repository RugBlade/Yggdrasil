# v0.6.5 Multi-Memory Reasoning

This is a Noeron extension over the existing DKT/IRG/EGR/RL/Frenet substrate.

For a query experience knot K_q, DKT retrieves several memories by finite H^s distance. Retrieval weights are converted into a finite support measure. When at least two learned stratified memories are available, learned memory receives the majority of reasoning mass so very recent ordinary episodic memories do not erase established learned structure.

Memories are grouped by learned Noeron semantic stratum. Inside the dominant compatible group a finite H^s-chart weighted knot is used as a reasoning-workspace proxy. The corresponding stored RL coordinates are combined into the RL memory target.

If support spans different learned semantic strata, the system preserves a dominant bundle and a contrast bundle. Their H^s bridge distance is measured, but the knots are not silently averaged into a single supposedly meaningful cross-stratum object.

The reasoning workspace records:

- memory IDs and H^s distances;
- normalized support weights;
- learned-memory count;
- learned semantic-stratum IDs;
- local isotopy-component IDs;
- dominant and contrast bundles;
- within-bundle H^s dispersion;
- structural agreement;
- support concentration;
- RL logical target;
- cross-bundle H^s distance;
- candidate learned-frontier links.

Repeated reasoning workspaces may form a persistent higher-order reasoning concept. Concept identity is matched using H^s workspace geometry and learned-stratum scope. Existing established semantic prototypes are used only to provide audit descriptors, never as the geometric identity mechanism.
