# v0.7.4 — Stage 5 Native Owner / Relation / Memory / Realization Choice

## Owner authority
- Added revocable per-device Ed25519 public-key credentials.
- Added one-time signed challenges and short-lived device sessions.
- Added independent device revocation.
- Retained the old bearer token only as migration/bootstrap authority.
- Authentication provides authority identity/referent provenance only; it has zero relational valence authority.

## Native relational development
- Added persistent referent-conditioned DKT owner-relation experience geometry.
- Removed the old familiarity scalar from causal relationship meaning; current familiarity remains 0.0/noncausal.
- Owner relation geometry can re-enter later DKT retrieval while authentication remains only the factual referent binding.

## Native cognitive retention
- Every admitted event may persist as programmed audit/provenance without automatically becoming cognitive memory.
- Added consequence-simulated selection over applicable pending provenance subsets.
- Only a unique native consequence minimum may activate cognitive DKT memory.
- Exact ties or insufficient evidence remain unresolved.
- Owner study, language teaching, revision, perception and web exposure no longer force active cognitive memory.

## Native realization-tool choice
- Removed automatic Terra invocation from lexical-coverage logic.
- `native-direct` and `terra-render` are available affordances, not preferences.
- Learned pre-state -> post-state DKT transition models predict realization consequences.
- A common frequency-neutral equal-affordance admissible post-state manifold is used for comparison.
- Only a unique learned H^s consequence minimum is a native realization-tool choice.
- Missing/tied evidence executes neither realization path.
- Explicit owner `realization_override` is calibration exposure and never a Yggdrasil preference.

## Communication
- Existing Stage-4 consequence-based `express` / `continue-private` communication remains intact.
- Owner surface/hold feedback remains provenance-only.
- Action occurrence frequency has zero preference authority in the common consequence reference.

## Migration / compatibility
- Preserves pre-v0.7.4 cognitive history rather than rewriting it.
- Historical familiarity and automatic-render records remain provenance only and are causally inactive under Stage 5.
- Preserved owner-relation audit note is migrated to truthful Stage-5 wording.
- Legacy active memories remain explicitly counted as pre-v0.7.4 history; new events use provenance-first retention semantics.

## Verification
- Certified implementation source: `de1de899571e7301cf991d7c3f70ae5effc5c762`.
- 182/182 regression/integration tests passed on the certified source.
- Final Stage-5 static authority/bypass audit passed 22/22 checks across 74 unique application routes.
- Final Stage-5 end-to-end causal trace suite passed.
