# v0.6.5 changelog — perception cleanup + multi-memory reasoning

- Removed closing-only theorem/lemma/proof markers from learning segmentation.
- Removed list/environment presentation scaffolding while preserving content.
- Added deterministic Frechet, embedding-space, immersion-space, diffeomorphism-space and infinity-symbol canonicalization.
- Routed mathematical notation relations/symbols through fixed IRG sensor roles instead of learning them as domain prototypes.
- Routed discourse/inference words to logical-discourse IRG atoms rather than semantic prototype learning.
- Changed one-observation context coherence from numerical zero to unestimated/null.
- Added eligible-prototype coherence to the learning-rate diagnostic.
- Increased DKT retrieval workspace to six memories and added a stratified multi-memory reasoning stage.
- Added learned-memory mass protection so a recent episodic question cannot automatically swamp established learned memories.
- Added dominant/contrast reasoning bundles; cross-stratum evidence is not silently averaged.
- Made the dominant multi-memory DKT workspace causally determine the RL memory target.
- Added persistent higher-order reasoning concepts formed from recurring H^s workspaces and learned-stratum scope.
- Added `/reasoning/state`, `/reasoning/concepts`, and read-only `/reasoning/probe`.
- Added reasoning concept counts/status to cognition state and learning audit.
- Terra remains renderer-only; no graph/vector/LLM cognition was added.
