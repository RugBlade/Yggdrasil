# Mathematical perception v0.6.4

The mathematical reader is a deterministic sensor front-end. It normalizes selected source notation so TeX implementation tokens do not masquerade as concepts, while leaving mathematical content available to IRG/DKT.

It is intentionally limited. Mapping `\\mathbb{R}` to `real-number-space` identifies notation role; it does not prove anything about R. Mapping `\\sim` to `equivalence-relation` exposes a relation symbol in contexts where the source uses it; it does not independently verify that the relation is mathematically an equivalence relation.

Compound concept candidates are grammar-like deterministic noun phrases, not nodes in a knowledge graph. Their learned meaning is still the context-derived DKT semantic knot.
