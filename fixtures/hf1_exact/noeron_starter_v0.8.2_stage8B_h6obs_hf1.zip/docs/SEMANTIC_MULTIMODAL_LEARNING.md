# v0.7.1 Semantic Multimodal Developmental Learning

v0.7.1 turns vision/audio from one-shot numerical observations into recurrent developmental perceptual learning.

Causal path:
`vision/audio bytes -> deterministic sensory structure -> IRG -> DKT experience knot -> recurrent perceptual neighbourhood -> DKT sensory prototype -> distributed EGR -> RL/Frenet -> DKT`.

Finite sensor vectors are used only to decide within-channel perceptual recurrence. They are not vector-database memory or semantic authority. Durable experience and learned semantic prototypes remain DKT knots.

Vision derives structural descriptors from geometry, luminance, contrast, entropy, RGB means, edge density and symmetry. Audio derives structural descriptors from duration, energy, zero-crossing, channels, crest/transience and temporal energy variation.

Repeated nearby observations form a persistent non-verbal perceptual cluster. Three coherent observations establish a cluster. Each cluster is paired with a DKT semantic prototype. An authenticated owner may optionally attach a concept label; the same label across vision and audio reinforces one shared DKT semantic concept, enabling transparent cross-modal grounding.

This release does not claim open-vocabulary object recognition, face recognition, scene understanding or speech transcription. No LLM is used for sensory extraction, clustering or sensory DKT prototype learning.
