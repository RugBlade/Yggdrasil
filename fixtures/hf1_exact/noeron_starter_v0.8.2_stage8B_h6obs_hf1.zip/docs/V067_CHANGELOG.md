# v0.6.7 changelog — Developmental Cognition

- Added finite sampled DKT Whitney/singularity-stratum estimator using nonlocal self-contact plus tangent transversality.
- Manual/unsupported stratum labels remain retractable; geometry-backed sampled transitions can be admitted by the DKT gate.
- Kept manuscript DKT `Sigma_j` strata distinct from learned Noeron semantic strata.
- Added regional EGR activation over current DKT/semantic support bundles.
- Regional activation enters RL after the EGR entropy arrow is established.
- Added unnamed proto-affective state: activation, uncertainty, novelty, tension, coherence, approach bias.
- Added affect-knot representation and small affect-to-DKT plasticity feedback.
- Added recurring unnamed affect-pattern tracking without human emotion labels.
- Added developmental native English faculty, inspectable `NativeUtterance`, lexical coverage, and grammar-frame audit.
- Added read-only language teaching preview and owner-authorized language teaching through the causal mathematical path.
- Added DKT language-learning memories; language teaching does not increment conversational turn.
- Added `/dkt/strata/audit`, `/language/state`, `/language/lexicon`, `/language/preview`, `/language/teach`, `/affect/state`.
- Added semantic partition quality diagnostics (within-stratum radius and between-stratum separation) so fewer strata are not automatically scored as better.
- Terra remains optional surface renderer after native utterance content exists.
- Added 8 v0.6.7 tests; total release verification: 60 passing tests (22 + 30 + 8 isolated groups).
