# v0.7.0 Upgrade

Preserves the v0.6.9 database and owner token.  No new lesson, web observation, vision/audio observation, or conversational turn is required for migration.  Validate the distributed field read-only before deliberately generating a new interaction.
