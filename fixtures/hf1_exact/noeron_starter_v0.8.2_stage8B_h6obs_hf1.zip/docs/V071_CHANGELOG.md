# v0.7.1 changelog

- structural visual and acoustic semantic descriptors;
- recurrent `SensoryConceptCluster` development;
- DKT semantic prototype anchoring for sensory clusters;
- optional owner-grounded labels and cross-modal DKT concept reinforcement;
- read-only visual/audio preview endpoints;
- read-only sensory concept audit;
- sensory observations remain turn-neutral;
- bulk sensory/tool traffic no longer inflates owner relational familiarity.
