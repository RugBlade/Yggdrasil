# v0.7.2.1 Web Learning Quality Gate

v0.7.2.1 is a patch over v0.7.2. It keeps the owner-authorized public GET-only web boundary and changes how untrusted page segments move from transient attention to durable DKT learning.

## Two-stage selection

A sanitized page segment may be selected for **transient attention** without being eligible for **durable learning**. The attention gate uses DKT novelty, existing semantic relevance, information density, propositional/content quality, boilerplate penalty, instruction-surface risk, and contradiction diagnostics. The durable gate is stricter: novelty alone is insufficient; content quality/usefulness must pass, boilerplate and directive risk must remain below durable thresholds, and stable vocabulary candidates must exist.

Web text remains `UNTRUSTED_ENVIRONMENTAL_INPUT` at every stage and cannot grant owner/tool authority.

## Main-content hygiene

HTML `nav`, `footer`, `aside`, and `form` containers are excluded before text segmentation, in addition to active/script/style elements. A second deterministic boilerplate diagnostic penalizes revision metadata, link-list/navigation labels, policy/footer text, and short navigation-like fragments.

## Instruction/directive detection

The untrusted-surface detector now recognizes general imperatives and reader-directed obligations, not only prompt-injection keywords. Thus benign text such as “please do not design applications…” is correctly recognized as instruction-like. Descriptive mentions of instructions are marked separately and receive reduced directivity risk unless stronger credential/prompt-injection signals occur.

Instruction detection is not an authority system. Even a missed directive remains non-authoritative; the detector is an additional durable-learning hygiene gate.

## Semantic vocabulary hygiene

Durable web memories supply a conservative channel-specific vocabulary candidate list to semantic-prototype learning. The filter prefers stable content words, repairs a small set of common e-dropping inflections, rejects many participial/proper-name fragments, and intentionally under-learns rather than creating malformed prototypes such as `provid`, `configur`, or `iana-manag`.

DKT context geometry remains semantic authority; the vocabulary filter only controls which surface forms may request a semantic prototype.
