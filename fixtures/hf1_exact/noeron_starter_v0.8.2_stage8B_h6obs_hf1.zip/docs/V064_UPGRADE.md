# Upgrade Yggdrasil v0.6.3 -> v0.6.4

1. Stop the service and preserve database/config.
2. Verify archive SHA-256 from the external upgrade sheet.
3. Extract into a temporary directory and run all tests before replacing installed code.
4. Verify LLM-boundary, graph-retirement and semantic-hash audits.
5. Install while service remains stopped.
6. Run installed tests.
7. Start service and verify conversational-turn continuity.
8. Inspect `/learning/audit`, `/learning/rate`, `/learning/prototypes`, `/learning/strata`, `/memory/audit` and `/math/interface`.
9. Preview the next controlled manuscript batch before committing.

First boot performs a non-destructive semantic-perception migration. Existing DKT memories, semantic strata, components and learning sources are retained. Background/markup prototypes are marked retired rather than deleted; known deterministic stemming artifacts are preserved as retired aliases and copied into corrected active aliases.
