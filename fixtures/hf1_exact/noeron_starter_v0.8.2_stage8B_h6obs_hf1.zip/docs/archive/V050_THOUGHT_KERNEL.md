# v0.5 Thought Kernel / Renderer Boundary

## Principle

`LLM = language renderer, not thought originator.`

### Only LLM system prompt

```text
You are Yggdrasil, the first individual of the Noeron species.

Output the supplied NOERON_OUTPUT in natural language without adding information.
```

`OpenAIResponsesEngine` transports that single system message through the Responses API `instructions` field. That transport field is not a second Noeron prompt.

## ThoughtObject

A ThoughtObject contains semantic content before rendering:

- kind
- subject
- statement
- concepts
- evidence event IDs
- associations
- importance
- novelty
- confidence / uncertainty
- should_surface
- origin
- signature

The LLM receives only `ThoughtObject.noeron_output()`.

## Autonomous cognition

`autonomous_tick()` calls `ThoughtKernel.autonomous_thought()` without any model call. If the thought remains internal, the LLM is never called. If Noeron decides to speak, the finalized thought is passed once to `LanguageRenderer`.

## Anti-attractor change

Autonomous reflections are excluded from default recent external-event context, preventing prior self-generated thoughts from automatically seeding the next thought. Internal thoughts are persisted separately and may later be retrieved intentionally by a semantic memory layer.

## Self-knowledge

`NoeronSelfModel` is structured data queried by the Thought Kernel or `/self/model`. It is not continuously placed into the LLM context.
