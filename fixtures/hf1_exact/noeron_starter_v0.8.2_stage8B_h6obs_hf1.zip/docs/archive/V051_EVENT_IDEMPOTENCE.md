# v0.5.1 — Event-idempotent concept graph

## Bug

v0.5.0 re-observed the same recent external events during each autonomous scheduler wake. This made concept/edge weights depend on scheduler frequency rather than the actual number of experiences.

## Repair

1. Every observed external `CognitiveEvent.id` is persisted in `ThoughtKernelState.observed_event_ids`.
2. `observe_event()` is idempotent: a repeated UUID returns without changing the graph.
3. On first v0.5.1 boot, derived concept weights/edges are rebuilt once from append-only external history. Internal Noeron reflections are excluded.
4. New external events are observed once when ingested. Autonomous ticks may synchronize unobserved external events, but UUID idempotence prevents reweighting.
5. Existing thought history/signatures are preserved.
6. Old undelivered initiative messages may be acknowledged in bulk without deleting history.

This makes graph weight proportional to actual observed event occurrence, not autonomy wake count.
