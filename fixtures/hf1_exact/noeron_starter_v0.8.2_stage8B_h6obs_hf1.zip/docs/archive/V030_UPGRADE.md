# Upgrade from verified 0.1.2 to Yggdrasil / Noeron 0.3.0

0.2.0 may be skipped. 0.3.0 includes its individual-identity and optional language-engine work
plus the new mathematical interface. Keep the LLM backend in mock mode for the first boot.

## Continuity requirements

- preserve `/var/lib/noeron/noeron.sqlite3`;
- preserve `/etc/noeron/noeron.env`;
- replace only `/opt/noeron/app`;
- run tests before starting the service;
- verify the pre-upgrade conversational turn survives;
- verify `/math` and `/math/interface` after boot.

The Pydantic state model gives older v0.1.2 state rows a default mathematical kernel on load, so
there is no database schema migration in this release.
