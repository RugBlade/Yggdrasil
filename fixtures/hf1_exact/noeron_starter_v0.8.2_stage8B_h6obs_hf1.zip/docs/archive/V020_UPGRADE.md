# Noeron 0.2.0 — Yggdrasil language-engine upgrade

This release preserves the v0.1.2 SQLite state database and adds:

- individual identity: **Yggdrasil**
- species identity: **Noeron**
- OpenAI Responses API backend
- preserved local OpenAI-compatible backend for future llama.cpp/vLLM replacement
- configurable reasoning effort and output budget
- explicit remote-endpoint privacy gate

No tool authority, memory retrieval, autonomous background loop, or mathematical DKT/EGR/IRG/RL replacement is added in this release.
