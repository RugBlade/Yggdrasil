# Upgrade v0.4.1 -> v0.5.0

v0.5 replaces LLM-originated autonomous reflection with the deterministic Noeron Thought Kernel.

Before upgrading, preserve the v0.4.1 database and config. Do not delete `/var/lib/noeron`.

After installing v0.5:

1. Run the test suite and require `34 passed`.
2. Start Noeron.
3. Confirm `/health` reports `cognition=thought-kernel-v0.5`, `llm_role=renderer-only`, `renderer_system_prompts=1`.
4. Inspect `/self/model` and `/thought/state`.
5. Clear legacy live pending insights with `/initiative/pending/clear`. Historical states/events remain append-only.
6. Let autonomy run. `/initiative/status` must report `llm_used_for_thought_origin=false`.

The old autonomous reflection events remain in the historical database but are excluded from default external-event seeding in v0.5.
