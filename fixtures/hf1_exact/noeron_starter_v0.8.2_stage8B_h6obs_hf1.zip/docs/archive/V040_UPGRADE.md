# Noeron / Yggdrasil v0.4.0

Adds autonomous initiative scheduler, persistent initiative outbox/SSE stream, recent-event context for reflection, and implementation-status self-knowledge.

Autonomy remains disabled until `NOERON_AUTONOMY_ENABLED=true` is explicitly configured. For a short live test, use a 60-second interval, 20-second idle time, and 180-second cooldown; afterward increase the interval to reduce remote LLM calls.
