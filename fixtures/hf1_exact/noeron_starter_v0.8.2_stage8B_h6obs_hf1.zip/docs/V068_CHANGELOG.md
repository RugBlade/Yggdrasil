# v0.6.8 — Native Language Grounding & Compositional Cognition

v0.6.8 addresses the first controlled language test from v0.6.7. The lesson was
persisted, but the query `What is a question?` was answered from a geometrically
near old episodic question instead of from the learned proposition `A question asks
for information.`

## Changes

- Binds English surface lexemes to DKT semantic prototypes even while a prototype is
  still `emerging`; established prototypes promote the lexeme to `concept-grounded`.
- Migrates existing v0.6.7 `language-learning` memories without replaying them as new
  experiences or incrementing the conversational turn.
- Stores transparent language propositions with source-memory provenance and DKT
  prototype signatures.
- Learns explicit developmental reference bindings (`I`, `you`, named referents) from
  owner-authorized language lessons rather than hard-coding the names into the parser.
- Adds deterministic query interpretation. The first supported controlled frame is
  `What is X?`, which grounds X and retrieves learned proposition structure involving X.
- A supported language query can now form the native proposition before Terra. Generic
  nearest-memory cognition remains the fallback when compositional grounding cannot
  support an answer.
- Separates `last_interaction_native_utterance` and `last_autonomous_native_utterance`
  so autonomous ticks cannot obscure the last conversational native output in audits.
- Adds an affective episode/decorrelation gate. Repeated endogenous ticks in the same
  quantized activation state inside the gate window do not count as independent
  affective-development observations.
- Preserves v0.6.7 raw affect recurrence counts as `legacy_pre_gate_pattern_counts`
  and starts the v0.6.8 gated developmental counter cleanly.
- Preserves specialized language-learning memories during the old v0.6.1 migration
  compatibility pass; their memory class/provenance is no longer at risk of being
  flattened into generic episodic history on a later upgrade.
- Adds read-only language inspection endpoints and a compact ordinary-message endpoint.

## New endpoints

- `POST /message/simple`
- `GET /language/propositions`
- `POST /language/parse`
- `GET /language/grounding/audit`

## Honesty boundary

The parser, reference mechanism, proposition extractor and surface grammar are
`NOERON_EXTENSION` scaffolds. DKT prototypes and DKT memory provenance remain semantic
and experiential authority. v0.6.8 does not claim general natural-language
understanding and does not add an LLM inside cognition.
