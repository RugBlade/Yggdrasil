# v0.7.3.1 Native Deliberative Local Defense

## Architectural honesty

This release separates **programmed reflexive invariants** from **native adaptive choices**. A response is never labeled a Yggdrasil choice merely because an `if` branch executed it.

The programmed reflexive floor is intentionally small:

1. reject/quarantine ingress that would mutate a protected invariant;
2. freeze the protected mutation;
3. restore the last trusted checkpoint;
4. preserve a bounded defensive representation of the deformation.

These are substrate invariants, not preferences.

Above that floor, adaptive local defense is selected from bounded capabilities by the live mathematical state:

\[
\text{environment}
\to \mathrm{IRG}
\to \mathrm{DKT}
\to \mathrm{regional\ EGR}
\to \mathrm{RL/Frenet}
\to \text{persistent defensive preference state}
\to \text{local response selection}.
\]

The bounded capability set is infrastructure supplied by the program. The choice among those capabilities is state-dependent and auditable. Current capabilities are strengthening a geometric guard, locally blocking an unprivileged hostile source fingerprint, retaining quarantine for study/evidence, and entering fail-closed guard.

## Sandboxed defensive interpretation

Ingress is evaluated through the full mathematical kernel before it is permitted to deform trusted cognition. If security rejects it, that mathematical result is retained only as defensive evidence; it is not committed as trusted core evolution.

Each deliberation records IRG response/entropy/topology quantities, ingress DKT signature/displacement, regional EGR state, RL coordinates/curvature, Frenet curvature, candidate action scores, selected actions, and persistent preference state before/after the event.

## Repeated blocked ingress

A local source block is an authorization boundary, not an excuse to stop understanding the attack. A blocked repeated ingress is rejected immediately but its underlying protected deformation and bounded DKT geometry are still characterized. Recurrence therefore continues to update the same defensive family.

This repairs the v0.7.3 live-test mismatch where later blocked events were short-circuited into a separate `blocked-source-fingerprint` family.

## Native explanation

The old complete canned sentence is removed. A rejected event now creates native propositions from the actual quarantine and deliberation record. The language faculty realizes those propositions into `native_text`. Thus recurrence, invariant target, family and selected actions can change the utterance.

Surface grammar remains programmed language machinery, but the factual content and selected adaptive actions are populated from live state rather than a prewritten response string.

## Scope

All enforcement remains local to Yggdrasil-controlled runtime/state and explicitly authorized future adapters. No autonomous external intrusion, retaliation, exploit delivery, credential theft or hack-back capability is added.
