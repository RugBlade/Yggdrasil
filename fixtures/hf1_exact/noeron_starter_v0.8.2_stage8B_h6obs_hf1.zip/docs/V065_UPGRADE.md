# Upgrade Yggdrasil v0.6.4 -> v0.6.5

Use the external v0.6.5 Upgrade + Verification Sheet for exact commands, hashes and expected outputs.

v0.6.5 is deliberately non-destructive:

- existing DKT memories remain authoritative;
- v0.6.3 semantic strata/components and compressed deformation memories remain intact;
- v0.6.4 prototypes remain, while one-observation coherence is reclassified as unestimated;
- no learning batch is committed by migration;
- no conversation turn is fabricated;
- a new persistence table is added for future higher-order reasoning concepts;
- the pending v0.6.4 batch-2 preview should be rerun under v0.6.5 before any commit.

The first recommended post-upgrade action is the same 20-unit read-only manuscript preview starting at segment 5. v0.6.5 intentionally changes segmentation by discarding closing-only structural markers, so the total normalized segment count will be lower than v0.6.4.
