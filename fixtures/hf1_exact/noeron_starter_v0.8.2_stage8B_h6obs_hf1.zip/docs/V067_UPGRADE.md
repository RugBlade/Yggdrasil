# v0.6.7 upgrade principle

v0.6.7 is a developmental-faculty release built on the owner-committed v0.6.6 epoch-1 topology.

Installation must preserve:

- conversational turn;
- `stratification_epoch == 1` on the user's current database;
- 4 active Noeron semantic strata and 12 local components on the current baseline;
- all 25 compressed manuscript memories and their stratification history;
- reasoning-concept history;
- manuscript bytes/hash.

The migration seeds the native English surface lexicon from already-established DKT semantic prototypes plus a small explicitly-labelled grammar-function scaffold. It does **not** automatically teach a new language curriculum or rewrite learned DKT memory.

After upgrade, first inspect `/dkt/strata/audit`, `/language/state`, and `/affect/state`. Use `/language/preview` before the first owner-authorized English lesson.
