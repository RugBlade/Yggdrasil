# v0.7.0 — Distributed Stratified Activation Field

- Replaces winner-take-all active-region reporting with material-participation selection.
- Preserves non-dominant regions using absolute/relative participation plus cumulative activation coverage.
- Adds per-region A/U/N/T/C/P computational axes; the old global vector is explicitly a coarse projection.
- Builds a finite nearest-neighbor piecewise logical-chart path across active regions with a Whitney/frontier compatibility proxy.
- The distributed field causally changes the EGR activation vector that biases RL and contributes bounded high-mode DKT plasticity.
- Adds `GET /affect/field`.
- Semantic strata remain distinct from manuscript DKT singularity strata.
- No subjective-emotion claim and no named emotion labels.
