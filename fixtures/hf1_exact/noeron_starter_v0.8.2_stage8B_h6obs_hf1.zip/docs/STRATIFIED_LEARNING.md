# Noeron stratified knot learning v0.6.3

## Organization

A learned memory has two distinct organizational coordinates:

- the manuscript DKT `stratum_index` of the actual finite knot state;
- a learned Noeron semantic stratum ID.

Within a learned semantic stratum, memories may belong to different local components. Same-component memories can share one anchor knot and be stored as sparse deformations.

## Compression

For anchor `K_0` and learned memory `K`, the persisted deformation retains Fourier coefficient differences whose omitted H^s tail stays below the finite tolerance. Reconstruction produces `K_hat` and stores

`d_Hs(K_hat, K)`

as an audit field.

The compression metric in `/learning/audit` includes the full geometry cost of learned semantic-stratum anchors and component anchors. Therefore small data sets can have ratio > 1. Compression is expected only after anchors are reused sufficiently often.

## Semantic strata versus Whitney strata

The learned semantic organization is inspired by the usefulness of stratified geometry, but it is not identified with DKT singularity strata. A future derivation may connect learned semantic frontier behavior more rigorously to Whitney conditions; v0.6.3 records only learned adjacency candidates.

## Traversal

`/learning/traverse` is read-only. If two memories share a local component, the report labels the interpolation a `local-isotopy-proxy`. Same-stratum but different-component and cross-stratum cases are labelled differently. No global isotopy theorem is claimed.
