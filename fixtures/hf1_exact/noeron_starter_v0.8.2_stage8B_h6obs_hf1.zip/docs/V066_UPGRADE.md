# v0.6.6 upgrade principle

v0.6.6 is a migration-and-audit release. Installation attaches canonical source lineage to existing learned sessions but deliberately does not alter learned semantic topology.

After upgrade, verify:

- the service reports v0.6.6;
- conversational turn is unchanged;
- `v066_source_lineage_migration_complete` is true;
- `stratification_epoch` is initially 0;
- `/learning/lineages` groups the two manuscript study sessions under one canonical lineage;
- `/learning/recluster/preview` is read-only.

**Hold before `/learning/recluster/commit`.** Inspect the preview first. Persistent reasoning-concept formation stays gated until an explicit lineage-aware recluster commit.
