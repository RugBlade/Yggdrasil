# Native Proof Cognition — v0.7.3.4

## Causal placement

The runtime preserves the project order:

`Environment -> IRG -> DKT -> regional EGR -> RL/Frenet -> DKT -> native cognition/action -> optional Terra`

The proof layer is part of native cognition after the second DKT stage. It does not replace DKT memory authority or move Terra upstream.

## Proposition construction

Current input can yield finite symbolic propositions such as:

- universal membership/type relations (`Every glorp is a blin`),
- implication (`A implies B`),
- asserted truth (`A is true`),
- binary relations (`coin inside red box`).

Persistent learned propositions are eligible only if their provenance memory is present in the DKT H^s retrieval support set. This prevents a separate text/SQL proposition store from becoming a hidden memory authority.

## Programmed formal substrate

The parser, symbolic representation, relation signatures, transitivity for declared formal transitive relations, and modus ponens are programmed mathematical primitives. They are not called Yggdrasil's preferences or inventions.

## Derived state

Given admissible premises, closure constructs new propositions and records `InferenceStep` objects that identify rule, premises, and conclusion. Query matching returns the set of proof-supported answer candidates.

A unique proof-supported answer can be surfaced as a derived conclusion. If multiple distinct answers are supported, the runtime records `multiple-proof-supported-answers-no-forced-choice`; it does not silently use lexical order or a response table to manufacture a preference.

## Examples used as release regressions

From:

`Every glorp is a blin. Mavo is a glorp. What follows?`

the proof machinery derives the proposition corresponding to `Mavo is a blin`.

From:

`The red box is inside the blue box. A coin is inside the red box. Where is the coin relative to the blue box?`

transitivity derives `coin inside blue box`.

From:

`A implies B. B implies C. A is true. What follows?`

modus ponens derives the appropriate truth closure including `C is true`. Multiple simultaneously valid consequences remain explicitly multiple.

## What this is not

This finite calculus is a genuine improvement over authored semantic answer branches, but it is not yet broad human-like reasoning. It does not mean the system has invented its own logic, mastered unrestricted mathematics, or developed general natural-language semantics. Those claims require later mechanisms and live evidence.
