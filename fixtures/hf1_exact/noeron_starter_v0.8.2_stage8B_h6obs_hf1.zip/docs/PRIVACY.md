# Privacy threat model

## Privacy levels

### Level 0: cloud-assisted

A cloud LLM or embedding endpoint receives content. This is not complete privacy, regardless
of transport encryption or provider promises.

### Level 1: self-hosted on rented infrastructure

Inference and storage are controlled by the application owner, but the data-center provider
retains physical and hypervisor-level trust. This is useful privacy, not absolute privacy.

### Level 2: on-premises connected

The model, state, and tools run on physically controlled hardware. Outbound network access is
denied by default and temporarily enabled only for audited updates.

### Level 3: offline/air-gapped

After verified installation, the machine does not communicate with external networks. Data
transfer uses deliberate offline procedures. This is the strongest practical target, though
supply-chain and physical-security risks still remain.

## Minimum controls before personal data is used

- full-disk encryption and encrypted offline backups;
- strong local authentication;
- outbound-deny firewall;
- loopback or mutually authenticated private model transport;
- no telemetry, analytics, hosted crash reporting, or cloud embeddings;
- signed/pinned software and model artifacts with recorded hashes;
- append-only provenance for memory changes;
- least-privilege tool capabilities;
- per-sensor permission for microphone, camera, files, calendar, and network;
- isolated shadow execution for untrusted transformations;
- recovery drills from immutable checkpoints.

## Critical rule

No external model API can be treated as fully private. To reach Level 2 or Level 3, use an
open-weight model running locally and ensure that every auxiliary component—embedding,
speech, search, storage, logs, and tools—is local as well.
