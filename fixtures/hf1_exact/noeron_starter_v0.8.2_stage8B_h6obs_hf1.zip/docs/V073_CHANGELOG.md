# v0.7.3 Changelog

- Added aggressive local defensive containment for protected-invariant deformation.
- Added pre-authority hostile ingress DKT representation.
- Added bounded defensive DKT sentinel knots and finite H^s deformation-family matching.
- Added persistent local defensive action history, hardened rules, source fingerprints, threat score, containment level and fail-closed state.
- Added local source-fingerprint blocking for unprivileged hostile ingress.
- Added owner-only local containment release without evidence/history deletion.
- Added `GET /security/defense/policy`.
- Added `POST /security/defense/release`.
- Expanded `/security/defense/audit` with actions, family prototypes and containment state.
- Strengthened `/security/defense/test-deformation` so the owner authorizes the test while the simulated ingress itself remains unprivileged.
- Preserved the no-external-retaliation/no-hack-back boundary.
- Tightened web main-content hygiene: substantial `<main>`/`<article>` content is preferred over surrounding heading/navigation residue.
- Added nine v0.7.3 regression tests. Total exact-build suite: 109 tests.
