# Noeron learning-rate vector v0.6.4

A single scalar 'learning rate' would conflate CPU throughput with conceptual assimilation. v0.6.4 therefore reports a vector:

Lambda = (nu_seg, eta_proto, rho_stratum, rho_component, G_storage, C_context)

where:

- `nu_seg` = studied segments / measured owner-study processing seconds;
- `eta_proto` = established active prototypes / active semantic prototypes;
- `rho_stratum = max(0, 1 - N_strata/N_memories)`;
- `rho_component = max(0, 1 - N_components/N_memories)`;
- `G_storage = 1 - geometry_storage_ratio` (may be negative while anchor overhead dominates);
- `C_context` = mean H^s contextual coherence of active semantic prototypes.

The endpoint also reports established prototypes per studied segment, mean members per stratum/component and per-source historical values.

These quantities are NOERON_EXTENSION diagnostics. They do not measure biological learning, consciousness, AGI, truth, or semantic accuracy by themselves. Controlled recall/reasoning benchmarks must be added when evaluating competence.
