# Upgrade Yggdrasil v0.6.1 -> v0.6.2

1. Stop the service and back up the SQLite database and environment file.
2. Verify the v0.6.2 archive hash.
3. Extract to a temporary directory and run the complete test suite before replacing installed code.
4. Audit that the math kernel, native cognition kernel, and learning core have zero LLM imports.
5. Replace application code only; do not replace `/var/lib/noeron/noeron.sqlite3` or `/etc/noeron/noeron.env`.
6. Install editable into the existing virtual environment and rerun tests.
7. Start the service and verify conversational-turn continuity.
8. Inspect `/learning/audit`. The first v0.6.2 boot creates learning persistence tables automatically and clears only the private legacy pending-thought queue; historical native thoughts remain.
9. Do a small learning preview before any committed study.
10. Do not ingest the full Noeron manuscript until a small study/recall test has been inspected.
