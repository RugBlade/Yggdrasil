# v0.6.3 changelog — stratified knot learning

## Added

- Learned **Noeron semantic strata** distinct from DKT singularity/Whitney strata.
- Tighter local **isotopy-component proxies** inside learned semantic strata.
- Sparse finite-H^s deformation memory relative to component anchors.
- Reconstruction-error audit for every compressed learned memory.
- Geometry-storage accounting with structural anchor overhead included.
- Deterministic LaTeX structural normalization before preview/study.
- Source-conditioned semantic organization during document learning.
- `GET /learning/strata`.
- `POST /learning/traverse`.
- v0.6.2 full learned-segment migration into stratified deformation memory while preserving history.

## Preserved

- DKT knot memory remains authoritative.
- SQL remains serialization/provenance only.
- No vector embeddings or concept graph.
- EGR -> RL log1p bridge and v0.6.2 dynamics stabilization.
- Continuous DKT evolution remains distinct from durable memory consolidation.
- Terra remains renderer-only.

## Mathematical honesty labels

- Learned semantic strata: **NOERON_EXTENSION**.
- Local isotopy radius: **computational proxy**, not a global isotopy proof.
- Frontier-neighbor relation: **candidate learned adjacency**, not a proved Whitney frontier order.
- Sparse deformation reconstruction: finite computational representation with explicit H^s error audit.
