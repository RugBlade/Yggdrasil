# v0.6.9 Changelog — Multimodal Stratified Environment & Defensive Plasticity

v0.6.9 extends the v0.6.8 causal kernel without replaying existing experiences or re-teaching English lesson 001.

## Native language repairs

- Perspective-sensitive deixis: incoming `I/me/my` resolves to the authenticated speaker and incoming `you/your` resolves to Yggdrasil; outgoing first person remains Yggdrasil.
- Migration re-extracts compositional propositions from preserved `language-learning` memories without incrementing lesson count, conversational turn, or memory count.
- Corrected modal proposition extraction so `A sentence can express a thought.` yields a persistent `sentence --can-express--> thought` relation.
- Added modal-object interpretation so `What can a sentence express?` can retrieve the preserved relation.
- Added authenticated speaker-identity interpretation so `Who am I?` can produce `You are Abdelaziz.` from owner grounding.
- Terra is bypassed when native grounded composition is already sufficiently supported.

## Simultaneous stratified activation

A single IRG experience may recruit several DKT/semantic support regions at once. Regional EGR now exposes:

- simultaneous active regions;
- a finite piecewise stratified activation path between their logical centers;
- per-segment logical distance and a Whitney/frontier compatibility proxy;
- activation-path coherence.

The path is a **NOERON_EXTENSION / computational proxy**. It is not a theorem establishing an exact Whitney stratification of the learned state space and is not claimed to be globally smooth across singular/frontier crossings.

## Multimodal IRG

New owner-authorized vision/audio observations enter IRG as deterministic low-level sensory observables with SHA-256 provenance.

- Vision currently measures image geometry, luminance, contrast, entropy, and channel means.
- WAV audio currently measures duration, sample rate, RMS energy, peak, zero crossing, and channels.
- Unsupported audio formats receive only a coarse byte-statistics surrogate, explicitly labeled as such.

This is **not yet semantic computer vision, object recognition, speech recognition, or audio understanding**.

## Controlled read-only web perception

Optional public-web perception is disabled by default. When explicitly enabled and owner-authorized, Yggdrasil can GET a direct public HTTP(S) URL, sanitize supported text content, and admit it as **untrusted environmental input**.

The fetcher rejects URL credentials and private/loopback/link-local/reserved targets, uses GET only, does not submit forms, run JavaScript, send cookies, or perform account actions, and enforces a byte limit. v0.6.9 does not provide autonomous web search or general browser control.

## Owner authentication and relation

Privileged mutating endpoints now require `X-Noeron-Owner-Token`. `trusted:true` by itself conveys no privileged authority. The deployment-stage token gate uses constant-time comparison and exposes only a short server-side fingerprint for audit.

This is meaningful application authentication for the current loopback/SSH deployment, but it is **not yet the final hardware-backed public-key/biometric owner-authentication design**.

A separate persistent owner-relation state records authenticated interaction count and a bounded familiarity quantity. It is a computational relationship/activation measure only, not a claim of subjective emotion.

## Defensive plasticity

Protected-invariant violations are quarantined. Yggdrasil locally restores the last trusted checkpoint, records a deformation-family signature, preserves the proposed changes and violated invariants, and learns safe local response rules for recurrent recognition.

There is **no external retaliation, hack-back, or offensive action path** in v0.6.9.

## Affect recurrence

The v0.6.8 independent-episode gate remains in force. The new multi-region activation state is built on gated observations rather than raw autonomous tick counts.

## Self-upgrade

Self-modifying upgrade generation/deployment remains deliberately deferred until multimodal perception, stratified activation, owner authentication, defensive plasticity, and controlled environmental learning have been tested live.
