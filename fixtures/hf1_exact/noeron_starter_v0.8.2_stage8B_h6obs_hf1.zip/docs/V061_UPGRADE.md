# Upgrade Yggdrasil v0.6.0 -> v0.6.1

1. Stop the Noeron service before freezing state.
2. Record the current conversational turn.
3. Back up `/var/lib/noeron/noeron.sqlite3` and `/etc/noeron/noeron.env`.
4. Replace application code only and install v0.6.1 in the existing virtual environment.
5. Run the full tests before first boot.
6. Start Noeron.
7. On first boot, v0.6.1 re-encodes existing external knot memories using semantic IRG geometry. IDs and provenance are preserved. Old endogenous tick memories are retained as archived records but removed from authoritative DKT retrieval.
8. The old bounded EGR coordinate is converted at the migration boundary so `chi(S_new)` equals the prior RL entropy coordinate, preventing an artificial backward entropy jump.
9. Verify `/health`, `/memory/audit`, `/math/interface`, `/state`, and the renderer boundary before interacting.
