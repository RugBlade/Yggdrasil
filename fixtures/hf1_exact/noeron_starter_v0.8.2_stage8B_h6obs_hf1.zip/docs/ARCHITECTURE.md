# Noeron architecture — v0.6.9

## Cognitive path

`environment -> IRG -> DKT retrieval/experience -> simultaneous stratified support -> regional EGR -> RL/Frenet -> DKT -> NativeProposition/NativeJudgment -> native utterance -> optional Terra`

## Language path

`surface utterance -> speaker/addressee perspective -> lexeme grounding -> DKT-linked proposition/query frame -> native proposition -> native realization`.

If direct composition is unsupported, DKT/RL memory reasoning remains the fallback. v0.6.9 preserves that geometric fallback rather than fabricating a proposition.

## Learning path

`canonical source / experience -> deterministic mathematical perception -> IRG -> DKT experience knot -> content-first Noeron semantic stratum -> local isotopy-component proxy -> compressed DKT deformation memory`.

Language lessons additionally form transparent DKT-linked proposition records. They are compositional audit structures over DKT semantic authority, not a return to the retired concept graph.

## Simultaneous activation path

A single event may activate multiple DKT/semantic support regions. v0.6.9 orders the finite active regions and records piecewise logical transitions with a Whitney/frontier compatibility proxy plus a path-coherence diagnostic. This is a `NOERON_EXTENSION`, not an exact smooth/Whitney theorem.

## Multimodal IRG

Vision/audio file observations are converted to deterministic low-level numerical observables and injected directly into IRG. Public web text, when owner-authorized and explicitly enabled, is admitted as untrusted environmental content with provenance.

## Control plane

Owner/operator authority is distinct from language/reference. A valid `X-Noeron-Owner-Token` grants the current deployment's privileged control role. Input text cannot confer that role, and `trusted:true` alone is not authentication.

## Defensive shell

Protected invariant mutations are rejected, quarantined, locally retracted to the last trusted checkpoint, and recorded as deformation families for future recognition. No external offensive retaliation exists.

## Boundaries

- DKT knot memory is authoritative memory/retrieval geometry.
- SQLite is serialization/provenance only.
- No concept graph or vector store has causal authority.
- Learned semantic strata remain distinct from manuscript DKT singularity strata.
- Vision/audio perception is low-level in v0.6.9.
- Web is direct public GET-only text perception, not autonomous browsing.
- Terra is optional surface rendering only.
- Computational affect/owner familiarity do not imply subjective feeling.
