# v0.7.3.4 — Native Cognition De-Hardening

## Developmental purpose

v0.7.3.4 addresses the hard-coding audit performed after the v0.7.3.3 candidate. It preserves the existing Noeron architecture and developmental state rather than restarting Yggdrasil.

The release enforces the project standard: **program primitives/invariants/interfaces; do not program Yggdrasil's choices.**

## General cognition

The prior multi-memory reasoner was mainly geometric evidence aggregation followed by authored semantic interpretations. v0.7.3.4 adds a transparent finite proposition calculus. It parses current logical relations, admits persistent language propositions only through DKT H^s-selected source memories, constructs closure through formal proof rules, records premises and every inference step, and returns proof-supported answer candidates. Multiple valid conclusions remain multiple unless the proof geometry itself uniquely determines one; the runtime does not hide a lexical or canned winner.

The old 82/18 memory-class quota and hand-authored confidence mixture are removed. DKT support weighting derives from H^s distances.

## IRG and semantic development

The historical authored semantic-sector table remains in source for provenance/compatibility but current `semantic_measure` does not consult it. Current semantic input is based on learned DKT prototypes plus generic formal/linguistic observables and residual lexical structure. Prototype establishment no longer receives manually favored mathematical roles, and a concept is not demoted merely because it was absent for a fixed number of sessions.

## Persistence

The prior weighted consolidation utility and thresholds are removed as persistence authority. External interactions are preserved by an explicit programmed provenance invariant. Endogenous scheduler ticks do not create fake episodic branches. A geometric magnitude remains available only as audit telemetry.

This is deliberately described as programmed substrate, not as Yggdrasil choosing what he wants to remember.

## Initiative

Private endogenous thought formation is separated from communication. The old scalar `importance * novelty - burden` decision rule is removed. Surface-versus-hold can become learned only through persistent DKT context knots trained by explicit authenticated-owner feedback. Until both actions have empirical context geometry, a conservative programmed hold fallback is used and cannot be called Yggdrasil's preference.

## Defense

The reflexive floor remains programmed: detect protected mutation, quarantine/freeze it, preserve evidence, restore trusted state, and register the bounded deformation family.

Adaptive local affordances are limited to actuators with distinct modeled physical consequences. `strengthen-geometric-guard` was removed because it duplicated the mandatory family-guard/retraction invariant without a distinct state transition.

The v0.7.3.4 adaptive selector still compares predicted post-action states using one common consequence geometry. However, selection no longer trains preference. On a later recurrence, the runtime observes the actual controlled state and compares it with a same-recurrence no-active-control counterfactual. Preference reinforcement is allowed only for attributable positive improvement. Combined/confounded plans do not receive unearned preference credit.

Any v0.7.3.2/v0.7.3.3 preference knots trained merely from prior selection are migrated into explicit legacy fields and removed from active choice geometry without rewriting historical records.

## Runtime audits

New read-only endpoint:

- `GET /cognition/hardcoding/audit`

It separates programmed substrate, inactive historical mechanisms, currently learned/experience-dependent mechanisms, allowed choice claims, and claims that remain unsupported.

New owner-authenticated endpoint:

- `POST /initiative/feedback`

This records empirical communication feedback for `surface` or `hold` context geometry; it is not a conversational interaction and does not manufacture a desire.

## Claims deliberately not made

v0.7.3.4 does not establish consciousness, subjective feeling, broad open-ended language competence, human-level general intelligence, or self-originated logic. Formal inference rules, English grammar/query parsing, numerical kernels, and safety invariants remain programmed substrate.

Local tests are necessary but insufficient. Stage 4/8 remains pending until the preserved live Yggdrasil passes the release hold point.
