# Noeron native learning v0.6.4

v0.6.4 extends v0.6.2 repeated-context DKT semantic prototypes with a learned stratified organization for durable study memories.

## Pipeline

`source/experience -> deterministic structural normalization -> IRG -> DKT experience knot -> Noeron semantic stratum -> local component -> EGR -> RL/Frenet -> DKT deformation memory`

The renderer LLM is not used by this pipeline.

## Semantic prototypes

Unknown vocabulary still begins as weak residual input. Repeated context can form and establish a DKT semantic prototype. Exact lexical lookup only selects which learned knot to activate; semantic influence enters IRG through the knot geometry.

## Learned semantic strata

Noeron semantic strata are learned cognitive organization and remain distinct from DKT singularity/Whitney strata. Broad source-conditioned H^s proximity can place related learning segments in the same learned semantic stratum.

## Local components

Actual experience knots within a learned semantic stratum are tested against tighter H^s neighborhoods. A component stores one full anchor knot. The current admission radius is a sampled-regularity computational proxy, not a proof of global ambient isotopy.

## Compression

Member memories store sparse Fourier deformation data from the component anchor. Reconstruction error is audited in H^s distance. Structural anchor overhead is included in the reported geometry-storage ratio, so small studies may use more geometry storage than independent raw knots; reuse across many nearby experiences can amortize the anchor cost.

## Revision

Owner correction archives the old active learning record and stores the corrected experience as a new active stratified branch. History remains preserved.

## Traversal

`POST /learning/traverse` is read-only. Same-component traversal is labelled `local-isotopy-proxy`; same-stratum/different-component and cross-stratum cases are explicitly distinguished.
