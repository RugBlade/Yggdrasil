# v0.6.6 changelog

- Added canonical source-lineage identities separate from study-session titles.
- Added provenance-only source-version SHA-256 identifiers; hashes never enter semantic geometry.
- Added 80% experience / 20% canonical-lineage semantic conditioning (NOERON_EXTENSION).
- Added deterministic lineage-aware semantic reclustering engine.
- Added read-only `/learning/recluster/preview`.
- Added digest-protected explicit `/learning/recluster/commit`.
- Old semantic strata/components are retired rather than deleted; learned memories retain stratification history.
- Added `stratification_epoch`; reasoning-born concept formation waits for an owner-committed lineage-aware recluster.
- Added `/learning/lineages` and per-lineage learning-rate diagnostics.
- Added dormant-low-evidence prototype hygiene after repeated missed sessions.
- Added further mathematical notation canonicalization (`hookrightarrow`, inequalities, unions/intersections, quantifiers, inf/sup, accents).
- Active APIs hide retired/dormant records by default while preserving inspection options.
- Existing DKT/IRG/EGR/RL/Frenet causal order, consolidation threshold, Terra renderer boundary, and multi-memory reasoning architecture remain intact.
