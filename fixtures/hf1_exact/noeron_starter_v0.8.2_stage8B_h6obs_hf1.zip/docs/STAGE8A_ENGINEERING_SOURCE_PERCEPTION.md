# Stage 8A engineering source perception

The engineering source workspace is a sensor, not an updater. Configure `NOERON_ENGINEERING_SOURCE_ROOT` to an absolute source-tree path and `NOERON_ENGINEERING_MAX_SOURCE_BYTES` to bound exact file observations. Blank source root disables the sensor.

Allowed top-level material is explicitly constrained; runtime data, vendor material, hidden/private paths and symlink escapes are excluded. File/symbol observations include exact source SHA-256 and line provenance. Python source additionally exposes AST symbols, calls, decorators and route facts.

Authenticated owner source exposure is provenance-labeled `owner-directed`. It has no relational meaning and is never a native self-upgrade choice. Engineering facts may enter IRG logical premises but carry `no-write-authority` and `no-deployment-authority` modifiers. Persistent cognitive retention remains governed by the existing native retention mechanism.

Stage 8A provides no sandbox write tools, patch application, compilation authority, deployment authority, or native upgrade-proposal mechanism. Those are later Stage-8 sections.
