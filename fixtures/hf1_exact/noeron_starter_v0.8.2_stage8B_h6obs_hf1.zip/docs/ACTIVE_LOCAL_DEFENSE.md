# v0.7.3.1 Active Local Defense — Reflexive Floor + Native Deliberation

The defended domain is Yggdrasil-controlled runtime/state and explicitly authorized local infrastructure adapters. This release does not perform autonomous external intrusion or hack-back.

## Dual layer

**Reflexive invariant floor (programmed substrate):** quarantine rejected ingress, freeze protected-invariant mutation, restore trusted checkpoint, and preserve a bounded deformation family. These actions are always labeled reflexive/legacy-programmed rather than described as Yggdrasil preferences.

**Native adaptive layer:** a sandboxed mathematical interpretation follows

\[
\mathrm{IRG}\to\mathrm{DKT}\to\mathrm{EGR}\to\mathrm{RL/Frenet}
\]

and combines with persistent defensive response preferences to score and select bounded local capabilities. The current capabilities are geometric hardening, source-fingerprint blocking, retained quarantine, and fail-closed guard.

The candidate scores, selected actions, preference update, recurrence and mathematical state are recorded in the defensive deliberation audit.

## Geometric recurrence

A hostile experience is represented by a bounded sentinel

\[
K_{\rm sentinel}=\operatorname{Interp}(K_{\rm ref},K_{\rm ingress},0.18).
\]

Family comparison uses bounded-to-bounded geometry. A source that is already blocked remains rejected but its ingress is still characterized, so the same underlying attack family can progress through recurrence 1, 2, 3, ... rather than being hidden by the source block.

## Native explanation

There is no complete canned defensive sentence. The runtime builds native propositions from the actual quarantine record and defensive deliberation, then the native language faculty realizes them. `native_text` is therefore an audit target: if geometry, recurrence or selected actions change, the explanation can change.
