# Noeron v0.8.0 — Stage 8A changelog

Stage 8A introduces authenticated, read-only perception of Yggdrasil's configured own-source tree. It adds exact source provenance, Python AST engineering facts, owner-only inspection routes, and an owner-directed source-observation route feeding the existing native mathematical path. It does not add code-write, patch, deployment, or native self-upgrade-choice authority.

Stage 7 remains live-certified and the roadmap remains 7/8 until all Stage-8 holdpoints complete.
