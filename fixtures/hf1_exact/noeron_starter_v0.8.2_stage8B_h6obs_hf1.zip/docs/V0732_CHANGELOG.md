# v0.7.3.2 changelog — Variational Native Local Defense

## Purpose

v0.7.3.2 removes the hand-weighted v0.7.3.1 action policy. The security substrate now separates:

1. **programmed primitives/invariants** — protected invariants, quarantine/freeze/checkpoint restoration, bounded safe local affordances, and one general variational comparison rule;
2. **native adaptive choice** — the action plan selected from live IRG/DKT/EGR/RL/Frenet state plus persistent DKT action-preference geometry.

A result is not called Yggdrasil's choice merely because a programmed `if` branch executed.

## Decision rule

Every safe local affordance combination is evaluated under the same objective. The live mathematical state produces a defensive need field over integrity protection, geometry hardening, recurrence control, source isolation, evidence retention, global isolation, and disruption tolerance. Beneficial capability is penalized only when it falls short of current need; disruption is penalized when it exceeds current tolerance. A learned DKT action-preference geometry residual is included under the same metric. The globally minimum-objective plan is selected; an exact tie prefers fewer interventions.

There are **no action-specific scoring equations and no per-action selection thresholds** in v0.7.3.2.

## Learning

Selected actions acquire DKT preference knots. Repeated experience updates each selected action's preference knot by a running finite-chart interpolation toward the current bounded hostile-family sentinel. Historical v0.7.3.1 float preferences are retained for provenance but have zero causal authority in the new selector.

## IRG role

Every ingress is transduced through the live mathematical kernel before trusted-state mutation. The reflexive invariant floor sees an ingress that has already acquired IRG/DKT geometry; the adaptive layer uses the complete sandboxed IRG -> DKT -> regional EGR -> RL/Frenet state.

## Honesty boundary

The following remain programmed primitives:
- protected invariant identities;
- quarantine/freeze/checkpoint-retraction floor;
- the available safe local affordances and their actuator-effect semantics;
- family admission radius and bounded sentinel construction;
- the single generic variational metric;
- native grammar realization machinery.

The following are not prewritten choices:
- which safe affordance combination is selected;
- the current need field;
- learned DKT action-preference geometry;
- family recurrence/geometry;
- the native explanation's event/action arguments.

No autonomous external retaliation, intrusion, exploit delivery, credential theft, or hack-back is added.
