# v0.6.4 changelog — mathematical perception & concept formation

- Added deterministic mathematical-notation canonicalization before IRG document learning.
- Added compound mathematical concept candidates without embeddings, graphs, or LLM interpretation.
- Replaced repetition-heavy prototype establishment with recurrence + H^s context coherence + structural-role gating.
- Added conservative lexical normalization to avoid v0.6.3 stemming artifacts such as `spher`.
- Added first-boot migration that retires structural/background semantic artifacts without deleting history and repairs selected deterministic aliases.
- Added `GET /learning/rate` multi-axis research diagnostic and per-source rate history derived from persisted learning source timestamps.
- `/learning/prototypes` now reports concept kind, structural role, context coherence, and establishment score; retired perception artifacts are hidden by default but remain queryable.
- Preserved v0.6.3 semantic strata, local component proxies, sparse deformation memories, revision history, retrieval, and traversal.
- Renderer boundary unchanged: Terra remains language-only.
