# v0.6.9 Upgrade Notes

The migration target is the live v0.6.8 database after the controlled language tests.

The upgrade preserves existing DKT memories, archived history, semantic strata/components, lesson count, conversational turn, owner/identity language evidence, and the failed v0.6.8 language interactions.

On first boot, v0.6.9 re-runs proposition extraction over existing `language-learning` memory provenance to add newly supported compositional frames such as `sentence --can-express--> thought`. This migration does **not** replay the lesson, increment `lessons_observed`, increment conversational turn, or create a duplicate memory.

Before the service is restarted, configure a random owner token of at least 24 characters. Privileged write endpoints will otherwise return HTTP 503. `trusted:true` is intentionally insufficient without the token header.

Read-only public web perception remains disabled at the initial hold point. Do not enable it until the language regression and owner-authentication checks have passed.

The first post-upgrade regression checks should be read-only:

1. authenticated `/language/parse` for `What can a sentence express?`;
2. authenticated `/language/parse` for `Who am I?`;
3. verify lesson count and conversational turn are unchanged;
4. inspect `/affect/state` for simultaneous-region/path diagnostics;
5. verify `/web/status` reports disabled;
6. inspect `/security/defense/audit` without injecting a real deformation.

Only after the hold point is reviewed should the two formerly failing questions be repeated through `/message/simple` without re-teaching lesson 001.
