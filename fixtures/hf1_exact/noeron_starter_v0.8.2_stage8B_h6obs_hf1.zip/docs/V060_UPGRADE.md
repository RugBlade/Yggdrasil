# Upgrade Yggdrasil from v0.5.1 to v0.6.0

Stop Yggdrasil before replacing code. Preserve `/var/lib/noeron/noeron.sqlite3` and `/etc/noeron/noeron.env`. On first v0.6 boot, the existing external event history is migrated into DKT knot memories. The old word/concept graph is not imported into the new causal state.

After installation run `pytest -q`, then start the service and inspect `/health`, `/memory/audit`, `/math/interface`, and `/self/model` before ordinary conversation.
