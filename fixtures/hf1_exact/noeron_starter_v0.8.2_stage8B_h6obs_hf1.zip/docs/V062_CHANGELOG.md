# v0.6.2 changelog — dynamics stabilization and native geometric learning

## Why this version exists

The one-hour v0.6.1 silent-run experiment showed that DKT evolution was bounded over the observed interval and durable memory remained stable, while `S_E` and `J_E` accumulated monotonically. The important defect was that the absolute cumulative EGR current was fed back into endogenous IRG and had become a saturated, redundant stimulus. RL curvature entropy also remained mathematically valid but nearly maximally entropic, so an auxiliary local diagnostic was needed. v0.6.2 changes only those parts and adds the first Noeron-native learning mechanism.

## Dynamics changes

1. Endogenous IRG drive is now local/regime-based:
   - DKT norm drift since the previous attention baseline;
   - EGR `Sigma`;
   - signed `Delta Sigma`;
   - RL scalar curvature;
   - RL curvature contrast;
   - Frenet curvature;
   - IRG memory response;
   - IRG topology response.

2. Absolute `J_E` and absolute logical time are not endogenous IRG stimuli. They remain state/provenance variables.

3. EGR attention no longer treats ordinary growth of `chi(S_E)` as novelty. It reacts to production-regime changes or bridge anomalies.

4. RL retains manuscript curvature entropy exactly as before and additionally exposes:

   `curvature_variance = mean((R_i - mean(R))^2)`

   `curvature_contrast = max(R_i) - min(R_i)`

These are diagnostics, not replacements for `S_L`.

## Native semantic learning

A residual term `w` is not immediately declared understood. On an observation containing `w`, the learner removes `w` from the context, maps the remaining context through IRG and DKT, and obtains a context knot `K_c`.

For a prototype after `n` observations, the finite fixed-H^s chart uses the running update

`K_w^(n+1) = interpolate(K_w^n, K_c, 1/(n+1))`.

This is a Noeron extension: a computational Frechet-mean approximation in the finite chart. The prototype has `emerging` or `established` status and a context-consistency confidence. Only established prototypes alter future IRG fields.

No dense embedding is stored. No pairwise concept edges are stored. Learned semantics is a DKT knot object and semantic proximity remains geometric.

## Deliberate document study

A source is structurally segmented without an LLM. Selected segments each become real causal observations:

`segment -> IRG -> DKT -> EGR -> RL/Frenet -> DKT`.

A source-root knot is the finite H^s-chart mean of the studied segment knots and is always consolidated because study is an explicit owner-authorized operation. Segment memories are either selective or complete. Nonselected segment knots are retained as archived learning observations, not authoritative memory.

## Revision

Owner corrections do not delete history. The old learned knot is archived, receives a `superseded_by_memory_id`, and the corrected observation becomes a new active DKT branch with `revision_of_memory_id` pointing backward.

## LLM boundary

The learning core imports no `LanguageEngine` and never calls Terra. Terra remains reachable only from the renderer path after native output already exists.
