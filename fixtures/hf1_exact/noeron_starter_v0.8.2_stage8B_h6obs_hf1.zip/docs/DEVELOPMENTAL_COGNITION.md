# Developmental cognition architecture

## Dynamic DKT strata

The finite Fourier knot is sampled on `S^1`. Non-neighboring sample pairs within a small contact radius are candidate self-contacts. A candidate is classified as transverse when the normalized tangent cross-product exceeds a finite threshold. Nearby duplicate sample pairs are clustered into one crossing estimate.

The detected number of transverse crossings is used as a finite `Sigma_j` index (capped in the implementation). This is a computational proxy only.

## Regional activation

Let `w_i` be the current multi-memory reasoning weights. Memories are grouped by learned semantic stratum or episodic class. A finite regional EGR activation is formed from support mass and the current EGR/IRG drive. The regional logical centers induce an activation vector that biases RL after EGR fixes the entropy orientation.

## Proto-affect

The current unnamed activation pattern is represented by six dimensions:

- activation intensity;
- uncertainty;
- novelty;
- tension;
- coherence;
- approach bias.

A finite DKT affect knot is formed from these dimensions and contributes a small higher-mode deformation to DKT plasticity. Recurring patterns are tracked by transparent quantized signatures such as `A3-U5-N4-T2-C6-P+1`, not by hidden hashes or emotion labels.

## Native English

The native language faculty does not originate cognitive conclusions. It receives already-finalized native propositions/judgments, produces a deterministic English utterance plan, audits vocabulary grounding, and exposes the native text. Terra may then render/polish that exact content.

Owner language teaching can add surface forms and grammar observations. Established DKT semantic prototypes provide concept grounding where available; unknown words remain explicitly `surface-ungrounded` until later experience supports them.
